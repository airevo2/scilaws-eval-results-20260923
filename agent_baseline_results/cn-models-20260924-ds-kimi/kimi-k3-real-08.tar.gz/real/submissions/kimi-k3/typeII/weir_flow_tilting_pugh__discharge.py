"""Power-law weir discharge Q = a * b * h^n, with per-cluster calibration of (a, n).

Sharp-crested weir flow follows Q ~ b * h^1.5 in the ideal case; for a tilted
weir plate the effective discharge coefficient and head exponent shift slightly,
so each cluster (fixed tilt/geometry) is fit with its own (a, n). The form is
monotone in h, vanishes at h=0, scales linearly with crest width b, and stays
physically sensible under extrapolation.
"""
import numpy as np
from scipy.optimize import curve_fit

USED_INPUTS = ["h_m", "p_m", "b_m"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {"a": {"init": None}, "n": {"init": None}}

def fit(X_fit, y_fit):
    h = np.asarray(X_fit[:, 0], dtype=float)
    b = np.asarray(X_fit[:, 2], dtype=float)
    y = np.asarray(y_fit, dtype=float)
    h = np.maximum(h, 1e-6)

    def f(hv, a, n):
        return a * b * np.power(hv, n)

    # Data-driven initial guesses from a log-log regression (robust fallback too).
    a0, n0 = 2.5, 1.55
    try:
        mask = (y > 0) & (b > 0)
        if mask.sum() >= 2:
            slope, intercept = np.polyfit(np.log(h[mask]), np.log(y[mask] / b[mask]), 1)
            n0 = float(np.clip(slope, 1.0, 2.5))
            a0 = float(np.clip(np.exp(intercept), 0.5, 10.0))
    except Exception:
        pass

    try:
        popt, _ = curve_fit(f, h, y, p0=[a0, n0], maxfev=5000)
        a_hat = float(np.clip(popt[0], 1e-3, 50.0))
        n_hat = float(np.clip(popt[1], 0.5, 4.0))
        if not (np.isfinite(a_hat) and np.isfinite(n_hat)):
            raise ValueError
    except Exception:
        a_hat, n_hat = a0, n0
    return {"a": a_hat, "n": n_hat}

def predict(X, a, n):
    h = np.maximum(np.asarray(X[:, 0], dtype=float), 0.0)
    b = np.asarray(X[:, 2], dtype=float)
    return a * b * np.power(h, n)