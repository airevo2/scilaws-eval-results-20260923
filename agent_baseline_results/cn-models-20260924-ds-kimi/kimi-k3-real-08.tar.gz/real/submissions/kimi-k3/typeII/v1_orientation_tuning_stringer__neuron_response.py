"""Circular-Gaussian orientation tuning curve (V1): R(theta) = b + A * exp(-0.5 * (d180(theta, mu) / sigma)^2), fit per neuron with a gentle log-prior pulling sigma toward 15 deg for stability on small fit windows."""
import numpy as np
from scipy.optimize import least_squares

USED_INPUTS = ["orientation_deg"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {
    "b":   {"init": None},
    "A":   {"init": None},
    "mu":  {"init": None},
    "sig": {"init": None},
}

def _model(theta, b, A, mu, sig):
    d = (np.asarray(theta, dtype=float) - mu + 90.0) % 180.0 - 90.0
    sig = max(float(sig), 1e-3)
    return b + A * np.exp(-0.5 * (d / sig) ** 2)

def fit(X_fit, y_fit):
    th = np.asarray(X_fit[:, 0], dtype=float)
    yy = np.asarray(y_fit, dtype=float)
    b0 = float(max(np.min(yy), 0.0))
    A0 = float(max(np.max(yy) - np.min(yy), 1e-3))
    mu0 = float(th[int(np.argmax(yy))])

    def resid(p):
        r = _model(th, *p) - yy
        # gentle data-anchored log-prior on the width (~15 deg)
        return np.concatenate([r, [2.0 * np.log(p[3] / 15.0)]])

    best, best_cost = None, np.inf
    for s0 in (8.0, 15.0, 30.0):
        try:
            out = least_squares(
                resid, [b0, A0, mu0, s0],
                bounds=([0.0, 0.0, -180.0, 3.0],
                        [np.inf, np.inf, 360.0, 80.0]),
                max_nfev=800,
            )
            c = float(np.sum((yy - _model(th, *out.x)) ** 2))
            if c < best_cost:
                best_cost, best = c, out.x
        except Exception:
            pass
    if best is None:
        best = np.array([b0, A0, mu0, 15.0])
    return {"b": float(best[0]), "A": float(best[1]),
            "mu": float(best[2]), "sig": float(best[3])}

def predict(X, b, A, mu, sig):
    return _model(X[:, 0], b, A, mu, sig)