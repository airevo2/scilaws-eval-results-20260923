"""Pipe-model allometry: A_L = k * A_S^alpha * H^beta, fit per cluster as a
log10-intercept k (LOCAL_FITTABLE). The two exponents are universal
LAW_CONSTANTS shared by all clusters; they were estimated once on the pooled
training clusters by minimizing log10 absolute error with per-cluster
intercepts absorbed (alpha ~ 1.28 close to the theoretical pipe-model value 1,
beta ~ -0.85 reflecting declining leaf-area:sapwood ratio with height).
The form is a pure power law, so it extrapolates monotonically and stays
physically sensible (positive, smooth) outside the observed input range.
Only k varies between clusters, capturing species/site leaf-area differences.
"""
import numpy as np

USED_INPUTS = ["a_ssbh", "h_t"]
LAW_CONSTANTS = {"alpha": 1.28, "beta": -0.85}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {"k": {"init": None}}

_EPS = 1e-12

def _base_log10(X):
    As = np.maximum(np.asarray(X[:, 0], dtype=float), _EPS)
    H = np.maximum(np.asarray(X[:, 1], dtype=float), _EPS)
    return LAW_CONSTANTS["alpha"] * np.log10(As) + LAW_CONSTANTS["beta"] * np.log10(H)

def fit(X_fit, y_fit):
    y = np.maximum(np.asarray(y_fit, dtype=float), _EPS)
    resid = np.log10(y) - _base_log10(X_fit)
    # per-cluster multiplicative offset (log10 intercept); median is robust
    k = float(np.median(resid))
    if not np.isfinite(k):
        k = 0.0
    return {"k": k}

def predict(X, k):
    logA = _base_log10(X) + float(k)
    logA = np.clip(logA, -12.0, 12.0)
    return np.power(10.0, logA)