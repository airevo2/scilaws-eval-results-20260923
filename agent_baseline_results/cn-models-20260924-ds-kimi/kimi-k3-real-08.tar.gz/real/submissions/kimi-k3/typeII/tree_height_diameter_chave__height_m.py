"""Pantropical height-diameter allometry: H = h0 + a*(1-exp(-b*D))^c (offset Chapman-Richards). h0,b,c are universal constants; only the asymptote scale a is re-fit per cluster by least squares."""
import numpy as np

USED_INPUTS = ["DBH_cm"]

LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}

# Universal constants fitted on the full training set (shared by ALL clusters).
_H0 = 1.82477   # intercept offset (m)
_B  = 0.01810   # rate constant (per cm)
_C  = 0.77412   # shape exponent

LOCAL_FITTABLE = {"a": {"init": 39.0}}

def _shape(D):
    Dc = np.maximum(np.asarray(D, dtype=float), 1e-9)
    return (1.0 - np.exp(-_B * Dc)) ** _C

def fit(X_fit, y_fit):
    # Least-squares estimate of the per-cluster scale a for H - h0 = a*shape(D).
    d = np.asarray(X_fit[:, 0], dtype=float)
    y = np.asarray(y_fit, dtype=float)
    f = _shape(d)
    sff = float(np.sum(f * f))
    if sff > 1e-12:
        a = float(np.sum((y - _H0) * f) / sff)
    else:
        a = 39.0
    if not np.isfinite(a) or a <= 0.0:
        a = 39.0
    return {"a": a}

def predict(X, a):
    d = np.asarray(X[:, 0], dtype=float)
    return _H0 + a * _shape(d)