"""Urban scaling (Bettencourt): log_GMP = a + b*log_pop. Universal superlinear
slope b≈1.10 shared by all clusters; per-cluster intercept a captures the
cluster/year productivity level. Fixed slope + per-cluster intercept is far more
robust to small or extrapolating fit windows than a free per-cluster slope."""
import numpy as np

USED_INPUTS = ["log_pop"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {"a": {"init": None}}

def fit(X_fit, y_fit):
    # Fixed universal slope (Bettencourt scaling exponent); per-cluster intercept.
    b = 1.0994
    x = X_fit[:, 0]
    a = float(np.mean(y_fit - b * x))
    return {"a": a}

def predict(X, a):
    b = 1.0994
    return a + b * X[:, 0]