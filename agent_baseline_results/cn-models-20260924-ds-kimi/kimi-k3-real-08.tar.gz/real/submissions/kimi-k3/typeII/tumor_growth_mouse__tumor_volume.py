"""Gompertz tumor-growth law, fit per animal.

V(t) = K * exp(-A * exp(-b*t)) with a universal decay-rate constant
b = 0.11 /day (shared by every cluster; the Gompertz rate constant is the
canonical, near-universal parameter in the xenograft literature). Per cluster
(animal) we fit only the carrying capacity K and the dimensionless lag/growth
parameter A = ln(K / V(0)).

This form is monotone increasing, bounded above by K, and stays finite and
sensible when extrapolated beyond the observed time range.
"""
import numpy as np
from scipy.optimize import curve_fit

USED_INPUTS = ["time_day"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {"b": 0.11}          # universal Gompertz decay rate (1/day), not fitted per cluster
LOCAL_FITTABLE = {"K": {"init": None}, "A": {"init": None}}

_B = OTHER_CONSTANTS["b"]

def _form(t, K, A):
    return K * np.exp(-A * np.exp(-_B * t))

def fit(X_fit, y_fit):
    t = np.asarray(X_fit[:, 0], dtype=float)
    y = np.asarray(y_fit, dtype=float)
    ymax = float(np.max(y)) if y.size else 100.0
    fallback = {"K": max(2.0 * ymax, 1.0), "A": 3.0}
    best = None
    starts = [
        (1.5 * ymax, 3.0), (2.0 * ymax, 4.0), (1.2 * ymax, 2.0),
        (3.0 * ymax, 6.0), (1.1 * ymax, 1.5),
    ]
    for p0 in starts:
        try:
            popt, _ = curve_fit(_form, t, y, p0=p0, maxfev=4000,
                                bounds=([1.0, 0.05], [1.0e5, 300.0]))
            ss = float(np.sum((y - _form(t, *popt)) ** 2))
            if best is None or ss < best[0]:
                best = (ss, popt)
        except Exception:
            continue
    if best is None:
        return fallback
    K, A = float(best[1][0]), float(best[1][1])
    if not (np.isfinite(K) and np.isfinite(A)) or K <= 0 or A <= 0:
        return fallback
    return {"K": K, "A": A}

def predict(X, K, A):
    t = np.asarray(X[:, 0], dtype=float)
    # clip the exponent argument to avoid overflow for extreme extrapolation
    z = np.clip(-A * np.exp(-_B * t), -700.0, 0.0)
    y = K * np.exp(z)
    return np.clip(np.nan_to_num(y, nan=0.0, posinf=1.0e6, neginf=0.0), 0.0, 1.0e6)