"""Peters (1964) GR quadrupole orbital-period decay for a binary pulsar.

PBDOT = -(192*pi/5) * (2*pi*G*M_sun/Pb_s)^(5/3) * (1/c^3) * (m1*m2/(m1+m2)^(1/3)) * F(e),
with F(e) = (1 + 73 e^2/24 + 37 e^4/96) / (1 - e^2)^(7/2), Pb_s = Pb days in seconds.
Fitted constants (chirp mass combination) baked in; calibrated on the GR-dominated
small-period regime of the simulator."""
import numpy as np

USED_INPUTS = ["Pb", "e"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    Pb = X[:, 0]
    e = X[:, 1]
    Pb_s = Pb * 86400.0
    e2 = e * e
    F = (1.0 + (73.0/24.0)*e2 + (37.0/96.0)*e2*e2) / np.power(1.0 - e2, 3.5)
    return -4.700141854943602e-06 * np.power(Pb_s, -5.0/3.0) * F