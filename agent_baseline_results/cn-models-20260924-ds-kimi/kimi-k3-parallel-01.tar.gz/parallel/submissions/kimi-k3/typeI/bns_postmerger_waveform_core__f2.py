"""Post-merger BNS peak GW frequency: Takami/Rezzolla-type universal relation.
f2 = (a + b * kap2t**c) / M, with fitted constants from NR-like experiments.
Mass-ratio dependence is negligible (verified experimentally), consistent with
the standard M, kappa_2^T-only form. Fitted: a=-1.4601, b=35.2922, c=-0.2801.
"""
import numpy as np

USED_INPUTS = ["mass", "kap2t", "m1", "m2"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    M = X[:, 0]
    kap = X[:, 1]
    a = -1.46014844
    b = 35.2922348
    c = -0.28010235
    return (a + b * np.power(kap, c)) / M