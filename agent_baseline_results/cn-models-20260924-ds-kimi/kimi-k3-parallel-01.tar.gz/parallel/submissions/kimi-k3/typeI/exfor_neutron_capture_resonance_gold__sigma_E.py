"""Au-197(n,gamma): single Lorentzian (Breit-Wigner-shaped) resonance at Er~4.87 eV
plus a steep background power law ~ E^-0.7, combined additively in sigma (barns);
target is log10 of the sum."""
import numpy as np

USED_INPUTS = ["E_eV"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    E = X[:, 0]
    bw = 149.26 / ((E - 4.874)**2 + (0.14519/2.0)**2)
    bg = 5.314 * E**-0.7
    return np.log10(bw + bg)