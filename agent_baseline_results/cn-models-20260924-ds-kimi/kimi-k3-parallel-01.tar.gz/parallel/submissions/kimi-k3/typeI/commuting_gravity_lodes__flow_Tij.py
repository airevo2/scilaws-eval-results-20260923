"""Radiation-model commuting flow: mean T = a*m_i*m_j/(m_j+s_ij), returned as log10(T+1)."""
import numpy as np

USED_INPUTS = ["m_i", "m_j", "s_ij"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    m_i = X[:, 0]
    m_j = X[:, 1]
    s_ij = X[:, 2]
    a = 0.06
    T = a * m_i * m_j / (m_j + s_ij)
    return np.log10(T + 1.0)