"""Mass-averaged dynamical-ejecta velocity: additive form, linear in (q-1) plus a
q-modulated power law in reduced tidal deformability Lambda_tilde.
vej = a + b*(q-1) + (c + d*(q-1)) * (Lambda_tilde/L0)^(-n), with n ~ 1/2."""
import numpy as np

USED_INPUTS = ["q", "Lambda_tilde"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    q = X[:, 0]
    L = X[:, 1]
    a = 0.180131
    b = -0.063762
    c = 0.053653
    d = -0.007595
    L0 = 333.74532
    n = 0.549245
    return a + b * (q - 1.0) + (c + d * (q - 1.0)) * (L / L0) ** (-n)