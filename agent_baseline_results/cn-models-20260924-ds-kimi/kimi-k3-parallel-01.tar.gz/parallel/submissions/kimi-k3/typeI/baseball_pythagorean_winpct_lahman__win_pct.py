"""Pythagenport win percentage: Pythagorean expectation with exponent
x = 1.5*log10((R+RA)/G) + 0.45, i.e. W% = R^x / (R^x + RA^x).

Evidence from experiments: (1) per-game Poisson game simulation is rejected
(it over-predicts extreme win% and implies strong G-dependence that is absent);
(2) win% depends on total runs, not just R/RA — at fixed ratio 1.25 (G=162),
win% rose 0.5908 -> 0.5964 -> 0.6068 (n=36 each) as R+RA went 990 -> 1188 -> 1584;
(3) implied exponents at those points (1.643, 1.752, 1.946) match
1.5*log10((R+RA)/G)+0.45 almost exactly (slope 1.485, intercept ~0.46);
(4) replicate variance matches Binomial(G, p) noise, so the deterministic mean
is the Pythagenport formula; the R=800/RA=600 series across G=52..162 is
consistent with the (R+RA)/G runs-per-game dependence once binomial noise is
accounted for."""
import numpy as np

USED_INPUTS = ["R", "RA", "G"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    R = X[:, 0]
    RA = X[:, 1]
    G = X[:, 2]
    x = 1.5 * np.log10((R + RA) / G) + 0.45
    Rx = np.power(R, x)
    RAx = np.power(RA, x)
    return Rx / (Rx + RAx)