"""Budyko-type runoff: Q = P * exp(-a*(Ep/P)^b), a Weibull survival curve in the
dryness index phi=Ep/P, fitted from simulator experiments (a=1.4042, b=1.5925)."""
import numpy as np

USED_INPUTS = ["p_mean", "pet_mean"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    P = X[:, 0]
    Ep = X[:, 1]
    phi = Ep / np.maximum(P, 1e-9)
    return P * np.exp(-1.4042 * phi ** 1.5925)