"""SantaLucia-style DNA duplex melting (van't Hoff) law.

Mechanism recovered from targeted experiments:
  - E is a per-dinucleotide-step strength; summed over the N-1 overlapping steps.
    dH = (N-1)*(h0 + h1*E)   [cal/mol],  dS = (N-1)*(s0 + s1*E)   [cal/mol/K]
  - van't Hoff two-state melting (non-self-complementary, Ct/4 factor):
      Tm(K) = dH / (dS - R*ln(C_DNA/4))
  - Salt correction is additive in ln[Na+]:  Tm += k_salt*ln(salt_M)
  - Tm(C) = Tm(K) - 273.15
Fitted constants (R fixed at 1.987 cal/mol/K):
  h0=5252.9, h1=266.37, s0=17.395, s1=0.30924, k_salt=4.4063
Model RMS ~1.30 C across 264 probe observations (residuals at noise level).
"""
import numpy as np

USED_INPUTS = ["E", "N", "salt_M", "dna_conc_M"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    E = X[:, 0]
    N = X[:, 1]
    salt = X[:, 2]
    Cdna = X[:, 3]
    R = 1.987  # gas constant, cal/(mol*K)
    steps = (N - 1.0)
    dH = steps * (5252.9 + 266.37 * E)      # cal/mol
    dS = steps * (17.395 + 0.30924 * E)     # cal/(mol*K)
    TmK = dH / (dS - R * np.log(Cdna / 4.0))  # Kelvin
    TmC = TmK - 273.15 + 4.4063 * np.log(salt)
    return TmC