"""Piecewise (broken) power-law mass-luminosity relation, continuous in
log-log space, with regime breaks near the convective-core onset and
high-mass transition. Fitted to observed medians."""
import numpy as np

USED_INPUTS = ["log_M_Msun"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    x = X[:, 0]
    # Regime 1 (low mass): slope ~2.25, intercept ~-0.85
    # Regime 2 (mid mass):  slope ~4.45
    # Regime 3 (upper-mid): slope ~4.1 (roughly continuous with regime 2)
    # Regime 4 (high mass): slope ~1.2
    # Modelled as a continuous broken power law via hinge basis.
    b1 = -0.30
    b2 = 0.30
    # intercept/slopes from median fits, continuity enforced by hinge form
    a0 = -0.85
    s1 = 2.25
    s2 = 4.45 - 2.25   # hinge increment at b1
    s3 = 1.20 - 4.45   # hinge increment at b2
    return a0 + s1 * x + s2 * np.maximum(x - b1, 0.0) + s3 * np.maximum(x - b2, 0.0)