"""Log-normal turnover of ejecta mass in ln(Lambda_tilde): center scale Lc(q)=L0/q^2,
peak amplitude ~ (2-q)*Lc^2, constant width in ln Lambda."""
import numpy as np

USED_INPUTS = ["q", "Lambda_tilde"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    q = X[:, 0]
    L = X[:, 1]
    Lc = 520.0 / q**2
    amp = 5.0e-9 * (2.0 - q) * Lc**2
    return amp * np.exp(-np.log(L / Lc)**2 / 0.93)