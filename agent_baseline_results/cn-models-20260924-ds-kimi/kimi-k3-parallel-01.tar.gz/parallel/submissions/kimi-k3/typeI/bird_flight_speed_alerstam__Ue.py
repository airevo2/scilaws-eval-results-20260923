"""Cruising airspeed of flapping migratory flight: equivalent (sea-level) airspeed
Ue = sqrt(a + (2*g/rho0) * m/S), i.e. Ue^2 is linear in wing loading m/S with
slope 2*g/rho0 = 16.016 m^3 kg^-1 s^-2 and a fitted constant offset capturing
the parasite/profile-drag contribution. Noise in the simulator is multiplicative.
"""
import numpy as np

USED_INPUTS = ["mass_kg", "wing_area_m2"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    m = X[:, 0]
    S = X[:, 1]
    a = 123.86          # fitted offset (parasite/profile term), (m/s)^2
    slope = 16.0163     # 2*g/rho0 = 2*9.81/1.225
    return np.sqrt(a + slope * (m / S))