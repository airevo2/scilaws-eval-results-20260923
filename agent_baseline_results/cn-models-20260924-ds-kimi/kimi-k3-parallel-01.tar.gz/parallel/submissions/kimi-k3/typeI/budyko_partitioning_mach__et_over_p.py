"""Budyko-framework evaporative fraction. Best fit: E/P = 1 - exp(-a * phi^b) (generalized Schreiber), which respects both limits: E/P ~ a*phi for small aridity (energy-limited, F->0) and E/P -> 1 for large aridity (water-limited). Fitted a=1.07, b=1.08 on 400+ observations; outperforms classic Schreiber/Turc/Fu/Zhang forms."""
import numpy as np

USED_INPUTS = ["pet_over_p"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    phi = X[:, 0]
    return 1.0 - np.exp(-1.07 * np.power(phi, 1.08))