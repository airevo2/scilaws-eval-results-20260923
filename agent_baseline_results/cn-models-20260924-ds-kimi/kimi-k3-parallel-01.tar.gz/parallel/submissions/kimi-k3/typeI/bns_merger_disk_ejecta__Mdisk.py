"""Disk mass as complementary-error-function (sigmoid) of compactness C1."""
import numpy as np
from scipy.special import erfc

USED_INPUTS = ["C1"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    C1 = X[:, 0]
    A = 0.105739
    mu = 0.155284
    sig = 0.016208
    return A * erfc((C1 - mu) / sig)