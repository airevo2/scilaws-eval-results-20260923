"""Isolation by distance: M_stat follows a sublinear power law in great-circle distance, M = a * d^b, fitted on the high-SNR regime (weighted log-log fit of binned means gives a ~ 6.34e-4, b ~ 0.589)."""
import numpy as np

USED_INPUTS = ["distance_km"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    d = np.asarray(X[:, 0], dtype=float)
    return 0.000634 * np.power(d, 0.589)