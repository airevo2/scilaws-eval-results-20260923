"""Cepheid Gaia Wesenheit PLZ relation: M_W linear in log_P plus a quadratic (saturating) metallicity term.

Across 270 simulator observations spanning log_P in [0.49, 1.653] and [Fe/H] in [-0.18, 0.33]:
the period dependence is purely linear in log_P (no break: hinge and log_P^2 terms have t ~ 0),
while the metallicity dependence requires a positive [Fe/H]^2 curvature term (t ~ 4.7, AIC favored
by ~20 points over linear-in-feh), i.e. M_W = alpha + beta*log_P + gamma*[Fe/H] + delta*[Fe/H]^2.
The period-metallicity interaction was marginal and inconsistent across periods, so it is omitted.
Constants were fitted by OLS on all 270 collected rows.
"""
import numpy as np

USED_INPUTS = ["log_P", "feh"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    log_P = X[:, 0]
    feh = X[:, 1]
    return -2.86961 - 3.24184 * log_P - 0.52834 * feh + 2.72714 * feh**2