"""Sub-grid cloud fraction driven primarily by relative humidity (RH),
increasing toward 1 as RH approaches saturation, with a correction for the
vertical RH gradient (dz_RH): strong negative dRH/dz suppresses cloud.
Fitted to the monotonic RH response observed in experiments (C ~ 0.2 at
RH=0.3 rising to ~1.1 near RH=1)."""
import numpy as np

USED_INPUTS = ["q_c", "q_i", "RH", "T", "dz_RH"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    q_c = X[:, 0]
    q_i = X[:, 1]
    RH = X[:, 2]
    T = X[:, 3]
    dz_RH = X[:, 4]
    # Logistic-in-RH response centered near RH~0.55, saturating near 1,
    # plus a linear suppression from negative vertical RH gradient.
    base = 1.10 / (1.0 + np.exp(-(RH - 0.55) / 0.12))
    grad = 380.0 * (dz_RH + 0.001)
    y = base + grad
    return y