"""Geiger–Nuttall law per cluster: log10(T_1/2) = a + b/sqrt(Q_alpha).
Per-cluster intercept a and slope b, with the slope shrunk toward the
universal Geiger–Nuttall value B0 for stability on tiny fit windows.
Monotone decreasing in Q_alpha and physically sensible on extrapolation.
LAW_CONSTANTS/OTHER_CONSTANTS left empty (B0 is a fixed shrinkage prior
used only inside fit(), not a free fitted constant).
"""
import numpy as np

USED_INPUTS = ["Q_alpha_MeV"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {"a": {"init": None}, "b": {"init": None}}

_B0 = 131.79588738774925   # universal Geiger–Nuttall slope prior
_LAM = 0.001               # slope shrinkage strength

def fit(X_fit, y_fit):
    Q = np.asarray(X_fit[:, 0], dtype=float)
    y = np.asarray(y_fit, dtype=float)
    x = 1.0 / np.sqrt(np.maximum(Q, 1e-9))
    if Q.size == 0:
        return {"a": 0.0, "b": _B0}
    if Q.size == 1:
        return {"a": float(y[0] - _B0 * x[0]), "b": _B0}
    xm = float(np.mean(x)); ym = float(np.mean(y))
    denom = float(np.sum((x - xm) ** 2)) + _LAM
    b = (float(np.sum((x - xm) * (y - ym))) + _LAM * _B0) / denom
    a = ym - b * xm
    return {"a": float(a), "b": float(b)}

def predict(X, a, b):
    Q = np.asarray(X[:, 0], dtype=float)
    return a + b / np.sqrt(np.maximum(Q, 1e-9))