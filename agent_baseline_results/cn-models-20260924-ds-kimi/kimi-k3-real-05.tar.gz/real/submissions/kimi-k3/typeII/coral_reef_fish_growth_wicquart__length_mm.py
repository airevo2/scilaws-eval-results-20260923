"""Richards generalized growth curve L(age) = Linf*(1-exp(-K*age))^(1/d), with per-cluster Linf, K, d refit by bounded multi-start least squares. Reduces to von Bertalanffy when d=1; passes through L(0)=0 and saturates at Linf, so it stays physically sensible when extrapolated."""
import numpy as np
from scipy.optimize import curve_fit

USED_INPUTS = ["Agei"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {"Linf": {"init": None}, "K": {"init": None}, "d": {"init": None}}

def _rich(t, Linf, K, d):
    t = np.maximum(np.asarray(t, dtype=float), 0.0)
    d = np.maximum(d, 1e-4)
    return Linf * (1.0 - np.exp(-K * t)) ** (1.0 / d)

def fit(X_fit, y_fit):
    t = np.asarray(X_fit[:, 0], dtype=float)
    y = np.asarray(y_fit, dtype=float)
    ymax = float(np.max(y))
    ystd = float(np.std(y)) if len(y) > 1 else 0.0
    gm = max(ymax * 1.3, ymax + ystd, 5.0)
    lb = [max(ymax * 0.9, 1.0), 1e-3, 0.1]
    ub = [max(ymax * 12.0, 50.0), 3.0, 12.0]
    best, bl = None, np.inf
    for K in (0.06, 0.25, 0.7):
        for d in (0.5, 1.5, 4.0):
            p0 = np.clip([gm, K, d], lb, ub)
            try:
                popt, _ = curve_fit(_rich, t, y, p0=p0, bounds=(lb, ub), maxfev=20000)
                loss = float(np.sum((_rich(t, *popt) - y) ** 2))
                if np.all(np.isfinite(popt)) and loss < bl:
                    bl, best = loss, popt
            except Exception:
                pass
    if best is None:
        best = np.array([max(ymax * 1.5, 10.0), 0.3, 1.0])
    return {"Linf": float(best[0]), "K": float(best[1]), "d": float(best[2])}

def predict(X, Linf, K, d):
    t = np.asarray(X[:, 0], dtype=float)
    return np.clip(_rich(t, Linf, K, d), 0.0, np.inf)