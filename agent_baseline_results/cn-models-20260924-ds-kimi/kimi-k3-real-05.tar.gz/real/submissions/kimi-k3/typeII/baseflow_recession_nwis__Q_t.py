"""Baseflow recession: Q(t) = Q0 / (1 + k0 * Q0^gamma * t).
Boussinesq-type (beta=2) recession where the recession rate scales as a
power of the event's initial discharge (higher flows drain faster).
Per-cluster params: k0 (rate coefficient), gamma (Q0-scaling exponent)."""
import numpy as np
from scipy.optimize import least_squares

USED_INPUTS = ["t", "Q_0"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {"k0": {"init": None}, "gamma": {"init": None}}

def _form(t, q0, k0, gamma):
    q0s = np.maximum(q0, 1e-9)
    c = k0 * np.power(q0s, gamma)
    return q0 / (1.0 + c * t)

def fit(X_fit, y_fit):
    t = X_fit[:, 0].astype(float)
    q0 = X_fit[:, 1].astype(float)
    y = np.asarray(y_fit, dtype=float)
    def resid(p):
        return _form(t, q0, p[0], p[1]) - y
    starts = [(0.1, 0.2), (0.05, 0.0), (0.02, 0.5), (0.3, -0.2),
              (0.01, 0.3), (0.5, 0.1), (0.001, 0.8)]
    best = None
    for p0 in starts:
        try:
            res = least_squares(resid, p0, bounds=([1e-7, -2.0], [50.0, 2.0]),
                                max_nfev=4000)
            if best is None or res.cost < best.cost:
                best = res
        except Exception:
            pass
    if best is None or not np.all(np.isfinite(best.x)):
        return {"k0": 0.05, "gamma": 0.2}
    return {"k0": float(best.x[0]), "gamma": float(best.x[1])}

def predict(X, k0, gamma):
    t = X[:, 0].astype(float)
    q0 = X[:, 1].astype(float)
    k0 = float(np.clip(k0, 1e-7, 50.0))
    gamma = float(np.clip(gamma, -2.0, 2.0))
    yp = _form(t, q0, k0, gamma)
    yp = np.where(np.isfinite(yp) & (yp >= 0.0), yp, np.maximum(q0, 0.0))
    return yp