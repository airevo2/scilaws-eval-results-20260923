"""Rydberg-Ritz binding energy: E = R/(n - delta)^2 with delta(n) = d0 + d2/(n-d0)^2 + d4/(n-d0)^4.
The three quantum-defect coefficients (d0,d2,d4) are re-fit per cluster (element/series)."""
import numpy as np
from scipy.optimize import least_squares

USED_INPUTS = ["n_qm", "l_qm"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {"R_inf_cm1": 109737.3157}
LOCAL_FITTABLE = {"d0": {"init": None}, "d2": {"init": None}, "d4": {"init": None}}

_R = 109737.3157

def _form(n, d0, d2, d4):
    x = n - d0
    return _R / (x - d2/x**2 - d4/x**4)**2

def _ls(n, E, p0, bounds):
    def rf(p):
        return (_form(n, *p) - E)/E
    return least_squares(rf, p0, method='trf', bounds=bounds, max_nfev=1500).x

def fit(X_fit, y_fit):
    n = X_fit[:, 0].astype(float)
    E = np.asarray(y_fit, dtype=float)
    # data-driven initial quantum defect
    d = n - np.sqrt(_R/E)
    d0i = float(np.median(d))
    cands = [np.array([d0i, 0.0, 0.0])]
    # two-parameter candidates (d4 fixed to 0)
    for s in ([d0i, 0.0], [0.9, 0.1], [1.3, 0.1], [2.5, 0.2], [3.5, 0.2]):
        try:
            p = _ls(n, E, [s[0], s[1], 0.0], ([0.0, -300., 0.0], [6.0, 300., 0.0]))
            cands.append(np.array([p[0], p[1], 0.0]))
        except Exception:
            pass
    # three-parameter candidates
    for s in ([d0i, 0.0, 0.0], [0.9, 0.1, 0.05], [1.3, 0.1, 0.0],
              [2.5, 0.2, 0.0], [3.5, 0.2, 0.0], [0.01, 0.0, 0.0]):
        try:
            p = _ls(n, E, list(s), ([0.0, -300., -2e5], [6.0, 300., 2e5]))
            cands.append(p)
        except Exception:
            pass
    best = None
    for p in cands:
        r = np.sqrt(np.mean((_form(n, *p) - E)**2))/np.mean(E)
        # parsimony penalty prefers stable small high-order coefficients
        score = r*(1.0 + 0.05*abs(p[1]) + 0.002*abs(p[2]))
        if best is None or score < best[0]:
            best = (score, p)
    p = best[1] if best is not None else np.array([d0i, 0.0, 0.0])
    return {"d0": float(p[0]), "d2": float(p[1]), "d4": float(p[2])}

def predict(X, d0, d2, d4):
    n = X[:, 0].astype(float)
    x = n - d0
    y = _R / (x - d2/x**2 - d4/x**4)**2
    return np.asarray(y, dtype=float)