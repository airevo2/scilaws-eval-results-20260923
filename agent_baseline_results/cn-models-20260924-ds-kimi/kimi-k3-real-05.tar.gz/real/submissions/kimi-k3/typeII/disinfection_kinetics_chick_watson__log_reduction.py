"""Hom-type disinfection law, shared across all clusters:

    LRV(CT) = log10(1 + a * CT^b)

This generalises the classical Chick-Watson / Hom model: the surviving fraction
follows N/N0 = 1/(1 + a*CT^b), so the log10 reduction is log10(1 + a*CT^b).
It is 0 at CT=0, monotone increasing, concave in log-CT (shoulder-to-linear
inactivation curve), and stays finite and physically sensible when extrapolated
to very large CT. The two parameters (a = inactivation-rate coefficient,
b = dose exponent) are re-fit per cluster; all clusters share the same form.
"""
import numpy as np
from scipy.optimize import least_squares

USED_INPUTS = ["CT"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {"a": {"init": None}, "b": {"init": None}}

def _form(x, a, b):
    return np.log10(1.0 + a * np.power(np.clip(x, 1e-12, None), b))

def fit(X_fit, y_fit):
    x = np.asarray(X_fit[:, 0], dtype=float)
    y = np.asarray(y_fit, dtype=float)
    x = np.where(np.isfinite(x) & (x > 0), x, 1e-12)
    y = np.where(np.isfinite(y), y, 0.0)

    best_cost = np.inf
    best = (1.0, 1.0)
    a0s = [1e-3, 1e-2, 1e-1, 1.0, 10.0, 100.0]
    b0s = [0.3, 0.7, 1.2, 2.0]
    for a0 in a0s:
        for b0 in b0s:
            try:
                res = least_squares(
                    lambda p: _form(x, p[0], p[1]) - y,
                    x0=[a0, b0],
                    bounds=([1e-10, 0.02], [1e10, 8.0]),
                    loss="huber", f_scale=1.0, max_nfev=2000,
                )
                if res.cost < best_cost and np.all(np.isfinite(res.x)):
                    best_cost = res.cost
                    best = (float(res.x[0]), float(res.x[1]))
            except Exception:
                continue

    a_hat, b_hat = best
    if not (np.isfinite(a_hat) and a_hat > 0):
        a_hat = 1.0
    if not (np.isfinite(b_hat) and b_hat > 0):
        b_hat = 1.0
    return {"a": a_hat, "b": b_hat}

def predict(X, a, b):
    x = np.asarray(X[:, 0], dtype=float)
    y = _form(x, a, b)
    y = np.where(np.isfinite(y), y, 0.0)
    return np.clip(y, 0.0, None)