"""AFM spherical-probe indentation: two-power-law loading curve.
F = K * [ (delta + d0)^n1 + c * delta^n2 ], with per-cluster stiffness K.
The sub-Hertzian shallow term (n1 ~ 0.39, contact rounding / finite contact
onset d0 ~ 2.9 um) plus a steep near-Hertzian term (n2 ~ 1.62) reproduces
every cluster with a single per-cluster scale; constants are universal."""
import numpy as np

USED_INPUTS = ["indentation_m", "R_m"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {"d0": 2.89e-06, "n1": 0.387, "c": 7.2e07, "n2": 1.621}
LOCAL_FITTABLE = {"K": {"init": None}}

def _shape(delta):
    return (delta + OTHER_CONSTANTS["d0"]) ** OTHER_CONSTANTS["n1"] \
        + OTHER_CONSTANTS["c"] * delta ** OTHER_CONSTANTS["n2"]

def fit(X_fit, y_fit):
    delta = np.asarray(X_fit[:, 0], dtype=float)
    delta = np.clip(delta, 0.0, None)
    x = _shape(delta)
    denom = float(x @ x)
    K = float(x @ y_fit) / denom if denom > 0 else 1.0
    if not np.isfinite(K):
        K = 1.0
    return {"K": K}

def predict(X, K):
    delta = np.asarray(X[:, 0], dtype=float)
    delta = np.clip(delta, 0.0, None)
    return K * _shape(delta)