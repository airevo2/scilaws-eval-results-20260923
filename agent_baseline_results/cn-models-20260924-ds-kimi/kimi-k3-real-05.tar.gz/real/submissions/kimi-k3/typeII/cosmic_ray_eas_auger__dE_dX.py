"""Universal Gaisser-Hillas shower profile with fixed shape parameter lambda=50 g/cm^2;
per-cluster amplitude A, starting depth X0, and shower maximum Xmax are fit by robust least squares."""
import numpy as np
from scipy.optimize import curve_fit

USED_INPUTS = ["X"]
LAW_CONSTANTS = {"lam": 50.0}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {"A": {"init": None}, "X0": {"init": None}, "Xmax": {"init": None}}

def _gh(X, A, X0, Xmax, lam=50.0):
    t = (X - X0) / (Xmax - X0)
    t = np.clip(t, 1e-9, None)
    return A * np.power(t, (Xmax - X0) / lam) * np.exp((Xmax - X) / lam)

def fit(X_fit, y_fit):
    X = np.asarray(X_fit[:, 0], dtype=float)
    y = np.asarray(y_fit, dtype=float)
    i = int(np.argmax(y))
    A0 = max(float(y[i]), 0.1)
    p0 = [A0, X[i] - 500.0, X[i]]
    lo = [1e-6, X.min() - 3000.0, X.min() - 100.0]
    hi = [1e4, X.max() - 1.0, X.max() + 300.0]
    p0 = [min(max(p, l), h) for p, l, h in zip(p0, lo, hi)]
    try:
        popt, _ = curve_fit(_gh, X, y, p0=p0, bounds=(lo, hi), maxfev=4000,
                            loss='soft_l1', f_scale=1.0)
        return {"A": float(popt[0]), "X0": float(popt[1]), "Xmax": float(popt[2])}
    except Exception:
        # Fallback: amplitude from peak, Xmax at observed peak, X0 far upstream.
        return {"A": float(A0), "X0": float(X[i] - 500.0), "Xmax": float(X[i])}

def predict(X, A, X0, Xmax):
    X = np.asarray(X[:, 0], dtype=float)
    lam = LAW_CONSTANTS["lam"]
    y = _gh(X, A, X0, Xmax, lam)
    return np.where(np.isfinite(y), y, 0.0)