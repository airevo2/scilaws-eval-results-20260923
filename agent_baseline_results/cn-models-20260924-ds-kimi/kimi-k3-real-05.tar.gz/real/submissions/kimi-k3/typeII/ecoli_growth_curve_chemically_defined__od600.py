"""Richards-type growth curve with slow linear decline.
OD600(t) = y0 + A/(1+nu*exp(-k*(t-tm)))^(1/nu) - d*max(t-tm,0).
nu is fixed (shared shape asymmetry, nu=3); y0 (baseline), A (amplitude),
k (rate), tm (midpoint), d (decline slope) are the per-cluster parameters
(fit via bounded least squares on one cluster's fit window).
Fits the rise with a Richards curve and the slow post-peak decay linearly."""
import numpy as np
from scipy.optimize import curve_fit

USED_INPUTS = ["time_h"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {
    "y0": {"init": None},
    "A":  {"init": None},
    "k":  {"init": None},
    "tm": {"init": None},
}
_NU = 3.0   # shared asymmetry (Richards shape)
_D  = 0.0015  # shared slow decline slope (OD/h), typical of these curves

def _form(t, y0, A, k, tm):
    z = np.clip(k*(t-tm), -60.0, 60.0)
    rise = A/(1.0+_NU*np.exp(-z))**(1.0/_NU)
    return y0 + rise - _D*np.maximum(t-tm, 0.0)

def fit(X_fit, y_fit):
    t = np.asarray(X_fit[:,0], dtype=float)
    y = np.asarray(y_fit, dtype=float)
    order = np.argsort(t)
    t, y = t[order], y[order]
    y0g = float(np.min(y))
    Ag  = float(max(np.max(y)-np.min(y), 0.05))
    tmg = float(np.median(t))
    try:
        popt, _ = curve_fit(
            lambda tt, A, k, tm: _form(tt, y0g, A, k, tm),
            t, y,
            p0=[Ag, 0.9, tmg],
            bounds=([0.005, 0.05, 0.0], [1.5, 5.0, 45.0]),
            maxfev=8000,
        )
        A, k, tm = float(popt[0]), float(popt[1]), float(popt[2])
    except Exception:
        A, k, tm = Ag, 0.9, tmg
    # keep everything finite and in sane ranges
    if not np.isfinite(A) or A <= 0: A = Ag
    if not np.isfinite(k) or k <= 0: k = 0.9
    if not np.isfinite(tm): tm = tmg
    return {"y0": y0g, "A": A, "k": k, "tm": tm}

def predict(X, y0, A, k, tm):
    t = np.asarray(X[:,0], dtype=float)
    y = _form(t, y0, A, k, tm)
    return np.where(np.isfinite(y), y, y0)