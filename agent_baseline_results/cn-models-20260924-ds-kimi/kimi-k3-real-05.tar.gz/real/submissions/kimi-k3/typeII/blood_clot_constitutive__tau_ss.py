"""Per-cluster strain-stiffening cubic shear law with offset:
tau_ss(gamma) = a + b*gamma + c*gamma^3.

Captures the nonlinear (cubic, odd-power dominant) stress-strain backbone of
whole-blood clots in simple shear, with a per-specimen stress offset 'a'
(pre-stress / drift). The linear modulus b and strain-stiffening coefficient c
are re-fit per cluster. Only 'gamma' is needed as input; conc_mM/time_min are
absorbed into the per-cluster fitted moduli. Robust (soft_l1) least squares
keeps the fit stable on small fit windows; gamma^3 extrapolates sensibly.
"""
import numpy as np
from scipy.optimize import least_squares

USED_INPUTS = ["gamma"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {
    "a": {"init": 0.0},   # stress offset (kPa)
    "b": {"init": 0.5},   # linear shear modulus (kPa)
    "c": {"init": 5.0},   # strain-stiffening cubic coefficient (kPa)
}

def _model(g, a, b, c):
    return a + b * g + c * g**3

def fit(X_fit, y_fit):
    g = np.asarray(X_fit[:, 0], dtype=float)
    y = np.asarray(y_fit, dtype=float)
    if len(g) < 3:
        return {"a": float(np.mean(y)) if len(y) else 0.0, "b": 0.5, "c": 5.0}
    def resid(p):
        return _model(g, *p) - y
    try:
        sol = least_squares(resid, x0=[0.0, 0.5, 5.0],
                            loss="soft_l1", f_scale=0.05, max_nfev=200)
        a, b, c = [float(v) for v in sol.x]
    except Exception:
        a, b, c = float(np.mean(y)), 0.5, 5.0
    if not (np.isfinite(a) and np.isfinite(b) and np.isfinite(c)):
        a, b, c = float(np.mean(y)), 0.5, 5.0
    return {"a": a, "b": b, "c": c}

def predict(X, a, b, c):
    g = np.asarray(X[:, 0], dtype=float)
    return _model(g, a, b, c)