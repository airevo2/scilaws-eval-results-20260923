"""Sips (Langmuir-Freundlich) adsorption isotherm: n = n_s*(b*P)^c / (1 + (b*P)^c).

This is a standard model for CO2 adsorption on heterogeneous microporous
adsorbents (zeolites/activated carbons). It reduces to Henry's law (linear in P)
at low pressure and saturates monotonically to the capacity n_s at high pressure.
Per-cluster parameters: n_s = saturation capacity (mmol/g), b = affinity constant
(1/bar), c = heterogeneity exponent. n_s is linear given (b,c), so fit() uses a
coarse (b,c) grid with linear solve for n_s, then a bounded robust (soft_l1)
least-squares refinement in log-parameter space; n_s is capped at 5*max(y) for
stable extrapolation from small fit windows.
"""
import numpy as np
from scipy.optimize import least_squares

USED_INPUTS = ["P_bar"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {"n_s": {"init": None}, "b": {"init": None}, "c": {"init": None}}


def _sips(P, n_s, b, c):
    P = np.asarray(P, dtype=float)
    x = np.power(np.maximum(b * np.maximum(P, 0.0), 1e-300), c)
    return n_s * x / (1.0 + x)


def fit(X_fit, y_fit):
    P = np.asarray(X_fit, dtype=float).ravel()
    y = np.asarray(y_fit, dtype=float).ravel()
    Ppos = P[P > 0]
    Pmed = float(np.median(Ppos)) if len(Ppos) else 1.0
    if not np.isfinite(Pmed) or Pmed <= 0:
        Pmed = 1.0
    ymax = max(float(np.max(y)), 1e-6)
    CAP_MULT, CMAX = 5.0, 4.0
    ncap = CAP_MULT * ymax

    # Coarse grid over (b, c); n_s solved linearly (model is linear in n_s).
    best, bestss = None, np.inf
    b_lo, b_hi = 0.02 / Pmed, 50.0 / Pmed
    for bb in np.logspace(np.log10(b_lo), np.log10(b_hi), 22):
        for cc in np.linspace(0.1, CMAX, 14):
            x = np.power(np.maximum(bb * P, 1e-300), cc)
            f = x / (1.0 + x)
            ns = float(np.dot(f, y) / max(np.dot(f, f), 1e-300))
            ns = min(max(ns, 0.0), ncap)
            ss = float(np.sum((ns * f - y) ** 2))
            if ss < bestss:
                bestss, best = ss, (ns, bb, cc)
    if best is None or not np.all(np.isfinite(best)):
        best = (ymax, 1.0 / Pmed, 1.0)

    # Bounded robust refinement in log-space.
    lb = np.log([1e-9, 1e-10, 0.05])
    ub = np.log([ncap, 1e6, CMAX])
    x0 = np.clip(np.log(np.maximum(best, 1e-12)), lb, ub)

    def resid(lp):
        ns, bb, cc = np.exp(lp)
        return _sips(P, ns, bb, cc) - y

    try:
        r = least_squares(resid, x0, bounds=(lb, ub), loss="soft_l1",
                          f_scale=1.0, max_nfev=400)
        n_s, b, c = [float(v) for v in np.exp(r.x)]
    except Exception:
        n_s, b, c = [float(v) for v in best]

    if not (np.isfinite(n_s) and np.isfinite(b) and np.isfinite(c)) \
            or n_s <= 0 or b <= 0 or c <= 0:
        n_s, b, c = float(best[0]), float(best[1]), float(best[2])
    return {"n_s": n_s, "b": b, "c": c}


def predict(X, n_s, b, c):
    return _sips(X[:, 0], n_s, b, c)