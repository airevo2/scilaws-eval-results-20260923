"""Per-cluster Cobb-Douglas in logs: ln(Y/L) = a + alpha*ln(K/L) + gamma*ln(h).

A Solow-style aggregate production function with constant elasticities. The three
parameters (level a, capital elasticity alpha, human-capital elasticity gamma) are
re-fit per cluster by ordinary least squares on that cluster's fit window; a guarded
fallback to fixed elasticities (0.5, 0.5) keeps the fit robust for tiny or
collinear windows."""
import numpy as np

USED_INPUTS = ["cn", "emp", "hc"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {"a": {"init": None}, "alpha": {"init": None}, "gamma": {"init": None}}

def fit(X_fit, y_fit):
    K = np.asarray(X_fit[:, 0], dtype=float)
    L = np.asarray(X_fit[:, 1], dtype=float)
    h = np.asarray(X_fit[:, 2], dtype=float)
    kl = np.log(np.maximum(K, 1e-12) / np.maximum(L, 1e-12))
    lh = np.log(np.maximum(h, 1e-12))
    y = np.asarray(y_fit, dtype=float)
    n = len(y)
    a, alpha, gamma = float(np.mean(y) - 0.5 * np.mean(kl) - 0.5 * np.mean(lh)), 0.5, 0.5
    if n >= 4 and np.std(kl) > 1e-9:
        Xd = np.column_stack([np.ones(n), kl, lh])
        try:
            beta, _, rank, _ = np.linalg.lstsq(Xd, y, rcond=None)
            if rank == 3 and np.all(np.isfinite(beta)) and np.all(np.abs(beta[1:]) < 5.0):
                a, alpha, gamma = float(beta[0]), float(beta[1]), float(beta[2])
        except Exception:
            pass
    return {"a": a, "alpha": alpha, "gamma": gamma}

def predict(X, a, alpha, gamma):
    K = np.asarray(X[:, 0], dtype=float)
    L = np.asarray(X[:, 1], dtype=float)
    h = np.asarray(X[:, 2], dtype=float)
    kl = np.log(np.maximum(K, 1e-12) / np.maximum(L, 1e-12))
    lh = np.log(np.maximum(h, 1e-12))
    return a + alpha * kl + gamma * lh