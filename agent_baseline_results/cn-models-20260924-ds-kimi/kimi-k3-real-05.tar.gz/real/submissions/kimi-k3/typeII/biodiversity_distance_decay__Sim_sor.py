"""Distance-decay of Sorensen similarity: S(d) = a * exp(-b * d), an exponential decay
bounded in (0, a] and monotone decreasing toward 0 — physically sensible under extrapolation.
Per cluster, a (initial similarity level) and b (decay rate) are re-fit from the cluster window:
b from a log-linear regression of S on d (clipped to [0, 3]), and a level-matched so the curve
passes through the cluster's mean similarity at the observed distances, making the fit robust
to small-window noise."""
import numpy as np

USED_INPUTS = ["env_dist"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {"a": {"init": None}, "b": {"init": None}}

def fit(X_fit, y_fit):
    d = np.asarray(X_fit[:, 0], dtype=float)
    s = np.asarray(y_fit, dtype=float)
    s_c = np.clip(s, 1e-6, None)
    if d.size < 2 or np.ptp(d) < 1e-9:
        a = float(np.mean(s))
        return {"a": max(a, 1e-4), "b": 0.0}
    try:
        slope, _ = np.polyfit(d, np.log(s_c), 1)
        b = float(np.clip(-slope, 0.0, 3.0))
        denom = float(np.mean(np.exp(-b * d)))
        if denom <= 0 or not np.isfinite(denom):
            denom = 1.0
        a = float(np.mean(s_c) / denom)
        a = float(np.clip(a, 1e-4, 2.0))
        if not np.isfinite(a):
            a = float(np.mean(s_c))
        return {"a": a, "b": b}
    except Exception:
        return {"a": max(float(np.mean(s_c)), 1e-4), "b": 0.0}

def predict(X, a, b):
    d = np.asarray(X[:, 0], dtype=float)
    y = a * np.exp(-np.clip(b, 0.0, None) * d)
    return np.clip(y, 0.0, 1.5)