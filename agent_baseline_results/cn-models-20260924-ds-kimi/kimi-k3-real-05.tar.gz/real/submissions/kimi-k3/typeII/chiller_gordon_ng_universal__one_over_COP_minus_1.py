"""1/COP = W/Q with W = a*(Tc-Te)*Tc/Te + b + e*Tc*Q + d*Q^2, fit per cluster.

Physically: compressor power = Carnot-reversible term a*(Tc-Te)*Tc/Te
(work against the temperature lift, scaled by condenser temperature), a
fixed parasitic/loss constant b, a capacity-coupled loss term e*Tc*Q, and a
small quadratic-load loss d*Q^2 (part-load inefficiency). Dividing W by the
evaporator load Q_e gives 1/COP; the submitted target is 1/COP - 1.

Features (from inputs T_ei, T_ci, Q_e):
  f1 = (T_ci - T_ei)*T_ci/T_ei          (reversible lift work, kW)
  f2 = 1                                 (constant loss, kW)
  f3 = T_ci*Q_e                          (capacity-coupled loss)
  f4 = (Q_e/100)^2                       (quadratic-load loss)
Model: r = 1/COP = (a*f1 + b + e*f3 + d*f4)/Q_e ;  y = r - 1.

fit() solves a per-cluster linear least squares for the 4 coefficients by
fitting W = r*Q_e = a*f1 + b + e*f3 + d*f4 (exactly linear in the params),
then predict() evaluates y = W/Q_e - 1. Four local parameters, one shared
functional form across all clusters.
"""
import numpy as np

USED_INPUTS = ["T_ei", "T_ci", "Q_e"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {
    "a": {"init": 0.5},
    "b": {"init": 50.0},
    "e": {"init": 0.005},
    "d": {"init": 0.0},
}

def _design_W(X):
    Te = np.asarray(X[:, 0], dtype=float)
    Tc = np.asarray(X[:, 1], dtype=float)
    Qe = np.asarray(X[:, 2], dtype=float)
    Qe = np.where(np.abs(Qe) < 1e-9, 1e-9, Qe)
    f1 = (Tc - Te) * Tc / Te          # reversible lift work (kW)
    f2 = np.ones_like(Qe)             # constant loss (kW)
    f3 = Tc * Qe                      # capacity-coupled loss
    f4 = (Qe / 100.0) ** 2            # quadratic-load loss
    return np.column_stack([f1, f2, f3, f4]), Qe

def fit(X_fit, y_fit):
    X_fit = np.asarray(X_fit, dtype=float)
    y_fit = np.asarray(y_fit, dtype=float)
    A, Qe = _design_W(X_fit)
    W = (1.0 + y_fit) * Qe            # target: 1/COP = W/Qe  ->  W = (1+y)*Qe
    # tiny ridge toward a physical init for stability on small windows
    p0 = np.array([0.5, 50.0, 0.005, 0.0])
    P = np.diag([1e-6, 1e-6, 1e-6, 1e-6])
    try:
        coef = np.linalg.solve(A.T @ A + P, A.T @ W + P @ p0)
        if not np.all(np.isfinite(coef)):
            raise ValueError
    except Exception:
        try:
            coef, *_ = np.linalg.lstsq(A, W, rcond=None)
        except Exception:
            coef = p0.copy()
    return {"a": float(coef[0]), "b": float(coef[1]),
            "e": float(coef[2]), "d": float(coef[3])}

def predict(X, a, b, e, d):
    X = np.asarray(X, dtype=float)
    A, Qe = _design_W(X)
    W = A[:, 0] * a + A[:, 1] * b + A[:, 2] * e + A[:, 3] * d
    y = W / Qe - 1.0
    return np.where(np.isfinite(y), y, 0.0)