"""Cardinal-temperature plateau model for 24h E. coli optical density under
sub-lethal antibiotic backgrounds.

Shared shape (all clusters): OD(T) = b + A * L(T; TL, sL) * S(T; TH)
  - L is a Gaussian rise from zero to a plateau at the low-temperature side:
    L = exp(-0.5*((TL-T)/sL)^2) for T < TL, else 1 (bacterial growth is ~0
    below a cluster-specific onset and plateaus through the optimum range).
  - S is a sharp logistic high-temperature collapse (heat/antibiotic kill),
    S = sigmoid(-(T-TH)/0.30); the collapse width 0.30 C is a fixed structural
    choice (the observed collapse between 41-44 C is near step-like).
  - b is the inoculum carry-over OD floor (~0.003).
Per cluster only {b, A, TL, sL, TH} are re-fit; the functional form is identical
for every cluster. Predictions stay in [b, b+A] and tend to the floor b at both
temperature extremes, so extrapolation outside 22-46 C remains physical.
"""
import numpy as np
from scipy.optimize import least_squares

USED_INPUTS = ["T"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {
    "b":  {"init": None},   # baseline OD floor
    "A":  {"init": None},   # plateau amplitude above baseline
    "TL": {"init": None},   # low-temperature knee (onset of plateau)
    "sL": {"init": None},   # low-temperature rise width
    "TH": {"init": None},   # high-temperature collapse midpoint
}

_SH = 0.30  # fixed structural width of the high-T collapse (near step-like)

def _sig(x):
    return 0.5 * (1.0 + np.tanh(x / 2.0))

def _form(T, b, A, TL, sL, TH):
    T = np.asarray(T, dtype=float)
    sL = max(float(sL), 0.3)
    z = np.clip((TL - T) / sL, -10.0, 10.0)
    low = np.exp(-0.5 * z * z)
    low = np.where(T < TL, low, 1.0)
    high = _sig(-(T - TH) / _SH)
    return b + A * low * high

def fit(X_fit, y_fit):
    T = np.asarray(X_fit[:, 0], dtype=float)
    y = np.asarray(y_fit, dtype=float)
    ymax = float(np.max(y)) if y.size else 0.01
    b0 = float(np.clip(np.min(y), 0.0, 0.05)) if y.size else 0.003
    A0 = max(ymax - b0, 0.01)

    def resid(p):
        return _form(T, p[0], p[1], p[2], p[3], p[4]) - y

    bounds = ([0.0, 0.0, 22.0, 0.3, 41.0],
              [0.05, 1.5, 42.0, 30.0, 48.0])
    best = None
    for tl in (28.0, 32.0, 36.0):
        for sl in (2.0, 6.0, 12.0):
            p0 = [b0, A0, tl, sl, 43.0]
            try:
                r = least_squares(resid, p0, bounds=bounds, max_nfev=1200)
                if best is None or r.cost < best.cost:
                    best = r
            except Exception:
                continue
    if best is None:
        return {"b": b0, "A": A0, "TL": 32.0, "sL": 6.0, "TH": 43.0}
    b, A, TL, sL, TH = [float(v) for v in best.x]
    return {"b": b, "A": A, "TL": TL, "sL": sL, "TH": TH}

def predict(X, b, A, TL, sL, TH):
    T = np.asarray(X[:, 0], dtype=float)
    y = _form(T, b, A, TL, sL, TH)
    return np.clip(np.nan_to_num(y, nan=float(b), posinf=float(b) + float(A),
                   neginf=float(b)), 0.0, None)