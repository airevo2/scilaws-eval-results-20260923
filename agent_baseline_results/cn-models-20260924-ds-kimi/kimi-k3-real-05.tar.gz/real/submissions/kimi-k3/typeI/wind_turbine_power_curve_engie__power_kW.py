"""Wind turbine power curve: Gompertz rise blended into a rated-power plateau (1976 kW), clipped to [0, Prated]."""
import numpy as np

USED_INPUTS = ["wind_speed_mps"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    v = np.asarray(X[:, 0], dtype=float)
    cap = 1976.0
    a, b, c, e, k = 1922.23158, 7.122111, 0.395914, 2.56648, 1.203032
    d = -cap * np.exp(-b * np.exp(c * e))
    g = np.minimum(d + a * np.exp(-b * np.exp(-c * (v - e))), cap)
    sig = 1.0 / (1.0 + np.exp(-k * (v - 12.0)))
    return np.minimum(np.clip(g * (1.0 - sig) + cap * sig, 0.0, None), cap)