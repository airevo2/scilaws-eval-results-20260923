"""Power-law scaling of eruption-column top height with mass eruption rate,
H = a * MER^b, with constants fitted to minimise MAE in log10 space (the
scoring metric). Power laws are the standard form for plume-height scaling
(Morton-Taylor-Turner buoyant-plume theory gives H ~ MER^(1/4); the fitted
exponent ~0.156 reflects wind/atmospheric effects in the data), and the form
stays positive, monotone, and physically sensible when extrapolated to the
higher MER of the test set."""
import numpy as np

USED_INPUTS = ["MER_kg_per_s"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    mer = X[:, 0]
    return 0.894897 * mer ** 0.156261