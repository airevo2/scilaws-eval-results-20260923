"""FEV1 = a * h^p * exp(-t/c): height-driven power law with exponential age decline."""
import numpy as np

USED_INPUTS = ["age", "height_cm"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    t = X[:, 0]
    h = X[:, 1]
    return 2.474e-4 * np.power(h, 1.9132) * np.exp(-t / 102.84)