"""Kozeny-Carman-type porosity-permeability law: log10(k) = a*log10(phi^3/(1-phi)^2) + b.
Probing showed log_k is strongly linear in log10(phi^3/(1-phi)^2) (corr 0.988) with a large
phi-dependent random component (latent grain-size factor); the deterministic mechanism is the
Kozeny-Carman porosity scaling."""
import numpy as np

USED_INPUTS = ["phi"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    phi = np.clip(X[:, 0], 1e-6, 1.0 - 1e-6)
    return 1.55 * np.log10(phi**3 / (1.0 - phi)**2) + 3.65