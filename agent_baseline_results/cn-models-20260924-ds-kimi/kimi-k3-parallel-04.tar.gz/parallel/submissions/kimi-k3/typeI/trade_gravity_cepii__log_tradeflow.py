"""Gravity equation: log trade flow is linear in origin & destination log-GDP,
log-distance, and binary trade facilitators (contiguity, common language,
colonial history, FTA). Coefficients are OLS estimates from simulator probes."""
import numpy as np

USED_INPUTS = ["log_gdp_o", "log_gdp_d", "log_dist", "contig", "comlang_off", "col_dep_ever", "fta_wto"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    go = X[:, 0]
    gd = X[:, 1]
    di = X[:, 2]
    c = X[:, 3]
    l = X[:, 4]
    k = X[:, 5]
    r = X[:, 6]
    return (-17.99
            + 1.14 * go
            + 0.82 * gd
            - 1.03 * di
            + 0.63 * c
            + 0.90 * l
            + 1.34 * k
            + 1.11 * r)