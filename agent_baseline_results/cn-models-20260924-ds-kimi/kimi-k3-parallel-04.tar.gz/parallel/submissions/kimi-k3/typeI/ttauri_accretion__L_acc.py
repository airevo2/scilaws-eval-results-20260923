"""Linear accretion-luminosity scaling: log L_acc = 1.5 * log L_star - 1.39 (plus Gaussian scatter, sigma ~ 0.33 dex, not modeled by the predictor).

Fit on 180 simulator probes over logL_star in [-2.523, 0.71]: OLS slope 1.53 +/- 0.02 (consistent with 3/2), intercept -1.37 +/- 0.03; residuals pass Shapiro/KS normality tests with std ~0.33-0.35 dex and no significant curvature (chi2 of group means vs linear: p=0.48). The deterministic mechanism is a power law L_acc proportional to L_star^1.5, i.e. linear in log-log."""
import numpy as np

USED_INPUTS = ["logL_star"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    x = X[:, 0]
    return 1.5 * x - 1.39