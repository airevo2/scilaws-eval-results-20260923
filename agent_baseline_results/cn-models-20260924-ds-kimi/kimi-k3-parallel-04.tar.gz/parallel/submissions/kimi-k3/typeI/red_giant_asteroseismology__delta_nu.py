"""Large separation scaling: delta_nu = A * nu_max^0.75 (canonical asteroseismic relation)."""
import numpy as np

USED_INPUTS = ["nu_max"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    nu_max = X[:, 0]
    return 0.2857 * np.power(nu_max, 0.75)