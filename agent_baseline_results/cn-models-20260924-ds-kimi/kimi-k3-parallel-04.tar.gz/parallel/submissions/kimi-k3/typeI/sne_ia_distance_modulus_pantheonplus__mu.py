"""Flat Lambda-CDM Hubble diagram: mu = 5*log10((1+z)*integral_0^z dz'/E(z')) + 25 + 5*log10(c/H0), E(z)=sqrt(Om*(1+z)^3 + 1-Om)."""
import numpy as np

USED_INPUTS = ["z_hd"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    z = np.asarray(X[:, 0], dtype=float)
    Om = 0.3
    C = 25.0 + 5.0 * np.log10(299792.458 / 73.0)
    zg = np.linspace(0.0, 2.27, 20001)
    E = np.sqrt(Om * (1.0 + zg) ** 3 + (1.0 - Om))
    inv = 1.0 / E
    I = np.concatenate([[0.0], np.cumsum(0.5 * (inv[1:] + inv[:-1]) * np.diff(zg))])
    Ii = np.interp(z, zg, I)
    return 5.0 * np.log10((1.0 + z) * Ii) + C