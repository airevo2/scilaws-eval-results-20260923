"""Modified Greenberg freeway fundamental diagram: speed v(k) = v0 + c*ln(k_j/k),
flow q(k) = k*v(k). The jam density k_j equals the simulator's upper domain bound
(249.453193 veh/km/lane ≈ 155 mi⁻¹); q plateaus (does not vanish) as k -> k_j,
which pins the logarithmic Greenberg form with a positive intercept v0 ≈ 11.1 km/h
at k_j (slope c ≈ 14.1 km/h). Residual scatter is stochastic observation noise,
largest at low density (free-flow speed heterogeneity)."""
import numpy as np

USED_INPUTS = ["k_veh_km_lane"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    k = np.asarray(X[:, 0], dtype=float)
    k_j = 249.453193      # jam density (veh/km/lane), = upper domain bound
    v0 = 11.1306          # speed intercept at k -> k_j (km/h)
    c = 14.0573           # Greenberg slope (km/h)
    v = v0 + c * np.log(k_j / np.clip(k, 1e-9, None))
    return k * v