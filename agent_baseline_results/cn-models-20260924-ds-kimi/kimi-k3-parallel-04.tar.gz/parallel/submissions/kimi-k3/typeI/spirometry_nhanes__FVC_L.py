"""FVC as a sum of two power-law growth terms: a height-driven component (lung size scales ~ h^3.1) plus an age-driven maturation component (~ t^1.5). Multiplicative log-normal noise (sigma ~ 0.11) was identified and removed by fitting on the log scale; this additive-power-law structure achieved chi2/dof ~ 1.0 against the replicate noise floor, beating bilinear log-log and shifted-log alternatives."""
import numpy as np

USED_INPUTS = ["age", "height_cm"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    t = X[:, 0]
    h = X[:, 1]
    return 4.0213e-07 * np.power(h, 3.10616) + 1.7718e-02 * np.power(t, 1.52493)