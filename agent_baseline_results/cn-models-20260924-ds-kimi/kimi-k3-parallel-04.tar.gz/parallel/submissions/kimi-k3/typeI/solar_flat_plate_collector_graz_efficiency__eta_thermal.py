"""Flat-plate collector efficiency (Hottel-Whillier form with temperature-dependent
loss coefficient): eta = eta0 - (b1*Tm)*(Tin-Tamb)/G - b2*(Tin-Tamb)^2/G,
where Tm = (Tin+Tamb)/2 is the mean fluid-plate temperature. The term b1*Tm*dT/G
is the linear convective loss with a plate-temperature-dependent overall loss
coefficient, and b2*dT^2/G is the second-order (radiation-like) loss. Constants
from a robust least-squares fit to experimental means (outlier-rejected)."""
import numpy as np

USED_INPUTS = ["G_W_m2", "T_in_C", "T_amb_C"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    G = X[:, 0]
    T_in = X[:, 1]
    T_amb = X[:, 2]
    dT = T_in - T_amb
    Tm = 0.5 * (T_in + T_amb)
    eta = 0.71285 - 0.05579 * Tm * dT / G - 0.02729 * dT * dT / G
    return eta