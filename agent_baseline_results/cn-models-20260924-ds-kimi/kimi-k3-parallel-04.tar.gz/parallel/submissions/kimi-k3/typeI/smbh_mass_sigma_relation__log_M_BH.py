"""Linear M_BH-M_sph relation: log_M_BH = alpha + beta*(log_M_sph - 11)."""
import numpy as np

USED_INPUTS = ["log_M_sph"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    x = X[:, 0]
    return 8.634572190330736 + 1.090990141923864 * (x - 11.0)