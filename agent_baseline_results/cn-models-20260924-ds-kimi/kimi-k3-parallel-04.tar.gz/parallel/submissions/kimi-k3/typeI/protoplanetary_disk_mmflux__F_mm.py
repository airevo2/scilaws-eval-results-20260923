"""Dust continuum flux vs stellar mass: power-law disk-mass scaling plus a constant flux floor (detection-limit plateau), F = 10^a * M_star^p + 10^b, expressed in log10."""
import numpy as np

USED_INPUTS = ["log10_M_star_SDF00"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    x = X[:, 0]
    return np.log10(10.0**(-2.5607) + 10.0**(-1.6007 + 1.2886*x))