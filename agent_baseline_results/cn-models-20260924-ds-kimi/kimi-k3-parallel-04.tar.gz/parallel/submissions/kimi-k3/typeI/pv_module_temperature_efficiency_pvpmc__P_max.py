"""PV module DC MPP power: P_mp = P_ref * (G/1000)^p * (1 + gamma*(T_c - 25)).
Near-linear in irradiance with a mild power-law efficiency droop at low light,
and a linear negative temperature coefficient (~-0.25 %/C, typical for c-Si).
Constants fitted from experiments; reference power ~202 W at STC."""
import numpy as np

USED_INPUTS = ["G_W_m2", "T_module_C"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    G = X[:, 0]
    T = X[:, 1]
    return 202.3 * (G / 1000.0) ** 0.9294 * (1.0 - 0.0025 * (T - 25.0))