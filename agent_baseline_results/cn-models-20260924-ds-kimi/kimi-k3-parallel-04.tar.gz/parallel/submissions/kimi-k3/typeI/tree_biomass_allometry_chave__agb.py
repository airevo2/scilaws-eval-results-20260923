"""Tropical tree aboveground biomass allometry: AGB = 0.089 * rho * D^2 * H^0.8.

Experiments show a multiplicative power law in wood density (rho), diameter (D)
and height (H). Joint log-log fits give exponents ~2.05-2.07 for D, ~1.0 for
rho, and ~0.82 for H; with rho fixed at 1 and D at 2 (standard Chave-style
form), the H exponent is 0.822 with residual std indistinguishable from the
free fit (0.183 vs 0.173). I adopt the compact structural form
AGB = a * rho * D^2 * H^0.8 with fitted constant a = 0.089 (from exp(mean of
log-residuals), matching the fit intercept 0.091)."""
import numpy as np

USED_INPUTS = ["wood_density", "diameter_cm", "height_m"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    rho = X[:, 0]
    D = X[:, 1]
    H = X[:, 2]
    return 0.089 * rho * D**2 * H**0.8