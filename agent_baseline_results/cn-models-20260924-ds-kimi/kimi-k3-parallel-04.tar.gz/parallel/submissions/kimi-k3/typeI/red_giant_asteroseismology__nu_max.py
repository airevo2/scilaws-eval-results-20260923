"""nu_max vs delta_nu for red giants: a power-law with mild log-log curvature,
nu_max = exp(c0 + c1*ln(dnu) + c2*ln(dnu)^2) = 4.739 * dnu^1.492 * dnu^(-0.0455*ln dnu).
This captures the smooth downward curvature (steep at low delta_nu, flattening toward
high delta_nu) superposed on the near-4/3 power-law scaling relation. Fitted on group
means (n>=6 per point) in log-log space; rms 3.0% vs 4.7% for a pure power law."""
import numpy as np

USED_INPUTS = ["delta_nu"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    dnu = X[:, 0]
    lx = np.log(dnu)
    # log-quadratic relation: ln(nu_max) = 1.557 + 1.4923*ln(dnu) - 0.0455*ln(dnu)^2
    return np.exp(1.557 + 1.4923 * lx - 0.0455 * lx**2)