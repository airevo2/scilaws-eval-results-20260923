"""Proton GE/GD: Sachs GE as a Kelly-style rational function of tau divided by the standard dipole GD=(1+Q^2/0.71)^-2."""
import numpy as np

USED_INPUTS = ["Q2_GeV2"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    Q2 = X[:, 0]
    tau = Q2 / (4.0 * 0.938272**2)
    GE = (1.0 - 0.42697 * tau) / (1.0 + 10.48215 * tau + 16.88995 * tau**2 + 4.72225 * tau**3)
    GD = 1.0 / (1.0 + Q2 / 0.71)**2
    return GE / GD