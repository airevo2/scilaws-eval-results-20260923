"""Endurance running velocity law: v = b + a*(1 - exp(-t/tau)) with event time t=d/v
solved by fixed-point iteration; women's velocity is a fixed multiplicative factor.
Constants fitted to per-distance peak record levels (men): a=4.91 m/s, b=6.32 m/s,
tau=132 s; women's factor 0.895."""
import numpy as np

USED_INPUTS = ["distance_m", "sex_M"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    d = X[:, 0].astype(float)
    s = X[:, 1].astype(float)
    a = 4.91
    b = 6.32
    tau = 132.0
    v = np.full(d.shape, 8.0)
    for _ in range(200):
        t = d / np.maximum(v, 1e-9)
        v_new = b + a * (1.0 - np.exp(-t / tau))
        if np.max(np.abs(v_new - v)) < 1e-12:
            v = v_new
            break
        v = v_new
    factor = np.where(s > 0.5, 1.0, 0.895)
    return v * factor