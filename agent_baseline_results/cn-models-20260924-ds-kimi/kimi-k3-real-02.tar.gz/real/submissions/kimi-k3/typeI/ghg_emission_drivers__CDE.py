"""Kaya-style emissions model: national CO2 = population x per-capita emissions,
where log per-capita emissions is a smooth function of affluence (log GDP/cap,
with curvature), working-age share (log AP), urbanization (UR) and mean
temperature (AT, with cold/threshold hinges capturing heating demand), plus
cross terms. Fitted by OLS on log(CDE/TP); 5-fold CV smape ~42."""
import numpy as np

USED_INPUTS = ["GDP", "TP", "AP", "UR", "AT"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    GDP, TP, AP, UR, AT = X[:, 0], X[:, 1], X[:, 2], X[:, 4], X[:, 5]
    g = (np.log(GDP) - 7.6) / 1.5
    a = (np.log(AP) - 4.05) / 0.16
    u = (UR / 100.0 - 0.5) / 0.25
    t = (AT - 22.0) / 6.0
    hm_t = np.maximum(1.5 - t, 0.0)          # warm-side threshold
    hm_cold = np.maximum(-2.5 - t, 0.0)      # very cold threshold (AT < ~7 C)
    log_pc = (6.2725
              + 1.3691 * g + 0.0076 * g**2
              + 0.2260 * a + 0.1466 * a**2
              + 0.3120 * u - 0.0821 * u**2
              + 0.4262 * hm_t
              + 0.1679 * g**2 * t
              - 0.2636 * g * a
              + 0.1412 * u**2 * t
              + 0.7853 * g**2 * hm_cold
              + 0.1007 * t * hm_cold
              + 0.0648 * g * t
              + 0.0035 * t**2
              - 0.1436 * g * u)
    return TP * np.exp(log_pc)