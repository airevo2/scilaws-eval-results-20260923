"""N2O emissions: population times a log-linear per-capita intensity model.

NOE = TP * exp(c0 + c1 lnG + c2 lnD + c3 AT + c4 AP + c5 lnG lnD + c6 lnD AT
              + c7 lnG AT + c8 AT^2 + c9 AP lnG + c10 lnG^2 + c11 UR + c12 lnD UR)

Per-capita N2O intensity is modelled as a smooth function of income (ln GDP),
population density (ln DP, a proxy for agricultural land intensity), working-age
share, urbanisation and mean temperature, with interactions capturing that the
income and density effects vary with climate. Constants fitted by direct
smape-optimal least squares on the training set. The form stays bounded and
monotonic-sensible under extrapolation to richer/denser test countries.
"""
import numpy as np

USED_INPUTS = ["GDP", "TP", "AP", "DP", "UR", "AT"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    GDP = X[:, 0]
    TP = X[:, 1]
    AP = X[:, 2]
    DP = X[:, 3]
    UR = X[:, 4]
    AT = X[:, 5]
    lG = np.log(np.maximum(GDP, 1e-9))
    lD = np.log(np.maximum(DP, 1e-9))
    e = (6.52220772
         - 0.02145092 * lG
         - 0.96268316 * lD
         + 0.04387507 * AT
         - 0.13379465 * AP
         + 0.07057705 * lG * lD
         + 0.00121962 * lD * AT
         - 0.00457169 * lG * AT
         - 0.00113937 * AT * AT
         + 0.01621560 * AP * lG
         - 0.06263510 * lG * lG
         - 0.00568757 * UR
         + 0.00117488 * lD * UR)
    e = np.clip(e, -30.0, 30.0)
    return TP * np.exp(e)