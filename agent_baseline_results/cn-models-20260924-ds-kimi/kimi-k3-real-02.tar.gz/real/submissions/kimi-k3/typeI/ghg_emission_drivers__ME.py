"""Kaya-style log-linear (power-law) model for national methane emissions.

ME = exp(c) * TP^a * GDP^b * DP^d * exp(u*UR + p*AP + t*AT)

Emissions scale near-proportionally with population, rise modestly with
GDP per capita, fall with population density (dense countries have less
extensive agriculture/land per person), and rise with urbanization
(waste sector). Power laws in TP/GDP/DP keep extrapolation monotone and
physically sensible; the small linear UR/AP/AT terms stay bounded over
the test ranges. Constants were fitted by directly minimizing SMAPE on
the training data (7 coefficients, at the cap).
"""
import numpy as np

USED_INPUTS = ["GDP", "TP", "AP", "DP", "UR", "AT"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    GDP = X[:, 0]
    TP = X[:, 1]
    AP = X[:, 2]
    DP = X[:, 3]
    UR = X[:, 4]
    AT = X[:, 5]
    log_me = (3.1524
              + 1.0281 * np.log(TP)
              + 0.1129 * np.log(GDP)
              - 0.3368 * np.log(DP)
              + 0.0034 * UR
              + 0.0059 * AP
              + 0.0008 * AT)
    return np.exp(log_me)