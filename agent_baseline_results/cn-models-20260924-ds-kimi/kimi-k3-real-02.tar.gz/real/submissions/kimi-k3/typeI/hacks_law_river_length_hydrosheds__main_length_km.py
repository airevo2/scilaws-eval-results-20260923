"""Hack's-law main-stem length: L = L_s + c*(A - A_c)^h.

The main-stem length is the terminal outlet segment length (L_s) plus a
Hack's-law power of the upstream contributing area (A - A_c, the area above
the terminal reach). Fitted by L1 in log10 space (matches the log_mae metric):
c = 1.222, h = 0.590. The exponent ~0.59 matches the classic Hack exponent
(~0.6) and the form extrapolates stably to very large basins (Ls and A_c
become negligible, leaving a pure power law in A).
"""
import numpy as np

USED_INPUTS = ["upland_area_skm", "catch_area_skm", "segment_length_km"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    A = X[:, 0].astype(float)
    Ac = X[:, 1].astype(float)
    Ls = X[:, 2].astype(float)
    upstream = np.maximum(A - Ac, 1.0)
    return Ls + 1.222 * np.power(upstream, 0.590)