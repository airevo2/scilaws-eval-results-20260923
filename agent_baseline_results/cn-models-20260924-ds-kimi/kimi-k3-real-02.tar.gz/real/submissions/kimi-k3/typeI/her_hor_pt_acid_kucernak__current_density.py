"""HOR/HER on Pt in acid: Butler-Volmer with gaussian overpotential damping and
modified-Arrhenius temperature law; power-law H2 partial-pressure dependence.

j = j0 * [exp((1-alpha)*a) - exp(-alpha*a)] * exp(-k*a^2),  a = F*eta/(R*T)
ln j0 = ln j0r - Ea/R*(1/T - 1/298) + d*(T-298) + 0.69*ln(P_H2/0.97)

Fitted on both series (T-series 4.0 M HClO4 drives the constants; the 0.69
pressure exponent comes from the T=298 K, 0.5 M HClO4 series, whose fitted
j0 amplitude ~126 is consistent with j0r at P~0.97)."""
import numpy as np

USED_INPUTS = ["eta", "T", "P_H2", "c_acid"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    eta = X[:, 0]
    T = X[:, 1]
    P = X[:, 2]
    F = 96485.0
    R = 8.314
    j0r = 145.650568
    Ea = 63841.0150
    d = -0.0636220925
    alpha = 0.578706588
    k = 0.0229970222
    j0 = j0r * np.exp(-Ea / R * (1.0 / T - 1.0 / 298.0) + d * (T - 298.0)) \
        * (P / 0.97) ** 0.69
    a = F * eta / (R * T)
    j = j0 * (np.exp((1.0 - alpha) * a) - np.exp(-alpha * a)) * np.exp(-k * a * a)
    return j