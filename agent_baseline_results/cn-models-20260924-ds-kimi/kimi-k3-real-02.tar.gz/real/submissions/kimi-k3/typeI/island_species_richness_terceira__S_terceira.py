"""Arthropod richness on Terceira: sublinear elevation-driven richness attenuated
exponentially by anthropogenic habitat modification, plus a small background richness.

S = 0.53397 * sqrt(h) * exp(-0.048333 * d) + 0.63704

Rationale: native forest (low disturbance d) at high altitude holds the most species;
richness decays roughly exponentially with habitat modification, and the attainable
richness scales sublinearly (square-root) with altitude, a proxy for the cool, humid,
native-laurel-forest zone. Chosen over 4-parameter variants by LOOCV/5-fold CV
(best generalization with only 3 fitted constants) and behaves sensibly when
extrapolated (monotone decreasing in d, gentle concave growth in h, always positive).
"""
import numpy as np

USED_INPUTS = ["d", "h"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    d = X[:, 0]
    h = X[:, 1]
    return 0.533972 * np.sqrt(np.maximum(h, 0.0)) * np.exp(-0.048333 * d) + 0.637044