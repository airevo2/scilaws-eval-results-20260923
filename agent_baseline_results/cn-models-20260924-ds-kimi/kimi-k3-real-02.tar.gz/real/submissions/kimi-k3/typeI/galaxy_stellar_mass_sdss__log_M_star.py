"""Stellar mass from red-sequence color (r - z_mag) and mean optical luminosity.

log10 M_star = 1.17990 + 1.06026*(r - z_mag) - 0.4*((i + z_mag)/2 - DM)

Physics: the distance-modulus-corrected mean i/z magnitude traces luminosity
(-0.4 converts mag to log L), while the rest-frame-optical color (r - z_mag)
traces the mass-to-light ratio (redder = older/higher M/L). Only the 2 fitted
constants allowed are used; the -0.4 factor is the exact mag-to-logL conversion."""
import numpy as np

USED_INPUTS = ["r", "i", "z_mag", "DM"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    r = X[:, 0]
    i = X[:, 1]
    z_mag = X[:, 2]
    DM = X[:, 3]
    color = r - z_mag
    lum_term = -0.4 * ((i + z_mag) / 2.0 - DM)
    return 1.17990 + 1.06026 * color + lum_term