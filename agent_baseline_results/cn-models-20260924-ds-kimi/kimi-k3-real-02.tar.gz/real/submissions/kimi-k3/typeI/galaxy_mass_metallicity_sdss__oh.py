"""Second-order mass–SFR relation: 12+log(O/H) as a full quadratic in (log_Mstar−10) and log_SFR, capturing the saturating mass–metallicity relation and the FMR-style anti-correlation of the SFR term at high mass."""
import numpy as np

USED_INPUTS = ["log_Mstar", "log_SFR"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    m = X[:, 0] - 10.0
    s = X[:, 1]
    return (8.9152
            + 0.217903 * m
            + 0.048565 * s
            - 0.156053 * m * m
            + 0.119728 * m * s
            - 0.043886 * s * s)