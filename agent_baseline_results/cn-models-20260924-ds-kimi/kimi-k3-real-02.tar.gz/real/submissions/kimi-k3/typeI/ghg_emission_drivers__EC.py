"""National primary energy consumption: log-linear model EC = exp(b0) * TP^b1 * exp(b2*ln(GDP)^2 + b3*AP + b4*UR + b5*AT + b6*UR*ln(GDP)). Energy scales near-linearly with population; the quadratic-in-log-GDP term captures rising then saturating per-capita energy intensity, moderated by urbanization; working-age share raises energy use; colder climates demand more energy."""
import numpy as np

USED_INPUTS = ["GDP", "TP", "AP", "DP", "UR", "AT"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    GDP = X[:, 0]
    TP = X[:, 1]
    AP = X[:, 2]
    UR = X[:, 4]
    AT = X[:, 5]
    lTP = np.log(TP)
    lG = np.log(GDP)
    logEC = (-12.998811
             + 1.045656 * lTP
             + 0.102737 * lG**2
             + 0.041591 * AP
             + 0.133514 * UR
             - 0.042328 * AT
             - 0.015823 * UR * lG)
    return np.exp(logEC)