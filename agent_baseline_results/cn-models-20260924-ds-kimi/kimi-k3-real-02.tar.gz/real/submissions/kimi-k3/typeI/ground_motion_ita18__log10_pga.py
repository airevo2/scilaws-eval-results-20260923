"""GMPE for log10(PGA) (RotD50, cm/s^2): linear magnitude scaling, magnitude-dependent
geometric attenuation of log10(sqrt(R^2+h0^2)) with fictitious depth h0, linear
anelastic distance term, additive EC8 site-class amplification (class A rock baseline),
and reverse-faulting style term. Constants fitted by least squares on 3449 records."""
import numpy as np

USED_INPUTS = ["Mw", "R_km", "depth_km", "ec8_A", "ec8_B", "ec8_C", "ec8_D", "ec8_E",
               "sof_NF", "sof_TF", "sof_SS"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    M = X[:, 0]
    R = X[:, 1]
    CB = X[:, 4]
    CC = X[:, 5]
    CD = X[:, 6]
    CE = X[:, 7]
    ER = X[:, 9]
    ESS = X[:, 10]
    Reff = np.sqrt(R**2 + 6.589935**2)
    return (2.040374 + 0.2357654 * M
            + (-2.611963 + 0.2396801 * M) * np.log10(Reff)
            - 0.003054502 * R
            + 0.05109379 * CB + 0.2471393 * CC + 0.1137357 * CD + 0.3872926 * CE
            - 0.1326197 * ER - 0.005599777 * ESS)