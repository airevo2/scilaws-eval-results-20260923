"""WGS84 normal gravity on the reference ellipsoid: Somigliana closed formula
with published WGS84 constants (gamma_e, k, e^2). The dominant data population
matches this exactly (residual sigma ~0.25 mGal); no fitted constants, and it
extrapolates physically to 60-80 deg."""
import numpy as np

USED_INPUTS = ["latitude"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    lat = X[:, 0]
    s2 = np.sin(np.radians(lat))**2
    ge = 9.7803253359        # WGS84 equatorial normal gravity (m/s^2)
    k = 0.00193185265241     # WGS84 gravity formula constant
    e2 = 0.00669437999013    # WGS84 first eccentricity squared
    return ge * (1.0 + k * s2) / np.sqrt(1.0 - e2 * s2)