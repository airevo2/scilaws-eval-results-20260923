"""Vickers hardness of refractory/CCA high-entropy alloys.
Physical picture: hardness has a baseline BCC solid-solution value set by the
enthalpy of mixing (more negative dHmix -> stronger bonding -> harder), plus an
electronic contribution from valence electron concentration that only becomes
active in the high-VEC regime (VEC > ~6, the BCC structural boundary in the
empirical VEC map). Only 3 fitted constants (b0, a, b); the VEC=6.0 threshold
is the well-established BCC stability boundary, not a fitted constant."""

import numpy as np

USED_INPUTS = ["VEC", "dHmix"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    v = X[:, 0]
    h = X[:, 1]
    return 394.0 + 500.0 * np.maximum(0.0, v - 6.0) - 7.5 * h