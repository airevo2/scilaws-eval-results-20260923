"""Forecaster-style continuous mass-radius relation for sub-stellar objects.
Piecewise power law in log-log space with three segments (rocky: R ~ M^0.284;
Neptunian/giant: R ~ M^0.589; degenerate Jovian/brown-dwarf: R ~ M^-0.007),
plus a smooth hinge at ~132 M_earth that bends the high-mass slope to
R ~ M^-0.044, matching the brown-dwarf radius roll-off.
Constants were fitted to the training data by direct SMAPE optimisation."""

import numpy as np

USED_INPUTS = ["M"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    M = np.asarray(X[:, 0], dtype=float)
    M = np.maximum(M, 1e-6)
    x = np.log(M)

    c, s1, s2, s3, s4 = 0.00715057, 0.28426156, 0.58923141, -0.00707086, -0.04434252
    lb1, lb2 = 0.72631745, 4.88475532   # log-mass breaks (~2.07 and ~132 M_earth)
    kappa = 4.5

    v1 = c + s1 * lb1
    v2 = v1 + s2 * (lb2 - lb1)

    lr = np.empty_like(x)
    m1 = x < lb1
    m2 = (x >= lb1) & (x < lb2)
    m3 = x >= lb2
    lr[m1] = c + s1 * x[m1]
    lr[m2] = v1 + s2 * (x[m2] - lb1)
    lr[m3] = v2 + s3 * (x[m3] - lb2)

    # smooth hinge at lb2 transitioning slope s3 -> s4
    z = x - lb2
    lr = lr + (s4 - s3) * np.logaddexp(0.0, kappa * z) / kappa

    return np.exp(lr)