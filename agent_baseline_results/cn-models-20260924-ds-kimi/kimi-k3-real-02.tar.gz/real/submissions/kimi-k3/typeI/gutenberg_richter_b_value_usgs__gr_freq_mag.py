"""Gutenberg-Richter frequency-magnitude law: log10 N(M >= M_threshold) = a - b*M.
Fitted on the catalog: a = 8.135243, b = 1.019128 (b near the canonical value ~1).
Linear form is well-supported (train RMSE 0.0063, best LOOCV among deg 1-3) and
extrapolates physically sensibly to M 7.5-9.1 (rate keeps decaying ~10x per unit M)."""
import numpy as np

USED_INPUTS = ["M_threshold"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    M = X[:, 0]
    return 8.135243 - 1.019128 * M