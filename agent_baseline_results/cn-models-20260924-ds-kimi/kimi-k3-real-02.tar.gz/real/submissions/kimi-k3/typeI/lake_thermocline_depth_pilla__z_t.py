"""Thermocline depth: depth-capacity term |log10(Z_max)|^0.8 plus fetch term log10(1+A_s) tapered in very deep lakes."""
import numpy as np

USED_INPUTS = ["A_s_km2", "Z_max_m"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    A_s = np.asarray(X[:, 0], dtype=float)
    Z_max = np.asarray(X[:, 1], dtype=float)
    lz = np.log10(np.maximum(Z_max, 1e-9))
    # deep-lake taper: wind fetch matters less when depth no longer limits mixing
    taper = 1.0 / (1.0 + 0.3 * np.clip(lz - 1.8, 0.0, None) ** 2)
    return 4.98241 * np.abs(lz) ** 0.8 + 2.04362 * np.log10(1.0 + np.maximum(A_s, 0.0)) * taper