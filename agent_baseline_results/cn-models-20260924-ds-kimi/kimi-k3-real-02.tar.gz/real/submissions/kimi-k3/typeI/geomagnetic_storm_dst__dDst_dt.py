"""Burton/O'Brien-McPherron ring-current model: dDst*/dt = Q(Ey) - Dst*/tau(Ey).

Injection Q = -a*max(Ey-Ec,0) (dawn-dusk electric field above a small threshold
drives ring-current injection). Decay time tau = t0*exp(-t1*Ey) shortens under
strong driving. Dst* = Dst - b*sqrt(P_dyn) + c corrects for magnetopause
currents; the fitted (b,c) combination acts as an effective pressure offset.
6 fitted constants. Train RMSE ~ 2.967 nT/hr; behaves sensibly across test range.
"""
import numpy as np

USED_INPUTS = ["Dst", "Ey", "P_dyn", "V_sw", "Bz_GSM", "n_sw", "B_mag", "T_sw"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    Dst = X[:, 0]
    Ey  = X[:, 1]
    P   = X[:, 2]
    Q = -2.47748 * np.clip(Ey - 0.13235, 0.0, None)
    tau = np.clip(21.49776 * np.exp(-0.02831 * Ey), 0.3, 300.0)
    Dststar = Dst - (-9.42165) * np.sqrt(P) + (-20.00631)
    return Q - Dststar / tau