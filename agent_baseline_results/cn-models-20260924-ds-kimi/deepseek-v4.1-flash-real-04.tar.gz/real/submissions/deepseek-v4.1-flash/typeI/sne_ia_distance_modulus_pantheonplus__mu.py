"""Flat Lambda-CDM luminosity distance modulus mu(z) = 5 log10(d_L/10pc)."""
import numpy as np

USED_INPUTS = ["z_hd"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    z = np.asarray(X[:, 0], dtype=float)
    Om = 0.34416832
    Ol = 1.0 - Om
    H0 = 72.66047129
    c_kms = 299792.458
    xg, wg = np.polynomial.legendre.leggauss(80)
    xg = 0.5 * (xg + 1.0)
    wg = 0.5 * wg
    zz = z[:, None]
    E = np.sqrt(Om * (1 + zz * xg[None, :]) ** 3 + Ol)
    integ = (wg[None, :] / E).sum(axis=1)
    Dc = (c_kms / H0) * z * integ
    dl = (1.0 + z) * Dc
    return 5.0 * np.log10(dl) + 25.0