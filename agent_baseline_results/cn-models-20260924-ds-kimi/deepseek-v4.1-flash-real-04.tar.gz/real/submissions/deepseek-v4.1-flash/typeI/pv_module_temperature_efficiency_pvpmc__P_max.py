"""Quadratic irradiance response (in G/1000) with quadratic temperature and air-mass
corrections, fit on the full training set.

P = G * (a + b*g + c*g^2) * (1 + d*t + e*t^2) * (1 + f*am + h*am^2)
with g = G/1000, t = Tc - 25 (deg C), am = AM - 1.5.
"""
import numpy as np

USED_INPUTS = ["G_W_m2", "T_module_C", "air_mass"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    G = X[:, 0]
    Tc = X[:, 1]
    AM = X[:, 3]
    g = G / 1000.0
    t = Tc - 25.0
    am = AM - 1.5
    eff = 0.218674986 + 0.0107900106 * g - 0.0222022622 * g * g
    tf = 1.0 + (-0.00103017651) * t + (-2.57528609e-05) * t * t
    af = 1.0 + 0.0665053628 * am + (-0.0423773557) * am * am
    return G * eff * tf * af