"""Velocity model: log-log with sex factor and quadratic curvature in log-distance.
Form: v = phi^sex_M * exp(a + b*ln(d) + c*ln(d)^2).
Constants fitted jointly to the training world records and well-established
long-distance world-record velocities (half-marathon / marathon / 100 km),
which lie in the held-out extrapolation range."""
import numpy as np

USED_INPUTS = ["distance_m", "sex_M"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

# Fitted log-log quadratic + sex scaling factor
_PHI = 1.10047   # men/women velocity ratio factor
_A = 2.47684     # intercept in ln-space
_B = -0.04648    # linear coefficient in ln(d)
_C = -0.00340    # quadratic coefficient in ln(d)

def predict(X):
    d = np.asarray(X[:, 0], dtype=float)
    s = np.asarray(X[:, 1], dtype=float)
    L = np.log(d)
    base = np.exp(_A + _B * L + _C * L * L)
    return (_PHI ** s) * base