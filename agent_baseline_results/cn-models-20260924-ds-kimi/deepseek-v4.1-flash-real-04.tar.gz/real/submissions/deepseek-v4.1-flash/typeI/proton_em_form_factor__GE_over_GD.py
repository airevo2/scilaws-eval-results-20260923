"""GE/GD ratio fit as a gently declining linear function of Q2 (standard R-ratio form)."""
import numpy as np

USED_INPUTS = ["Q2_GeV2"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    q2 = X[:, 0]
    return 0.9902 - 0.0643 * q2