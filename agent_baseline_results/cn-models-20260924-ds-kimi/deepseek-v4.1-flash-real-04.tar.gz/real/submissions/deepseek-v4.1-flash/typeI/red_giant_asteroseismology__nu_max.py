"""Single power-law scaling relation nu_max = A * delta_nu^b.

The dominant seismological scaling for the frequency of maximum oscillation
power is a power law in the large frequency separation.  Both the physical
asteroseismic scaling relation (nu_max ~ g Teff^-0.5, with g ~ Delta_nu^(4/3)
for roughly equal-mass red giants) and the empirical data support an exponent
near 4/3.  Fitting the training data in log space (appropriate because the
measurement errors are constant in fractional terms) gives a two-parameter
power law that is the best available description.

Constants A and b are the two global fitted constants (log-space ordinary
least-squares over all 12875 training rows):
    A = exp(1.6455) = 5.1838
    b = 1.3592
This form is smooth, monotonic and physically sensible well beyond the
training range of delta_nu.
"""
import numpy as np

USED_INPUTS = ["delta_nu"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    dn = X[:, 0]
    return 5.1838 * dn ** 1.35923