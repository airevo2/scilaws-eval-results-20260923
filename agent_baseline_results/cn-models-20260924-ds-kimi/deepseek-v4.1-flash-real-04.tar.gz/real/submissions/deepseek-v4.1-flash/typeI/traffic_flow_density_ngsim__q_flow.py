"""Logarithmic density-flow relation with additive corridor and time offsets.

Physically: per-lane flow rises steeply at low density and bends over
(logarithmic-like saturation), consistent with the fundamental diagram's
congested-branch curvature.  Corridor identity shifts the flow level
(different corridors have different operating regimes) and the recording
time bin carries a mild negative trend (congestion build-up).  Four global
constants, all baked in as literals.
"""
import numpy as np

USED_INPUTS = ["k_veh_km_lane", "corridor", "t_bin_s"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}


def predict(X):
    k = X[:, 0]          # veh/km/lane
    corridor = X[:, 1]   # 0 = US-101, 1 = I-80
    t = X[:, 3]          # start time of bin (s)
    a = 1147.145
    b = 7.37
    d = -538.956
    e = -0.693
    return a * np.log1p(k / b) + d * corridor + e * t