"""FEV1 power-law in height with age attenuation: a*h^b*(1-c*age)^d."""
import numpy as np

USED_INPUTS = ["age", "height_cm"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    age = X[:, 0]
    h = X[:, 1]
    a = 1.89765158e-04
    b = 1.94924656e+00
    c = 8.67217717e-03
    d = 6.56005061e-01
    return a * h ** b * (1.0 - c * age) ** d