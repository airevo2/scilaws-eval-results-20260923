"""Multi-linear SMBH mass relation with sigma0, spheroid mass, and pseudobulge flag."""
import numpy as np

USED_INPUTS = ["sigma0", "log_M_sph", "Pseudobulge"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    sigma0 = X[:, 0]
    log_M_sph = X[:, 1]
    pseudobulge = X[:, 3]
    return 0.0069 * sigma0 + 0.3876 * log_M_sph - 0.6087 * pseudobulge + 2.7988