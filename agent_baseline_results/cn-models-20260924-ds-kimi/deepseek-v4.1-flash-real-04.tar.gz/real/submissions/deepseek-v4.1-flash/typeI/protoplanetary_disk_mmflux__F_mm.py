"""Flux model: mm flux grows with stellar mass for detections; upper limits sit at a fixed lower offset."""
import numpy as np

USED_INPUTS = ["log10_M_star", "log10_M_star_BCAH98", "log10_M_star_SDF00", "is_F_uplim"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    logM = X[:, 0:3].mean(axis=1)
    flag = X[:, 3]
    z = logM * (1.0 - flag) - flag
    a = -1.3518970943566098
    b = 1.0335416775459023
    return a + b * z