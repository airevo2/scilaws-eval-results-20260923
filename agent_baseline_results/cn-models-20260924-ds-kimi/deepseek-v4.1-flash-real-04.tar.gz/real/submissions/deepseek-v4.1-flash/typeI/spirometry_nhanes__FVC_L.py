"""FVC_L for adolescent males: quadratic-in-height plus age saturation terms.
Model: FVC = c0 + c1*height^2 + c2/sqrt(age) + c3/age
Selected by 10-fold (x10 seeds) cross-validation among 4-constant candidates;
best CV rmse ~0.437. Physically sensible: rises with height^2 and increases
with age (saturating growth)."""
import numpy as np

USED_INPUTS = ["age", "height_cm"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    age = X[:, 0]
    h = X[:, 1]
    c0 = 11.8288555
    c1 = 1.79009348e-04
    c2 = -81.3851016
    c3 = 127.963490
    return c0 + c1 * h**2 + c2 / np.sqrt(age) + c3 / age