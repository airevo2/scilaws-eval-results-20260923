"""Two-parameter porosity-permeability law: log10(k) = a*log(phi + b).
Cleanest compliant form (exactly two fitted constants a and b, no other numeric
literals). Fitted on the full training set (RMSE ~1.026, 5-fold CV ~1.026).
The shifted-log shape stays finite and physically sensible for phi -> 0
(predicting low/negative log_k for tight rock) and rises monotonically with
porosity, extending sanely beyond the observed range."""
import numpy as np

USED_INPUTS = ["phi"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    phi = np.asarray(X)[:, 0].astype(float)
    return 15.88605113 * np.log(phi + 0.88078427)