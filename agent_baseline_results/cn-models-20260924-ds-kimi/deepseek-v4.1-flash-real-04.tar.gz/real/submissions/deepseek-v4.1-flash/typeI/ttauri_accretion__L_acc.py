"""logL_acc fit: logL_acc = a*logL_star + b*(log10 M_star)^2 + c."""
import numpy as np

USED_INPUTS = ["logL_star", "M_star_B98"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    logL = X[:, 0]
    M = X[:, 1]
    logM = np.log10(M)
    return -0.982 + 0.991 * logL - 1.651 * logM**2