"""Quadratic-in-logs gravity model with combined trade-policy dummies.

Fitted by OLS on 470,769 bilateral observations (5-fold CV RMSE ≈ 2.481).
Form: ln X_ij = a0 + a1*ln d + a2*(lnY_i+lnY_n)^2 + a3*lnY_n
             + a4*(lnY_n)^2 + a5*lnY_n*(ln d)^2
             + a6*(contig + comlang_off + col_dep_ever + fta_wto)
"""
import numpy as np

USED_INPUTS = ["log_gdp_o", "log_gdp_d", "log_dist",
               "contig", "comlang_off", "col_dep_ever", "fta_wto"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}


def predict(X):
    go = X[:, 0]
    gd = X[:, 1]
    d = X[:, 2]
    c = X[:, 3]
    cl = X[:, 4]
    cd = X[:, 5]
    fta = X[:, 6]

    g = go + gd
    policy = c + cl + cd + fta

    return (25.2392
            - 3.0123 * d
            + 0.0169 * g ** 2
            - 1.6530 * gd
            + 0.0246 * gd ** 2
            + 0.0065 * gd * d ** 2
            + 0.7851 * policy)