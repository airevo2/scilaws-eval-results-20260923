"""Chave-type pantropical power-law: AGB = a*(rho * D^2 * H)^b.
Fitted by minimizing log10 MAE on the training set."""
import numpy as np

USED_INPUTS = ["wood_density", "diameter_cm", "height_m"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    rho = X[:, 0]
    D = X[:, 1]
    H = X[:, 2]
    a = 0.059330
    b = 0.983680
    comp = rho * (D ** 2) * H
    return a * np.power(comp, b)