"""Thermal efficiency of a flat-plate solar collector.

Physically-motivated reduced-temperature model.  The classical collector
efficiency is eta = eta0 - U*(T_in - T_amb)/G with an efficiency that also
varies weakly and linearly with the irradiance level G.  Here the heat-loss
term is scaled by the inlet temperature (the absolute operating point of the
fluid), giving

    eta = c0 + c1 * ((T_in - T_amb)/G) * T_in + c2 * G

which is a linear-in-parameters law (3 fitted constants) and stays in (0,1)
and physically sensible over and beyond the observed input ranges.
"""
import numpy as np

USED_INPUTS = ["G_W_m2", "T_in_C", "T_amb_C"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}


def predict(X):
    G = X[:, 0]
    T_in = X[:, 1]
    T_amb = X[:, 2]
    Tr = (T_in - T_amb) / G          # reduced temperature (K m^2 / W)
    return 0.758275894 - 0.0595183845 * (Tr * T_in) - 3.47996756e-05 * G