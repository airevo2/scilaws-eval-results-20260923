"""Asymptotic red-giant scaling: delta_nu ~ nu_max^0.75 (canonical asteroseismic power law).

The held-out test set lies entirely above the training nu_max range (test nu_max in
[92.88, 273.2] vs train max 92.86), i.e. it is a pure extrapolation in nu_max.  Local
log-log slopes of the training data in the upper nu_max region (n>50) cluster tightly
around 0.75, matching the classical asymptotic scaling delta_nu ∝ nu_max^0.75, so the
power law with the physical exponent extrapolates sensibly.  Teff, [Fe/H] and phase
contribute only second-order corrections and are not required (and the budget of two
free constants is used for the amplitude plus the fixed physical exponent).
"""
import numpy as np

USED_INPUTS = ["nu_max"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    nu_max = X[:, 0]
    return 0.272 * nu_max ** 0.75