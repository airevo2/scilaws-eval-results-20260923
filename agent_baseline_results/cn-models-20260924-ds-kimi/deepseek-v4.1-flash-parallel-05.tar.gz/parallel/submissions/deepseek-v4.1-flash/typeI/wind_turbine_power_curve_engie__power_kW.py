"""Standard utility-scale wind turbine power curve: piecewise
cut-in / cubic ramp / rated plateau (Betz cubic law between cut-in and rated).

P(v) = 0                                      for v < v_ci
     = P_r * (v^3 - v_ci^3)/(v_r^3 - v_ci^3)  for v_ci <= v < v_r
     = P_r                                    for v >= v_r
with v_ci = 3 m/s, v_r = 11 m/s, P_r = 2000 kW.
"""
import numpy as np

USED_INPUTS = ["wind_speed_mps"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}


def predict(X):
    v = np.asarray(X[:, 0], dtype=float)
    v_ci = 3.0
    v_r = 11.0
    P_r = 2000.0
    out = np.zeros_like(v)
    ramp = (v >= v_ci) & (v < v_r)
    out[ramp] = P_r * (v[ramp] ** 3 - v_ci ** 3) / (v_r ** 3 - v_ci ** 3)
    out[v >= v_r] = P_r
    return out