"""Offset power-law (Mastin-type) plume height: H = c + a * MER^b, with the
exponent fixed at the classic Mastin value b = 0.241 (physical constant), leaving
two global fitted constants c (offset) and a (scale)."""
import numpy as np

USED_INPUTS = ["MER_kg_per_s"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    mer = X[:, 0]
    c = 0.6998
    a = 0.2624
    b = 0.241
    return c + a * np.power(mer, b)