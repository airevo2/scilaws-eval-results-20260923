"""Hom / Chick-Watson power-law disinfection model: LR = a * CT^b.

Log10 reduction is a power law of the disinfection dose CT. The exponent b
(cluster-specific) captures the whole observed range from near-flat plateaus
(b -> 0) to steep, super-linear responses (b > 1); a sets the overall scale.
Both parameters are recalibrated per cluster.
"""
import numpy as np

USED_INPUTS = ["CT"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}

LOCAL_FITTABLE = {
    "a": {"init": None},
    "b": {"init": None},
}

def _form(CT, a, b):
    CT = np.clip(np.asarray(CT, dtype=float), 0.0, None)
    return a * np.power(CT, b)

def fit(X_fit, y_fit):
    CT = np.asarray(X_fit[:, 0], dtype=float)
    y = np.asarray(y_fit, dtype=float)
    # Log-log least squares on strictly positive points (power law is linear in log-log).
    mask = (CT > 0.0) & (y > 0.0) & np.isfinite(CT) & np.isfinite(y)
    a, b = None, None
    if mask.sum() >= 2:
        x = np.log(CT[mask])
        ly = np.log(y[mask])
        if np.ptp(x) > 1e-8:
            b_raw, _ = np.polyfit(x, ly, 1)
            b = float(np.clip(b_raw, 0.0, 3.0))
            a = float(np.exp(np.mean(ly - b * x)))
    if a is None or not np.isfinite(a) or a <= 0.0:
        # Fallback: crude scale from positive responses with a mid exponent.
        b = 0.5
        pos = y[y > 0.0]
        scale = float(np.median(pos)) if pos.size else 1.0
        ctm = float(np.median(CT[CT > 0.0])) if np.any(CT > 0.0) else 1.0
        a = scale / (ctm ** b) if ctm ** b > 0 else scale
        a = float(max(a, 1e-6))
    b = float(np.clip(b, 0.0, 3.0))
    a = float(max(a, 1e-9))
    return {"a": a, "b": b}

def predict(X, a, b):
    return _form(np.asarray(X)[:, 0], a, b)