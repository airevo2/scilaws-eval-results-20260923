"""Classic 2-parameter Geiger–Nuttall / Viola–Seaborg form:
log10(T1/2 / s) = a / sqrt(Q_alpha) + b, with a and b re-fit per cluster
(they absorb the Z-dependence of the parent isotope chain)."""
import numpy as np

USED_INPUTS = ["Q_alpha_MeV"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {"a": {"init": None}, "b": {"init": None}}


def _form(Q, a, b):
    return a / np.sqrt(Q) + b


def fit(X_fit, y_fit):
    Q = np.asarray(X_fit[:, 0], dtype=float)
    y = np.asarray(y_fit, dtype=float)
    x = 1.0 / np.sqrt(Q)
    A = np.vstack([x, np.ones_like(x)]).T
    try:
        coef, *_ = np.linalg.lstsq(A, y, rcond=None)
        a, b = float(coef[0]), float(coef[1])
        if not (np.isfinite(a) and np.isfinite(b)):
            raise ValueError
    except Exception:
        a, b = 100.0, -35.0
    return {"a": a, "b": b}


def predict(X, a, b):
    Q = np.asarray(X[:, 0], dtype=float)
    return _form(Q, a, b)