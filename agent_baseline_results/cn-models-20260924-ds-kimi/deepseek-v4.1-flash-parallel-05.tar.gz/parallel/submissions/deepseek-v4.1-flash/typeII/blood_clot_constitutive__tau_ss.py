"""Simple-shear Cauchy stress of a nonlinear elastic (fibrin) network.

For an isotropic incompressible hyperelastic solid under simple shear,
I1 = I2 = 3 + gamma^2, so the shear stress is tau = 2(dW/dI1 + dW/dI2)*gamma,
i.e. an ODD function of gamma of the form tau = gamma * f(gamma^2).
Truncating at the leading strain-stiffening order gives the two-term form

    tau_ss = a * gamma + b * gamma^3

where `a` (initial shear modulus) and `b` (stiffening coefficient) are the
per-cluster parameters.  Both the linear and the cubic term were visible in
the observed curves (nearly linear response for |gamma| < ~0.15, cubic
stiffening above), so this single mechanism is used for every cluster.
"""
import numpy as np

USED_INPUTS = ["gamma"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {"a": {"init": None}, "b": {"init": None}}


def _design(g):
    return np.vstack([g, g ** 3]).T


def fit(X_fit, y_fit):
    g = np.asarray(X_fit[:, 0], dtype=float).ravel()
    y = np.asarray(y_fit, dtype=float).ravel()
    M = _design(g)
    # Robust-ish least squares on the two odd basis functions.
    try:
        coef, *_ = np.linalg.lstsq(M, y, rcond=None)
        a, b = float(coef[0]), float(coef[1])
    except Exception:
        a, b = 0.0, 6.0
    if not np.isfinite(a):
        a = 0.0
    if not np.isfinite(b):
        b = 6.0
    return {"a": a, "b": b}


def predict(X, a, b):
    g = np.asarray(X[:, 0], dtype=float).ravel()
    return a * g + b * g ** 3