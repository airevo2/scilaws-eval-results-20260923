"""Brutsaert nonlinear-reservoir baseflow recession:
Q(t) = Q_0 * (1 + (b-1) * a * Q_0^(b-1) * t)^(-1/(b-1)).
Two per-cluster parameters (a, b) are shared across all events of a gauge;
the dependence on the row-level initial discharge Q_0 makes higher-Q_0
recessions decay faster in relative terms, as observed."""
import numpy as np
from scipy.optimize import least_squares

USED_INPUTS = ["t", "Q_0"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {"a": {"init": None}, "b": {"init": None}}


def _form(t, Q0, a, b):
    m = b - 1.0
    return Q0 * (1.0 + m * a * Q0 ** m * t) ** (-1.0 / m)


def fit(X_fit, y_fit):
    t = X_fit[:, 0].astype(float)
    Q0 = X_fit[:, 1].astype(float)
    y = np.clip(y_fit.astype(float), 1e-9, None)
    mask = t >= 1.0
    if mask.sum() < 3:
        mask = np.ones_like(t, dtype=bool)
    t, Q0, y = t[mask], Q0[mask], y[mask]
    logy = np.log(y)

    def resid(p):
        a = np.exp(p[0])
        b = 1.0 + np.exp(p[1])
        pred = _form(t, Q0, a, b)
        return np.log(np.clip(pred, 1e-9, None)) - logy

    a0, b0 = 0.01, 1.4
    try:
        r = least_squares(resid, [np.log(a0), np.log(b0 - 1.0)],
                          max_nfev=2000)
        a = float(np.exp(r.x[0]))
        b = float(1.0 + np.exp(r.x[1]))
    except Exception:
        a, b = a0, b0
    if not np.isfinite(a) or a <= 0:
        a = a0
    if not np.isfinite(b) or b <= 1.001:
        b = b0
    return {"a": a, "b": b}


def predict(X, a, b):
    t = np.asarray(X[:, 0], dtype=float)
    Q0 = np.asarray(X[:, 1], dtype=float)
    m = b - 1.0
    base = 1.0 + m * a * Q0 ** m * t
    base = np.clip(base, 1e-12, None)
    return Q0 * base ** (-1.0 / m)