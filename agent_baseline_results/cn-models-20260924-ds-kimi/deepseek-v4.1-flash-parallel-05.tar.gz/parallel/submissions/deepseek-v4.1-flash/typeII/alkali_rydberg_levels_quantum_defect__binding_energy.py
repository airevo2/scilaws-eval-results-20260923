"""Rydberg-Ritz: binding energy E = R/(n - delta)^2 with a quantum defect
delta = d0 + d2/(n - d0)^2 (Rydberg-Ritz expansion).  The Rydberg constant R,
the series limit's quantum defect d0 and the Ritz correction d2 are re-fit per
cluster; the functional shape is identical for every cluster."""
import numpy as np
from scipy.optimize import least_squares

USED_INPUTS = ["n_qm"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {"R": {"init": [109737.0]}, "d0": {"init": [2.0]}, "d2": {"init": [1.0]}}

def _delta(n, d0, d2):
    base = np.maximum(n - d0, 1e-3)
    return d0 + d2 / base**2

def _form(n, R, d0, d2):
    d = _delta(n, d0, d2)
    return R / np.maximum(n - d, 1e-3)**2

def fit(X_fit, y_fit):
    n = np.asarray(X_fit[:, 0], dtype=float)
    y = np.asarray(y_fit, dtype=float)
    # initial guesses
    R0 = float(np.median(y * (n - 0.5)**2))
    if not np.isfinite(R0) or R0 <= 0:
        R0 = 109737.0
    # crude estimate of d0 via fixed physical R
    Rph = 109737.31568
    d0_0 = float(np.median(n - np.sqrt(Rph / np.maximum(y, 1e-9))))
    if not np.isfinite(d0_0):
        d0_0 = 0.5

    def resid(p):
        R, d0, d2 = p
        return _form(n, R, d0, d2) - y

    best = None
    for p0 in ([R0, d0_0, 1.0], [Rph, d0_0, 0.0], [R0, d0_0, -1.0],
               [Rph, max(d0_0, 0.0), 0.5]):
        try:
            res = least_squares(resid, p0, method="lm", max_nfev=20000)
            if best is None or res.cost < best.cost:
                best = res
        except Exception:
            continue
    if best is None:
        return {"R": R0, "d0": d0_0, "d2": 0.0}
    R, d0, d2 = best.x
    if not (np.isfinite(R) and np.isfinite(d0) and np.isfinite(d2)):
        return {"R": R0, "d0": d0_0, "d2": 0.0}
    return {"R": float(R), "d0": float(d0), "d2": float(d2)}

def predict(X, R, d0, d2):
    n = np.asarray(X[:, 0], dtype=float)
    return _form(n, R, d0, d2)