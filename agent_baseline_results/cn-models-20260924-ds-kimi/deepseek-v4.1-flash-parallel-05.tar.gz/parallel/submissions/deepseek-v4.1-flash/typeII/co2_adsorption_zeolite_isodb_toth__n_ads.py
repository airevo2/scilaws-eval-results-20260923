"""Toth isotherm: n = q * b*P / (1 + (b*P)^t)^(1/t).
The low-pressure log-log slope approaches 1 and then smoothly decreases as
(b*P)^t grows, which matches the observed curvature across all clusters;
only q (capacity), b (affinity) and t (heterogeneity) vary per cluster."""
import numpy as np
from scipy.optimize import least_squares

USED_INPUTS = ["P_bar"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {"q": {"init": None}, "b": {"init": None}, "t": {"init": None}}


def _toth(P, q, b, t):
    P = np.asarray(P, dtype=float)
    bP = np.maximum(np.abs(b) * P, 1e-300)
    return q * bP / np.power(1.0 + np.power(bP, np.abs(t)), 1.0 / np.abs(t))


def fit(X_fit, y_fit):
    P = np.asarray(X_fit[:, 0], dtype=float)
    y = np.asarray(y_fit, dtype=float)
    ym = float(np.max(y)) if len(y) else 1.0
    Pmed = float(np.median(P)) if len(P) else 1.0
    if Pmed <= 0:
        Pmed = 1e-3
    p0s = [
        [max(ym * 1.3, 1e-3), 1.0 / Pmed, 0.5],
        [max(ym * 1.3, 1e-3), 1.0 / Pmed, 0.7],
        [max(ym * 1.3, 1e-3), 10.0 / Pmed, 0.4],
        [max(ym * 1.3, 1e-3), 0.3 / Pmed, 0.8],
        [max(ym * 1.3, 1e-3), 5.0 / Pmed, 0.35],
    ]
    best = None
    for p0 in p0s:
        try:
            r = least_squares(lambda p: y - _toth(P, p[0], p[1], p[2]),
                              p0, method='lm', max_nfev=20000)
            res = float(np.sqrt(np.mean((y - _toth(P, *r.x)) ** 2)))
            if best is None or res < best[0]:
                best = (res, r.x)
        except Exception:
            pass
    if best is None:
        return {"q": max(ym, 1e-3), "b": 1.0 / Pmed, "t": 0.5}
    q, b, t = best[1]
    q = float(abs(q))
    if q <= 0:
        q = max(ym, 1e-3)
    b = float(abs(b))
    if b <= 0:
        b = 1.0 / Pmed
    t = float(min(max(abs(t), 1e-2), 5.0))
    return {"q": q, "b": b, "t": t}


def predict(X, q, b, t):
    P = np.asarray(X[:, 0], dtype=float)
    out = _toth(P, q, b, t)
    return np.nan_to_num(out, nan=0.0, posinf=0.0, neginf=0.0)