"""Generalized cardinal-temperature (beta) thermal performance curve for OD600(24h).

    OD(T) = A * (T - Tmin)^alpha * (Tmax - T)^beta   for Tmin < T < Tmax
          = 0                                        otherwise

The shared functional form is a cardinal-temperature / beta curve: growth is
zero below a minimum temperature Tmin and above a maximum temperature Tmax, and
rises to a single interior optimum. Only the curve parameters (amplitude,
cardinal temperatures, and the two shape exponents) are re-fit per antibiotic
background (cluster).
"""
import numpy as np
from scipy.optimize import curve_fit

USED_INPUTS = ["T"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {
    "A": {"init": [0.5]},
    "Tmin": {"init": [18.0]},
    "Tmax": {"init": [46.0]},
    "alpha": {"init": [2.0]},
    "beta": {"init": [1.0]},
}


def _form(T, A, Tmin, Tmax, alpha, beta):
    T = np.asarray(T, dtype=float)
    v = np.clip(T - Tmin, 0.0, None)
    w = np.clip(Tmax - T, 0.0, None)
    return A * np.power(v, alpha) * np.power(w, beta)


def fit(X_fit, y_fit):
    T = np.asarray(X_fit[:, 0], dtype=float)
    y = np.asarray(y_fit, dtype=float)

    # Sensible fallback / starting point from the data.
    A0 = max(float(np.nanmax(y)) * 20.0, 1e-3)
    p0 = [A0, 18.0, 46.0, 2.0, 1.0]
    lo = [0.0, -60.0, 40.0, 0.3, 0.3]
    hi = [1e3, 32.0, 90.0, 10.0, 10.0]

    try:
        popt, _ = curve_fit(_form, T, y, p0=p0, bounds=(lo, hi), maxfev=8000)
        A, Tmin, Tmax, alpha, beta = [float(p) for p in popt]
    except Exception:
        A, Tmin, Tmax, alpha, beta = p0

    # Guard against degenerate / non-finite fits.
    if not np.all(np.isfinite([A, Tmin, Tmax, alpha, beta])) or A < 0:
        A, Tmin, Tmax, alpha, beta = p0
    if Tmin >= Tmax:
        Tmin, Tmax = 18.0, 46.0

    return {"A": A, "Tmin": Tmin, "Tmax": Tmax, "alpha": alpha, "beta": beta}


def predict(X, A, Tmin, Tmax, alpha, beta):
    return _form(X[:, 0], A, Tmin, Tmax, alpha, beta)