"""Hidden chiller mechanism: 1/COP is linear in the condenser/evaporator inlet
temperatures plus a fixed-loss (1/Q_e) and a load-degradation (Q_e) term.

1/COP - 1 = c0 + c1*T_ci + c2*T_ei + c3/Q_e + c4*Q_e
"""
import numpy as np

USED_INPUTS = ["T_ei", "T_ci", "Q_e"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}

LOCAL_FITTABLE = {
    "c0": {"init": None},
    "c1": {"init": None},
    "c2": {"init": None},
    "c3": {"init": None},
    "c4": {"init": None},
}


def _design(X):
    Te = X[:, 0]
    Tc = X[:, 1]
    Q = X[:, 2]
    Qs = np.where(np.abs(Q) < 1e-9, 1e-9, Q)
    return np.column_stack([np.ones_like(Qs), Tc, Te, 1.0 / Qs, Qs])


def fit(X_fit, y_fit):
    # Linear least squares: robust, fast, no initial guess needed.
    try:
        A = _design(np.asarray(X_fit, dtype=float))
        coef, _, _, _ = np.linalg.lstsq(A, np.asarray(y_fit, dtype=float), rcond=None)
        return {
            "c0": float(coef[0]),
            "c1": float(coef[1]),
            "c2": float(coef[2]),
            "c3": float(coef[3]),
            "c4": float(coef[4]),
        }
    except Exception:
        ybar = float(np.mean(y_fit)) if len(y_fit) else 0.0
        return {"c0": ybar, "c1": 0.0, "c2": 0.0, "c3": 0.0, "c4": 0.0}


def predict(X, c0, c1, c2, c3, c4):
    X = np.asarray(X, dtype=float)
    Te = X[:, 0]
    Tc = X[:, 1]
    Q = X[:, 2]
    Qs = np.where(np.abs(Q) < 1e-9, 1e-9, Q)
    return c0 + c1 * Tc + c2 * Te + c3 / Qs + c4 * Qs