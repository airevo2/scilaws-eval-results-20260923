"""Human-capital-augmented, per-worker (development-accounting) Cobb-Douglas form.

The hidden simulator generates aggregate output from capital (K = cn),
labour (L = emp) and a human-capital index (h = hc).  Working in per-worker
terms, the recovered mechanism is a log-linear production function in the
capital-labour ratio and human capital:

    log_Y = ln(Y/L) = A + alpha * ln(K/L) + beta * ln(h)

i.e.  Y = exp(A) * K^alpha * L^(1-alpha) * h^beta.

The SAME linear-in-logs shape holds for every cluster; only the three
per-cluster coefficients (TFP term A, capital-ratio share alpha, and the
human-capital elasticity beta) are re-calibrated from each cluster's own
fit window.  No group identifier is used anywhere.
"""
import numpy as np

USED_INPUTS = ["cn", "emp", "hc"]      # K, L, h
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {"A": {"init": None}, "alpha": {"init": None}, "beta": {"init": None}}


def _features(X):
    K = np.clip(np.asarray(X[:, 0], dtype=float), 1e-12, None)
    L = np.clip(np.asarray(X[:, 1], dtype=float), 1e-12, None)
    h = np.clip(np.asarray(X[:, 2], dtype=float), 1e-12, None)
    x1 = np.log(K) - np.log(L)     # ln(K/L)
    x2 = np.log(h)                 # ln(h)
    return x1, x2


def _form(X, A, alpha, beta):
    x1, x2 = _features(X)
    return A + alpha * x1 + beta * x2


def fit(X_fit, y_fit):
    X_fit = np.asarray(X_fit, dtype=float)
    y_fit = np.asarray(y_fit, dtype=float)
    x1, x2 = _features(X_fit)
    D = np.column_stack([np.ones_like(x1), x1, x2])
    try:
        coef, *_ = np.linalg.lstsq(D, y_fit, rcond=None)
        A, alpha, beta = (float(coef[0]), float(coef[1]), float(coef[2]))
        if not (np.isfinite(A) and np.isfinite(alpha) and np.isfinite(beta)):
            raise ValueError
    except Exception:
        # robust fallbacks: mean level, unit capital share, small h share
        A = float(np.mean(y_fit)) if len(y_fit) else 0.0
        alpha, beta = 1.0 / 3.0, 0.0
    return {"A": A, "alpha": alpha, "beta": beta}


def predict(X, A, alpha, beta):
    return _form(np.asarray(X, dtype=float), A, alpha, beta)