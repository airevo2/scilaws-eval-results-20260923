"""Power-exponential decay of occurrence-based Sørensen similarity with
environmental distance:  S = A * exp(-(d/L)^gamma),  gamma shared (~0.3),
A and L are the two per-cluster parameters (intercept-like amplitude and the
environmental-distance decay scale of each dataset)."""
import numpy as np
from scipy.optimize import curve_fit

USED_INPUTS = ["env_dist"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {"A": {"init": None}, "L": {"init": None}}

GAMMA = 0.3


def _form(d, A, L):
    L = np.maximum(L, 1e-9)
    return A * np.exp(-np.power(np.maximum(d, 0.0) / L, GAMMA))


def fit(X_fit, y_fit):
    d = np.asarray(X_fit[:, 0], dtype=float)
    y = np.asarray(y_fit, dtype=float)
    A0 = float(np.max(y)) if len(y) else 0.6
    A0 = max(A0, 1e-3)
    L0 = float(np.median(d)) if len(d) else 1.0
    L0 = max(L0, 1e-3)
    try:
        popt, _ = curve_fit(
            _form, d, y,
            p0=[A0, L0],
            bounds=([0.0, 1e-6], [5.0, 1e6]),
            maxfev=20000,
        )
        A, L = float(popt[0]), float(popt[1])
        if not (np.isfinite(A) and np.isfinite(L)) or L <= 0:
            raise ValueError
        return {"A": A, "L": L}
    except Exception:
        return {"A": A0, "L": L0}


def predict(X, A, L):
    d = np.asarray(X[:, 0], dtype=float)
    return _form(d, A, L)