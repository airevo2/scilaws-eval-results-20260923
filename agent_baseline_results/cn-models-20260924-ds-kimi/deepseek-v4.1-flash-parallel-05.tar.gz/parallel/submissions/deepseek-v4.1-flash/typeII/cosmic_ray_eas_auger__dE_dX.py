"""Gaisser-Hillas longitudinal shower profile: dE/dX = N * ((X-X0)/(Xm-X0))^((Xm-X0)/lam) * exp((Xm-X)/lam).
Shared functional form across all clusters; N, X0, Xm, lam are per-cluster (locally fitted)."""
import numpy as np

USED_INPUTS = ["X"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {
    "N":    {"init": None},
    "X0":   {"init": None},
    "Xm":   {"init": None},
    "lam":  {"init": None},
}


def _gh(X, N, X0, Xm, lam):
    X = np.asarray(X, float)
    arg = (X - X0) / (Xm - X0)
    arg = np.clip(arg, 1e-12, None)
    return N * arg ** ((Xm - X0) / lam) * np.exp((Xm - X) / lam)


def fit(X_fit, y_fit):
    from scipy.optimize import least_squares

    X = np.asarray(X_fit, float).ravel()
    y = np.asarray(y_fit, float).ravel()
    pos = y > 0
    if pos.sum() >= 4:
        X, y = X[pos], y[pos]

    xp = float(X[np.argmax(y)])
    ymax = float(np.max(y))
    xmin = float(np.min(X))
    xmax = float(np.max(X))

    p0 = [ymax, xmin - 50.0, xp, 70.0]
    lb = [ymax * 1e-3, xmin - 3000.0, xmin, 5.0]
    ub = [ymax * 1e3, xmin - 1e-3, xmax + 1000.0, 5000.0]

    def resid(p):
        return np.log(_gh(X, *p)) - np.log(y)

    try:
        sol = least_squares(resid, p0, bounds=(lb, ub), max_nfev=5000)
        N, X0, Xm, lam = sol.x
    except Exception:
        N, X0, Xm, lam = p0

    # sanity fallbacks
    if not np.all(np.isfinite([N, X0, Xm, lam])) or N <= 0 or lam <= 0:
        N, X0, Xm, lam = ymax, xmin - 50.0, xp, 70.0

    return {"N": float(N), "X0": float(X0), "Xm": float(Xm), "lam": float(lam)}


def predict(X, N, X0, Xm, lam):
    return _gh(X, N, X0, Xm, lam)