"""Generalized von Bertalanffy growth (Puetter form): L(t) = Linf * (1 - exp(-K*t))^p.
Per-cluster parameters Linf (asymptotic length), K (growth rate), p (allometric exponent),
which gives the observed power-law initial rise (t^p) and saturating asymptote."""
import numpy as np
from scipy.optimize import curve_fit

USED_INPUTS = ["Agei"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {"Linf": {"init": None}, "K": {"init": None}, "p": {"init": None}}

def _form(t, Linf, K, p):
    t = np.asarray(t, dtype=float)
    base = 1.0 - np.exp(-K * np.clip(t, 0.0, None))
    return Linf * np.power(np.clip(base, 0.0, None), p)

def fit(X_fit, y_fit):
    t = np.asarray(X_fit[:, 0], dtype=float)
    y = np.asarray(y_fit, dtype=float)
    ymax = float(np.max(y)) if len(y) else 100.0
    if not np.isfinite(ymax) or ymax <= 0:
        ymax = 100.0
    p0 = [ymax * 1.2, 0.3, 0.4]
    try:
        popt, _ = curve_fit(
            _form, t, y, p0=p0,
            bounds=([ymax * 0.9, 1e-6, 1e-3], [ymax * 6.0, 50.0, 3.0]),
            maxfev=20000)
        Linf, K, p = popt
    except Exception:
        Linf, K, p = p0
    return {"Linf": float(Linf), "K": float(K), "p": float(p)}

def predict(X, Linf, K, p):
    return _form(X[:, 0], Linf, K, p)