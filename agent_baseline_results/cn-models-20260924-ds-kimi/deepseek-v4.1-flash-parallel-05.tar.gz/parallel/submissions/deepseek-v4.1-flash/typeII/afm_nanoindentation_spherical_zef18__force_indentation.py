"""Hertzian spherical-probe contact law: F = (4/3) E* sqrt(R) * delta^{3/2}.
The single per-cluster parameter is the elastic prefactor k (k = (4/3) E* sqrt(R)),
which absorbs the constant tip radius R for this dataset."""
import numpy as np

USED_INPUTS = ["indentation_m"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {"k": {"init": [0.5]}}

def _form(delta, k):
    d = np.clip(delta, 0.0, None)
    return k * np.power(d, 1.5)

def fit(X_fit, y_fit):
    d = np.clip(X_fit[:, 0], 0.0, None)
    x = np.power(d, 1.5)
    denom = float(np.sum(x * x))
    if denom <= 0.0:
        k = 0.0
    else:
        k = float(np.sum(x * y_fit) / denom)
    if not np.isfinite(k) or k <= 0.0:
        # robust fallback from the largest indentation point
        dmax = float(np.max(d)) if d.size else 1.0
        ymax = float(np.max(y_fit)) if y_fit.size else 0.0
        k = ymax / (dmax ** 1.5) if dmax > 0 else 0.0
    return {"k": k}

def predict(X, k):
    return _form(X[:, 0], k)