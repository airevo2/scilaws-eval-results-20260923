"""Logistic (sigmoidal) growth: OD600(t) = bg + A / (1 + exp(-r (t - t0))).
Per-cluster parameters: background bg, amplitude A (carrying capacity), growth rate r,
and inflection time t0. Non-growing wells have A ~ 0."""
import numpy as np
from scipy.optimize import curve_fit

USED_INPUTS = ["time_h"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {
    "bg": {"init": None},
    "A": {"init": None},
    "r": {"init": None},
    "t0": {"init": None},
}

def _form(t, bg, A, r, t0):
    return bg + A / (1.0 + np.exp(-r * (t - t0)))

def fit(X_fit, y_fit):
    t = np.asarray(X_fit[:, 0], dtype=float)
    y = np.asarray(y_fit, dtype=float)
    bg0 = float(np.min(y))
    A0 = max(float(np.max(y) - bg0), 1e-4)
    t0_0 = float(t[np.argmax(y)])
    r0 = 0.9
    best = None
    # multi-start to stay robust across growth and non-growth clusters
    for amp in (A0, 0.5 * A0, 0.01):
        for rr in (r0, 0.4, 2.0):
            p0 = [bg0, max(amp, 1e-6), rr, t0_0]
            try:
                popt, _ = curve_fit(_form, t, y, p0=p0, maxfev=20000,
                                    bounds=([-1.0, 0.0, 1e-4, -50.0],
                                            [1.0, 2.0, 20.0, 200.0]))
                sse = float(np.sum((_form(t, *popt) - y) ** 2))
                if best is None or sse < best[0]:
                    best = (sse, popt)
            except Exception:
                continue
    if best is None:
        return {"bg": bg0, "A": A0, "r": r0, "t0": t0_0}
    _, popt = best
    return {"bg": float(popt[0]), "A": float(popt[1]),
            "r": float(popt[2]), "t0": float(popt[3])}

def predict(X, bg, A, r, t0):
    t = np.asarray(X[:, 0], dtype=float)
    return _form(t, bg, A, r, t0)