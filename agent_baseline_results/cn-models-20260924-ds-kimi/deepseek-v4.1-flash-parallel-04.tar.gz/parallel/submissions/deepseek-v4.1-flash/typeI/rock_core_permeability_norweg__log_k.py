"""Power-law permeability-porosity relation: log10(k) = A + B*log10(phi)."""
import numpy as np

USED_INPUTS = ["phi"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    phi = X[:, 0]
    return 4.1 + 3.9 * np.log10(phi)