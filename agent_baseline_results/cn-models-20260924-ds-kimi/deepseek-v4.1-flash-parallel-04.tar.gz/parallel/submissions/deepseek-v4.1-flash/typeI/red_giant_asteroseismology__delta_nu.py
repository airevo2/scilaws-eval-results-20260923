"""Asteroseismic scaling relation: large separation as a power law of nu_max.

The large frequency separation Δν scales with the frequency of maximum
oscillation power ν_max as a power law with the canonical exponent 3/4:
    Δν = A * ν_max^(3/4)
The constant A ≈ 0.2847 was fitted from simulator observations.
"""
import numpy as np

USED_INPUTS = ["nu_max"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    nu_max = X[:, 0]
    return 0.2847 * nu_max ** 0.75