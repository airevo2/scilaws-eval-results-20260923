"""Single power-law scaling of nu_max with delta_nu (solar-like scaling relation)."""
import numpy as np

USED_INPUTS = ["delta_nu"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    d = X[:, 0]
    return 5.05 * np.power(d, 1.35)