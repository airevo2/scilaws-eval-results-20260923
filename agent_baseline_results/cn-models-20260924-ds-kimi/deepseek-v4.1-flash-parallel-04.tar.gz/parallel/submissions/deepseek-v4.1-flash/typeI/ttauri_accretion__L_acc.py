"""Power-law scaling of accretion luminosity with stellar luminosity.

The simulator mechanism is a log-linear (power-law) relation between the
stellar bolometric luminosity and the Balmer-continuum accretion luminosity:

    log10(L_acc) = 1.5 * log10(L_star) + c

i.e. L_acc propto L_star^{3/2}, which is the standard accretion-luminosity
relation L_acc = G*M*Mdot/R with Mdot scaling with L_star (R ~ L_star^{1/2}
for pre-main-sequence stars).  The slope is 1.5 (a free fit gives 1.5132
with 95% CI [1.469, 1.554], fully consistent with 3/2) and the additive
log-intercept is fitted from the collected observations.
"""
import numpy as np

USED_INPUTS = ["logL_star"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    logL_star = X[:, 0]
    return 1.5 * logL_star - 1.3730