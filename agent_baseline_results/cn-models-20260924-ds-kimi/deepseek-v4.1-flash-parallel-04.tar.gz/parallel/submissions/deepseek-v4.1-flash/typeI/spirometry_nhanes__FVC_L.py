"""Additive separable model: FVC = quadratic in height + quadratic in age.

Structure recovered from replicated experiments:
- Age effect is ADDITIVE (increments across age are constant across height),
  not multiplicative. It grows quadratically with age (t^2).
- Height effect is a convex quadratic in height (approx h^2 with a small
  negative linear term), independent of age.
So FVC = a*h^2 + b*h + c*t^2 + d.
"""
import numpy as np

USED_INPUTS = ["age", "height_cm"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    t = X[:, 0]
    h = X[:, 1]
    return 3.31e-4 * h * h - 0.0502 * h + 0.00418 * t * t + 2.585