"""log_M_BH vs log_M_sph: quadratic (concave-up) in log-log space.

The relation log10(M_BH) vs log10(M_sph) is not a single power law: the local
slope rises from ~0.85-1.0 at the low-mass end to ~1.2 at the high-mass end,
and OLS/bin-mean residuals against a straight log-log line trace a clear
U-shape (both ends above the line, middle below). A quadratic in log_M_sph
captures this curvature, improving rms from 0.303 (linear) to ~0.288, with a
quadratic coefficient that is strongly positive under bootstrap (100% of
resamples, ~4 sigma), i.e. an increasing mass slope.

log10(M_BH/Msun) = a*(log_M_sph)^2 + b*log_M_sph + c
fitted over 282 simulator rows: a=0.0604, b=-0.1708, c=3.1447
"""
import numpy as np

USED_INPUTS = ["log_M_sph"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    x = X[:, 0]
    return 0.0604 * x * x - 0.1708 * x + 3.1447