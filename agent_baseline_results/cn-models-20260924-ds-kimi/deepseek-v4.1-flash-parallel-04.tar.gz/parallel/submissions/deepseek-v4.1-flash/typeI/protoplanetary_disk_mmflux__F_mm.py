"""Millimeter continuum flux: power law in stellar mass with a 3-sigma detection floor.

The disk flux follows a power law F = A * M_star^alpha (M_star in solar masses),
and falls to a fixed 3-sigma upper-limit floor of Flim = 0.003 Jy for very
low-mass / faint disks. Fitted in log space:
    log10 F = log10( 10^(logA + alpha*logM) + Flim )
with logA ~ -1.625 (A ~ 0.0237), alpha ~ 1.335, and Flim = 0.003 Jy fixed.
Two free global constants (logA, alpha); the floor is the known survey limit.
"""
import numpy as np

USED_INPUTS = ["log10_M_star_SDF00"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    x = X[:, 0]                       # log10 M_star (dex M_sun)
    logA = -1.6254                    # log10 A
    alpha = 1.3352                    # power-law exponent
    Flim = 0.003                      # 3-sigma flux limit (Jy)
    return np.log10(10.0 ** (logA + alpha * x) + Flim)