"""Tropical tree above-ground biomass power law.

Structure recovered from designed experiments (variation of each input while
holding the others fixed, plus free log-log regression over ~400 group means):

    ln(AGB) = ln(C) + a*ln(rho) + b*ln(D) + c*ln(H)

Fitted exponents (se in parentheses):
    a = 0.997 (0.014)  -> 1   (wood density enters linearly)
    b = 2.020 (0.009)  -> 2   (biomass ~ stem cross-sectional area)
    c = 0.916 (0.008)  -> fractional height exponent

Fixing the two integer exponents (rho^1, D^2), the remaining 2-parameter form
AGB = C * rho * D^2 * H^c fits the group-mean data as well as the fully free
4-parameter regression (rmse 0.200 vs 0.199), and clearly better than the
single-exponent Chave form C*(rho*D^2*H)^p (rmse 0.225, which leaves a
systematic residual trend in ln H).  Fitted C = 0.0651, c = 0.916.
"""
import numpy as np

USED_INPUTS = ["wood_density", "diameter_cm", "height_m"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    rho = X[:, 0]
    D = X[:, 1]
    H = X[:, 2]
    return 0.0651 * rho * D ** 2 * H ** 0.916