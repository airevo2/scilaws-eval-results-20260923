"""Reduced-form log-linear gravity equation: ln X_ij = b0 + b1*lnY_i + b2*lnY_j + b3*ln d_ij + b4*contig + b5*comlang + b6*col_dep. (A symmetric exporter/importer GDP elasticity was rejected; origin and destination elasticities differ markedly.)"""
import numpy as np

USED_INPUTS = ["log_gdp_o", "log_gdp_d", "log_dist", "contig", "comlang_off", "col_dep_ever"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    lgdp_o = X[:, 0]
    lgdp_d = X[:, 1]
    ldist = X[:, 2]
    contig = X[:, 3]
    comlang = X[:, 4]
    col = X[:, 5]
    return (-17.31 + 1.127 * lgdp_o + 0.845 * lgdp_d - 1.173 * ldist
            + 1.215 * contig + 0.934 * comlang + 1.309 * col)