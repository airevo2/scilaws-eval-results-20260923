"""G_E/G_D as a low-Q^2 polynomial expansion in Q^2 (passes through 1 at Q^2=0).

The measured ratio is essentially flat near Q^2=0 (~1) and then falls
increasingly steeply toward high Q^2; a smooth two-term even polynomial in
Q^2 (1 + a*Q^2 + b*Q^4) captures this curvature and is algebraically compact.
"""
import numpy as np

USED_INPUTS = ["Q2_GeV2"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    q2 = X[:, 0]
    a = -0.07630
    b = -0.00843
    return 1.0 + a * q2 + b * q2 * q2