"""Riegel power-law velocity-distance model with a multiplicative sex factor.

Velocity decays as a power law of race distance (Riegel: t = a*d^b  =>  v = C*d^(1-b)),
and men run at a fixed multiple (~1.11x) of women's velocity at every distance,
so the sex effect enters as a constant multiplicative scale (1 + k*sex_M).

Fitted constants (from robust/median fits of the collected records):
  C = 11.86, exponent B = -0.0775, sex coefficient k = 0.112
"""
import numpy as np

USED_INPUTS = ["distance_m", "sex_M"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    d = X[:, 0].astype(float)
    s = X[:, 1].astype(float)
    return 11.86 * np.power(d, -0.0775) * (1.0 + 0.112 * s)