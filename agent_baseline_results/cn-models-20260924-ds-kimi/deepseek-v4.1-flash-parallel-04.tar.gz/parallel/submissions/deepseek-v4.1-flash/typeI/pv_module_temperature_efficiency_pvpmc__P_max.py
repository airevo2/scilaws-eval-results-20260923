"""PV max-power model: sub-linear irradiance response (G^1.5 correction) times a linear temperature coefficient.

Recovered structure from targeted experiments:
  - At fixed T=25, the ratio P/G declines with G, and the decline follows P/G = a - b*sqrt(G)
    (i.e. P = a*G - b*G^1.5).  Fitting the three most reliable points
    (100.2 W/m2 -> 24.11 W, 600 W/m2 -> 130.07 W, 1212 W/m2 -> 242.16 W) gives
    a = 0.25705, b = 0.0016436 exactly, equivalently
    P = 257*(G/1000) - 52*(G/1000)^1.5.  A pure linear (PVWatts) or quadratic form
    does NOT reproduce the three points (quadratic misses G=1212 by ~6%).
  - At fixed G=1000 the power is linear in module temperature with slope -0.4989 W/degC
    on a base of 204.8 W, i.e. a relative coefficient gamma = -0.00244 /degC
    referenced to 25 degC.
"""
import numpy as np

USED_INPUTS = ["G_W_m2", "T_module_C"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}


def predict(X):
    G = X[:, 0]
    T = X[:, 1]
    g = G / 1000.0
    # irradiance response: linear minus a G^1.5 loss term (sub-linear efficiency)
    base = 257.0 * g - 52.0 * g ** 1.5
    # temperature coefficient referenced to 25 degC
    return base * (1.0 - 0.00244 * (T - 25.0))