"""Flat LambdaCDM distance modulus: mu = 25 + 5*log10(dL), dL = (c/H0)(1+z)*Integral dz/E(z) with E(z)=sqrt(Om(1+z)^3+(1-Om))."""
import numpy as np

USED_INPUTS = ["z_hd"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    z = np.asarray(X[:, 0], dtype=float)
    Om = 0.378031
    H0 = 71.71
    c = 299792.458  # km/s

    def E(zp):
        return 1.0 / np.sqrt(Om * (1.0 + zp) ** 3 + (1.0 - Om))

    # cumulative integral of E from 0 to z using Simpson's rule on a grid
    zgrid = np.linspace(0.0, max(z.max(), 1e-6), 4001)
    Eg = E(zgrid)
    # cumulative trapezoid
    dz = zgrid[1] - zgrid[0]
    cum = np.concatenate([[0.0], np.cumsum(0.5 * (Eg[1:] + Eg[:-1]) * dz)])
    integ = np.interp(z, zgrid, cum)

    dL = (c / H0) * (1.0 + z) * integ
    mu = 25.0 + 5.0 * np.log10(dL)
    return mu