"""Greenberg speed-density model: q = vf * k * ln(kj/k)."""
import numpy as np

USED_INPUTS = ["k_veh_km_lane"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    k = X[:, 0]
    vf = 13.25
    kj = 595.6
    return vf * k * np.log(kj / k)