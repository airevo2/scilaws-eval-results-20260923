"""FEV1 = C * (A - age) * height^2 with clean constants C=1e-6, A=150."""
import numpy as np

USED_INPUTS = ["age", "height_cm"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    age = X[:, 0]
    height_cm = X[:, 1]
    return 1.0e-6 * (150.0 - age) * height_cm ** 2