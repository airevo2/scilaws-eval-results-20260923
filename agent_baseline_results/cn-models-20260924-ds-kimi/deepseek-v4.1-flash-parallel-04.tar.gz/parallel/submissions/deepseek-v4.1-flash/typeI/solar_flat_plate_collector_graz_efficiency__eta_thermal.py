"""Collector efficiency: optical gain minus a heat-loss term whose loss coefficient grows with inlet temperature.

eta = c0 + c1*(T_in - T_amb)/G + c2*(T_in - T_amb)*T_in/G
    = eta0 - (a + b*T_in)*(T_in - T_amb)/G
i.e. Hottel-Whillier-style efficiency for a collector whose overall loss coefficient U_L is linear in the collector (inlet) temperature, with the usual (T_in - T_amb)/G driving force.
"""
import numpy as np

USED_INPUTS = ["G_W_m2", "T_in_C", "T_amb_C"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    G = X[:, 0]
    Ti = X[:, 1]
    Ta = X[:, 2]
    c0 = 0.7051
    c1 = 0.9565
    c2 = -0.0674
    x = (Ti - Ta) / G
    return c0 + c1 * x + c2 * x * Ti