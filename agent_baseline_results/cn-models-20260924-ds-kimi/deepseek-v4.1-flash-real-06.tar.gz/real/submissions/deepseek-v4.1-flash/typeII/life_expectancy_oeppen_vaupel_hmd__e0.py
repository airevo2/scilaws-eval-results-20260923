"""Saturating exponential approach of period life expectancy to an asymptote.

    e0(t) = a * (1 - exp(-b * (t - 1700)))

One shared functional form across all clusters; only the pair (a, b) is
re-calibrated per cluster:
  - a : asymptotic maximum life expectancy (years)
  - b : pace of mortality improvement (per year)

1700 is a fixed structural origin of the form (not fitted).
"""
import numpy as np
from scipy.optimize import curve_fit

USED_INPUTS = ["year"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {"a": {"init": None}, "b": {"init": None}}

_T0 = 1700.0


def _form(t, a, b):
    return a * (1.0 - np.exp(-b * (t - _T0)))


def fit(X_fit, y_fit):
    t = np.asarray(X_fit[:, 0], dtype=float)
    y = np.asarray(y_fit, dtype=float)
    # sensible starting values from the data
    a0 = max(float(np.max(y)) * 1.05, 80.0)
    b0 = 0.01
    try:
        popt, _ = curve_fit(
            _form, t, y, p0=[a0, b0],
            bounds=([60.0, 1e-5], [200.0, 0.5]),
            maxfev=10000,
        )
        a_hat, b_hat = float(popt[0]), float(popt[1])
        if not (np.isfinite(a_hat) and np.isfinite(b_hat)):
            raise ValueError
        return {"a": a_hat, "b": b_hat}
    except Exception:
        # robust linear fallback: fit a locally, keep mild b
        try:
            dt = t - _T0
            g = 1.0 - np.exp(-b0 * dt)
            a_hat = float(np.sum(g * y) / np.sum(g * g))
            if not np.isfinite(a_hat) or a_hat <= 0:
                a_hat = a0
        except Exception:
            a_hat = a0
        return {"a": a_hat, "b": b0}


def predict(X, a, b):
    t = np.asarray(X[:, 0], dtype=float)
    y = _form(t, a, b)
    return np.asarray(y, dtype=float)