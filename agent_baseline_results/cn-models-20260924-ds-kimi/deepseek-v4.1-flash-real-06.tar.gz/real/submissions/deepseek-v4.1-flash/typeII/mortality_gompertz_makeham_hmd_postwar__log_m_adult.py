"""Per-cluster mortality schedule: log central death rate linear in a scaled age term
(x*log x) plus a calendar-year trend. Three per-cluster coefficients (a, b, c) are
obtained by ordinary least squares on the cluster's fit window."""

import numpy as np

USED_INPUTS = ["age", "year"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {
    "a": {"init": [-6.0]},
    "b": {"init": [0.02]},
    "c": {"init": [-0.01]},
}

_YEAR_CENTER = 1985.0


def _design(x, t):
    x = np.asarray(x, dtype=float)
    tc = np.asarray(t, dtype=float) - _YEAR_CENTER
    return np.column_stack([np.ones_like(x), x * np.log(x), tc])


def fit(X_fit, y_fit):
    X_fit = np.asarray(X_fit, dtype=float)
    y_fit = np.asarray(y_fit, dtype=float)
    a, b, c = -6.0, 0.02, -0.01
    try:
        A = _design(X_fit[:, 0], X_fit[:, 1])
        coef, _, _, _ = np.linalg.lstsq(A, y_fit, rcond=None)
        a, b, c = float(coef[0]), float(coef[1]), float(coef[2])
        if not (np.isfinite(a) and np.isfinite(b) and np.isfinite(c)):
            a, b, c = -6.0, 0.02, -0.01
    except Exception:
        a, b, c = -6.0, 0.02, -0.01
    return {"a": a, "b": b, "c": c}


def predict(X, a, b, c):
    X = np.asarray(X, dtype=float)
    x = X[:, 0]
    tc = X[:, 1] - _YEAR_CENTER
    return a + b * (x * np.log(x)) + c * tc