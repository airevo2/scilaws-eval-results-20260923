"""Exponential strain-energy-like surface model for biaxial skin: 
sigma11 = A*E1*exp(B*E1^2 + C*E2^2 + D*E1*E2) + g*E1, with E1=(l1^2-1)/2, E2=(l2^2-1)/2."""
import numpy as np
from scipy.optimize import least_squares

USED_INPUTS = ["lambda11", "lambda22"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {
    "A": {"init": [0.01]},
    "B": {"init": [5.0]},
    "C": {"init": [5.0]},
    "D": {"init": [5.0]},
    "g": {"init": [0.0]},
}

def _E(l):
    return (l * l - 1.0) / 2.0

def _form(X, A, B, C, D, g):
    l1 = X[:, 0]; l2 = X[:, 1]
    E1 = _E(l1); E2 = _E(l2)
    return A * E1 * np.exp(B * E1 ** 2 + C * E2 ** 2 + D * E1 * E2) + g * E1

def fit(X_fit, y_fit):
    X = np.asarray(X_fit, dtype=float)
    y = np.asarray(y_fit, dtype=float)
    lo = [1e-8, -50.0, -50.0, -50.0, -50.0]
    hi = [10.0, 50.0, 50.0, 50.0, 50.0]
    p0s = [
        [0.01, 5.0, 5.0, 5.0, 0.0],
        [0.005, 2.0, 10.0, 5.0, 0.0],
        [0.02, 10.0, 2.0, 0.0, 0.0],
    ]
    best = None
    for p0 in p0s:
        try:
            sol = least_squares(lambda p: _form(X, *p) - y, p0,
                                bounds=(lo, hi), max_nfev=4000)
            r = float(np.sqrt(np.mean((_form(X, *sol.x) - y) ** 2)))
            if best is None or r < best[0]:
                best = (r, sol.x)
        except Exception:
            continue
    if best is None:
        return {"A": 0.01, "B": 5.0, "C": 5.0, "D": 5.0, "g": 0.0}
    p = best[1]
    return {"A": float(p[0]), "B": float(p[1]), "C": float(p[2]),
            "D": float(p[3]), "g": float(p[4])}

def predict(X, A, B, C, D, g):
    X = np.asarray(X, dtype=float)
    out = _form(X, A, B, C, D, g)
    return np.nan_to_num(out, nan=0.0, posinf=0.0, neginf=0.0)