"""Corresponding-states liquid-vapor surface tension.

sigma = A * (1 - T/Tc)**1.2

The shape factor (1 - T/Tc)**1.2 is the universal critical surface-tension
scaling form (1.2 is the structural critical exponent of the liquid-vapor
interface, not a fitted coefficient). The substance-specific magnitude is
captured entirely by the single per-cluster amplitude A, which is the only
LOCAL_FITTABLE parameter.
"""
import numpy as np

USED_INPUTS = ["T_K", "rho_liq", "T_c", "M_mol"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {"A": {"init": None}}

def _base(T, Tc):
    Tr = np.clip(T / Tc, 0.0, 1.0)
    return (1.0 - Tr) ** 1.2

def fit(X_fit, y_fit):
    T = X_fit[:, 0]
    Tc = X_fit[:, 2]
    b = _base(T, Tc)
    denom = float(np.sum(b * b))
    if not np.isfinite(denom) or denom <= 0.0:
        return {"A": float(np.mean(y_fit)) if len(y_fit) else 0.0}
    A = float(np.sum(b * y_fit) / denom)
    if not np.isfinite(A):
        A = float(np.mean(y_fit)) if len(y_fit) else 0.0
    return {"A": A}

def predict(X, A):
    T = X[:, 0]
    Tc = X[:, 2]
    return A * _base(T, Tc)