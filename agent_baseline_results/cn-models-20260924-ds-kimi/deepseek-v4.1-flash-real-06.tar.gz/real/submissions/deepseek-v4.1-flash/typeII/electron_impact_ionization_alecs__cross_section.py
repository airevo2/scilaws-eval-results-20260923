"""Electron-impact single-ionization cross section.

Shared functional form (Bethe/Born-inspired threshold form):

    sigma(E) = A * (E - I)^p / E^q        (E > I, else 0)

with a per-cluster amplitude A, a per-cluster ionization threshold I, and
per-cluster exponents p, q.  The same exponent/magnitude structure reproduces
every measured curve (rise from threshold, broad maximum near ~100 eV, slow
power-law fall-off at high energy); only (A, I, p, q) are re-fit per cluster.
No universal constants are baked in.
"""
import numpy as np
from scipy.optimize import least_squares

USED_INPUTS = ["electron_energy_eV"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {
    "A": {"init": None},
    "I": {"init": None},
    "p": {"init": None},
    "q": {"init": None},
}


def _model(E, A, I, p, q):
    E = np.maximum(np.asarray(E, float), 1e-6)
    x = np.maximum(E - I, 0.0)
    out = A * np.power(x, p) / np.power(E, q)
    return np.where(np.isfinite(out), out, 0.0)


def fit(X_fit, y_fit):
    E = np.asarray(X_fit[:, 0], float)
    y = np.asarray(y_fit, float)
    Emax = float(np.max(y)) if y.size else 1.0
    Epeak = float(E[int(np.argmax(y))]) if y.size else 100.0
    Imin = float(np.min(E)) if E.size else 10.0

    lo = [0.0, 0.0, 0.3, 0.5]
    hi = [1e7, 1e4, 6.0, 8.0]

    guesses = []
    for p0, q0 in ((2.4, 3.0), (2.0, 2.5), (3.0, 3.5), (1.5, 2.0)):
        for I0 in (max(Imin * 0.5, 0.5), Imin * 0.9, max(Imin - 5.0, 0.5)):
            denom = max((max(Epeak - I0, 1e-3)) ** p0, 1e-12)
            A0 = max(Emax * (max(Epeak, 1e-3) ** q0) / denom, 1e-3)
            guesses.append([A0, I0, p0, q0])

    best = None
    for g0 in guesses:
        g0 = [min(max(g0[k], lo[k] + 1e-9), hi[k] - 1e-9) for k in range(4)]
        try:
            res = least_squares(
                lambda par: _model(E, *par) - y,
                g0, bounds=(lo, hi), max_nfev=4000,
            )
            if best is None or res.cost < best.cost:
                best = res
        except Exception:
            continue

    if best is not None:
        A, I, p, q = best.x
    else:
        A, I, p, q = max(Emax, 1e-3), Imin * 0.5, 2.4, 3.0

    return {"A": float(A), "I": float(I), "p": float(p), "q": float(q)}


def predict(X, A, I, p, q):
    return _model(X[:, 0], A, I, p, q)