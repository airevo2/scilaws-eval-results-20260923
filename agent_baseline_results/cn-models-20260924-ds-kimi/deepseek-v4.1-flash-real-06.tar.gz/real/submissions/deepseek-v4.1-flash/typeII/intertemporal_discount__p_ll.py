"""Hyperbolic delay-discounting with a bias intercept (per-cluster params beta,k,c).

    d = beta * ( ln(V_LL/V_SS) + ln((1+k*t_SS)/(1+k*t_LL)) ) + c
    p_LL = 1 / (1 + exp(-d))

ln(V_LL/V_SS) is exactly log_amount_ratio; the second term is the log ratio of
the hyperbolic (Mazur) discount factors at the two delays. beta is the choice
sensitivity to value/delay, k the per-cluster discount rate, c a decision bias.
"""
import numpy as np
from scipy.optimize import least_squares

USED_INPUTS = ["log_amount_ratio", "ss_time_days", "ll_time_days"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {"beta": {"init": [2.0]}, "k": {"init": [0.02]}, "c": {"init": [0.0]}}

def _sig(d):
    return 1.0 / (1.0 + np.exp(-np.clip(d, -500.0, 500.0)))

def _logit(beta, k, c, LR, TSS, TLL):
    return beta * (LR + np.log((1.0 + k * TSS) / (1.0 + k * TLL))) + c

def fit(X_fit, y_fit):
    LR = X_fit[:, 0]
    TSS = X_fit[:, 1]
    TLL = X_fit[:, 2]
    y = np.asarray(y_fit, dtype=float)

    p0 = np.array([2.0, 0.02, 0.0])
    bnd = ([0.01, 1e-6, -10.0], [200.0, 10.0, 10.0])

    def resid(p):
        return _sig(_logit(p[0], p[1], p[2], LR, TSS, TLL)) - y

    best = None
    for k0 in (0.001, 0.01, 0.1, 1.0):
        for c0 in (-0.5, 0.0, 0.5):
            try:
                r = least_squares(resid, [2.0, k0, c0], bounds=bnd, max_nfev=4000)
                if best is None or r.cost < best.cost:
                    best = r
            except Exception:
                pass
    if best is None:
        return {"beta": 2.0, "k": 0.02, "c": 0.0}
    b, k, c = best.x
    return {"beta": float(b), "k": float(k), "c": float(c)}

def predict(X, beta, k, c):
    LR = X[:, 0]
    TSS = X[:, 1]
    TLL = X[:, 2]
    return _sig(_logit(beta, k, c, LR, TSS, TLL))