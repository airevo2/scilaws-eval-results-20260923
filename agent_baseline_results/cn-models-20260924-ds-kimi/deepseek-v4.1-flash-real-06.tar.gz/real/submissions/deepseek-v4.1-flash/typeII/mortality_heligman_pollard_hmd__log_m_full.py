"""Heligman–Pollard-type age profile (hump centre fixed) plus a linear calendar-year trend; all 8 coefficients refit per cluster."""
import numpy as np
from scipy.optimize import least_squares

USED_INPUTS = ["age", "year"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {
    "A": {"init": [0.001]},
    "B": {"init": [0.1]},
    "C": {"init": [0.1]},
    "D": {"init": [0.0005]},
    "E": {"init": [5.0]},
    "G": {"init": [1e-5]},
    "H": {"init": [1.1]},
    "s": {"init": [-0.015]},
}

_F = 22.0          # fixed hump centre of the age profile
_T0 = 1997.0       # centring constant for the year trend

def _form(x, t, A, B, C, D, E, G, H, s):
    xx = np.maximum(x, 1e-3)
    t1 = A ** np.power(x + B, C)
    t2 = D * np.exp(-E * (np.log(xx) - np.log(_F)) ** 2)
    t3 = G * H ** x / (1.0 + G * H ** x)
    base = np.log(np.maximum(t1 + t2 + t3, 1e-12))
    return base + s * (t - _T0)

def fit(X_fit, y_fit):
    x = np.asarray(X_fit[:, 0], dtype=float)
    t = np.asarray(X_fit[:, 1], dtype=float)
    y = np.asarray(y_fit, dtype=float)
    p0 = [0.001, 0.1, 0.1, 0.0005, 5.0, 1e-5, 1.1, -0.015]
    lb = [1e-6, 1e-3, 0.01, 1e-8, 0.1, 1e-8, 1.0, -0.3]
    ub = [1.0, 10.0, 1.5, 1.0, 50.0, 1.0, 1.3, 0.3]

    def resid(p):
        return _form(x, t, *p) - y

    try:
        res = least_squares(resid, p0, bounds=(lb, ub), max_nfev=4000)
        p = res.x
    except Exception:
        p = p0
    keys = ["A", "B", "C", "D", "E", "G", "H", "s"]
    return {k: float(v) for k, v in zip(keys, p)}

def predict(X, A, B, C, D, E, G, H, s):
    x = np.asarray(X[:, 0], dtype=float)
    t = np.asarray(X[:, 1], dtype=float)
    return _form(x, t, A, B, C, D, E, G, H, s)