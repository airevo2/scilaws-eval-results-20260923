"""Non-rectangular hyperbola light-response curve (fixed curvature theta=0.5).

A_n(Q) = [ (phi*Q + Amax) - sqrt((phi*Q + Amax)^2 - 4*theta*phi*Q*Amax) ] / (2*theta) - Rd

Per-cluster parameters: phi (quantum yield), Amax (light-saturated asymptote),
Rd (dark respiration). Curvature theta is the universal dimensionless constant 0.5.
"""
import numpy as np
from scipy.optimize import curve_fit

USED_INPUTS = ["Qin"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {"phi": {"init": None}, "Amax": {"init": None}, "Rd": {"init": None}}

_THETA = 0.5

def _nrh(I, phi, Amax, Rd):
    I = np.asarray(I, dtype=float)
    b = phi * I + Amax
    disc = np.maximum(b * b - 4.0 * _THETA * phi * I * Amax, 0.0)
    return (b - np.sqrt(disc)) / (2.0 * _THETA) - Rd

def fit(X_fit, y_fit):
    I = np.asarray(X_fit[:, 0], dtype=float)
    y = np.asarray(y_fit, dtype=float)
    phi0 = 0.05
    Amax0 = max(float(np.max(y)) + max(-float(np.min(y)), 0.0), 1.0)
    Rd0 = max(-float(np.min(y)), 0.1)
    p0 = [phi0, Amax0, Rd0]
    try:
        popt, _ = curve_fit(_nrh, I, y, p0=p0,
                            bounds=([1e-4, 0.05, 0.0], [1.0, 80.0, 20.0]),
                            maxfev=40000)
        return {"phi": float(popt[0]), "Amax": float(popt[1]), "Rd": float(popt[2])}
    except Exception:
        return {"phi": phi0, "Amax": Amax0, "Rd": Rd0}

def predict(X, phi, Amax, Rd):
    return _nrh(X[:, 0], phi, Amax, Rd)