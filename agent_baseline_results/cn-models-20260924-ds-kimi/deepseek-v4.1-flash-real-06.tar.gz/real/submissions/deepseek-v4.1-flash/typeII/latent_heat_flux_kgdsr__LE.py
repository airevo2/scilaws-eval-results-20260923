"""Penman-Monteith with LAI- and VPD-limited surface conductance.

LE = [alpha*Delta*(Rn-G) + C*Ga*VPD] / (Delta + gamma*(1 + Ga/Gs))
Gs = Gs0 * LAI/(LAI+Lh) / (1 + VPD/VPD0)
"""
import numpy as np
from scipy.optimize import curve_fit

USED_INPUTS = ["delta", "Rnet", "Qg", "VPD", "Ga", "LAI"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {
    "Gs0": {"init": [0.05]},
    "VPD0": {"init": [1.0]},
    "alpha": {"init": [1.0]},
    "C": {"init": [1200.0]},
    "Lh": {"init": [1.0]},
}

_GAMMA = 0.0665

def _form(delta, Rn, G, VPD, Ga, LAI, Gs0, VPD0, alpha, C, Lh):
    Gs = Gs0 * LAI / (LAI + Lh) / (1.0 + VPD / VPD0)
    Gs = np.maximum(Gs, 1e-4)
    num = alpha * delta * (Rn - G) + C * Ga * VPD
    den = delta + _GAMMA * (1.0 + Ga / Gs)
    return num / den

def fit(X_fit, y_fit):
    delta = X_fit[:, 0]; Rn = X_fit[:, 1]; G = X_fit[:, 2]
    VPD = X_fit[:, 3]; Ga = X_fit[:, 4]; LAI = X_fit[:, 5]
    p0 = [0.05, 1.0, 1.0, 1200.0, 1.0]
    lo = [1e-4, 0.01, 0.1, 1.0, 0.01]
    hi = [5.0, 100.0, 5.0, 1e5, 50.0]
    try:
        popt, _ = curve_fit(_form, (delta, Rn, G, VPD, Ga, LAI), y_fit,
                            p0=p0, maxfev=20000, bounds=(lo, hi))
        p = [float(v) for v in popt]
    except Exception:
        p = p0
    return {"Gs0": p[0], "VPD0": p[1], "alpha": p[2], "C": p[3], "Lh": p[4]}

def predict(X, Gs0, VPD0, alpha, C, Lh):
    return _form(X[:, 0], X[:, 1], X[:, 2], X[:, 3], X[:, 4], X[:, 5],
                 Gs0, VPD0, alpha, C, Lh)