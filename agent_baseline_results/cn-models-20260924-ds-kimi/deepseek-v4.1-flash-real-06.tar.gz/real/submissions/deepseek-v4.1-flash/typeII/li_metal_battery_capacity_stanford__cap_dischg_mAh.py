"""Capacity fade: exponential decay times a linear-fade correction, one shared form.

Per cluster we fit three local parameters (Q0, a, b) so that the discharge
capacity follows

    Q(EFC) = Q0 * exp(-a * EFC) * (1 - b * EFC)

Q0 plays the role of the (extrapolated) initial capacity of the cell, the
exp(-a*EFC) factor captures the smooth degradation of the active material and
the (1 - b*EFC) factor captures the additional (knee-like) capacity loss that
becomes important at large equivalent-full-cycle counts.  The same functional
shape holds for every cell/design; only the three scalars differ.
"""
import numpy as np
from scipy.optimize import curve_fit

USED_INPUTS = ["efc"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {"Q0": {"init": None}, "a": {"init": None}, "b": {"init": None}}


def _form(e, Q0, a, b):
    return Q0 * np.exp(-a * e) * (1.0 - b * e)


def _fallback(e, y):
    # linear model Q = Q0 - slope*e  ->  Q0 = intercept, b = slope/Q0, a = 0
    Q0 = float(np.max(y))
    if Q0 <= 0:
        Q0 = 1.0
    try:
        A = np.vstack([np.ones_like(e), e]).T
        coef, *_ = np.linalg.lstsq(A, y, rcond=None)
        c0, c1 = float(coef[0]), float(coef[1])
        if c0 > 0 and np.isfinite(c0) and np.isfinite(c1):
            return {"Q0": c0, "a": 0.0, "b": -c1 / c0}
    except Exception:
        pass
    return {"Q0": Q0, "a": 0.0, "b": 0.0}


def fit(X_fit, y_fit):
    e = np.asarray(X_fit[:, 1], dtype=float)
    y = np.asarray(y_fit, dtype=float)

    ymax = float(np.max(y)) if y.size else 1.0
    if not np.isfinite(ymax) or ymax <= 0:
        ymax = 1.0

    lo = [1e-9, -0.01, -0.01]
    hi = [5.0 * ymax, 0.10, 0.10]

    p0_candidates = [
        [ymax, 0.001, 0.0005],
        [ymax, 0.0005, 0.001],
        [ymax, 0.0, 0.0],
        [float(y[0]) if y.size else ymax, 0.0005, 0.0001],
    ]

    for p0 in p0_candidates:
        p0 = [min(max(p0[i], lo[i] * 1.01), hi[i] * 0.99) for i in range(3)]
        try:
            popt, _ = curve_fit(_form, e, y, p0=p0, bounds=(lo, hi), maxfev=20000)
            Q0, a, b = float(popt[0]), float(popt[1]), float(popt[2])
            if np.isfinite(Q0) and np.isfinite(a) and np.isfinite(b) and Q0 > 0:
                return {"Q0": Q0, "a": a, "b": b}
        except Exception:
            continue

    return _fallback(e, y)


def predict(X, Q0, a, b):
    e = np.asarray(X[:, 1], dtype=float)
    out = Q0 * np.exp(-a * e) * (1.0 - b * e)
    out = np.where(np.isfinite(out), out, 0.0)
    return np.clip(out, 0.0, None)