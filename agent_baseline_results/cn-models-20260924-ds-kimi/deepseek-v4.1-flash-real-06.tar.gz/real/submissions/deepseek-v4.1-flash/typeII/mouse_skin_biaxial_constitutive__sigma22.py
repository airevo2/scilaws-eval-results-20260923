"""Fung-type biaxial skin model (per-cluster, 5 parameters).

Cauchy stress in the cranial-caudal direction:

    sigma22 = lambda22^2 * exp(a1*E11^2 + a2*E22^2 + a4*E11*E22) * (B*E22 + D*E11)

with Green strains E11 = (lambda11^2 - 1)/2, E22 = (lambda22^2 - 1)/2.
The lambda22^2 prefactor converts the second-Piola-like response to Cauchy
stress; the exponential-Q form is the standard soft-tissue (Fung) strain
energy structure. A single functionally identical shape is used for every
cluster; only (a1, a2, a4, B, D) are refit per cluster.
"""
import numpy as np
from scipy.optimize import least_squares

USED_INPUTS = ["lambda11", "lambda22"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {
    "a1": {"init": [1.0, 5.0, 15.0]},
    "a2": {"init": [5.0, 10.0, 15.0]},
    "a4": {"init": [1.0, -3.0, -6.0]},
    "B":  {"init": [0.001, 0.01]},
    "D":  {"init": [0.001, 0.01]},
}


def _E(l):
    return (l * l - 1.0) / 2.0


def _form(l11, l22, a1, a2, a4, B, D):
    E11 = _E(l11)
    E22 = _E(l22)
    Q = a1 * E11 * E11 + a2 * E22 * E22 + a4 * E11 * E22
    Q = np.clip(Q, -50.0, 50.0)
    return l22 * l22 * np.exp(Q) * (B * E22 + D * E11)


def fit(X_fit, y_fit):
    l11 = np.asarray(X_fit[:, 0], float)
    l22 = np.asarray(X_fit[:, 1], float)
    y = np.asarray(y_fit, float)

    lo = np.array([-60.0, -60.0, -60.0, -50.0, -50.0])
    hi = np.array([60.0, 60.0, 60.0, 50.0, 50.0])

    starts = [
        [1.0, 10.0, -3.0, 1.0e-3, 1.0e-3],
        [5.0, 12.0, -5.0, 5.0e-3, 2.0e-3],
        [10.0, 15.0, -7.0, 2.0e-3, 5.0e-3],
        [0.5, 6.0, -1.0, 1.0e-2, 1.0e-2],
        [15.0, 10.0, -3.0, 1.0e-4, 1.0e-4],
    ]

    ys = float(np.std(y))
    scale = ys if ys > 0 else 1.0

    best = None
    for s in starts:
        try:
            r = least_squares(
                lambda p: (_form(l11, l22, *p) - y) / scale,
                np.array(s, float),
                bounds=(lo, hi),
                max_nfev=1000,
            )
            if best is None or r.cost < best.cost:
                best = r
        except Exception:
            continue

    if best is None:
        p = np.array(starts[0], float)
    else:
        p = best.x
    p = np.where(np.isfinite(p), p, np.array(starts[0], float))

    return {"a1": float(p[0]), "a2": float(p[1]), "a4": float(p[2]),
            "B": float(p[3]), "D": float(p[4])}


def predict(X, a1, a2, a4, B, D):
    l11 = np.asarray(X[:, 0], float)
    l22 = np.asarray(X[:, 1], float)
    out = _form(l11, l22, a1, a2, a4, B, D)
    out = np.where(np.isfinite(out), out, 0.0)
    return out