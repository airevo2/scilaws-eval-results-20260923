"""Adult log-mortality: linear in a power of age plus a saturating (arctan) calendar-year trend.
Shared functional form across all clusters; only the three coefficients (a, b, c) are per-cluster.
Because the model is linear in (a, b, c) for the fixed features, fit() uses ordinary least squares.
"""
import numpy as np

USED_INPUTS = ["age", "year"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {"a": {"init": None}, "b": {"init": None}, "c": {"init": None}}


def _features(age, year):
    x = np.asarray(age, dtype=float)
    t = (np.asarray(year, dtype=float) - 1957.0) / 50.0
    return np.column_stack([np.ones_like(x), x ** 1.4, np.arctan(t)])


def fit(X_fit, y_fit):
    y = np.asarray(y_fit, dtype=float)
    try:
        F = _features(X_fit[:, 0], X_fit[:, 1])
        coef, _, _, _ = np.linalg.lstsq(F, y, rcond=None)
        a, b, c = float(coef[0]), float(coef[1]), float(coef[2])
        if not np.all(np.isfinite([a, b, c])):
            raise ValueError
        return {"a": a, "b": b, "c": c}
    except Exception:
        return {"a": float(np.mean(y)), "b": 0.0, "c": 0.0}


def predict(X, a, b, c):
    F = _features(X[:, 0], X[:, 1])
    return F[:, 0] * a + F[:, 1] * b + F[:, 2] * c