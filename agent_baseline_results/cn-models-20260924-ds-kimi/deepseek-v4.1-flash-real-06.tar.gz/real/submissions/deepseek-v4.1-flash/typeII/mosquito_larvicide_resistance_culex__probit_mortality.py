"""Two-parameter log-logistic (Hill) dose-response in log10 concentration.

Mortality P rises sigmoidally with log-dose: P = 1 / (1 + 10^(-s*(log10C - x0))).
Per-cluster parameters: slope s and inflection log-dose x0. This is the canonical
logit dose-response model used for larvicide bioassays; it is monotone, bounded in
[0,1], and behaves sensibly when extrapolated.
"""
import numpy as np
from scipy.optimize import curve_fit

USED_INPUTS = ["log10_conc_ppb"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {"s": {"init": [1.5]}, "x0": {"init": [1.5]}}

def _form(x, s, x0):
    z = np.clip(-s * (x - x0), -60.0, 60.0)
    return 1.0 / (1.0 + 10.0 ** z)

def fit(X_fit, y_fit):
    x = X_fit[:, 0].astype(float)
    y = y_fit.astype(float)
    x0_0 = float(np.median(x))
    p0 = [1.5, x0_0]
    try:
        popt, _ = curve_fit(_form, x, y, p0=p0, maxfev=20000,
                            bounds=([0.05, x0_0 - 20.0], [20.0, x0_0 + 20.0]))
        s, x0 = float(popt[0]), float(popt[1])
        if not (np.isfinite(s) and np.isfinite(x0)) or s <= 0:
            raise ValueError
    except Exception:
        s, x0 = 1.5, x0_0
    return {"s": s, "x0": x0}

def predict(X, s, x0):
    x = X[:, 0].astype(float)
    return _form(x, s, x0)