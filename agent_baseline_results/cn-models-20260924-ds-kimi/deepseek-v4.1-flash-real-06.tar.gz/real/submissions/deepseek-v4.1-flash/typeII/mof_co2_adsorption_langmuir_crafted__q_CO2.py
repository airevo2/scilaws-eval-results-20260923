"""Langmuir-Freundlich (Sips) isotherm: q = qs*(b*P)^n / (1 + (b*P)^n).
One shared functional form across all clusters, with 3 per-cluster parameters
(saturation uptake qs, affinity b, heterogeneity exponent n)."""
import numpy as np
from scipy.optimize import least_squares

USED_INPUTS = ["P_bar"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {"qs": {"init": None}, "b": {"init": None}, "n": {"init": None}}


def _sips(P, qs, b, n):
    bp = b * P
    bpn = np.power(bp, n)
    return qs * bpn / (1.0 + bpn)


def fit(X_fit, y_fit):
    P = np.asarray(X_fit[:, 0], dtype=float)
    y = np.asarray(y_fit, dtype=float)
    m = max(float(np.max(y)) * 1.05, 1e-3)
    best = None
    bestcost = np.inf
    for b0 in (0.1, 1.0, 10.0):
        for n0 in (0.55, 0.8, 1.1, 1.4):
            th0 = np.log([m, b0, n0])

            def resid(th):
                qs, bb, nn = np.exp(th)
                return _sips(P, qs, bb, nn) - y

            try:
                sol = least_squares(resid, th0, max_nfev=300)
                if sol.cost < bestcost:
                    bestcost = sol.cost
                    best = np.exp(sol.x)
            except Exception:
                pass
    if best is None:
        best = np.array([m, 1.0, 0.8])
    qs, b, n = float(best[0]), float(best[1]), float(best[2])
    if not np.isfinite(qs) or qs <= 0:
        qs = m
    if not np.isfinite(b) or b <= 0:
        b = 1.0
    if not np.isfinite(n) or n <= 0:
        n = 0.8
    return {"qs": qs, "b": b, "n": n}


def predict(X, qs, b, n):
    P = np.asarray(X[:, 0], dtype=float)
    bp = b * P
    bpn = np.power(bp, n)
    return qs * bpn / (1.0 + bpn)