"""Power-law tail with a per-cluster slope and a shrunk income-time drift.

ln S(p) = a + b * ln p + s * (year - 2000), where (a, b, s) are fit per
cluster.  The per-year drift s is shrunk toward the universal pooled drift
G_DRIFT (fitted once on the whole training sample), which keeps the form
stable when the fit window is short or noisy and extrapolates sensibly in
time.  a and b capture the level and the (Pareto) tail exponent of each
country's income distribution.
"""
import numpy as np

USED_INPUTS = ["log_p_above", "top_pct", "year"]

# single universal constant: pooled within-cluster drift of ln S per year
LAW_CONSTANTS = {"G_DRIFT": 0.00466}
OTHER_CONSTANTS = {}

LOCAL_FITTABLE = {
    "a": {"init": None},   # level of the power law
    "b": {"init": None},   # tail exponent (slope on ln p)
    "s": {"init": None},   # per-cluster income-time drift
}

_YEAR_REF = 2000.0
_LAMBDA = 1000.0  # ridge weight pulling s toward the universal drift


def fit(X_fit, y_fit):
    x = np.asarray(X_fit[:, 0], dtype=float)          # ln p
    t = np.asarray(X_fit[:, 2], dtype=float) - _YEAR_REF  # centred year

    # shrunk least squares:  [a b s] = argmin ||X w - y||^2 + lam (s - g)^2
    A = np.column_stack([np.ones_like(x), x, t])
    n = A.shape[0]
    lam = _LAMBDA
    A2 = np.vstack([A, [0.0, 0.0, np.sqrt(lam)]])
    y2 = np.concatenate([np.asarray(y_fit, dtype=float),
                         [np.sqrt(lam) * LAW_CONSTANTS["G_DRIFT"]]])

    # fallbacks: plain linear fit, then simple level/exponent
    try:
        w, _, _, _ = np.linalg.lstsq(A2, y2, rcond=None)
        a, b, s = float(w[0]), float(w[1]), float(w[2])
    except Exception:
        try:
            b, a = np.polyfit(x, y_fit, 1)
            a, b, s = float(a), float(b), LAW_CONSTANTS["G_DRIFT"]
        except Exception:
            a = float(np.mean(y_fit))
            b, s = 0.48, LAW_CONSTANTS["G_DRIFT"]

    if not np.isfinite([a, b, s]).all():
        a, b, s = float(np.mean(y_fit)), 0.48, LAW_CONSTANTS["G_DRIFT"]
    return {"a": a, "b": b, "s": s}


def predict(X, a, b, s):
    x = np.asarray(X[:, 0], dtype=float)
    t = np.asarray(X[:, 2], dtype=float) - _YEAR_REF
    return a + b * x + s * t