"""Per-cluster linear growth law: log-growth of measles cases is driven by the
log infected fraction log(I/N), a seasonal modulation of the current epidemic
size (log(I)*cos(annual phase)) and a higher seasonal harmonic, i.e. a small
TSIR/flux-like form.

g_t = a + b*log(I/N + eps) + c*log(I+1)*cos(2*pi*s/26) + d*cos(6*pi*s/26)

Only (a, b, c, d) are re-fit per cluster; the shape is shared by all clusters.
"""
import numpy as np
from numpy.linalg import lstsq

USED_INPUTS = ["cases_prev", "biweek", "log_pop"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {
    "a": {"init": None},
    "b": {"init": None},
    "c": {"init": None},
    "d": {"init": None},
}

_EPS = 1e-9


def _design(X):
    I = np.asarray(X[:, 0], dtype=float)
    s_idx = np.asarray(X[:, 1], dtype=float)
    lp = np.asarray(X[:, 2], dtype=float)
    N = 10.0 ** lp
    lI = np.log(I + 1.0)
    lIN = np.log(np.maximum(I, 0.0) / N + _EPS)
    s = 2.0 * np.pi * s_idx / 26.0
    c1 = np.cos(s)
    c3 = np.cos(3.0 * s)
    return np.column_stack([np.ones(I.shape[0]), lIN, lI * c1, c3])


def fit(X_fit, y_fit):
    X_fit = np.asarray(X_fit, dtype=float)
    y_fit = np.asarray(y_fit, dtype=float)
    A = _design(X_fit)
    # Small ridge for numerical stability across small windows.
    lam = 1e-6
    AtA = A.T @ A + lam * np.eye(A.shape[1])
    Atb = A.T @ y_fit
    try:
        coef = np.linalg.solve(AtA, Atb)
    except Exception:
        try:
            coef, _, _, _ = lstsq(A, y_fit, rcond=None)
        except Exception:
            coef = np.zeros(A.shape[1])
    coef = np.nan_to_num(coef, nan=0.0, posinf=0.0, neginf=0.0)
    if not np.all(np.isfinite(coef)):
        coef = np.zeros(A.shape[1])
    return {"a": float(coef[0]), "b": float(coef[1]),
            "c": float(coef[2]), "d": float(coef[3])}


def predict(X, a, b, c, d):
    A = _design(np.asarray(X, dtype=float))
    y = A @ np.array([a, b, c, d], dtype=float)
    return np.nan_to_num(y, nan=0.0, posinf=0.0, neginf=0.0)