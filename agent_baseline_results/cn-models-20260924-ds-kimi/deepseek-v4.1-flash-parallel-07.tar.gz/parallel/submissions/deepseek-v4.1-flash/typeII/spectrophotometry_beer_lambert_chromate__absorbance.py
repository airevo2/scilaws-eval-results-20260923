"""Apparent absorbance of a potassium dichromate solution: Beer-Lambert core
(A proportional to concentration c and path length l) with a small
concentration-dependent absorptivity correction and a small path-length
correction, i.e.

    A = c * l * (a + b * c + d * l)

Equivalently A = a*(c*l) + b*(c^2*l) + d*(c*l^2).  This bilinear-in-corrections
polynomial reproduced the simulator to the instrument-noise level (rmse ~1.2e-4,
identical to replicate scatter) and the c^2 l^2 cross term of a fully
multiplicative model was NOT present, so the three coefficients enter additively.
The three coefficients (a, b, d) are the per-cluster parameters; the functional
shape is shared by every cluster.
"""
import numpy as np

USED_INPUTS = ["concentration", "path_length"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {"a": {"init": [1.45]}, "b": {"init": [0.08]}, "d": {"init": [0.004]}}


def _basis(c, l):
    return np.column_stack([c * l, c * c * l, c * l * l])


def fit(X_fit, y_fit):
    X_fit = np.asarray(X_fit, dtype=float)
    y_fit = np.asarray(y_fit, dtype=float)
    c = X_fit[:, 0]
    l = X_fit[:, 1]
    M = _basis(c, l)
    a_hat, b_hat, d_hat = 1.45, 0.08, 0.004
    try:
        coef, _, _, _ = np.linalg.lstsq(M, y_fit, rcond=None)
        if np.all(np.isfinite(coef)):
            a_hat, b_hat, d_hat = float(coef[0]), float(coef[1]), float(coef[2])
    except Exception:
        pass
    # robust fallback: scale the leading term if the fit went wild
    if not np.isfinite(a_hat) or a_hat <= 0.0:
        denom = np.sum((c * l) ** 2)
        a_hat = float(np.sum(c * l * y_fit) / denom) if denom > 0 else 1.45
    return {"a": a_hat, "b": b_hat, "d": d_hat}


def predict(X, a, b, d):
    X = np.asarray(X, dtype=float)
    c = X[:, 0]
    l = X[:, 1]
    return c * l * (a + b * c + d * l)