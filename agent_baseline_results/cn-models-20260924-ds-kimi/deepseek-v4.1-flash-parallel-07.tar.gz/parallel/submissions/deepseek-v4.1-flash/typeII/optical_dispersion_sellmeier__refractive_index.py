"""Two-term Sellmeier dispersion: n^2 = 1 + A1*l^2/(l^2-c1) + A2*l^2/(l^2-c2).
One oscillator pole below the probed range (UV) and one far above (IR)."""
import numpy as np
from scipy.optimize import least_squares

USED_INPUTS = ["wavelength_um"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {"A1": {"init": None}, "c1": {"init": None},
                  "A2": {"init": None}, "c2": {"init": None}}


def _n2(l, A1, c1, A2, c2):
    return 1.0 + A1 * l ** 2 / (l ** 2 - c1) + A2 * l ** 2 / (l ** 2 - c2)


def _resid(p, lam, n):
    A1, c1, A2, c2 = p
    val = _n2(lam, A1, c1, A2, c2)
    return np.sqrt(np.clip(val, 1e-6, None)) - n


def fit(X_fit, y_fit):
    lam = np.asarray(X_fit[:, 0], dtype=float)
    n = np.asarray(y_fit, dtype=float)
    lmin2 = float(np.min(lam) ** 2)
    lmax2 = float(np.max(lam) ** 2)

    lo = [-50.0, -1e6, -50.0, -1e6]
    hi = [80.0, 1e6, 80.0, 1e6]

    best = None
    best_cost = np.inf

    # Candidate initial guesses: UV pole below range, IR pole above range.
    c1_cands = [0.05 * lmin2, 0.2 * lmin2, 0.5 * lmin2, 0.85 * lmin2, 0.99 * lmin2]
    c2_cands = [1.5 * lmax2, 3.0 * lmax2, 10.0 * lmax2, 100.0 * lmax2]
    a_base = max(float(np.max(n)) ** 2 - 1.0, 0.1)
    a2_cands = [0.05 * a_base, 0.3 * a_base, a_base, 3.0 * a_base]

    for c1 in c1_cands:
        for c2 in c2_cands:
            for A2 in a2_cands:
                p0 = [a_base, c1, A2, c2]
                try:
                    r = least_squares(_resid, p0, args=(lam, n),
                                      bounds=(lo, hi), max_nfev=2000)
                except Exception:
                    continue
                if r.cost < best_cost:
                    best_cost = r.cost
                    best = r.x

    if best is None:
        # fallback: 1-oscillator style
        best = [a_base, 0.5 * lmin2, 1e-3, 100.0 * lmax2]

    A1, c1, A2, c2 = best
    return {"A1": float(A1), "c1": float(c1), "A2": float(A2), "c2": float(c2)}


def predict(X, A1, c1, A2, c2):
    lam = np.asarray(X[:, 0], dtype=float)
    val = _n2(lam, A1, c1, A2, c2)
    return np.sqrt(np.clip(val, 1e-6, None))