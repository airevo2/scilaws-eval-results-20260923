"""Log male/female central death-rate ratio as a separable plane in age and calendar
year:  ln(alpha) = a + b*age + c*year.  One shared functional form; the intercept and
the age- and year-slopes are the three per-cluster parameters re-fit for each cluster
(country/period), which is the structure the simulator exposes (a smooth, essentially
linear age trend combined with a near-linear secular year trend)."""
import numpy as np
from scipy.optimize import least_squares

USED_INPUTS = ["age", "year"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {"a": {"init": None}, "b": {"init": None}, "c": {"init": None}}


def _form(age, year, a, b, c):
    return a + b * age + c * year


def fit(X_fit, y_fit):
    age = np.asarray(X_fit[:, 0], dtype=float)
    year = np.asarray(X_fit[:, 1], dtype=float)
    y = np.asarray(y_fit, dtype=float)
    # Linear least squares for the 3 parameters (plane fit).
    A = np.column_stack([np.ones_like(age), age, year])
    try:
        coef, *_ = np.linalg.lstsq(A, y, rcond=None)
        a, b, c = coef
    except Exception:
        a, b, c = float(np.mean(y)), 0.0, 0.0
    # One robust refinement pass in case of heteroscedastic points.
    try:
        res = least_squares(
            lambda p: _form(age, year, p[0], p[1], p[2]) - y,
            x0=[a, b, c], method="lm", max_nfev=2000,
        )
        a, b, c = res.x
    except Exception:
        pass
    return {"a": float(a), "b": float(b), "c": float(c)}


def predict(X, a, b, c):
    age = np.asarray(X[:, 0], dtype=float)
    year = np.asarray(X[:, 1], dtype=float)
    return _form(age, year, a, b, c)