"""Chézy-type resistance law: V = C * sqrt(R * S), with a single
per-cluster coefficient C (absorbing roughness / S-level effects).

Experiments across 8 clusters showed (i) within a cluster V^2 is linear in R
(the bed slope S is constant within a cluster), i.e. V ∝ sqrt(R), and
(ii) the leading scale differs per cluster while the sqrt(RS) shape is shared.
This is the classic Chézy / Darcy-Weisbach form V = C sqrt(R S_f), so it is
kept with one local parameter and no global constants.
"""
import numpy as np

USED_INPUTS = ["R_m", "SLOPE"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {"C": {"init": None}}


def _base(X):
    R = np.asarray(X[:, 0], dtype=float)
    S = np.asarray(X[:, 1], dtype=float)
    return np.sqrt(np.maximum(R * S, 0.0))


def fit(X_fit, y_fit):
    x = _base(X_fit)
    y = np.asarray(y_fit, dtype=float)
    denom = float(np.sum(x * x))
    if denom <= 0.0:
        C = float(np.mean(y)) if y.size else 1.0
    else:
        C = float(np.sum(x * y) / denom)
    if not np.isfinite(C) or C <= 0.0:
        C = max(float(np.mean(y)) if y.size else 1.0, 1e-6)
    return {"C": C}


def predict(X, C):
    return C * _base(X)