"""Fredlund-Xing style soil-water characteristic curve (m=1):
theta(h) = theta_r + (theta_s - theta_r) / ln(e + (alpha*h)^n)
which is the Fredlund & Xing (1994) SWCC equation with the m exponent set to 1.
Per-cluster parameters: residual water content theta_r, saturated water content
theta_s, inverse air-entry scale alpha, and pore-size distribution index n.
"""
import numpy as np
from scipy.optimize import curve_fit

USED_INPUTS = ["lab_head_m"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {
    "theta_r": {"init": None},
    "theta_s": {"init": None},
    "alpha": {"init": None},
    "n": {"init": None},
}


def _fx(h, theta_r, theta_s, alpha, n):
    h = np.asarray(h, dtype=float)
    u = np.maximum(alpha * h, 0.0)
    return theta_r + (theta_s - theta_r) / np.log(np.e + u ** n)


def fit(X_fit, y_fit):
    h = np.asarray(X_fit[:, 0], dtype=float)
    y = np.asarray(y_fit, dtype=float)
    # robust initial guesses
    ts0 = float(np.max(y)) + 0.02
    tr0 = float(np.min(y)) * 0.8 if np.min(y) > 0 else 0.02
    a0 = 1.0 / max(np.median(h), 1e-6)
    p0 = [tr0, ts0, a0, 2.0]
    bounds = ([0.0, 0.0, 1e-8, 1.001], [0.7, 1.0, 1e4, 100.0])
    try:
        popt, _ = curve_fit(_fx, h, y, p0=p0, bounds=bounds, maxfev=20000)
        return {"theta_r": float(popt[0]), "theta_s": float(popt[1]),
                "alpha": float(popt[2]), "n": float(popt[3])}
    except Exception:
        return {"theta_r": float(tr0), "theta_s": float(ts0),
                "alpha": float(a0), "n": 2.0}


def predict(X, theta_r, theta_s, alpha, n):
    return _fx(X[:, 0], theta_r, theta_s, alpha, n)