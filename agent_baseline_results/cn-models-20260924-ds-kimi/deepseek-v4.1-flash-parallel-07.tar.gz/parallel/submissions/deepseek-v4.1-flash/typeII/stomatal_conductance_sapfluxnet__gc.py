"""Logarithmic (Oren-type) canopy conductance model: Gc = a - b*ln(D).

Gc_proxy declines with daytime VPD following the classic logarithmic
stomatal-closure model used for SAPFLUXNET canopy conductance
(Oren et al. 1999): Gs = Gs_ref * (1 - m*ln(D/D_ref)), which is algebraically
a - b*ln(D). One shared functional form; the intercept a and slope b are the
only per-cluster parameters (fit by ordinary least squares on ln D).
"""
import numpy as np

USED_INPUTS = ["vpd"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {"a": {"init": None}, "b": {"init": None}}


def fit(X_fit, y_fit):
    D = np.asarray(X_fit[:, 0], dtype=float)
    y = np.asarray(y_fit, dtype=float)
    # model: Gc = a - b*ln(D)  ->  design matrix [1, -ln D]
    A = np.column_stack([np.ones_like(D), -np.log(D)])
    try:
        coef, *_ = np.linalg.lstsq(A, y, rcond=None)
        a = float(coef[0])
        b = float(coef[1])
        if not (np.isfinite(a) and np.isfinite(b)):
            raise ValueError
    except Exception:
        a = float(np.mean(y))
        b = 0.0
    return {"a": a, "b": b}


def predict(X, a, b):
    D = np.asarray(X[:, 0], dtype=float)
    return a - b * np.log(D)