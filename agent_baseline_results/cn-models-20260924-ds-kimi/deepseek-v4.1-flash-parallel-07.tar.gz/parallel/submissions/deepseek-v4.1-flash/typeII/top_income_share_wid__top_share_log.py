"""Power-law tail: log top-share is linear in log of the top-fraction p.

    ln S(p) = a * ln p + b      (i.e. S(p) = exp(b) * p^a)

The same functional shape holds for every cluster; only the slope `a`
(Pareto-tail exponent) and the intercept `b` (scale) are re-fit per cluster
by ordinary least squares on that cluster's (ln p, ln S) window.
"""
import numpy as np

USED_INPUTS = ["log_p_above"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {"a": {"init": None}, "b": {"init": None}}


def _form(x, a, b):
    return a * x + b


def fit(X_fit, y_fit):
    x = np.asarray(X_fit[:, 0], dtype=float)
    y = np.asarray(y_fit, dtype=float)
    # Ordinary least squares for ln S = a * ln p + b
    n = x.size
    if n < 2:
        a = 0.5
        b = float(np.mean(y)) - a * float(np.mean(x)) if n else 0.0
        return {"a": a, "b": b}
    xm = x.mean()
    ym = y.mean()
    sxx = np.sum((x - xm) ** 2)
    sxy = np.sum((x - xm) * (y - ym))
    a = sxy / sxx if sxx > 1e-12 else 0.5
    b = ym - a * xm
    return {"a": float(a), "b": float(b)}


def predict(X, a, b):
    x = np.asarray(X[:, 0], dtype=float)
    return a * x + b