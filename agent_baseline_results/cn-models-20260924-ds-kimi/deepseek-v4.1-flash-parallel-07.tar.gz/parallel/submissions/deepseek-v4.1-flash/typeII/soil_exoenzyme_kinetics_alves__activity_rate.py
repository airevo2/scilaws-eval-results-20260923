"""Michaelis-Menten enzyme kinetics: v = Vmax * S / (Km + S), with per-cluster Vmax and Km."""
import numpy as np
from scipy.optimize import curve_fit

USED_INPUTS = ["substrate_conc"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {"Vmax": {"init": None}, "Km": {"init": None}}

def _mm(S, Vmax, Km):
    return Vmax * S / (Km + S)

def fit(X_fit, y_fit):
    S = np.asarray(X_fit[:, 0], dtype=float)
    y = np.asarray(y_fit, dtype=float)
    V0 = max(1.2 * float(np.max(y)), 1.0)
    K0 = max(0.5 * float(np.median(S)), 1.0)
    try:
        popt, _ = curve_fit(_mm, S, y, p0=[V0, K0], maxfev=10000,
                            bounds=([0.0, 1e-6], [np.inf, np.inf]))
        Vmax = float(popt[0]); Km = float(popt[1])
    except Exception:
        Vmax, Km = V0, K0
    if not np.isfinite(Vmax) or Vmax <= 0:
        Vmax = V0
    if not np.isfinite(Km) or Km <= 0:
        Km = K0
    return {"Vmax": Vmax, "Km": Km}

def predict(X, Vmax, Km):
    S = np.asarray(X[:, 0], dtype=float)
    return _mm(S, Vmax, Km)