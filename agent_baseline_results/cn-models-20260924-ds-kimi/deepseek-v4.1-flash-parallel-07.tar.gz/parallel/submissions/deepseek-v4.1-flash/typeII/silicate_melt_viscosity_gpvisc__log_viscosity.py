"""VFT (Vogel-Fulcher-Tammann) viscosity law: log10(eta) = A + B/(T - T0).
A (pre-exponential offset), B (activation-like scale in K), and T0 (VFT
reference temperature in K) are the three per-cluster parameters; the
functional shape is shared across all clusters."""
import numpy as np
from scipy.optimize import curve_fit

USED_INPUTS = ["T"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {"A": {"init": None}, "B": {"init": None}, "T0": {"init": None}}

def _vft(T, A, B, T0):
    return A + B / (T - T0)

def fit(X_fit, y_fit):
    T = np.asarray(X_fit[:, 0], dtype=float)
    y = np.asarray(y_fit, dtype=float)
    # Initial guesses from the data range.
    T0_0 = float(np.min(T)) * 0.5
    span = float(np.max(T) - np.min(T)) if np.max(T) > np.min(T) else 1.0
    A0 = float(np.min(y))
    B0 = (float(np.max(y)) - float(np.min(y))) * (float(np.mean(T)) - T0_0)
    if not np.isfinite(B0) or B0 <= 0:
        B0 = 2000.0
    p0 = [A0, B0, T0_0]
    try:
        popt, _ = curve_fit(_vft, T, y, p0=p0, maxfev=100000)
        A, B, T0 = (float(popt[0]), float(popt[1]), float(popt[2]))
    except Exception:
        A, B, T0 = A0, B0, T0_0
    # Guard against a pole inside the data range (T0 >= min(T)); fall back.
    if not np.isfinite(A) or not np.isfinite(B) or not np.isfinite(T0):
        A, B, T0 = A0, B0, T0_0
    return {"A": A, "B": B, "T0": T0}

def predict(X, A, B, T0):
    T = np.asarray(X[:, 0], dtype=float)
    denom = T - T0
    # Avoid division by zero / sign flips at the pole.
    denom = np.where(np.abs(denom) < 1e-6, 1e-6, denom)
    return A + B / denom