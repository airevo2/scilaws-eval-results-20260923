"""WLF free-volume equation for polymer melt viscosity, shared across clusters.

    log10(eta) = log10(eta_g) - b * (T - Tg) / (C2 + (T - Tg))

The functional shape (a saturating free-volume fraction of the reduced
temperature above Tg) is identical for every polymer cluster.  Two parameters
are re-fit per cluster: `a` (the plateau / reference value log10 eta_g) and
`b` (the strength of the WLF drop, ~C1).  `C2` is the universal WLF
free-volume constant shared by all clusters.
"""
import numpy as np

USED_INPUTS = ["Temperature_K", "Tg_K"]
LAW_CONSTANTS = {"C2": 51.6}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {"a": {"init": [3.0]}, "b": {"init": [10.0]}}

_C2 = 51.6


def _shape(T, Tg):
    x = T - Tg
    return x / (_C2 + x)


def fit(X_fit, y_fit):
    T = np.asarray(X_fit[:, 0], dtype=float)
    Tg = np.asarray(X_fit[:, 1], dtype=float)
    y = np.asarray(y_fit, dtype=float)
    u = _shape(T, Tg)
    # y = a - b*u  -> linear least squares in (a, b)
    A = np.column_stack([np.ones_like(u), -u])
    try:
        sol, *_ = np.linalg.lstsq(A, y, rcond=None)
        a, b = float(sol[0]), float(sol[1])
    except Exception:
        a, b = float(np.mean(y)), 0.0
    if not np.isfinite(a):
        a = float(np.mean(y))
    if not np.isfinite(b):
        b = 0.0
    return {"a": a, "b": b}


def predict(X, a, b):
    T = np.asarray(X[:, 0], dtype=float)
    Tg = np.asarray(X[:, 1], dtype=float)
    return a - b * _shape(T, Tg)