"""Asymmetric gamma-shaped sunspot cycle pulse.

Each solar cycle is modelled as a single asymmetric pulse of the form
    ssn(t) = A * x^k * exp(k*(1 - x)),   x = (t - t0)/tau
which rises from zero at t0, peaks at x = 1 (i.e. t = t0 + tau) with value A,
and decays with a long right tail.  The dimensionless shape exponent k is a
UNIVERSAL constant shared by every cycle; only the amplitude A, the cycle
start t0 and the time-scale tau are re-calibrated per cluster.
"""
import numpy as np
from scipy.optimize import curve_fit

USED_INPUTS = ["t_year"]
LAW_CONSTANTS = {"k": 4.0}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {"A": {"init": None}, "t0": {"init": None}, "tau": {"init": None}}

_K = 4.0


def _form(t, A, t0, tau):
    x = np.clip((t - t0) / tau, 1e-9, None)
    return A * x**_K * np.exp(_K * (1.0 - x))


def fit(X_fit, y_fit):
    t = np.asarray(X_fit[:, 0], dtype=float)
    y = np.asarray(y_fit, dtype=float)

    A0 = max(float(np.max(y)), 1.0)
    i_peak = int(np.argmax(y))
    t_peak = float(t[i_peak])
    span = float(t.max() - t.min())
    tau0 = max(span / 4.0, 0.5)
    t00 = t_peak - tau0

    best = None
    for A_ in (A0, 1.5 * A0, 0.6 * A0):
        for tau_ in (tau0, 0.6 * tau0, 1.5 * tau0):
            p0 = [A_, t_peak - tau_, tau_]
            lo = [0.0, t.min() - 3.0 * tau0, 1e-3]
            hi = [np.inf, t.max() + 3.0 * tau0, 10.0 * span + 1.0]
            try:
                popt, _ = curve_fit(_form, t, y, p0=p0,
                                    bounds=(lo, hi), maxfev=8000)
                res = np.sum((_form(t, *popt) - y) ** 2)
                if best is None or res < best[0]:
                    best = (res, popt)
            except Exception:
                continue

    if best is None:
        return {"A": A0, "t0": t00, "tau": tau0}

    A_hat, t0_hat, tau_hat = best[1]
    if not np.isfinite([A_hat, t0_hat, tau_hat]).all() or tau_hat <= 0:
        return {"A": A0, "t0": t00, "tau": tau0}
    return {"A": float(A_hat), "t0": float(t0_hat), "tau": float(tau_hat)}


def predict(X, A, t0, tau):
    t = np.asarray(X[:, 0], dtype=float)
    return _form(t, A, t0, tau)