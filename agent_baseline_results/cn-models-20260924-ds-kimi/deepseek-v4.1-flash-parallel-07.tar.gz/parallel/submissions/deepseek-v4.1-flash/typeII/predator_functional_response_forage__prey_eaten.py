"""Ivlev exponential (type II-like) functional response.

The number of prey eaten saturates *exponentially* fast with prey density
(a hallmark of Ivlev's feeding equation), NOT hyperbolically as in Holling's
disc equation: at a deterministic low-density point (N=1, group 3) the model
gives ~1.02, while a fitted disc equation would give ~1.4; at high density
(N>=16) the curve is already flat, whereas a disc equation keeps climbing.
Across every observed cluster the same shape holds and only two parameters
change: the saturating intake Nmax and the attack/efficiency rate a.

    prey_eaten = Nmax * (1 - exp(-a * prey_density))
"""
import numpy as np
from scipy.optimize import curve_fit

USED_INPUTS = ["prey_density"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {"Nmax": {"init": None}, "a": {"init": None}}


def _form(N, Nmax, a):
    return Nmax * (1.0 - np.exp(-a * N))


def fit(X_fit, y_fit):
    N = np.asarray(X_fit[:, 0], dtype=float)
    y = np.asarray(y_fit, dtype=float)
    # robust starting guesses
    Nmax0 = max(float(np.max(y)) * 1.3, 1.0)
    medN = float(np.median(N)) if len(N) else 1.0
    a0 = 1.0 / max(medN, 1.0)
    try:
        popt, _ = curve_fit(
            _form, N, y, p0=[Nmax0, a0],
            bounds=([1e-9, 1e-9], [np.inf, np.inf]), maxfev=100000,
        )
        Nmax_hat = float(popt[0])
        a_hat = float(popt[1])
        if not (np.isfinite(Nmax_hat) and np.isfinite(a_hat)):
            raise ValueError
        return {"Nmax": Nmax_hat, "a": a_hat}
    except Exception:
        return {"Nmax": float(Nmax0), "a": float(a0)}


def predict(X, Nmax, a):
    N = np.asarray(X[:, 0], dtype=float)
    return Nmax * (1.0 - np.exp(-a * N))