"""Power-law competition (self-thinning / constant-final-yield) form: mean plant mass
decays as a power of density, w = a * N^(-b), with per-cluster (per-species/pot) scale a
and exponent b calibrated from that cluster only."""
import numpy as np

USED_INPUTS = ["density"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {"a": {"init": None}, "b": {"init": None}}


def _power(N, a, b):
    return a * np.power(np.clip(N, 1e-9, None), -b)


def fit(X_fit, y_fit):
    N = np.asarray(X_fit[:, 0], dtype=float)
    y = np.asarray(y_fit, dtype=float)
    # Robust log-log linear fit; fall back to simple feasible parameters.
    mask = (N > 0) & (y > 0) & np.isfinite(N) & np.isfinite(y)
    a_hat, b_hat = 1.0, 0.9
    if np.count_nonzero(mask) >= 3:
        lx = np.log(N[mask])
        ly = np.log(y[mask])
        # weighted least squares (down-weight extreme residuals iteratively)
        w = np.ones_like(lx)
        for _ in range(3):
            sw = np.sum(w)
            mx = np.sum(w * lx) / sw
            my = np.sum(w * ly) / sw
            cov = np.sum(w * (lx - mx) * (ly - my))
            var = np.sum(w * (lx - mx) ** 2)
            slope = cov / var if var > 0 else 0.0
            intercept = my - slope * mx
            resid = ly - (intercept + slope * lx)
            s = np.median(np.abs(resid)) + 1e-9
            w = 1.0 / (1.0 + (resid / (3.0 * s)) ** 2)
        b_hat = float(-slope)
        a_hat = float(np.exp(intercept))
        if not (np.isfinite(a_hat) and np.isfinite(b_hat)) or a_hat <= 0:
            a_hat, b_hat = 1.0, 0.9
    elif np.count_nonzero(mask) >= 1:
        a_hat = float(np.mean(y[mask] * np.power(N[mask], 0.9)))
        b_hat = 0.9
    return {"a": a_hat, "b": b_hat}


def predict(X, a, b):
    N = np.asarray(X[:, 0], dtype=float)
    out = _power(N, a, b)
    return np.nan_to_num(out, nan=0.0, posinf=0.0, neginf=0.0)