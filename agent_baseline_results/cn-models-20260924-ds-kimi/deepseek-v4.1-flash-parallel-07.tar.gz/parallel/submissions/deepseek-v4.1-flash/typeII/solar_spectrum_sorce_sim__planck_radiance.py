"""Planck blackbody spectral radiance (per nm, per sr) with one per-cluster
effective temperature T.  Same functional form for every cluster; only T is
re-fit per cluster.

    L(λ; T) = (2 h c² / λ⁵) / (exp(h c / (λ k T)) − 1)   [W m⁻² nm⁻¹ sr⁻¹]

λ is converted from nm to m, and the per-metre Planck radiance is scaled by
1e-9 to give radiance per nm.
"""
import numpy as np
from scipy.optimize import curve_fit

USED_INPUTS = ["wavelength_nm"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}

# physical constants (universal, not fitted)
_H = 6.62607015e-34      # Planck constant   [J s]
_C = 2.99792458e8        # speed of light    [m s^-1]
_K = 1.380649e-23        # Boltzmann constant[J K^-1]

LOCAL_FITTABLE = {"T": {"init": None}}


def _planck(lam_nm, T):
    lam = np.asarray(lam_nm, dtype=float) * 1e-9           # m
    return (2.0 * _H * _C ** 2 / lam ** 5) / (np.exp(_H * _C / (lam * _K * T)) - 1.0) * 1e-9


def fit(X_fit, y_fit):
    lam = np.asarray(X_fit[:, 0], dtype=float)
    y = np.asarray(y_fit, dtype=float)
    # restrict to the photospheric peak region for a robust Wien-guided guess
    m = (lam > 300.0) & (lam < 2500.0) & (y > 0)
    if m.sum() >= 3:
        lamw, yw = lam[m], y[m]
        X = np.column_stack([np.ones_like(lamw), 1.0 / lamw])
        coef, *_ = np.linalg.lstsq(X, np.log(yw) + 5.0 * np.log(lamw), rcond=None)
        b = -coef[1]                                        # slope in 1/lam
        T0 = _H * _C / (_K * b * 1e-9) if b > 1e-6 else 5700.0
    else:
        T0 = 5700.0
    # keep the initial guess in a sensible stellar range
    T0 = float(np.clip(T0, 3000.0, 12000.0))
    try:
        popt, _ = curve_fit(_planck, lam, y, p0=[T0], maxfev=5000)
        T = float(popt[0])
        if not np.isfinite(T) or T <= 0:
            T = T0
    except Exception:
        T = T0
    return {"T": T}


def predict(X, T):
    return _planck(X[:, 0], T)