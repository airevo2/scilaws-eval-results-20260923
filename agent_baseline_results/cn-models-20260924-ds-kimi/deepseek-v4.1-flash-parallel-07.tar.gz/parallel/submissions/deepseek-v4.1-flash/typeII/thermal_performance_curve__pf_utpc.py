"""Gaussian thermal performance curve (Gaussian in temperature, log-quadratic).

ln P(T) = ln Pmax - ((T - Topt)/w)^2
i.e. P(T) = Pmax * exp(-((T - Topt)/w)^2).

The shared mechanism is one symmetric Gaussian peak on temperature; the three
per-cluster parameters are the peak height (absorbs the trait unit), the peak
location (thermal optimum) and the thermal breadth. Fitted in log space so the
multiplicative unit scale is absorbed cleanly.
"""
import numpy as np
from scipy.optimize import least_squares

USED_INPUTS = ["temperature"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {"ln_Pmax": {"init": None}, "Topt": {"init": None}, "w": {"init": None}}


def _lnP(T, ln_Pmax, Topt, w):
    w = np.abs(w) + 1e-9
    return ln_Pmax - ((T - Topt) / w) ** 2


def fit(X_fit, y_fit):
    T = np.asarray(X_fit[:, 0], dtype=float)
    y = np.asarray(y_fit, dtype=float)
    y = np.clip(y, 1e-300, None)
    ly = np.log(y)
    # initial guesses
    i = int(np.argmax(ly))
    lnA0 = float(ly[i])
    To0 = float(T[i])
    w0 = float(max(np.ptp(T) / 3.0, 1.0))
    p0 = np.array([lnA0, To0, w0], dtype=float)

    def resid(p):
        return _lnP(T, p[0], p[1], p[2]) - ly

    try:
        sol = least_squares(resid, p0, max_nfev=20000)
        p = sol.x
    except Exception:
        p = p0
    # fallbacks if fit degenerated (non-finite or absurd)
    if not np.all(np.isfinite(p)):
        p = p0
    return {"ln_Pmax": float(p[0]), "Topt": float(p[1]), "w": float(abs(p[2])) + 1e-9}


def predict(X, ln_Pmax, Topt, w):
    T = np.asarray(X[:, 0], dtype=float)
    return np.exp(_lnP(T, ln_Pmax, Topt, w))