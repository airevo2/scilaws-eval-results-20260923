"""At-a-station hydraulic geometry power law: w = a * Q^b.

Each gauging station (cluster) has its own coefficient a and exponent b;
the functional form (power law in discharge) is shared across all clusters.
"""
import numpy as np

USED_INPUTS = ["chan_discharge"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {"a": {"init": None}, "b": {"init": None}}


def predict(X, a, b):
    Q = np.asarray(X[:, 0], dtype=float)
    Q = np.clip(Q, 1e-12, None)
    return a * Q ** b


def fit(X_fit, y_fit):
    Q = np.asarray(X_fit[:, 0], dtype=float)
    y = np.asarray(y_fit, dtype=float)
    mask = (Q > 0) & (y > 0) & np.isfinite(Q) & np.isfinite(y)
    # Fallback defaults in case of degenerate input.
    a_hat, b_hat = 10.0, 0.3
    if np.count_nonzero(mask) >= 3:
        lQ = np.log(Q[mask])
        ly = np.log(y[mask])
        A = np.vstack([lQ, np.ones_like(lQ)]).T
        coef, *_ = np.linalg.lstsq(A, ly, rcond=None)
        if np.all(np.isfinite(coef)):
            b_hat = float(coef[0])
            a_hat = float(np.exp(coef[1]))
    return {"a": a_hat, "b": b_hat}