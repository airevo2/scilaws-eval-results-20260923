"""Power-law allometry with a shared exponent 1/2: H = a * sqrt(D), one scale a per cluster."""
import numpy as np

USED_INPUTS = ["DBH_cm"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {"a": {"init": None}}

def predict(X, a):
    D = np.asarray(X[:, 0], dtype=float)
    D = np.clip(D, 0.0, None)
    return a * np.sqrt(D)

def fit(X_fit, y_fit):
    D = np.asarray(X_fit[:, 0], dtype=float)
    y = np.asarray(y_fit, dtype=float)
    s = np.sqrt(np.clip(D, 0.0, None))
    denom = float(np.sum(s * s))
    if denom <= 0.0:
        return {"a": float(np.mean(y)) if y.size else 1.0}
    a = float(np.sum(y * s) / denom)
    if not np.isfinite(a) or a <= 0.0:
        a = float(np.mean(y / s)) if np.all(s > 0) and y.size else 1.0
    return {"a": a}