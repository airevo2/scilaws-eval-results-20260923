"""Wrapped-Gaussian orientation tuning curve (periodic over 180 deg).

R(theta) = b + A * exp(-0.5 * (d/sigma)^2),  d = wrap180(theta - theta0)

One shared functional form across all clusters; per-cluster parameters are the
baseline b, peak amplitude A, preferred orientation theta0, and tuning width
sigma. The angular difference is wrapped to a 180-degree period because
orientations 0 and 180 deg are identical (orientation-defined gratings).
"""
import numpy as np
from scipy.optimize import curve_fit

USED_INPUTS = ["orientation_deg"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {
    "b": {"init": None},
    "A": {"init": None},
    "th0": {"init": None},
    "sig": {"init": None},
}


def _form(th, b, A, th0, sig):
    d = ((th - th0 + 90.0) % 180.0) - 90.0
    return b + A * np.exp(-0.5 * (d / sig) ** 2)


def fit(X_fit, y_fit):
    th = np.asarray(X_fit[:, 0], dtype=float)
    y = np.asarray(y_fit, dtype=float)
    b0 = float(np.median(y))
    A0 = float(max(y.max() - b0, 1.0))
    th0_0 = float(th[int(np.argmax(y))])
    sig0 = 15.0
    try:
        popt, _ = curve_fit(
            _form, th, y, p0=[b0, A0, th0_0, sig0],
            bounds=([-1e5, 0.0, -360.0, 1.0], [1e5, 1e6, 360.0, 90.0]),
            maxfev=10000,
        )
        b, A, th0, sig = [float(v) for v in popt]
        if not np.isfinite(A) or A < 0:
            A = A0
        if not np.isfinite(sig) or sig <= 0:
            sig = sig0
        return {"b": b, "A": A, "th0": th0, "sig": sig}
    except Exception:
        return {"b": b0, "A": A0, "th0": th0_0, "sig": sig0}


def predict(X, b, A, th0, sig):
    th = np.asarray(X[:, 0], dtype=float)
    return _form(th, b, A, th0, sig)