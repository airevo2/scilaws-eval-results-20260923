"""Shared power-law allometry linking leaf area to sapwood area and height.

Across all probed clusters the response is well described by a single
monotone power law in the two inputs

    A_L = k * A_S^p * H^q

where the EXPONENTS (p, q) are shared structural constants of the mechanism
and only the scalar coefficient k is re-fit for each cluster (the few
per-cluster scale differences).  Regressing log A_L on log A_S and log H
within each cluster gives compatible near-constant exponents (cluster 0:
~1.33/-0.95, cluster 4: ~1.10/-0.83, clusters 1 & 2: ~0.95/0.0), and a joint
fit with per-cluster intercepts and common slopes yields p ~ 1.14, q ~ -0.71.
The form is therefore a pure power law in (A_S, H) with one local scale.
"""
import numpy as np

USED_INPUTS = ["a_ssbh", "h_t"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {"k": {"init": None}}

_P = 1.14   # shared exponent on sapwood cross-sectional area
_Q = -0.71  # shared exponent on height


def _base(A, H):
    A = np.asarray(A, dtype=float)
    H = np.asarray(H, dtype=float)
    # guard against invalid values so predict stays finite
    A = np.where(A > 0, A, 1e-12)
    H = np.where(H > 0, H, 1e-12)
    return np.power(A, _P) * np.power(H, _Q)


def fit(X_fit, y_fit):
    X_fit = np.asarray(X_fit, dtype=float)
    y_fit = np.asarray(y_fit, dtype=float).ravel()
    base = _base(X_fit[:, 0], X_fit[:, 1])
    m = np.isfinite(base) & np.isfinite(y_fit) & (base > 0) & (y_fit > 0)
    if m.sum() == 0:
        return {"k": 1.0}
    # geometric-mean scale factor (equivalent to OLS on log-scale with slope 1)
    k = float(np.exp(np.mean(np.log(y_fit[m]) - np.log(base[m]))))
    if not np.isfinite(k) or k <= 0:
        k = 1.0
    return {"k": k}


def predict(X, k):
    X = np.asarray(X, dtype=float)
    return k * _base(X[:, 0], X[:, 1])