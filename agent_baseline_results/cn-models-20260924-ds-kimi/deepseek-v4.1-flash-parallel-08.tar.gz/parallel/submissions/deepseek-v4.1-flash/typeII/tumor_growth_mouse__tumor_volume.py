"""Gompertz tumor-growth law: V(t) = K * exp( ln(V0/K) * exp(-r t) ).

The caliper volume follows a Gompertz saturating growth curve. The specific
growth rate g(V) = (1/V) dV/dt = r * (ln K - ln V) is linear in ln V, which is
exactly what the per-group derivative analysis showed (gr vs lnV R^2 ~ 0.98-0.996).
Each cluster is described by three local parameters: V0 (initial volume), r
(proliferation rate, per day) and K (carrying capacity, mm^3). Same functional
form for every cluster; only (V0, r, K) are re-fit per cluster.
"""
import numpy as np
from scipy.optimize import curve_fit

USED_INPUTS = ["time_day"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {"V0": {"init": None}, "r": {"init": None}, "K": {"init": None}}


def _gompertz(t, V0, r, K):
    V0 = np.maximum(V0, 1e-9)
    K = np.maximum(K, 1e-9)
    return K * np.exp(np.log(V0 / K) * np.exp(-r * t))


def fit(X_fit, y_fit):
    t = np.asarray(X_fit[:, 0], dtype=float)
    y = np.asarray(y_fit, dtype=float)
    y = np.where(y > 1e-6, y, 1e-6)
    logy = np.log(y)

    # initial guesses from the observed range
    V0_0 = max(float(y[0]), 1.0)
    K_0 = max(float(np.max(y)) * 1.5, V0_0 * 1.5)
    r_0 = 0.2

    def f(t, V0, r, K):
        return np.log(np.clip(_gompertz(t, V0, r, K), 1e-12, None))

    best = None
    for p0 in ([V0_0, r_0, K_0], [V0_0, 0.1, K_0], [V0_0, 0.4, K_0]):
        try:
            popt, _ = curve_fit(f, t, logy, p0=p0,
                                bounds=([1e-3, 1e-4, 1e-1], [1e6, 5.0, 1e7]),
                                maxfev=20000)
            rss = float(np.sum((logy - f(t, *popt)) ** 2))
            if best is None or rss < best[0]:
                best = (rss, popt)
        except Exception:
            continue

    if best is None:
        # crude fallback: exponential / linear-in-log fit
        try:
            A = np.vstack([np.ones_like(t), t]).T
            c, _, _, _ = np.linalg.lstsq(A, logy, rcond=None)
            r = max(c[1], 1e-3)
            V0 = float(np.exp(c[0]))
            K = float(np.exp(c[0] + c[1] * (t.max() + 5.0)))
        except Exception:
            V0, r, K = V0_0, r_0, K_0
        return {"V0": V0, "r": r, "K": K}

    V0, r, K = best[1]
    return {"V0": float(V0), "r": float(abs(r)), "K": float(abs(K))}


def predict(X, V0, r, K):
    t = np.asarray(X[:, 0], dtype=float)
    return _gompertz(t, V0, r, K)