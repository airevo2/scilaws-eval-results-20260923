"""Sharp-crested (tilted) weir: standard weir equation with a Rehbock-type
discharge coefficient that is linear in the relative head h/p.

    Q = (2/3) * Cd * sqrt(2g) * b * h^(3/2)

    Cd = a + k * (h/p)

The tilt of the weir plate (fixed within each experimental group) sets the
per-cluster level `a` and slope `k` of the coefficient; the functional shape
is shared by every cluster.
"""
import numpy as np

USED_INPUTS = ["h_m", "p_m", "b_m"]
LAW_CONSTANTS = {"g": 9.81}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {"a": {"init": None}, "k": {"init": None}}

_G = 9.81
_C = (2.0 / 3.0) * np.sqrt(2.0 * _G)


def _Cd_from(X, y):
    h = X[:, 0]
    p = X[:, 1]
    b = X[:, 2]
    return y / (_C * b * h ** 1.5), h / p


def fit(X_fit, y_fit):
    h = X_fit[:, 0]
    p = X_fit[:, 1]
    b = X_fit[:, 2]
    x = h / p
    Cd = y_fit / (_C * b * h ** 1.5)
    A = np.column_stack([np.ones_like(x), x])
    try:
        coef, *_ = np.linalg.lstsq(A, Cd, rcond=None)
        a = float(coef[0])
        k = float(coef[1])
    except Exception:
        a, k = float(np.mean(Cd)), 0.0
    if not np.isfinite(a):
        a = float(np.mean(Cd))
    if not np.isfinite(k):
        k = 0.0
    return {"a": a, "k": k}


def predict(X, a, k):
    h = X[:, 0]
    p = X[:, 1]
    b = X[:, 2]
    Cd = a + k * (h / p)
    return _C * b * h ** 1.5 * Cd