"""Urban scaling (Cobb-Douglas) power law: log GMP is linear in log population.
Shared structure: ln Y = a_g + b_g * ln N, with per-cluster productivity (intercept)
and per-cluster agglomeration elasticity (slope)."""
import numpy as np

USED_INPUTS = ["log_pop"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {"a": {"init": None}, "b": {"init": None}}


def fit(X_fit, y_fit):
    x = np.asarray(X_fit[:, 0], dtype=float)
    y = np.asarray(y_fit, dtype=float)
    # Ordinary least squares of ln Y on ln N
    n = x.size
    if n < 2:
        return {"a": float(np.mean(y)) if n else 0.0, "b": 1.0}
    xm = x.mean()
    ym = y.mean()
    sxx = np.sum((x - xm) ** 2)
    if sxx <= 0:
        return {"a": float(ym - 1.0 * xm), "b": 1.0}
    b = np.sum((x - xm) * (y - ym)) / sxx
    a = ym - b * xm
    return {"a": float(a), "b": float(b)}


def predict(X, a, b):
    x = np.asarray(X[:, 0], dtype=float)
    return a + b * x