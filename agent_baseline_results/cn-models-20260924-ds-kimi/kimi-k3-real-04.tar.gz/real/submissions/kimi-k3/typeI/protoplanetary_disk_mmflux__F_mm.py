"""Disk 1.3 mm flux vs stellar mass (BCAH98 grid), blending detection-only OLS
with censored (Tobit) likelihood to correct for the ~51% non-detection fraction.
log10 F_1.3mm = a + b * log10 M_star(BCAH98)."""
import numpy as np

USED_INPUTS = ["log10_M_star_BCAH98"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    logM = X[:, 0]
    return -1.5618 + 0.6373 * logM