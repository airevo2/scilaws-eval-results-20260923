"""Pooled Greenberg-type fundamental diagram: q = alpha(corridor) * k * v0 * [ln(kj/k)]^m.

Type-I single-pool fit: one shared density-flow curve (v0, kj, m) with a single
multiplicative corridor factor (alpha for I-80, fixed at 1 for US-101). This is a
generalised Greenberg speed-density law v = v0 [ln(kj/k)]^m, which rises from
q=0 at k=0, peaks near observed freeway capacity (~3500 veh/h/ln for US-101),
and decays to 0 at the jam density kj. Four fitted constants total.
"""
import numpy as np

USED_INPUTS = ["k_veh_km_lane", "corridor"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    k = np.asarray(X[:, 0], dtype=float)
    corridor = np.asarray(X[:, 1], dtype=float)
    alpha = np.where(corridor < 0.5, 1.0, 0.77740229)
    v0 = 21.1172584
    kj = 452.49196318
    m = 0.74204817
    log_term = np.log(np.maximum(kj, 1.001) / np.maximum(k, 1e-9))
    q = alpha * k * v0 * np.power(np.clip(log_term, 0.0, None), m)
    return np.clip(q, 0.0, None)