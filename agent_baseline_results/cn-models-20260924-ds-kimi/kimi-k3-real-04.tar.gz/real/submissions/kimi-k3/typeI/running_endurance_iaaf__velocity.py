"""Velocity vs distance: multiplicative sex factor times a quadratic in ln(distance).
v = (1 - r*(1-s_M)) * (a + b*ln d + c*(ln d)^2). Sex ratio ~0.902 constant across
distances; quadratic in log d captures the sprint-to-endurance curvature and gives
physically sensible declining velocities for 20-100 km ultras."""
import numpy as np

USED_INPUTS = ["distance_m", "sex_M"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    d = np.asarray(X[:, 0], dtype=float)
    s = np.asarray(X[:, 1], dtype=float)
    x = np.log(d)
    base = 16.26397 - 1.624916 * x + 0.05892 * x * x
    return (1.0 - 0.097933 * (1.0 - s)) * base