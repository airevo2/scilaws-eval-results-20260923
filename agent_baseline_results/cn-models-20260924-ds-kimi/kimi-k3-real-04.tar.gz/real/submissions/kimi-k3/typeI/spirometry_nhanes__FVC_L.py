"""FVC for adolescent boys: linear in h^2 plus piecewise-linear age (knots 12, 16)."""
import numpy as np

USED_INPUTS = ["age", "height_cm"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    age = X[:, 0]
    h = X[:, 1]
    a1 = np.minimum(age, 12.0)
    a2 = np.clip(age - 12.0, 0.0, 4.0)
    a3 = np.clip(age - 16.0, 0.0, None)
    return (-0.80502049
            + 0.0001776602 * h**2
            - 0.022807261 * a1
            + 0.1691807 * a2
            + 0.099623689 * a3)