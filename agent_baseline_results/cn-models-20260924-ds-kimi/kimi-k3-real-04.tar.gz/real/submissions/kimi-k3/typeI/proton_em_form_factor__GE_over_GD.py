"""Proton GE/GD via GM_Kelly/mu_p times a piecewise-linear polarization ratio P(Q^2),
divided by the standard dipole. P captures the Rosenbluth-to-polarization transition
(slope break at Q^2~0.58) and is flattened beyond Q^2~5.66 to stay physical in
extrapolation. 4 fitted constants + 1 fixed tail slope."""
import numpy as np

USED_INPUTS = ["Q2_GeV2"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    q = np.asarray(X[:, 0], dtype=float)
    # Standard dipole form factor
    GD = (1.0 + q / 0.71) ** -2
    # Kelly (2004) magnetic Sachs form factor GM_p / mu_p
    Mp2 = 0.93827203 ** 2
    t = q / (4.0 * Mp2)
    GM_over_mu = (1.0 + 0.12 * t) / (1.0 + 10.97 * t + 18.86 * t ** 2 + 6.55 * t ** 3)
    # Polarization ratio mu_p*GE/GM: continuous piecewise linear in Q^2
    c1, s1, s2 = 0.58375, -0.06652, -0.13472   # fitted break point and slopes
    c2, s3 = 5.6629, -0.02                      # fitted second break; fixed mild tail slope
    P = 1.0 + s1 * q
    P = np.where(q > c1, 1.0 + s1 * c1 + s2 * (q - c1), P)
    P = np.where(q > c2, 1.0 + s1 * c1 + s2 * (c2 - c1) + s3 * (q - c2), P)
    # GE/GD = (GM/mu_p) * P / GD
    return GM_over_mu * P / GD