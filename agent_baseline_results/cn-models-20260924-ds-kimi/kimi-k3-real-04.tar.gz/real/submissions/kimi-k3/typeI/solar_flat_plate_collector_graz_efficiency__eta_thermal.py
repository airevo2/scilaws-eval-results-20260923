"""Flat-plate collector gross-area thermal efficiency.

Empirical reduced-temperature formulation with a mild inlet-temperature
curvature and a small ambient-temperature/irradiance coupling (captures
residual temperature-dependent optical/loss effects):

    eta = a0 - a1*(T_in - T_amb)/G + b1*T_in + b2*T_in^2/1e4 + q*G*T_amb/1e5

The first two terms are the classical Hottel-Whillier linear loss law in
reduced temperature T*=(T_in-T_amb)/G; the remaining terms absorb the
observed mean-temperature dependence of the loss/optical coefficients.
Constants fitted by ordinary least squares on the 252-row training set.
"""
import numpy as np

USED_INPUTS = ["G_W_m2", "T_in_C", "T_amb_C", "WS_m_s"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    G = X[:, 0]
    Tin = X[:, 1]
    Tamb = X[:, 2]
    dT = Tin - Tamb
    return (2.36018191
            - 2.48309076 * dT / G
            - 0.04792538 * Tin
            + 3.24648126 * Tin**2 / 1.0e4
            + 0.20055031 * G * Tamb / 1.0e5)