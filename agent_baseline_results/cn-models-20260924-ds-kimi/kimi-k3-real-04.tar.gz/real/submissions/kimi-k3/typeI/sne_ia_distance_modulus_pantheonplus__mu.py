"""Standardised SN Ia Hubble diagram: flat Lambda-CDM distance modulus versus CMB-frame redshift.

predict computes mu = 5 log10[(1+z) * integral_0^z du/E(u)] + C for a flat
Lambda-CDM universe with E(u)=sqrt(Omega_m(1+u)^3+1-Omega_m). The two global
constants (Omega_m=0.34416831 and C=43.07761246, i.e. H0 about 72.66 km/s/Mpc)
were fitted jointly to the 1392 training supernovae and extrapolate smoothly to
z>0.4. Gauss-Legendre quadrature (24 nodes) is accurate to <<1e-6 mag over the
training/test redshift range; no fitting is done at evaluation time.
"""
import numpy as np

USED_INPUTS = ["z_hd"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    z = np.asarray(X[:, 0], dtype=float)
    Om = 0.34416831
    C = 43.07761246
    # Gauss-Legendre nodes/weights on [-1, 1]
    x = np.array([-0.06405689286260563, -0.1911188674736163, -0.3150426796961634,
                  -0.4337935076260451, -0.5454214713888396, -0.6480936519369755,
                  -0.7401241915785544, -0.820001985973903, -0.8864155270044011,
                  -0.9382745520027328, -0.9747285559713095, -0.9951872199970213,
                   0.06405689286260563,  0.1911188674736163,  0.3150426796961634,
                   0.4337935076260451,  0.5454214713888396,  0.6480936519369755,
                   0.7401241915785544,  0.820001985973903,  0.8864155270044011,
                   0.9382745520027328,  0.9747285559713095,  0.9951872199970213], dtype=float)
    w = np.array([0.12793819534675216, 0.1258374563468283, 0.12167047292780339,
                  0.1155056680537256, 0.10744427011596563, 0.09761865210411389,
                  0.08619016153195328, 0.07334648141108031, 0.05929858491543678,
                  0.04427743881741981, 0.028531388628933663, 0.0123412297999872,
                  0.12793819534675216, 0.1258374563468283, 0.12167047292780339,
                  0.1155056680537256, 0.10744427011596563, 0.09761865210411389,
                  0.08619016153195328, 0.07334648141108031, 0.05929858491543678,
                  0.04427743881741981, 0.028531388628933663, 0.0123412297999872], dtype=float)
    u = 0.5 * z[:, None] * (x[None, :] + 1.0)
    integrand = 1.0 / np.sqrt(Om * (1.0 + u) ** 3 + (1.0 - Om))
    integral = 0.5 * z * np.sum(integrand * w[None, :], axis=1)
    return 5.0 * np.log10((1.0 + z) * integral) + C