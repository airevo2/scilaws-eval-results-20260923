"""BH mass from fundamental-plane-style linear relation in log-space:
log10(M_BH) = a + b*log10(sigma0) + c*log10(M_sph) + d*Pseudobulge.
Fitted by OLS on the 99 training rows (rmse 0.404, LOO 0.423, 10-fold CV 0.423,
best of the forms tested). Pseudobulges sit ~0.68 dex below classical bulges at
fixed sigma and spheroid mass (Sahu/Graham/Davis-style offset). Extrapolates
monotonically and sensibly (power-law in both sigma and M_sph)."""
import numpy as np

USED_INPUTS = ["sigma0", "log_M_sph", "B_T", "Pseudobulge"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    sigma0 = X[:, 0]
    log_M_sph = X[:, 1]
    pb = X[:, 3]
    return -2.0679 + 2.6833 * np.log10(sigma0) + 0.4050 * log_M_sph - 0.6788 * pb