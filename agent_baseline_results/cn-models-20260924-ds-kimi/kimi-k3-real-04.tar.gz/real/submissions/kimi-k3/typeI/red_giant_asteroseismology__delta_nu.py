"""Asteroseismic large-separation scaling for red giants, calibrated on RGB stars:
delta_nu ∝ nu_max^(3/4) * (Teff/5772 K)^(3/8) — the relation obtained by combining
nu_max ∝ g/sqrt(Teff) and delta_nu ∝ sqrt(mean density). Amplitude and exponent
fitted on hydrogen-shell-burning (phase==1) stars, which dominate the high-nu_max
regime where the test set lies; physically motivated exponents ensure sensible
extrapolation to nu_max ≈ 273 uHz (delta_nu ≈ 17-20 uHz)."""
import numpy as np

USED_INPUTS = ["nu_max", "Teff"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    nu_max = X[:, 0]
    Teff = X[:, 1]
    return 0.30082 * np.power(nu_max, 0.74800) * np.power(Teff / 5772.0, 0.375)