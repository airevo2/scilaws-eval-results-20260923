"""GLI-style multiplicative spirometry reference equation for FEV1 (L) in adult women.

FEV1 = exp(c0) * (h/100)^p * exp(-a*age) * (age/20)^c
fitted by nonlinear least squares in the original (litre) space.
4 fitted constants; monotone decline with age, power-law rise with height,
positive and physically sensible under extrapolation.
"""
import numpy as np

USED_INPUTS = ["age", "height_cm"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    age = X[:, 0]
    h = X[:, 1]
    return np.exp(0.60596211 + 1.93950392 * np.log(h / 100.0) - 0.01658869 * age) * (age / 20.0) ** 0.28186912