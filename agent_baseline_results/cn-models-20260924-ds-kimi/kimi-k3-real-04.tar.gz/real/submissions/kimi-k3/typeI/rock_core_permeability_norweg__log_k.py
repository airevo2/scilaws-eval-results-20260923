"""Porosity-permeability: log10(k) = a + b*(1 - exp(-(4.8*phi)^2.1) + 0.15*phi).
A stretched-exponential (Weibull-CDF-shaped) rise captures the strongly nonlinear,
concave-then-saturating permo-porosity trend; the small linear term keeps the
high-porosity end rising gently for safe extrapolation to phi=0.6. Two fitted
constants (a=-1.4065, b=4.3886); fixed shape exponents."""
import numpy as np

USED_INPUTS = ["phi"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    phi = X[:, 0]
    f = 1.0 - np.exp(-(4.8 * phi) ** 2.1) + 0.15 * phi
    return -1.4064800642625908 + 4.388596612986242 * f