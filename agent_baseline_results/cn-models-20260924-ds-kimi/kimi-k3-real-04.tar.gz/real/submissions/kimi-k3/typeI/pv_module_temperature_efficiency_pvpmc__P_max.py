"""PV module max-power: P = (G/1000)*Tpoly(dT,AM,Gn)*exp(AMpoly)*WSpoly*Gpoly, physically factorized."""
import numpy as np

USED_INPUTS = ["G_W_m2", "T_module_C", "WS_m_s", "air_mass"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    G = X[:, 0]; T = X[:, 1]; WS = X[:, 2]; AM = X[:, 3]
    dT = T - 25.0
    x = AM - 1.5
    Gn = (G - 1000.0) / 1000.0
    w = WS - 1.0
    tpoly = (216.79123207510716
             - 0.20874123807469863 * dT
             - 0.011894474394679829 * dT**2
             + 2.1165293691155937e-05 * dT**3
             - 0.49254234218720017 * x * dT
             + 0.20186996075018912 * dT * Gn
             - 0.0229768252805605 * x * dT**2)
    amfac = np.exp(0.22537421220559822 * x
                   - 0.07533853669065368 * x**2
                   + 0.035433988521252804 * x**3)
    wfac = 1.0 + 0.0034324946241310475 * w + 0.004046293317601715 * w**2
    gfac = (1.0 - 0.0930537445411547 * Gn
            - 0.3968448498469726 * Gn**2
            - 0.43336094567168154 * Gn**3
            + 0.2584382203039659 * x * Gn
            - 0.00026545411693348317 * dT * w
            - 1.773952041655978e-05 * dT**2 * w)
    return (G / 1000.0) * tpoly * amfac * wfac * gfac