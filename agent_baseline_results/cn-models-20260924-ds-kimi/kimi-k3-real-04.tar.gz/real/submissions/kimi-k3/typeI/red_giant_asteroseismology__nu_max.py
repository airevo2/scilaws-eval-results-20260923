"""nu_max scaling relation anchored to the Sun: nu_max = nu_max,sun * (delta_nu/delta_nu,sun)^b * (Teff/Teff,sun)^(-1/2), with b fitted (=1.4024); solar reference values are physical constants, so only one free global constant is used. Form follows the acoustic-cutoff-frequency homology argument and stays physically sensible when extrapolated to higher delta_nu."""
import numpy as np

USED_INPUTS = ["delta_nu", "Teff"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    dnu = X[:, 0]
    teff = X[:, 1]
    # Solar anchors: nu_max,sun = 3090 uHz, delta_nu,sun = 135.1 uHz, Teff,sun = 5772 K
    return 22.8727 * np.power(dnu, 1.4024) * np.power(teff / 5772.0, -0.5)