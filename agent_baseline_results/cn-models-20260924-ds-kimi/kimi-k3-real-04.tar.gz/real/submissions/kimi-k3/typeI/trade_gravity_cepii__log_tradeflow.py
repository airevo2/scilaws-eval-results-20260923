"""Log-linear gravity equation: ln X_ij = b0 + b1 ln Y_i + b2 ln Y_n + b3 ln d_ij
+ b4 contig + b5 comlang_off + b6 fta_wto. Coefficients from OLS on 470k training
pairs (7 free constants, within cap)."""
import numpy as np

USED_INPUTS = ["log_gdp_o", "log_gdp_d", "log_dist", "contig", "comlang_off", "fta_wto"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    lo = X[:, 0]
    ld = X[:, 1]
    dist = X[:, 2]
    contig = X[:, 3]
    comlang = X[:, 4]
    fta = X[:, 5]
    return (-18.74195282
            + 1.17341683 * lo
            + 0.88793280 * ld
            - 1.15677541 * dist
            + 1.03869944 * contig
            + 0.95909470 * comlang
            + 0.76367781 * fta)