"""Allometric AGB law (Chave et al. 2014 form): AGB = c * (rho * D^2 * H)^b, constants refit by L1 regression in log10 space on the training data."""
import numpy as np

USED_INPUTS = ["wood_density", "diameter_cm", "height_m"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    rho = X[:, 0]
    D = X[:, 1]
    H = X[:, 2]
    return 0.059330 * (rho * D**2 * H) ** 0.983680