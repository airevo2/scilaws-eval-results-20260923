"""Michaelis-Menten substrate saturation: v = Vmax * S / (Km + S), fit per cluster."""
import numpy as np

USED_INPUTS = ["substrate_conc"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {"Vmax": {"init": None}, "Km": {"init": None}}

def _mm(S, Vmax, Km):
    return Vmax * S / (Km + S)

def fit(X_fit, y_fit):
    from scipy.optimize import least_squares
    S = np.asarray(X_fit[:, 0], dtype=float)
    y = np.asarray(y_fit, dtype=float)
    ypos = np.maximum(y, 1e-3)

    # Positivity-safe inits.
    Vp0 = max(float(np.max(y)), 1e-3)
    Kp0 = float(np.clip(np.median(S), 1.0, 500.0))

    # Primary: robust log-space least squares (noise is multiplicative).
    def resid(lp):
        V, K = np.exp(lp)
        return np.log(np.maximum(_mm(S, V, K), 1e-6)) - np.log(ypos)

    try:
        p0 = np.log([Vp0, Kp0])
        lo = np.log([1e-4, 1e-3])
        hi = np.log([1e8, 1e8])
        r = least_squares(resid, p0, bounds=(lo, hi), max_nfev=4000)
        V, K = np.exp(r.x)
        if np.isfinite(V) and np.isfinite(K) and V > 0 and K > 0:
            return {"Vmax": float(V), "Km": float(K)}
    except Exception:
        pass

    # Fallback: ordinary linear least squares on the untransformed data.
    try:
        from scipy.optimize import curve_fit
        popt, _ = curve_fit(_mm, S, y, p0=[Vp0, Kp0], maxfev=10000)
        V, K = float(popt[0]), float(popt[1])
        if np.isfinite(V) and np.isfinite(K) and V > 0 and K > 0:
            return {"Vmax": V, "Km": K}
    except Exception:
        pass

    return {"Vmax": Vp0, "Km": Kp0}

def predict(X, Vmax, Km):
    S = np.asarray(X[:, 0], dtype=float)
    out = Vmax * S / (Km + S)
    return np.where(np.isfinite(out), out, 0.0)