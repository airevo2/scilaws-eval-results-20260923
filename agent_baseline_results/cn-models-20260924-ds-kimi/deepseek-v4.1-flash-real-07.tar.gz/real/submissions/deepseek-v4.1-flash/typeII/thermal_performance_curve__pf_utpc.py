"""Two-sided (skew) Gaussian thermal performance curve, fit per cluster.

P(T) = Pmax * exp( -0.5 * ((T - Topt)/s)^2 ),  s = s_left if T < Topt else s_right
"""
import numpy as np
from scipy.optimize import least_squares

USED_INPUTS = ["temperature"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}

LOCAL_FITTABLE = {
    "Pmax": {"init": None},
    "Topt": {"init": None},
    "s_left": {"init": None},
    "s_right": {"init": None},
}


def _form(T, Pmax, Topt, s_left, s_right):
    s = np.where(T < Topt, s_left, s_right)
    return Pmax * np.exp(-0.5 * ((T - Topt) / s) ** 2)


def fit(X_fit, y_fit):
    T = np.asarray(X_fit[:, 0], dtype=float)
    y = np.asarray(y_fit, dtype=float)

    Tlo, Tup = float(np.min(T)), float(np.max(T))
    Tr = max(Tup - Tlo, 1e-6)
    ymax = float(np.max(y))
    ymean = float(np.mean(y))

    # Fallback parameters (also used if optimisation fails).
    fb = {
        "Pmax": max(ymax, 1e-12),
        "Topt": float(T[int(np.argmax(y))]),
        "s_left": Tr / 2.0,
        "s_right": Tr / 2.0,
    }

    # Only attempt curve fitting when there is real variation and positive peak.
    if ymax <= 1e-15 or (np.max(y) - np.min(y)) <= 1e-18:
        return fb

    iopt = int(np.argmax(y))
    topts = [float(T[iopt]), 0.5 * (Tlo + Tup), Tlo + 0.7 * Tr, Tlo + 0.3 * Tr]
    sds = [Tr / 3.0, Tr / 2.0, Tr / 4.0]

    lb = [0.0, Tlo - Tr, Tr / 50.0, Tr / 50.0]
    ub = [ymax * 10.0 + 1e-12, Tup + Tr, Tr * 20.0, Tr * 20.0]

    best = None
    best_err = np.inf
    for to in topts:
        for sd in sds:
            p0 = [max(ymax, 1e-12), to, sd, sd]
            try:
                sol = least_squares(
                    lambda p: _form(T, *p) - y,
                    p0,
                    bounds=(lb, ub),
                    loss="soft_l1",
                    f_scale=0.1 * ymax,
                    max_nfev=400,
                )
                err = float(np.sum((_form(T, *sol.x) - y) ** 2))
                if err < best_err:
                    best_err = err
                    best = sol.x
            except Exception:
                continue

    if best is None or not np.all(np.isfinite(best)):
        return fb

    Pmax = float(best[0])
    Topt = float(best[1])
    s_left = float(best[2])
    s_right = float(best[3])

    if not np.isfinite(Pmax) or Pmax < 0:
        Pmax = fb["Pmax"]
    if not np.isfinite(Topt):
        Topt = fb["Topt"]
    if not np.isfinite(s_left) or s_left <= 0:
        s_left = Tr / 2.0
    if not np.isfinite(s_right) or s_right <= 0:
        s_right = Tr / 2.0

    return {"Pmax": Pmax, "Topt": Topt, "s_left": s_left, "s_right": s_right}


def predict(X, Pmax, Topt, s_left, s_right):
    T = np.asarray(X[:, 0], dtype=float)
    yp = _form(T, Pmax, Topt, s_left, s_right)
    yp = np.where(np.isfinite(yp), yp, 0.0)
    return np.clip(yp, 0.0, None)