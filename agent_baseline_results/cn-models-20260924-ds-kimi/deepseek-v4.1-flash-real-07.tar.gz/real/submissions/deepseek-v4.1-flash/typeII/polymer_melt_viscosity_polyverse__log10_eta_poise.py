"""Arrhenius temperature dependence plus universal molecular-weight scaling.

log10(eta) = a + b/T + c * log10(Mw)

c is a universal (shared) Mw exponent; a and b are the only per-cluster
(per-polymer) parameters, calibrated by linear least squares on one window.
The form is smooth and physically sensible for extrapolation in T and Mw.
"""
import numpy as np

USED_INPUTS = ["Temperature_K", "log10_Mw", "Shear_Rate", "Tg_K"]
LAW_CONSTANTS = {"c_Mw": 2.8}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {"a": {"init": None}, "b": {"init": None}}

_C_MW = 2.8


def fit(X_fit, y_fit):
    T = np.asarray(X_fit[:, 0], dtype=float)
    Mw = np.asarray(X_fit[:, 1], dtype=float)
    y = np.asarray(y_fit, dtype=float)
    # subtract the universal Mw term, then fit a + b/T by least squares
    r = y - _C_MW * Mw
    invT = 1.0 / np.clip(T, 1.0, None)
    A = np.column_stack([np.ones_like(invT), invT])
    try:
        coef, *_ = np.linalg.lstsq(A, r, rcond=None)
        a = float(coef[0])
        b = float(coef[1])
        if not (np.isfinite(a) and np.isfinite(b)):
            raise ValueError
    except Exception:
        mean_r = float(np.mean(r)) if r.size else 0.0
        a, b = mean_r, 0.0
    return {"a": a, "b": b}


def predict(X, a, b):
    T = np.asarray(X[:, 0], dtype=float)
    Mw = np.asarray(X[:, 1], dtype=float)
    invT = 1.0 / np.clip(T, 1.0, None)
    return a + b * invT + _C_MW * Mw