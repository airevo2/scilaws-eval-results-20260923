"""Dispersion form: n^2 = 1 + A*lambda^2/(lambda^2 - B) - C*lambda^2.

A UV Sellmeier pole (A, B with B < lambda_min^2) plus a broad infrared
correction term (-C*lambda^2). Three per-cluster parameters (A, B, C),
fitted by reducing to a linear least-squares problem in (A, C) for each
candidate pole B, scanning/refining B by a bounded scalar minimisation.
Stays physically sensible when extrapolated (n decreases smoothly with
wavelength and remains > 1)."""
import numpy as np
from scipy.optimize import minimize_scalar

USED_INPUTS = ["wavelength_um"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {"A": {"init": None}, "B": {"init": None}, "C": {"init": None}}


def fit(X_fit, y_fit):
    lam = np.asarray(X_fit[:, 0], float)
    n = np.asarray(y_fit, float)
    o = np.argsort(lam)
    lam, n = lam[o], n[o]
    y2 = n ** 2
    lmin2 = float(lam.min()) ** 2
    lo = 1e-8
    hi = lmin2 * 0.999999
    if hi <= lo:
        hi = lo * 10.0

    def obj(B):
        denom = lam ** 2 - B
        if np.any(denom <= 0):
            return 1e18
        M = np.column_stack([lam ** 2 / denom, -lam ** 2])
        try:
            sol = np.linalg.lstsq(M, y2 - 1.0, rcond=None)[0]
        except Exception:
            return 1e18
        return float(np.sum((1.0 + M @ sol - y2) ** 2))

    B = 0.5 * (lo + hi)
    try:
        r = minimize_scalar(obj, bounds=(lo, hi), method="bounded",
                            options={"xatol": 1e-12})
        B = float(r.x)
    except Exception:
        pass

    denom = lam ** 2 - B
    if np.any(denom <= 0):
        B = lo
        denom = lam ** 2 - B
    M = np.column_stack([lam ** 2 / denom, -lam ** 2])
    try:
        A, C = np.linalg.lstsq(M, y2 - 1.0, rcond=None)[0]
    except Exception:
        A, C = 1.0, 0.0
    if not np.isfinite(A) or not np.isfinite(C):
        A, C = 1.0, 0.0
    return {"A": float(A), "B": float(B), "C": float(C)}


def predict(X, A, B, C):
    lam = np.asarray(X[:, 0], float)
    denom = lam ** 2 - B
    denom = np.where(denom == 0.0, 1e-12, denom)
    v = 1.0 + A * lam ** 2 / denom - C * lam ** 2
    return np.sqrt(np.maximum(v, 1e-6))