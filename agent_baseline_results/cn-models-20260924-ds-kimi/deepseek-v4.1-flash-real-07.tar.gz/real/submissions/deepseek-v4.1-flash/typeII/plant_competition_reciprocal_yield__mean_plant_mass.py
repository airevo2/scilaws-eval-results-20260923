"""Reciprocal yield law of plant competition: w = a / (1 + k*N).

Mean per-plant mass (w) declines with surviving density (N) because the pot's
resources are shared.  The reciprocal-yield / Michaelis-Menten form
w = a/(1+k*N) is the standard physical model: at low density each plant
approaches its potential mass a, while at high density total yield saturates so
per-plant mass falls as ~ a/(k*N).  Only two per-cluster parameters (a, k) vary
between species; a is the low-density asymptotic mass and k sets the density at
which crowding halves it.
"""
import numpy as np

USED_INPUTS = ["density"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {"a": {"init": None}, "k": {"init": None}}


def fit(X_fit, y_fit):
    N = np.asarray(X_fit[:, 0], dtype=float)
    w = np.asarray(y_fit, dtype=float)
    # Reciprocal yield: 1/w = (1/a) + (k/a) * N  -> linear least squares.
    try:
        X = np.column_stack([np.ones_like(N), N])
        coef, *_ = np.linalg.lstsq(X, 1.0 / w, rcond=None)
        b0, b1 = float(coef[0]), float(coef[1])
        if not np.isfinite(b0) or b0 <= 1e-9:
            b0 = 1.0 / max(np.max(w), 1e-9)
        if not np.isfinite(b1) or b1 < 1e-6:
            b1 = 1e-6
        a = 1.0 / b0
        k = b1 / b0
    except Exception:
        a = float(np.max(w)) if np.size(w) else 1.0
        k = 1e-3
    if not np.isfinite(a) or a <= 0:
        a = float(np.max(w)) if np.size(w) else 1.0
    if not np.isfinite(k) or k <= 0:
        k = 1e-3
    return {"a": a, "k": k}


def predict(X, a, k):
    N = np.asarray(X[:, 0], dtype=float)
    return a / (1.0 + k * N)