"""Van Genuchten (1980) soil-water characteristic curve:
theta(h) = theta_r + (theta_s - theta_r) / [1 + (alpha*h)^n]^m, with m = 1 - 1/n.
Four per-cluster parameters (theta_r, theta_s, alpha, n) are fit by bounded
least squares on each cluster's window; the same functional form is used for
every cluster. This is the standard physically-motivated WRC model.
"""
import numpy as np
from scipy.optimize import curve_fit

USED_INPUTS = ["lab_head_m"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}

LOCAL_FITTABLE = {
    "theta_r": {"init": None},
    "theta_s": {"init": None},
    "alpha": {"init": None},
    "n": {"init": None},
}


def _vg(h, theta_r, theta_s, alpha, n):
    h = np.asarray(h, dtype=float)
    m = 1.0 - 1.0 / n
    return theta_r + (theta_s - theta_r) / (1.0 + (alpha * h) ** n) ** m


def fit(X_fit, y_fit):
    h = np.asarray(X_fit[:, 0], dtype=float)
    t = np.asarray(y_fit, dtype=float)

    # Bounds (physically sensible). theta in [0,1]; alpha in (0, large]; n > 1.
    tr_lo, tr_hi = 0.0, max(float(np.min(t)), 0.0) * 1.0 + 1e-6
    ts_lo = max(float(np.max(t)), 0.02)
    ts_hi = 1.0
    lo = np.array([tr_lo, min(ts_lo, 0.999), 1e-6, 1.02])
    hi = np.array([min(tr_hi, 0.99), ts_hi, 1e3, 25.0])
    # ensure lo < hi strictly
    lo = np.minimum(lo, hi - 1e-8)

    ts0 = min(max(float(np.max(t)) * 1.002, 0.05), 0.999)
    tr0 = min(max(float(np.min(t)) * 0.5, 0.0), 0.9)

    starts = []
    for a in (0.01, 0.05, 0.3):
        for n in (1.3, 2.5):
            starts.append([tr0, ts0, a, n])

    best = None
    best_cost = np.inf
    for p0 in starts:
        p0 = np.clip(np.array(p0, dtype=float), lo + 1e-8, hi - 1e-8)
        try:
            popt, _ = curve_fit(_vg, h, t, p0=p0, bounds=(lo, hi), maxfev=4000)
            pred = _vg(h, *popt)
            cost = float(np.sum((pred - t) ** 2))
            if np.isfinite(cost) and cost < best_cost:
                best_cost = cost
                best = popt
        except Exception:
            continue

    if best is None:
        # fallback: simple two-parameter-ish guess
        return {"theta_r": tr0, "theta_s": ts0, "alpha": 0.05, "n": 1.5}

    return {
        "theta_r": float(best[0]),
        "theta_s": float(best[1]),
        "alpha": float(best[2]),
        "n": float(best[3]),
    }


def predict(X, theta_r, theta_s, alpha, n):
    h = np.asarray(X[:, 0], dtype=float)
    out = _vg(h, theta_r, theta_s, alpha, n)
    out = np.where(np.isfinite(out), out, theta_s)
    return out