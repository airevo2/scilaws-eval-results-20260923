"""Saturating (Leuning-style) stomatal conductance response to VPD: Gc = a / (1 + D/b)."""
import numpy as np
from scipy.optimize import curve_fit

USED_INPUTS = ["vpd"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {"a": {"init": None}, "b": {"init": None}}


def _form(D, a, b):
    return a / (1.0 + D / b)


def fit(X_fit, y_fit):
    D = np.asarray(X_fit[:, 0], dtype=float)
    y = np.asarray(y_fit, dtype=float)
    p0 = [max(float(np.max(y)), 0.1), max(float(np.median(D)), 0.2)]
    try:
        popt, _ = curve_fit(
            _form, D, y, p0=p0,
            bounds=([1e-4, 1e-3], [1e5, 1e3]),
            maxfev=10000,
        )
        a_hat, b_hat = float(popt[0]), float(popt[1])
        if not (np.isfinite(a_hat) and np.isfinite(b_hat) and a_hat > 0 and b_hat > 0):
            raise ValueError
    except Exception:
        a_hat, b_hat = p0
    return {"a": a_hat, "b": b_hat}


def predict(X, a, b):
    D = np.asarray(X[:, 0], dtype=float)
    return a / (1.0 + D / b)