"""Solar disk spectral radiance as a blackbody (Planck) at a per-cluster effective
temperature.  L(lambda) = 2 h c^2 / (lambda^5 (exp(hc/(lambda k T)) - 1)),
consistent with L = SSI / Omega for a blackbody Sun seen through the SORCE-SIM bins.
The single per-cluster parameter is the effective (brightness) temperature T."""
import numpy as np
from scipy.optimize import minimize_scalar

USED_INPUTS = ["wavelength_nm"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {"T": {"init": [5772.0]}}

# physical constants (not fitted)
_h = 6.62607015e-34
_c = 2.99792458e8
_kB = 1.380649e-23


def _planck(lam_nm, T):
    lam = np.asarray(lam_nm, float) * 1e-9
    x = _h * _c / (lam * _kB * T)
    x = np.clip(x, 1e-12, 500.0)
    B = (2.0 * _h * _c**2 / lam**5) / np.expm1(x)
    return B * 1e-9  # W m^-2 nm^-1 sr^-1


def fit(X_fit, y_fit):
    lam = np.asarray(X_fit[:, 0], float)
    y = np.asarray(y_fit, float)

    def ssd(T):
        p = _planck(lam, T)
        return float(np.sum((p - y) ** 2))

    T = 5772.0
    try:
        res = minimize_scalar(ssd, bounds=(3500.0, 9000.0), method="bounded",
                              options={"xatol": 0.5})
        if np.isfinite(res.x):
            T = float(res.x)
    except Exception:
        pass
    if not np.isfinite(T) or T <= 0:
        T = 5772.0
    return {"T": float(T)}


def predict(X, T):
    return _planck(np.asarray(X[:, 0], float), T)