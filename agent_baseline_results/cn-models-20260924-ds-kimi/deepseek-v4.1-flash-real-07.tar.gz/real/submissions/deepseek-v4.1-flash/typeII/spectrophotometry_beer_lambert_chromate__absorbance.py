"""Beer-Lambert absorbance with a quadratic concentration deviation:
   A = a * c * l + b * c^2 * l  (per-cluster a, b)."""
import numpy as np

USED_INPUTS = ["concentration", "path_length"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {"a": {"init": None}, "b": {"init": None}}

def fit(X_fit, y_fit):
    c = X_fit[:, 0]
    l = X_fit[:, 1]
    X = np.column_stack([c * l, c * c * l])
    try:
        p, _, _, _ = np.linalg.lstsq(X, y_fit, rcond=None)
        if not np.all(np.isfinite(p)):
            raise ValueError("non-finite")
        return {"a": float(p[0]), "b": float(p[1])}
    except Exception:
        cl = c * l
        denom = float(np.sum(cl * cl))
        a = float(np.sum(cl * y_fit) / denom) if denom > 1e-12 else 0.0
        return {"a": a, "b": 0.0}

def predict(X, a, b):
    c = X[:, 0]
    l = X[:, 1]
    return a * c * l + b * c * c * l