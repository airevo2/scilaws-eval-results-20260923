"""Holling type II functional response, fit per cluster.

    N_a = a * N / (1 + b * N)

where N is prey_density, a is the attack-rate scale (units of items per unit
density) and b (>= 0) sets the saturation density. Both parameters are
per-cluster (equivalent to attack rate a and handling time h = b/a).
"""
import numpy as np
from scipy.optimize import curve_fit

USED_INPUTS = ["prey_density"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {"a": {"init": None}, "b": {"init": None}}


def _form(N, a, b):
    return a * N / (1.0 + b * N)


def fit(X_fit, y_fit):
    N = np.asarray(X_fit[:, 0], dtype=float)
    Na = np.asarray(y_fit, dtype=float)
    # sensible fallbacks
    a0 = float(np.sum(N * Na) / np.sum(N * N)) if np.sum(N * N) > 0 else 1.0
    if not np.isfinite(a0) or a0 <= 0:
        a0 = 1.0
    med = float(np.median(N)) if N.size else 1.0
    b0 = 1.0 / med if med > 0 else 1.0
    try:
        popt, _ = curve_fit(_form, N, Na, p0=[a0, b0], maxfev=5000,
                            bounds=(0.0, np.inf))
        a, b = float(popt[0]), float(popt[1])
        if not (np.isfinite(a) and np.isfinite(b)) or a <= 0 or b < 0:
            raise ValueError
        return {"a": a, "b": b}
    except Exception:
        return {"a": a0, "b": b0}


def predict(X, a, b):
    N = np.asarray(X[:, 0], dtype=float)
    return a * N / (1.0 + b * N)