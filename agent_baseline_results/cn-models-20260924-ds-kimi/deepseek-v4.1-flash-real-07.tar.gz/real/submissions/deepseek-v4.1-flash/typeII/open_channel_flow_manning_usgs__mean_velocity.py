"""Power-law stage-velocity relation: V = a * R^0.5, one per-cluster coefficient.

Physically the cross-section mean velocity scales with hydraulic depth as a
power law; the bed slope is constant within each reach (cluster) and therefore
only rescales the local coefficient a, so it need not appear explicitly. The
single local parameter a is fit per cluster by least squares, which directly
minimises the RMSE objective. The exponent 0.5 (~sqrt) matches the empirical
value found across clusters and behaves sensibly for extrapolation.
"""
import numpy as np

USED_INPUTS = ["R_m", "SLOPE"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {"a": {"init": [0.5]}}

_P = 0.5

def fit(X_fit, y_fit):
    R = X_fit[:, 0].astype(float)
    V = y_fit.astype(float)
    base = np.power(np.clip(R, 1e-9, None), _P)
    denom = float(np.sum(base * base))
    if denom <= 0 or not np.isfinite(denom):
        a = float(np.mean(V)) if len(V) else 0.5
    else:
        a = float(np.sum(V * base) / denom)
    if not np.isfinite(a) or a <= 0:
        a = 0.5
    return {"a": a}

def predict(X, a):
    R = X[:, 0].astype(float)
    base = np.power(np.clip(R, 1e-9, None), _P)
    return a * base