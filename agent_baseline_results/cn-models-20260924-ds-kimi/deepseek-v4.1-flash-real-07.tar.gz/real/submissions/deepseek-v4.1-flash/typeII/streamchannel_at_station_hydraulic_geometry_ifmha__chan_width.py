"""At-a-station hydraulic geometry: width ~ discharge power law.
w = 10**a * Q**b, with per-cluster intercept a and slope b (log-log linear)."""
import numpy as np

USED_INPUTS = ["chan_discharge"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {"a": {"init": None}, "b": {"init": None}}

def fit(X_fit, y_fit):
    Q = np.asarray(X_fit[:, 0], dtype=float)
    y = np.asarray(y_fit, dtype=float)
    ok = (Q > 0) & (y > 0) & np.isfinite(Q) & np.isfinite(y)
    if np.sum(ok) >= 2:
        xl = np.log10(Q[ok])
        yl = np.log10(y[ok])
        b, a = np.polyfit(xl, yl, 1)
    else:
        # fallback: no positive data
        a = np.log10(max(np.mean(y) if len(y) else 10.0, 1e-6))
        b = 0.15
    if not np.isfinite(a):
        a = 1.5
    if not np.isfinite(b):
        b = 0.15
    # keep slope physically sensible (0 < b < 1 typically); clamp extremes
    b = float(np.clip(b, 0.0, 0.9))
    return {"a": float(a), "b": float(b)}

def predict(X, a, b):
    Q = np.asarray(X[:, 0], dtype=float)
    Q = np.where(Q > 0, Q, 1e-6)
    return np.power(10.0, a) * np.power(Q, b)