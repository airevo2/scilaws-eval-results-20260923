"""Log male/female central death rate ratio as a per-cluster linear combination
of three fixed shape features: log(age), an exponential age-decay term, and
sqrt(year). Each cluster (country/population) gets its own three coefficients,
which absorb its level and its age-profile tilt.

    ln_sex_ratio(age, year) = a*log(age) + b*exp(-(age-30)/30) + c*sqrt(year)

The shape features are universal (fixed structural constants only, no fitted
global constants); only {a, b, c} vary across clusters and are calibrated by
ordinary least squares on the fit window.
"""
import numpy as np

USED_INPUTS = ["age", "year"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {"a": {"init": None}, "b": {"init": None}, "c": {"init": None}}


def _design(X):
    age = np.asarray(X[:, 0], dtype=float)
    year = np.asarray(X[:, 1], dtype=float)
    f1 = np.log(np.clip(age, 1.0, None))          # log(age)
    f2 = np.exp(-(age - 30.0) / 30.0)             # age decay term
    f3 = np.sqrt(np.clip(year, 1.0, None))        # sqrt(year)
    return np.column_stack([f1, f2, f3])


def fit(X_fit, y_fit):
    A = _design(X_fit)
    y = np.asarray(y_fit, dtype=float)
    try:
        coef, _, _, _ = np.linalg.lstsq(A, y, rcond=None)
    except Exception:
        coef = np.zeros(3)
    if not np.all(np.isfinite(coef)):
        coef = np.zeros(3)
    return {"a": float(coef[0]), "b": float(coef[1]), "c": float(coef[2])}


def predict(X, a, b, c):
    A = _design(X)
    return A[:, 0] * a + A[:, 1] * b + A[:, 2] * c