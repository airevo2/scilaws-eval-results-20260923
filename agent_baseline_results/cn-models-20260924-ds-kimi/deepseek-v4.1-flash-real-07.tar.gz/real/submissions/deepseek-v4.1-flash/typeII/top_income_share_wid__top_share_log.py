"""Top-share log linear in log_p with a year-slope on the log_p coefficient.

ln S(p) = a + b*ln(p) + c*ln(p)*(year - 2001)

Three per-cluster parameters (a, b, c); the (year-2001) interaction lets the
Pareto slope drift linearly over time while extrapolation stays linear and
sensible for any p or year.
"""
import numpy as np

USED_INPUTS = ["log_p_above", "top_pct", "year"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {"a": {"init": None}, "b": {"init": None}, "c": {"init": None}}

_Y0 = 2001.0


def _design(X):
    L = X[:, 0]
    T = X[:, 2] - _Y0
    return np.column_stack([L, L * T, np.ones_like(L)])


def fit(X_fit, y_fit):
    L = np.asarray(X_fit[:, 0], dtype=float)
    T = np.asarray(X_fit[:, 2], dtype=float) - _Y0
    y = np.asarray(y_fit, dtype=float)
    A = np.column_stack([L, L * T, np.ones_like(L)])
    try:
        # mild ridge on the interaction term for numerical stability
        n = A.shape[0]
        pen = np.zeros((3, 3))
        pen[1, 1] = 1e-6 * n
        coef = np.linalg.solve(A.T @ A + pen, A.T @ y)
        b, c, a = coef
    except Exception:
        b = c = 0.0
        a = float(np.mean(y)) if len(y) else 0.0
    if not np.all(np.isfinite([a, b, c])):
        b = c = 0.0
        a = float(np.mean(y)) if len(y) else 0.0
    return {"a": float(a), "b": float(b), "c": float(c)}


def predict(X, a, b, c):
    X = np.asarray(X, dtype=float)
    L = X[:, 0]
    T = X[:, 2] - _Y0
    return a + b * L + c * L * T