"""Asymmetric Gaussian cycle shape: monthly sunspot number rises faster than it
falls, peaking at the solar-cycle maximum.  The left/right width ratio R is a
single universal shape constant; amplitude A, peak epoch t0 and rise width w are
re-fit from each cluster's own data.  This captures the well-known Waldmeier
effect (fast rise / slow decay) while keeping the per-cluster freedom small."""
import numpy as np
from scipy.optimize import curve_fit

USED_INPUTS = ["t_year"]
LAW_CONSTANTS = {"R": 2.0}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {"A": {"init": None}, "t0": {"init": None}, "w": {"init": None}}


def _shape(t, A, t0, w, R):
    d = t - t0
    s = np.where(d < 0.0, w, w * R)
    return A * np.exp(-0.5 * (d / s) ** 2)


def fit(X_fit, y_fit):
    t = np.asarray(X_fit[:, 0], dtype=float)
    y = np.asarray(y_fit, dtype=float)
    R = LAW_CONSTANTS["R"]
    ymax = float(np.max(y))
    imax = int(np.argmax(y))
    A0 = max(ymax * 1.2, 3.0)
    t0_0 = float(t[imax]) + 0.5
    w0 = 2.5
    lo = [0.0, float(t.min()) - 12.0, 0.3]
    hi = [max(8000.0, 4.0 * ymax + 10.0), float(t.max()) + 12.0, 30.0]
    try:
        popt, _ = curve_fit(
            lambda tt, A, t0, w: _shape(tt, A, t0, w, R),
            t, y, p0=[A0, t0_0, w0], maxfev=6000, bounds=(lo, hi),
        )
        A, t0, w = (float(popt[0]), float(popt[1]), float(popt[2]))
        if not (np.isfinite(A) and np.isfinite(t0) and np.isfinite(w)):
            raise ValueError("non-finite fit")
        return {"A": A, "t0": t0, "w": w}
    except Exception:
        return {"A": A0, "t0": t0_0, "w": w0}


def predict(X, A, t0, w):
    t = np.asarray(X[:, 0], dtype=float)
    y = _shape(t, A, t0, w, LAW_CONSTANTS["R"])
    return np.nan_to_num(y, nan=0.0, posinf=0.0, neginf=0.0)