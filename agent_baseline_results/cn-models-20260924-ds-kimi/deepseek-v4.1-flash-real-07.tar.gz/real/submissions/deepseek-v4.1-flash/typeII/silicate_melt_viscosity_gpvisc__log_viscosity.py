"""Per-cluster Arrhenius/VFT-type temperature law: log10(eta) = a + b / (T - C).

Composition is constant within a cluster, so the temperature dependence carries the
signal; a two-parameter (a, b) fit with a fixed reference offset C reproduces each
cluster's viscosity-temperature curve and extrapolates sensibly to neighbouring
temperatures. a and b are the per-cluster fittable parameters.
"""
import numpy as np

USED_INPUTS = ["T"]
LAW_CONSTANTS = {"C": 300.0}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {"a": {"init": None}, "b": {"init": None}}

_C = 300.0


def _inv(T):
    d = T - _C
    d = np.where(d < 5.0, 5.0, d)
    return 1.0 / d


def fit(X_fit, y_fit):
    T = np.asarray(X_fit[:, 0], dtype=float)
    y = np.asarray(y_fit, dtype=float)
    z = _inv(T)
    A = np.column_stack([np.ones_like(z), z])
    try:
        coef, *_ = np.linalg.lstsq(A, y, rcond=None)
        a = float(coef[0]); b = float(coef[1])
        if not (np.isfinite(a) and np.isfinite(b)):
            raise ValueError
    except Exception:
        a = float(np.mean(y))
        b = 0.0
    return {"a": a, "b": b}


def predict(X, a, b):
    T = np.asarray(X[:, 0], dtype=float)
    z = _inv(T)
    return a + b * z