"""Leaf area from sapwood area with a height correction (single global exponent, one per-cluster intercept)."""
import numpy as np

USED_INPUTS = ["a_ssbh", "h_t"]
LAW_CONSTANTS = {"g": -0.155}   # universal height exponent shared by all clusters
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {"c": {"init": None}}   # per-cluster intercept (log-mean)

def fit(X_fit, y_fit):
    A_S = np.asarray(X_fit[:, 0], dtype=float)
    H = np.asarray(X_fit[:, 1], dtype=float)
    y = np.asarray(y_fit, dtype=float)
    ok = (A_S > 0) & (H > 0) & (y > 0)
    g = LAW_CONSTANTS["g"]
    if np.sum(ok) == 0:
        return {"c": 1.0}
    log_res = np.log(y[ok]) - np.log(A_S[ok]) - g * np.log(H[ok])
    log_c = float(np.mean(log_res))
    log_c = float(np.clip(log_c, -50.0, 50.0))
    return {"c": float(np.exp(log_c))}

def predict(X, c):
    A_S = np.asarray(X[:, 0], dtype=float)
    H = np.asarray(X[:, 1], dtype=float)
    g = LAW_CONSTANTS["g"]
    A_S = np.clip(A_S, 1e-12, None)
    H = np.clip(H, 1e-6, None)
    return c * A_S * np.power(H, g)