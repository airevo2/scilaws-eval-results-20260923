"""Sharp-crested weir discharge, universal head-shape with one per-cluster scale.

Across all clusters the weir height p and crest width b are constant within a
cluster, so their (level) effect is absorbed by the single per-cluster scale C.
What must generalise is the shape of Q versus the upstream head h. Fitting a
power law h^n to every cluster gives a consistent exponent n ~ 1.59 (slightly
steeper than the ideal 1.5), and a small negative head offset with n ~ 1.53
captures this curvature markedly better under withheld-window cross-validation:

    Q = C * b * (h + k)^n        (n, k universal; C re-fit per cluster)

C is fitted by closed-form least squares on the cluster's window; the form is
monotone and stays finite/sensible when extrapolated (the tiny offset vanishes
relative to h as h grows).
"""
import numpy as np

USED_INPUTS = ["h_m", "b_m"]
LAW_CONSTANTS = {"n": 1.53, "k": -0.0028}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {"C": {"init": None}}


def _shape(h, b, n, k):
    hh = np.maximum(h + k, 1e-4)   # keep base positive & finite
    return b * hh ** n


def fit(X_fit, y_fit):
    h = np.asarray(X_fit[:, 0], dtype=float)
    b = np.asarray(X_fit[:, 2], dtype=float)
    n = LAW_CONSTANTS["n"]
    k = LAW_CONSTANTS["k"]
    s = _shape(h, b, n, k)
    denom = float(np.sum(s * s))
    if denom <= 0 or not np.isfinite(denom):
        # fallback: match the mean level
        return {"C": float(np.mean(y_fit))}
    C = float(np.sum(y_fit * s) / denom)
    if not np.isfinite(C):
        C = float(np.mean(y_fit))
    return {"C": C}


def predict(X, C):
    h = np.asarray(X[:, 0], dtype=float)
    b = np.asarray(X[:, 2], dtype=float)
    n = LAW_CONSTANTS["n"]
    k = LAW_CONSTANTS["k"]
    return C * _shape(h, b, n, k)