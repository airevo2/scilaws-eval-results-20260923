"""Agglomeration power law: ln Y = beta * ln N + a, one global slope, per-cluster intercept."""
import numpy as np

USED_INPUTS = ["log_pop"]
LAW_CONSTANTS = {"beta": 1.095}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {"a": {"init": None}}

def fit(X_fit, y_fit):
    x = X_fit[:, 0]
    beta = LAW_CONSTANTS["beta"]
    a = float(np.mean(y_fit - beta * x))
    return {"a": a}

def predict(X, a):
    beta = LAW_CONSTANTS["beta"]
    return a + beta * X[:, 0]