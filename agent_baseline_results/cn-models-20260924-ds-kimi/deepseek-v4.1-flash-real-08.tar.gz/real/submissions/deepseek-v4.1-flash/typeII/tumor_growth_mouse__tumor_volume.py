"""Quadratic-in-time tumor growth: V = a * (t + t0)^2, two per-cluster parameters (a, t0)."""
import numpy as np
from scipy.optimize import least_squares

USED_INPUTS = ["time_day"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {"a": {"init": None}, "t0": {"init": None}}


def _form(t, a, t0):
    return a * np.maximum(t + t0, 1e-3) ** 2


def fit(X_fit, y_fit):
    t = np.asarray(X_fit[:, 0], dtype=float)
    V = np.asarray(y_fit, dtype=float)
    n = len(t)
    if n == 0:
        return {"a": 1.0, "t0": 1.0}

    def resid(p):
        a, t0 = p
        return _form(t, a, t0) - V

    # initial guess: positive a, small positive t0
    tbar = max(float(np.mean(t)), 1.0)
    a0 = max(float(np.mean(V)) / (tbar + 1.0) ** 2, 1e-6)
    try:
        r = least_squares(resid, [a0, 1.0],
                          bounds=([1e-8, -max(3.9, float(np.min(t)) - 0.1)], [1e8, 1e4]),
                          max_nfev=6000)
        a_hat, t0_hat = float(r.x[0]), float(r.x[1])
    except Exception:
        a_hat, t0_hat = a0, 0.0

    if not np.isfinite(a_hat) or a_hat <= 0:
        a_hat = a0
    if not np.isfinite(t0_hat):
        t0_hat = 0.0
    return {"a": a_hat, "t0": t0_hat}


def predict(X, a, t0):
    t = np.asarray(X[:, 0], dtype=float)
    return _form(t, a, t0)