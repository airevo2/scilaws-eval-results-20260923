"""Weibull (Chapman-Richards-style) height-diameter allometry: H = a*(1-exp(-(D/D0)^b)).
The two shape parameters D0 and b are universal across all clusters (fitted globally);
only the asymptote/scale a is re-fit per cluster from that cluster's window.
Physically sensible: monotone saturating, H(0)=0, asymptote a."""
import numpy as np

USED_INPUTS = ["DBH_cm"]
LAW_CONSTANTS = {"D0": 54.183, "b": 0.7286}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {"a": {"init": None}}


def _basis(D, D0, b):
    D = np.asarray(D, dtype=float)
    D = np.clip(D, 1e-6, None)
    return 1.0 - np.exp(-np.power(D / D0, b))


def fit(X_fit, y_fit):
    D = np.asarray(X_fit[:, 0], dtype=float)
    y = np.asarray(y_fit, dtype=float)
    f = _basis(D, LAW_CONSTANTS["D0"], LAW_CONSTANTS["b"])
    denom = float(np.sum(f * f))
    if denom <= 1e-12:
        a_hat = float(np.mean(y)) if y.size else 1.0
    else:
        a_hat = float(np.sum(f * y) / denom)
    if not np.isfinite(a_hat) or a_hat <= 0:
        a_hat = max(float(np.max(y)) if y.size else 1.0, 1.0)
    return {"a": a_hat}


def predict(X, a):
    D = np.asarray(X[:, 0], dtype=float)
    f = _basis(D, LAW_CONSTANTS["D0"], LAW_CONSTANTS["b"])
    out = a * f
    return np.asarray(out, dtype=float)