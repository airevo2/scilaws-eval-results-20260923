"""Two-harmonic orientation tuning curve: b + a*cos(2(theta-theta0)) + c*cos(4(theta-theta0)).
Per-cluster parameters {b, a, c, theta0}. Given theta0 the model is linear in (b,a,c),
so fit() scans theta0 over a grid and solves a tiny linear least-squares at each point,
which is fast and robust. The even-harmonic (2nd + 4th) Fourier form is the standard
orientation-tuning shape and generalises across clusters."""
import numpy as np

USED_INPUTS = ["orientation_deg"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {
    "b": {"init": None},
    "a": {"init": None},
    "c": {"init": None},
    "th0": {"init": None},
}


def _design(th, t0):
    d = 2.0 * np.deg2rad(th - t0)
    return np.column_stack([np.ones_like(th), np.cos(d), np.cos(2.0 * d)])


def _solve_at(th, r, t0):
    B = _design(th, t0)
    coef, _, _, _ = np.linalg.lstsq(B, r, rcond=None)
    resid = B @ coef - r
    return float(np.sum(resid * resid)), coef


def fit(X_fit, y_fit):
    th = np.asarray(X_fit[:, 0], dtype=float)
    r = np.asarray(y_fit, dtype=float)
    if th.size == 0 or not np.all(np.isfinite(r)):
        return {"b": float(np.mean(r)) if r.size else 0.0, "a": 0.0, "c": 0.0, "th0": 0.0}
    b_fallback = float(np.percentile(r, 10))

    best_cost, best_coef, best_t0 = None, None, 0.0
    for t0 in np.arange(0.0, 180.0, 5.0):
        try:
            cost, coef = _solve_at(th, r, t0)
        except Exception:
            continue
        if best_cost is None or cost < best_cost:
            best_cost, best_coef, best_t0 = cost, coef, t0

    # refine theta0 on a finer grid around the best coarse value
    if best_t0 is not None:
        for t0 in np.arange(best_t0 - 5.0, best_t0 + 5.0 + 1e-9, 1.0):
            try:
                cost, coef = _solve_at(th, r, t0)
            except Exception:
                continue
            if cost < best_cost:
                best_cost, best_coef, best_t0 = cost, coef, t0

    if best_coef is None:
        return {"b": b_fallback, "a": 0.0, "c": 0.0, "th0": 0.0}
    return {
        "b": float(best_coef[0]),
        "a": float(best_coef[1]),
        "c": float(best_coef[2]),
        "th0": float(best_t0),
    }


def predict(X, b, a, c, th0):
    th = np.asarray(X[:, 0], dtype=float)
    d = 2.0 * np.deg2rad(th - th0)
    return b + a * np.cos(d) + c * np.cos(2.0 * d)