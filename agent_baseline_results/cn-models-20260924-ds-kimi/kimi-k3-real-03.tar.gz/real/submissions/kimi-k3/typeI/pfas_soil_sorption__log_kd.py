"""PFAS soil-water partitioning: organic-carbon partitioning with sub-linear foc
scaling plus a pH-dependent mineral-surface background term.
log_kd = log10( Koc * foc^g + Kd_min(pH) ),
Koc = 10^(a*log_Kow + b*log_S + c), Kd_min = 10^(d + e*pH).
Constants fitted by nonlinear least squares on the 685-row training set
(row-level fit, CV RMSE ~0.54); form stays bounded and monotone when
extrapolated to long-chain, high-Kow PFAS."""
import numpy as np

USED_INPUTS = ["log_Kow", "log_S", "foc", "pH"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    log_Kow = X[:, 0]
    log_S = X[:, 1]
    foc = np.clip(X[:, 2], 1e-6, None)
    pH = X[:, 3]
    log_koc = 0.0310 * log_Kow - 0.4704 * log_S + 2.5951
    kd_oc = np.power(10.0, log_koc) * np.power(foc, 0.4765)
    kd_min = np.power(10.0, 0.6673 - 0.2091 * pH)
    return np.log10(kd_oc + kd_min + 1e-12)