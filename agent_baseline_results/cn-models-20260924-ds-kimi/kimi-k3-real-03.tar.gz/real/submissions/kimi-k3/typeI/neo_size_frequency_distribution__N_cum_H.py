"""Cumulative NEO H-distribution: log10 N(<H) = a*H + b (standard power-law
size-frequency in magnitude space), fitted by L1 in log10 space to minimize
log_mae. Linear-in-H exponential law stays sensible under extrapolation."""
import numpy as np

USED_INPUTS = ["H_upper"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    H = X[:, 0]
    return np.power(10.0, 0.474177 * H - 5.415792)