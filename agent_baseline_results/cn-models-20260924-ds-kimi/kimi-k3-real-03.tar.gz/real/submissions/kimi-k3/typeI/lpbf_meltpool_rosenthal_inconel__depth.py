"""Melt-pool depth: threshold-linear energy-density term plus a direct power/velocity
coupling channel. d = a*(P-Pth)_+ / (V^1.1662 * D^1.5421) + g*P/V.
The V and D exponents come from the clean single-power block (which spans V and D);
a, Pth, g fitted jointly by least squares. Nonnegativity is guaranteed for all
positive inputs, and the form stays physically sensible (monotone increasing in P,
decreasing in V and D) across the extrapolated test range."""
import numpy as np

USED_INPUTS = ["laser_power_W", "scan_velocity_mm_per_s", "beam_diameter_um"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    P = X[:, 0]
    V = X[:, 1]
    D = X[:, 2]
    a = 1.14470428e6
    Pth = 50.7676893
    g = 30.9296738
    c = 1.16617597
    e = 1.54210862
    return a * np.maximum(P - Pth, 0.0) / (V**c * D**e) + g * P / V