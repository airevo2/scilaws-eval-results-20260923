"""pp total cross-section: sigma = A + B*ln^2(s/28.94) + C*s^-eta (Froissart ln^2 rise + Regge fall).
B fixed to the published PDG/COMPETE value 0.308; A, C, eta fitted to training data."""
import numpy as np

USED_INPUTS = ["s"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    s = np.asarray(X[:, 0], dtype=float)
    s = np.maximum(s, 1e-6)
    return 35.2398 + 0.308 * np.log(s / 28.94) ** 2 + 14.2970 * s ** (-0.3711)