"""18650 capacity fade: quadratic in cycle index (concave, decelerating fade), monotone decreasing over [1,168]."""
import numpy as np

USED_INPUTS = ["cycle_index"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    k = X[:, 0].astype(float)
    return 2.561e-05 * k**2 - 8.44155e-03 * k + 2.06357277