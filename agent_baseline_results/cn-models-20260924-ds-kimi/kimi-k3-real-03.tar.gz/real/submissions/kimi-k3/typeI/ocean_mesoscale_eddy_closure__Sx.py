"""Linear eddy-momentum closure: Sx as a linear combination of the enstrophy-gradient, vorticity-strain-gradient terms, mean-flow advection (u), vortex-stretching/shear production (v*D), and stretching deformation (Dtilde)."""
import numpy as np

USED_INPUTS = ["u", "v", "zeta", "D", "Dtilde", "d_zeta2_dx", "d_zetaD_dx", "d_zetaDtilde_dy"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    u = X[:, 0]
    v = X[:, 1]
    D = X[:, 3]
    Dtilde = X[:, 4]
    g1 = X[:, 5]  # d(zeta^2)/dx
    g2 = X[:, 6]  # d(zeta D)/dx
    g3 = X[:, 7]  # d(zeta Dtilde)/dy
    return (-7.70113121e+08 * g1
            + 1.38612412e+09 * g2
            - 1.25001267e+09 * g3
            + 1.70024524e-07 * u
            + 4.30965999e-01 * (v * D)
            - 3.52464130e-03 * Dtilde)