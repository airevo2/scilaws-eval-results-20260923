"""Life expectancy vs GDP per capita: e0 = a - b / Y^0.72 (diminishing-returns power law)."""
import numpy as np

USED_INPUTS = ["gdppc"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    Y = X[:, 0]
    return 75.4810 - 698.7148 / np.power(Y, 0.72)