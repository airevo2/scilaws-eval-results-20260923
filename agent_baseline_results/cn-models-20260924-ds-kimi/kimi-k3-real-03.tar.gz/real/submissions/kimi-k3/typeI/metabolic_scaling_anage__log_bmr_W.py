"""Allometric BMR law: log10(B/W) = a + b*log10(M/g), with canonical 3/4
(Kleiber) exponent for robust extrapolation from 39 g–4 kg training range
out to 3.7 g shrews and 3.7 t elephants; intercept fitted to these data."""
import numpy as np

USED_INPUTS = ["body_mass_g"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    M = X[:, 0]
    return -1.81946 + 0.75 * np.log10(M)