"""Modified Steinmetz equation in log10 space: shared frequency/flux exponents and a linear temperature coefficient, with a per-waveform-shape intercept (sine/triangular/trapezoidal hysteresis-loop area factor)."""
import numpy as np

USED_INPUTS = ["f_Hz", "B_peak_T", "T_C", "waveform_id"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    f = X[:, 0]
    B = X[:, 1]
    T = X[:, 2]
    w = X[:, 3].astype(int)
    # per-waveform intercept (waveform factor of the Steinmetz law)
    c0 = np.where(w == 0, -4.05, np.where(w == 1, -4.25, -4.55))
    return c0 + 1.74 * np.log10(f) + 2.50 * np.log10(B) - 0.0030 * (T - 60.0)