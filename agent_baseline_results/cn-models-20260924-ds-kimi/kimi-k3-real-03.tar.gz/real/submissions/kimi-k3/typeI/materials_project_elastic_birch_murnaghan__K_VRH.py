"""Bulk modulus K_VRH (GPa) from an energy-density scaling law:
K scales as (mass density)^(2/3) divided by atomic volume^(4/3), i.e.
K = C * rho^(2/3) / V^(4/3). Physically, K is an energy per unit volume;
with characteristic cohesive energy scaling as E ~ V^(-2/3) (d^2E/dV^2 term),
one obtains K ~ (M/V)^(2/3) / V^(4/3). Fit C=1372.35 (rho in g/cm^3, V in A^3)
by least squares on 827 training compounds (CV RMSE ~ 36.3 GPa). The form is
positive, monotone, and well-behaved under extrapolation."""
import numpy as np

USED_INPUTS = ["V_atomic_A3", "density_g_cm3"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    V = X[:, 0]
    rho = X[:, 1]
    return 1372.35329 * np.power(rho, 2.0/3.0) / np.power(V, 4.0/3.0)