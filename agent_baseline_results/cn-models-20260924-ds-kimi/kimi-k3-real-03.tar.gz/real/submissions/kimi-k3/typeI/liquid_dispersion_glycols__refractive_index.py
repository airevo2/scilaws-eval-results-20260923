"""Ethylene glycol refractive index: two-term Cauchy dispersion with a linear,
weakly dispersive thermo-optic term: n(l,T) = c0 + c1/l^2 + (c2 + c3/l^2)*T.
Constants from a Huber-robust least-squares fit to the training grid (l in um,
T in degC); validates against published n_D(20C)=1.4318, n_D(25C)=1.4306 and
extrapolates smoothly into 0.65-1.07 um."""
import numpy as np

USED_INPUTS = ["lambda_um", "temperature_C"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    lam = X[:, 0]
    T = X[:, 1]
    inv2 = 1.0 / (lam * lam)
    return (1.426807934
            + 0.003757101837 * inv2
            + (-0.0002740225739 - 3.660887682e-06 * inv2) * T)