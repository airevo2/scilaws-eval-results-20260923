"""Parker-spiral azimuthal IMF: B_phi = C1 * B_r / sqrt(v_sw^2 + v_a^2).

Physics: the Parker spiral gives tan(psi) = |B_phi/B_r| = Omega*r/v_sw, i.e.
B_phi = -B_r * (Omega*r) / sqrt(v_sw^2 + (Omega*r)^2) when B_r itself is the
radial field already reduced by the spiral geometry; equivalently the
azimuthal response to B_r saturates for slow wind. Here v_a = 550 km/s is a
fixed structural constant (asymptotic spiral speed scale at 1 AU, bracketing
Omega*r_AU ~ 404 km/s) and C1 = -528.49 is the single fitted global constant
(negative: positive outward B_r maps to negative/prograde-reversed B_phi).
The form is odd in B_r, bounded, monotone in |B_r|, decreases gently with
v_sw, and stays physically sensible on the test range.
"""
import numpy as np

USED_INPUTS = ["B_r_nT", "v_sw_km_s", "r_AU"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    B_r = X[:, 0]
    v_sw = X[:, 1]
    # C1 = -528.49 (fitted); v_a = 550 km/s fixed Parker-spiral asymptote scale
    return -528.49 * B_r / np.sqrt(v_sw**2 + 550.0**2)