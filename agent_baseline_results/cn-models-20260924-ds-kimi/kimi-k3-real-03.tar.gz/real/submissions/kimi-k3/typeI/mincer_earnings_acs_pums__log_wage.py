"""Extended Mincer wage equation: piecewise-linear returns to schooling with knots at 10, 14, and 19 years (capturing low-education flatness, the high-school-to-college rise, and a flattened post-graduate slope), plus the classic concave quadratic experience profile peaking near 34 years."""
import numpy as np

USED_INPUTS = ["SCHL_years", "exp"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    s = X[:, 0]
    x = X[:, 1]
    h10 = np.maximum(s - 10.0, 0.0)
    h14 = np.maximum(s - 14.0, 0.0)
    h19 = np.maximum(s - 19.0, 0.0)
    return (9.817083550645005
            + 0.12149504228807251 * h10
            + 0.043531439817935884 * h14
            - 0.15759914523247218 * h19
            + 0.036157781290706695 * x
            - 0.0005272409106294586 * x**2)