"""Cubic polynomial in log10-log10 space for the Mars cumulative crater SFD.

log10(N(>=D)) = a*x^3 + b*x^2 + c*x + d, with x = log10(D_lower_km).

A cubic in log-log space captures the smooth steepening of the cumulative
size-frequency distribution from slope ~-1 near D=1 km to ~-3.5 at D~120 km,
with sub-0.005 dex mean error on training and the best strict forward
(extrapolation) cross-validation among candidate forms. Only D_lower_km is
used; the other columns are perfectly collinear with it."""
import numpy as np

USED_INPUTS = ["D_lower_km"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    x = np.log10(np.asarray(X[:, 0], dtype=float))
    log10_N = (-0.52843732 * x**3
               + 1.23369969 * x**2
               - 1.90854969 * x
               - 2.56908592)
    return np.power(10.0, log10_N)