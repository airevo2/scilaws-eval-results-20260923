"""Nine-term liquid-drop style fit for binding energy per nucleon B/A (MeV), fitted to the training nuclei."""
import numpy as np

USED_INPUTS = ["Z", "N", "A", "NZ_diff", "pair"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    Z = X[:, 0].astype(float)
    N = X[:, 1].astype(float)
    A = X[:, 2].astype(float)
    D = X[:, 3].astype(float)
    pair = X[:, 4].astype(float)
    I = D / A
    C = Z * (Z - 1.0) / A**(4.0/3.0)
    return (17.65468401
            - 26.81758703 * A**(-1.0/3.0)
            - 0.80654874 * C
            - 12.11104550 * I*I
            + 11.54004798 * A**(-2.0/3.0)
            + 6.23128093 * pair / A**1.3
            + 20.64822651 * I*I / A
            + 0.81289556 * C * np.abs(I)
            - 1.33381990 * np.abs(D) / A**(2.0/3.0))