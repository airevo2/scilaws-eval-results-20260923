"""Mauna Loa monthly CO2: exponential(tau=54yr)+linear secular trend, annual and
semiannual harmonics with a linearly growing annual-cycle amplitude.

Form (tc = year_decimal - 2000, t = year_decimal):
  c(t) = a0 + a1*tc + a2*exp(tc/54)
         + b1*cos(2 pi t) + b2*sin(2 pi t)
         + b3*cos(4 pi t) + b4*sin(4 pi t)
         + tc*(g1*cos(2 pi t) + g2*sin(2 pi t))
The mild exponential acceleration (tau ~ 54 yr) extrapolates far more safely than
a quadratic, which was observed to overshoot badly beyond the training window.
Training RMSE 0.787 ppm; forward-extrapolation holdouts (train<=2010..2016 ->
predict later years) give RMSE ~0.53-0.65 ppm, and 2020-2026 predictions track
observed Mauna Loa annual means.
"""
import numpy as np

USED_INPUTS = ["year_decimal"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    t = X[:, 0]
    tc = t - 2000.0
    e = np.exp(tc / 54.0)
    y = (280.2833623663
         + 0.1844896507 * tc
         + 88.8603709379 * e
         - 0.9450853969 * np.cos(2.0 * np.pi * t)
         + 2.7601705720 * np.sin(2.0 * np.pi * t)
         + 0.6520385620 * np.cos(4.0 * np.pi * t)
         - 0.4428676411 * np.sin(4.0 * np.pi * t)
         + 0.0051384136 * tc * np.cos(2.0 * np.pi * t)
         + 0.0099225440 * tc * np.sin(2.0 * np.pi * t))
    return y