"""Cardinal Temperature Model with Inflection (CTMI, Rosso 1993) for temperature-
dependent growth (OD600 at 24 h). One functional form shared by all clusters;
the four cardinal-temperature / amplitude parameters are re-fit per cluster."""
import numpy as np
from scipy.optimize import curve_fit

USED_INPUTS = ["T"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {
    "Tmin": {"init": [10.0]},
    "Topt": {"init": [38.0]},
    "Tmax": {"init": [45.0]},
    "mu_opt": {"init": [0.5]},
}

def _ctmi(T, Tmin, Topt, Tmax, mu_opt):
    T = np.asarray(T, dtype=float)
    num = mu_opt * (T - Tmax) * (T - Tmin) ** 2
    den = (Topt - Tmin) * ((Topt - Tmin) * (T - Topt)
                           - (Topt - Tmax) * (Topt + Tmin - 2.0 * T))
    safe = np.where(np.abs(den) < 1e-12, 1e-9, den)
    mu = num / safe
    mu = np.where((T <= Tmin) | (T >= Tmax), 0.0, mu)
    return np.clip(mu, 0.0, None)

def fit(X_fit, y_fit):
    T = np.asarray(X_fit[:, 0], dtype=float)
    y = np.asarray(y_fit, dtype=float)
    p0 = [10.0, 38.0, 45.0, max(0.1, float(np.max(y)) if y.size else 0.5)]
    bounds = ([0.0, 25.0, 40.0, 0.0], [25.0, 44.0, 55.0, 5.0])
    try:
        popt, _ = curve_fit(_ctmi, T, y, p0=p0, bounds=bounds, maxfev=20000)
        return {"Tmin": float(popt[0]), "Topt": float(popt[1]),
                "Tmax": float(popt[2]), "mu_opt": float(popt[3])}
    except Exception:
        return {"Tmin": p0[0], "Topt": p0[1], "Tmax": p0[2], "mu_opt": p0[3]}

def predict(X, Tmin, Topt, Tmax, mu_opt):
    return _ctmi(X[:, 0], Tmin, Topt, Tmax, mu_opt)