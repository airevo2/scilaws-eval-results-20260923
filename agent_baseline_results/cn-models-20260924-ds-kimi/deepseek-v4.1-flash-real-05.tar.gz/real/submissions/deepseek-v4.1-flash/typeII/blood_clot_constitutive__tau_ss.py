"""Per-cluster 3-term elastic shear response: tau = a*|gamma| + b*gamma^3 + c*gamma^5. The odd high-order terms capture the stiffening filament network, while the |gamma| term captures the low-amplitude nonlinearity/asymmetry seen in the cyclic hysteresis envelope."""
import numpy as np

USED_INPUTS = ["gamma", "conc_mM", "time_min"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {"a": {"init": None}, "b": {"init": None}, "c": {"init": None}}


def _design(gam):
    return np.column_stack([np.abs(gam), gam ** 3, gam ** 5])


def fit(X_fit, y_fit):
    gam = X_fit[:, 0]
    A = _design(gam)
    try:
        coef, *_ = np.linalg.lstsq(A, y_fit, rcond=None)
        a, b, c = float(coef[0]), float(coef[1]), float(coef[2])
        if not (np.isfinite(a) and np.isfinite(b) and np.isfinite(c)):
            raise ValueError
    except Exception:
        a, b, c = 0.0, 6.0, 0.0
    return {"a": a, "b": b, "c": c}


def predict(X, a, b, c):
    gam = X[:, 0]
    return a * np.abs(gam) + b * gam ** 3 + c * gam ** 5