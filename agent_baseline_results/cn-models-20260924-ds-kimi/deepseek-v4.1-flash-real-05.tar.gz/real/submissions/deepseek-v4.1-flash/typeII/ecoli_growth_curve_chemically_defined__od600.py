"""Four-parameter logistic (sigmoidal) growth curve, one per cluster.

OD600(t) = A + (K - A) / (1 + exp(-r * (t - t_mid)))

A      : baseline (inoculum) OD
K      : carrying-capacity plateau OD
r      : maximal specific growth rate (1/h)
t_mid  : inflection time (h)

All four parameters are re-fit per cluster from that cluster's fit window;
the functional shape is identical for every cluster.
"""
import numpy as np
from scipy.optimize import curve_fit

USED_INPUTS = ["time_h"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {
    "A": {"init": None},
    "K": {"init": None},
    "r": {"init": None},
    "t_mid": {"init": None},
}


def _logistic(t, A, K, r, t_mid):
    z = np.clip(r * (np.asarray(t, dtype=float) - t_mid), -60.0, 60.0)
    return A + (K - A) / (1.0 + np.exp(-z))


def _fallback(y_fit, t_fit):
    A = float(np.mean(y_fit[:3])) if len(y_fit) >= 3 else float(y_fit[0])
    K = float(max(np.max(y_fit) + 0.05, A + 0.15))
    r = 0.8
    t_mid = float(t_fit[len(t_fit) // 2])
    return {"A": A, "K": K, "r": r, "t_mid": t_mid}


def fit(X_fit, y_fit):
    t = np.asarray(X_fit[:, 0], dtype=float)
    y = np.asarray(y_fit, dtype=float)

    # sort by time to make initialisation sensible
    order = np.argsort(t)
    t = t[order]
    y = y[order]

    if len(t) < 4:
        return _fallback(y, t)

    A0 = float(np.mean(y[:min(3, len(y))]))
    K0 = float(max(np.max(y) + 0.05, A0 + 0.15))
    y_half = A0 + 0.5 * (K0 - A0)
    idx = np.argmax(y > y_half)
    if idx > 0 and y_half > y[0]:
        t_mid0 = float(t[idx])
    else:
        t_mid0 = float(t[len(t) // 2])

    lower = [-0.15, 0.05, 0.02, -25.0]
    upper = [0.5, 3.0, 20.0, 80.0]

    best = None
    for tm in (t_mid0, t_mid0 + 3.0, t_mid0 - 2.0, t_mid0 + 6.0):
        for r0 in (0.4, 0.8, 1.6):
            try:
                popt, _ = curve_fit(
                    _logistic, t, y,
                    p0=[A0, K0, r0, tm],
                    bounds=(lower, upper),
                    maxfev=4000,
                )
                resid = _logistic(t, *popt) - y
                mse = float(np.mean(resid * resid))
                if best is None or mse < best[0]:
                    best = (mse, popt)
            except Exception:
                continue

    if best is None:
        return _fallback(y, t)

    popt = best[1]
    A = float(np.clip(popt[0], lower[0], upper[0]))
    K = float(np.clip(popt[1], lower[1], upper[1]))
    r = float(np.clip(popt[2], lower[2], upper[2]))
    t_mid = float(np.clip(popt[3], lower[3], upper[3]))
    return {"A": A, "K": K, "r": r, "t_mid": t_mid}


def predict(X, A, K, r, t_mid):
    t = np.asarray(X[:, 0], dtype=float)
    return _logistic(t, A, K, r, t_mid)