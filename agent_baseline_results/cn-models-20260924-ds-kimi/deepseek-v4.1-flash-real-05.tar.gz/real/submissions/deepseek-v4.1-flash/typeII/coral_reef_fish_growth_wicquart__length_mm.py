"""Power-law length-at-age: L = A * Age^B (2 per-cluster parameters, fit by least squares)."""
import numpy as np
from scipy.optimize import curve_fit

USED_INPUTS = ["Agei"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {"A": {"init": None}, "B": {"init": None}}


def _form(a, A, B):
    return A * np.power(np.maximum(a, 0.0), B)


def fit(X_fit, y_fit):
    a = np.asarray(X_fit[:, 0], dtype=float)
    y = np.asarray(y_fit, dtype=float)
    # least-squares fit in log space is more robust for a power law
    pos = a > 0
    A0, B0 = 100.0, 0.28
    if pos.sum() >= 2 and np.all(y[pos] > 0):
        try:
            lb = np.log(y[pos])
            la = np.log(a[pos])
            B0, logA = np.polyfit(la, lb, 1)
            A0 = float(np.exp(logA))
        except Exception:
            pass
    p0 = [max(A0, 1e-3), B0]
    try:
        popt, _ = curve_fit(_form, a, y, p0=p0, maxfev=20000)
        A, B = float(popt[0]), float(popt[1])
        if not (np.isfinite(A) and np.isfinite(B)):
            raise ValueError
    except Exception:
        A, B = p0
    return {"A": A, "B": B}


def predict(X, A, B):
    a = np.asarray(X[:, 0], dtype=float)
    return _form(a, A, B)