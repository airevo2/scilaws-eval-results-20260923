"""
Distance-decay of taxonomic similarity: stretched-exponential form
    S = exp(-a * d^b)
with two per-cluster parameters (a, b). Passes through S=1 at d=0
(identical environments share all species) and decays monotonically,
staying within [0,1] for all d >= 0.
"""
import numpy as np
from scipy.optimize import curve_fit

USED_INPUTS = ["env_dist"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {"a": {"init": [0.3]}, "b": {"init": [0.7]}}


def _form(d, a, b):
    d = np.asarray(d, dtype=float)
    d = np.maximum(d, 0.0)
    return np.exp(-a * np.power(d, b))


def fit(X_fit, y_fit):
    d = np.asarray(X_fit[:, 0], dtype=float)
    y = np.asarray(y_fit, dtype=float)
    p0 = [0.3, 0.7]
    try:
        popt, _ = curve_fit(
            _form, d, y, p0=p0,
            bounds=([1e-6, 1e-3], [5.0, 5.0]),
            maxfev=20000,
        )
        a, b = float(popt[0]), float(popt[1])
        if not (np.isfinite(a) and np.isfinite(b)):
            raise ValueError
        return {"a": a, "b": b}
    except Exception:
        # Robust fallback: fit only the exponent on the log scale with b fixed.
        try:
            mask = (y > 1e-3) & (d > 1e-8)
            if mask.sum() >= 2:
                lr = np.log(y[mask])
                dd = np.log(d[mask])
                A = np.vstack([np.ones_like(dd), dd]).T
                coef, _, _, _ = np.linalg.lstsq(A, -lr, rcond=None)
                b = float(np.clip(coef[1], 1e-3, 5.0))
                a = float(np.clip(coef[0], 1e-6, 5.0))
                return {"a": a, "b": b}
        except Exception:
            pass
        return {"a": 0.3, "b": 0.7}


def predict(X, a, b):
    return _form(X[:, 0], a, b)