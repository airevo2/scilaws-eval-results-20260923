"""Geiger-Nuttall / Gamow law: log10(T1/2) = A / sqrt(Q_alpha) + B, fit per cluster.

The alpha-decay half-life follows the Gamow tunneling formula, whose dominant
dependence is exp(const/sqrt(Q)); in log10 this becomes A/sqrt(Q) + B. Only the
two intercept/slope parameters vary between isotope chains (clusters), so this is
a genuinely transferable one-shape form.
"""
import numpy as np

USED_INPUTS = ["Q_alpha_MeV"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}

LOCAL_FITTABLE = {
    "A": {"init": [140.0]},
    "B": {"init": [-50.0]},
}

# Regularization priors (fixed, not fitted to any cluster) keep small-window fits stable.
_A0 = 140.0
_B0 = -50.0
_LAM = 0.002


def _fit_AB(q, l):
    x = 1.0 / np.sqrt(q)
    M = np.vstack([x, np.ones_like(x)]).T
    try:
        p = np.linalg.solve(M.T @ M + _LAM * np.eye(2),
                            M.T @ l + _LAM * np.array([_A0, _B0]))
    except Exception:
        p = np.array([_A0, _B0])
    # Guard against degenerate/absurd extrapolations.
    if not np.all(np.isfinite(p)) or p[0] <= 0.0:
        p = np.array([_A0, _B0])
    return float(p[0]), float(p[1])


def fit(X_fit, y_fit):
    q = np.asarray(X_fit[:, 0], dtype=float)
    l = np.asarray(y_fit, dtype=float)
    A, B = _fit_AB(q, l)
    return {"A": A, "B": B}


def predict(X, A, B):
    q = np.asarray(X[:, 0], dtype=float)
    q = np.clip(q, 1e-3, None)
    return A / np.sqrt(q) + B