"""Brutsaert-Nieber nonlinear-reservoir recession: -dQ/dt = a*Q^b.
Closed form  Q(t) = Q0 * [1 + a*(b-1)*Q0^(b-1)*t]^(-1/(b-1)).
Two per-cluster parameters (a, b); Q0 is the observed anchor discharge."""
import numpy as np
from scipy.optimize import curve_fit

USED_INPUTS = ["t", "Q_0"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {"a": {"init": None}, "b": {"init": None}}


def _form(t, Q0, a, b):
    t = np.asarray(t, dtype=float)
    Q0 = np.maximum(np.asarray(Q0, dtype=float), 1e-6)
    b = np.clip(b, 1.02, 3.0)
    base = 1.0 + a * (b - 1.0) * np.power(Q0, b - 1.0) * t
    base = np.maximum(base, 1e-9)
    return Q0 * np.power(base, -1.0 / (b - 1.0))


def fit(X_fit, y_fit):
    t = np.asarray(X_fit[:, 0], dtype=float)
    Q0 = np.maximum(np.asarray(X_fit[:, 1], dtype=float), 1e-6)
    y = np.asarray(y_fit, dtype=float)

    def f(tv, a, b):
        return _form(tv, Q0, a, b)

    try:
        popt, _ = curve_fit(f, t, y, p0=[0.01, 1.5],
                            bounds=([1e-6, 1.02], [10.0, 3.0]), maxfev=20000)
        a_hat, b_hat = float(popt[0]), float(popt[1])
        if not (np.isfinite(a_hat) and np.isfinite(b_hat)):
            raise ValueError
    except Exception:
        a_hat, b_hat = 0.01, 1.5
    return {"a": a_hat, "b": b_hat}


def predict(X, a, b):
    t = np.asarray(X[:, 0], dtype=float)
    Q0 = np.asarray(X[:, 1], dtype=float)
    return _form(t, Q0, a, b)