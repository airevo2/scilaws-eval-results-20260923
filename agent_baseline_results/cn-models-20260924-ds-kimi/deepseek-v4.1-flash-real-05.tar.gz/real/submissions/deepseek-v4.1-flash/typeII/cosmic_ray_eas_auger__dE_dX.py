"""Beta / Nishimura-Kamata-type shower profile:  dE/dX = N * (X/Xmax)^a * exp(a*(1 - X/Xmax)).
One universal shape constant 'a' plus two per-cluster parameters (N, Xmax). The form rises
toward the shower maximum Xmax and falls off afterwards, mimicking the Gaisser-Hillas / NKG
longitudinal profile that describes fluorescence energy deposit along the shower axis.
Positive definite and well behaved under extrapolation in X."""
import numpy as np
from scipy.optimize import curve_fit

USED_INPUTS = ["X"]
LAW_CONSTANTS = {"a": 2.0}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {"N": {"init": None}, "Xmax": {"init": None}}


def _beta(X, N, Xmax, a):
    xr = np.clip(X / Xmax, 1e-8, None)
    return N * xr ** a * np.exp(a * (1.0 - xr))


def _form(X, N, Xmax):
    return _beta(X, N, Xmax, 2.0)


def fit(X_fit, y_fit):
    X = np.asarray(X_fit, dtype=float).ravel()
    y = np.asarray(y_fit, dtype=float).ravel()
    N0 = max(float(np.max(y)) * 1.5, 1e-3)
    Xmax0 = float(X[int(np.argmax(y))])
    lo = [1e-6, float(np.min(X)) * 0.5 + 1e-6]
    hi = [1e6, float(np.max(X)) * 3.0 + 1.0]
    try:
        popt, _ = curve_fit(_form, X, y, p0=[N0, Xmax0], bounds=(lo, hi), maxfev=4000)
        N_hat, Xmax_hat = float(popt[0]), float(popt[1])
        if not (np.isfinite(N_hat) and np.isfinite(Xmax_hat)) or N_hat <= 0 or Xmax_hat <= 0:
            raise ValueError
    except Exception:
        N_hat, Xmax_hat = N0, Xmax0 if Xmax0 > 0 else float(np.max(X))
    return {"N": N_hat, "Xmax": Xmax_hat}


def predict(X, N, Xmax):
    X = np.asarray(X, dtype=float).ravel()
    return _form(X, N, Xmax)