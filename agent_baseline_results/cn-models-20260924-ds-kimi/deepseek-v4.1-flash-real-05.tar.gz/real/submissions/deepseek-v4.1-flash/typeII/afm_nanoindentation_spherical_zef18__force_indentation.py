"""Hertz spherical-indentation form with a single per-cluster amplitude.

Physics: for a rigid sphere of radius R pressed into a soft half-space,
Hertz contact theory gives the indentation force

    F = (4/3) E* sqrt(R) * delta^(3/2),

where delta is the indentation depth and E* the reduced/effective elastic
modulus.  The probe radius R is constant for this dataset, so the whole
prefactor (4/3) E* sqrt(R) is a single per-cluster scale factor `a` that
encodes that cluster's local effective stiffness.  The exponent 3/2 is the
fixed Hertz contact exponent (a theoretical value, not a fitted constant),
so nothing except the one physical amplitude changes between clusters.
"""
import numpy as np

USED_INPUTS = ["indentation_m", "R_m"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}

# Single per-cluster parameter: Hertz prefactor a = (4/3) E* sqrt(R).
LOCAL_FITTABLE = {"a": {"init": None}}

# Fixed Hertz contact exponent (theoretical, material-independent).
_P = 1.5

def _x(delta):
    # delta^1.5  (clip tiny/negative depths to keep things finite)
    d = np.clip(delta, 0.0, None)
    return d ** _P

def fit(X_fit, y_fit):
    delta = X_fit[:, 0].astype(float)
    F = y_fit.astype(float)
    x = _x(delta)
    denom = float(np.sum(x * x))
    if denom > 0:
        a = float(np.sum(F * x) / denom)
    else:
        # fall back to an order-of-magnitude estimate
        a = float(np.mean(F)) / max(float(np.mean(x)), 1e-30)
    if not np.isfinite(a) or a <= 0:
        a = 1e-4
    return {"a": a}

def predict(X, a):
    delta = X[:, 0].astype(float)
    return a * _x(delta)