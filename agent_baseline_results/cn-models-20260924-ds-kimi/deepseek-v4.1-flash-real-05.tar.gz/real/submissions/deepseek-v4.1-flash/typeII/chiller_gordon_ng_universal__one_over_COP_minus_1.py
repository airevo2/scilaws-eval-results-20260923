"""Gordon-Ng style thermodynamic model for chiller 1/COP - 1.

1/COP - 1 = m0 + m1*(T_ci/T_ei) + m2*(T_ci/Q_e) + m3*(1/Q_e)

This is the standard Gordon-Ng linear reformulation of chiller efficiency:
the reciprocal COP minus one varies linearly with the temperature ratio
(T_ci/T_ei) and the condenser-load interaction (T_ci/Q_e) plus the internal
loss term (1/Q_e). Per-cluster parameters are the four coefficients, fit by
ordinary least squares. The form is physically sensible and stays finite for
extrapolation (larger Q_e lowers 1/COP-1 toward the Carnot-like floor set by
the temperature ratio).
"""
import numpy as np

USED_INPUTS = ["T_ei", "T_ci", "Q_e"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {
    "m0": {"init": [-1.85]},
    "m1": {"init": [0.98]},
    "m2": {"init": [0.61]},
    "m3": {"init": [-160.0]},
}


def _design(T_ei, T_ci, Q_e):
    ones = np.ones_like(T_ei)
    return np.column_stack([ones, T_ci / T_ei, T_ci / Q_e, 1.0 / Q_e])


def fit(X_fit, y_fit):
    T_ei = X_fit[:, 0]
    T_ci = X_fit[:, 1]
    Q_e = X_fit[:, 2]
    A = _design(T_ei, T_ci, Q_e)
    try:
        coef, _, _, _ = np.linalg.lstsq(A, y_fit, rcond=None)
    except Exception:
        coef = np.array([-1.85, 0.98, 0.61, -160.0])
    coef = np.asarray(coef, dtype=float).ravel()
    if coef.size != 4 or not np.all(np.isfinite(coef)):
        coef = np.array([-1.85, 0.98, 0.61, -160.0])
    return {"m0": float(coef[0]), "m1": float(coef[1]),
            "m2": float(coef[2]), "m3": float(coef[3])}


def predict(X, m0, m1, m2, m3):
    T_ei = X[:, 0]
    T_ci = X[:, 1]
    Q_e = X[:, 2]
    return m0 + m1 * (T_ci / T_ei) + m2 * (T_ci / Q_e) + m3 / Q_e