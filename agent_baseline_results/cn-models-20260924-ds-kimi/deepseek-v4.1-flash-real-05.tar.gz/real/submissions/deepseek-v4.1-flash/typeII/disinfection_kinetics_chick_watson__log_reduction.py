"""Saturating log-dose inactivation: LRV = a*(1 - exp(-b*log1p(CT))).

Chick-Watson style disinfection where the log10 reduction rises with the
disinfection dose CT and saturates toward a plateau `a` (a physically
sensible limit for plate-count assays), with `b` setting the curvature.
The form gives exactly 0 at CT=0 and stays bounded/sensible when
extrapolated to very large CT.
"""
import numpy as np
from scipy.optimize import curve_fit

USED_INPUTS = ["CT"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {"a": {"init": None}, "b": {"init": None}}


def _form(CT, a, b):
    CT = np.maximum(CT, 0.0)
    z = np.clip(b * np.log1p(CT), 0.0, 50.0)
    return a * (1.0 - np.exp(-z))


def fit(X_fit, y_fit):
    CT = np.asarray(X_fit[:, 0], dtype=float)
    y = np.asarray(y_fit, dtype=float)
    a0 = max(1.5 * float(np.mean(y)), 0.5)
    p0 = [a0, 0.5]
    try:
        popt, _ = curve_fit(
            _form, CT, y, p0=p0,
            bounds=([0.0, 0.0], [np.inf, np.inf]),
            maxfev=20000,
        )
        a, b = float(popt[0]), float(popt[1])
        if not (np.isfinite(a) and np.isfinite(b)):
            raise ValueError
        return {"a": a, "b": b}
    except Exception:
        return {"a": a0, "b": 0.5}


def predict(X, a, b):
    return _form(np.asarray(X[:, 0], dtype=float), a, b)