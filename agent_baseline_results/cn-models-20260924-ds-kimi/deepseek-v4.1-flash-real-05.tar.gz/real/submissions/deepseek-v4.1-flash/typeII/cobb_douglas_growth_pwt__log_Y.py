"""Constant-returns-to-scale (Cobb-Douglas-like) production form with human capital
augmenting labour. Per cluster fit an intercept c and a capital share a:

    ln(Y/L) = c + a*ln(K/L) + (1-a)*ln(h)

i.e. output per worker is a geometric mix of capital-per-worker and the
human-capital index. Only two per-cluster parameters (c, a) are calibrated by
least squares on one cluster's fit window; the shape is shared across clusters.
"""
import numpy as np

USED_INPUTS = ["cn", "emp", "hc"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {"c": {"init": None}, "a": {"init": None}}


def fit(X_fit, y_fit):
    lnK = np.log(np.maximum(X_fit[:, 0], 1e-12))
    lnL = np.log(np.maximum(X_fit[:, 1], 1e-12))
    lnh = np.log(np.maximum(X_fit[:, 2], 1e-12))
    lnKL = lnK - lnL
    # Regress (y - lnh) on [1, (lnKL - lnh)] to enforce CRS: a + (1-a) = 1.
    A = np.column_stack([np.ones_like(y_fit), lnKL - lnh])
    target = y_fit - lnh
    try:
        coef, _, _, _ = np.linalg.lstsq(A, target, rcond=None)
        c = float(coef[0])
        a = float(coef[1])
        if not (np.isfinite(c) and np.isfinite(a)):
            raise ValueError
    except Exception:
        c = float(np.mean(target))
        a = 0.5
    # Keep the capital share economically sensible.
    a = float(np.clip(a, 0.0, 1.5))
    return {"c": c, "a": a}


def predict(X, c, a):
    lnK = np.log(np.maximum(X[:, 0], 1e-12))
    lnL = np.log(np.maximum(X[:, 1], 1e-12))
    lnh = np.log(np.maximum(X[:, 2], 1e-12))
    lnKL = lnK - lnL
    return c + a * (lnKL - lnh) + lnh