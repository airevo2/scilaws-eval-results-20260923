"""Sips (Langmuir-Freundlich) isotherm, per-cluster parameters.

n(P) = nm * (K*P)^t / (1 + (K*P)^t)

Physically standard for adsorption of CO2 on microporous adsorbents: nm is the
saturation capacity (mmol/g), K the affinity constant (1/bar), and t the
heterogeneity exponent (0<t<=1). Reduces to Langmuir when t=1. The form stays
bounded and physically sensible on extrapolation (approaches nm as P -> inf).
"""
import numpy as np
from scipy.optimize import curve_fit

USED_INPUTS = ["P_bar"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {"nm": {"init": None}, "K": {"init": None}, "t": {"init": None}}

def _sips(P, nm, K, t):
    KP = K * P
    KPt = KP ** t
    return nm * KPt / (1.0 + KPt)

def fit(X_fit, y_fit):
    P = np.asarray(X_fit[:, 0], dtype=float)
    y = np.asarray(y_fit, dtype=float)
    ymax = float(np.max(y)) if y.size else 1.0
    ymax = max(ymax, 1e-6)
    best = None
    # Multi-start over a small grid, pick lowest residual.
    for nm0 in (ymax * 1.1, ymax * 1.6, ymax * 0.7):
        for K0 in (0.05, 0.5, 5.0):
            for t0 in (0.6, 0.85, 1.0):
                try:
                    popt, _ = curve_fit(
                        _sips, P, y, p0=[nm0, K0, t0],
                        bounds=([0.0, 0.0, 0.05], [np.inf, np.inf, 1.0]),
                        maxfev=2000,
                    )
                    res = np.sqrt(np.mean((_sips(P, *popt) - y) ** 2))
                    if best is None or res < best[0]:
                        best = (res, popt)
                except Exception:
                    continue
    if best is None:
        return {"nm": ymax, "K": 1.0, "t": 0.8}
    nm, K, t = best[1]
    return {"nm": float(nm), "K": float(K), "t": float(t)}

def predict(X, nm, K, t):
    P = np.asarray(X[:, 0], dtype=float)
    return _sips(P, nm, K, t)