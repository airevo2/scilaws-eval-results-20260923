"""Rydberg-Ritz quantum-defect expansion: E_bind = R_inf / (n*)^2 with
n* = n - d0 - d2/(n-d0)^2 - d4/(n-d0)^4. The Rydberg constant is a universal
physical constant; the three quantum-defect coefficients (d0, d2, d4) are fit
per cluster/series."""
import numpy as np
from scipy.optimize import curve_fit

USED_INPUTS = ["n_qm", "l_qm"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {"d0": {"init": None}, "d2": {"init": None}, "d4": {"init": None}}

# Rydberg constant for the alkali valence electron series (cm^-1), physical constant.
_R_INF = 109737.315685


def _form(n, d0, d2, d4):
    nn = n - d0
    return _R_INF / (nn - d2 / nn ** 2 - d4 / nn ** 4) ** 2


def fit(X_fit, y_fit):
    n = np.asarray(X_fit[:, 0], dtype=float)
    E = np.asarray(y_fit, dtype=float)
    nmin = float(np.min(n))
    ub = max(nmin - 0.05, 0.05)

    starts = [[0.0, 0.0, 0.0],
              [nmin / 2.0, 0.0, 0.0],
              [max(nmin - 1.0, 0.0), 0.0, 0.0]]
    try:
        d0_est = float(n[-1] - np.sqrt(_R_INF / max(E[-1], 1.0)))
        starts.append([min(max(d0_est, -1.0), ub - 1e-3), 0.0, 0.0])
    except Exception:
        pass

    cands = []
    for s in starts:
        try:
            popt, _ = curve_fit(_form, n, E, p0=s,
                                bounds=([-2.0, -5.0, -5.0], [ub, 5.0, 5.0]),
                                maxfev=5000)
            cands.append(popt)
        except Exception:
            pass

    if not cands:
        return {"d0": float(min(ub, nmin - 1.0)), "d2": 0.0, "d4": 0.0}

    costs = [np.sum((_form(n, *p) - E) ** 2) for p in cands]
    best = cands[int(np.argmin(costs))]
    return {"d0": float(best[0]), "d2": float(best[1]), "d4": float(best[2])}


def predict(X, d0, d2, d4):
    n = np.asarray(X[:, 0], dtype=float)
    return _form(n, d0, d2, d4)