"""Power-law fit: log10(H) = a*log10(MER) + b, fitted by L1 (minimises log_mae)."""
import numpy as np

USED_INPUTS = ["MER_kg_per_s"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    MER = np.asarray(X[:, 0], dtype=float)
    a = 0.1564763392286738
    b = -0.04917154104167576
    H = 10.0 ** (a * np.log10(MER) + b)
    return H