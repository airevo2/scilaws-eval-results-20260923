"""Biaxial mouse-skin Cauchy stress σ22: multiplicative fiber-family form.
σ22 = (A*E1^p + B) * (exp(b*E2) - 1) + D*E1^q, with Green-type strains
E1 = λ11² - λ11⁻², E2 = λ22² - λ22⁻². The exponential E2 term captures the
collagen fiber uncrimping toe-to-heel transition along the loading axis 2,
modulated by the transverse stretch through the E1^p factor (fiber-family
interaction); the D term is the isotropic matrix baseline that produces
non-zero stress at λ22=1 when λ11>1. Exponents p, b, q are shared across
clusters; A, B, D are re-fit per cluster (specimen stiffness)."""
import numpy as np

USED_INPUTS = ["lambda11", "lambda22"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
P_EXP, B_EXP, Q_EXP = 2.5, 3.0, 1.5   # shared shape exponents (same for all clusters)
LOCAL_FITTABLE = {"A": {"init": [1e-4, 3e-4, 1e-3, 3e-3]},
                  "B": {"init": [1e-5, 1e-4, 3e-4, 1e-3]},
                  "D": {"init": [0.0, 1e-4, 1e-3, 3e-3]}}

def _basis(X):
    l1 = np.asarray(X[:, 0], dtype=float)
    l2 = np.asarray(X[:, 1], dtype=float)
    E1 = l1**2 - l1**-2
    E2 = l2**2 - l2**-2
    t = np.expm1(B_EXP * E2)
    b1 = (E1**P_EXP) * t
    b2 = t
    b3 = E1**Q_EXP
    return np.column_stack([b1, b2, b3])

def fit(X_fit, y_fit):
    Z = _basis(X_fit)
    y = np.asarray(y_fit, dtype=float)
    try:
        coef, _, _, _ = np.linalg.lstsq(Z, y, rcond=None)
        A, B, D = float(coef[0]), float(coef[1]), float(coef[2])
    except Exception:
        A, B, D = 3e-4, 3e-4, 0.0
    if not (np.isfinite(A) and np.isfinite(B) and np.isfinite(D)):
        A, B, D = 3e-4, 3e-4, 0.0
    return {"A": A, "B": B, "D": D}

def predict(X, A, B, D):
    Z = _basis(X)
    out = Z[:, 0] * A + Z[:, 1] * B + Z[:, 2] * D
    return np.asarray(out, dtype=float)