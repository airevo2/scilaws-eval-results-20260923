"""Heligman-Pollard 3-component mortality law fit per cluster:
log M(x) = log( A^(x+B)^C + D*exp(-E*(ln(x/F))^2) + exp(g + h*x) ).
Components: child mortality decline (power law), lognormal young-adult
accident hump, and Gompertz adult senescence. All 8 params refit per cluster."""
import numpy as np
from scipy.optimize import curve_fit

USED_INPUTS = ["age"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {
    "A": {"init": 6e-4}, "B": {"init": 0.05}, "C": {"init": 0.1},
    "D": {"init": 5e-4}, "E": {"init": 9.0}, "F": {"init": 22.0},
    "g": {"init": -10.3}, "h": {"init": 0.095},
}

def _hp(x, A,B,C, D,E,F, g,h):
    x = np.asarray(x, dtype=float)
    xc = np.clip(x, 1e-6, None)
    t1 = np.exp((np.clip(x + B, 1e-9, None) ** C) * np.log(np.clip(A, 1e-12, None)))
    t2 = D * np.exp(-E * (np.log(xc / F)) ** 2)
    t3 = np.exp(np.clip(g + h * x, -60.0, 50.0))
    return np.log(np.clip(t1 + t2 + t3, 1e-15, None))

def fit(X_fit, y_fit):
    aa = X_fit[:, 0].astype(float)
    yy = np.asarray(y_fit, dtype=float)
    lb = [1e-6, 0.0, 0.005, 1e-7, 2.0, 15.0, -13.5, 0.06]
    ub = [5e-2, 2.0, 0.6, 5e-2, 20.0, 30.0, -7.5, 0.14]
    inits = [
        [6e-4, 0.02, 0.08, 5e-4, 9.0, 22.0, -10.3, 0.095],
        [3e-4, 0.0, 0.03, 6e-4, 10.0, 23.0, -10.5, 0.10],
        [1e-3, 0.5, 0.15, 3e-4, 8.0, 21.0, -10.0, 0.09],
    ]
    best = None
    for p0 in inits:
        try:
            popt, _ = curve_fit(_hp, aa, yy, p0=p0, bounds=(lb, ub), maxfev=8000)
            r = np.sqrt(np.mean((_hp(aa, *popt) - yy) ** 2))
            if best is None or r < best[0]:
                best = (r, popt)
        except Exception:
            pass
    if best is None:
        best = (np.inf, np.array(inits[0], dtype=float))
    p = best[1]
    return {"A": float(p[0]), "B": float(p[1]), "C": float(p[2]),
            "D": float(p[3]), "E": float(p[4]), "F": float(p[5]),
            "g": float(p[6]), "h": float(p[7])}

def predict(X, A, B, C, D, E, F, g, h):
    return _hp(X[:, 0], A, B, C, D, E, F, g, h)