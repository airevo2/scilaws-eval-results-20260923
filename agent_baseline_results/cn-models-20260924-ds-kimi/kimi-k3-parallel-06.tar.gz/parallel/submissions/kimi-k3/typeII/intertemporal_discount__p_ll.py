"""Hyperbolic delay discounting of reward amounts with a softmax (logistic) choice rule.

Each cluster (study/subject population) has its own choice sharpness b and
hyperbolic discount rate k. Subjective value of an option with amount V and
delay t is V/(1 + k*t); the probability of choosing the larger-later option is
the logistic of b times the difference of the two discounted subjective values:
    p_ll = sigmoid( b * ( V_LL/(1 + k*t_LL) - V_SS/(1 + k*t_SS) ) ).
Two parameters (b, k) are re-fit per cluster; the functional form is shared.
"""
import numpy as np
from scipy.optimize import curve_fit

USED_INPUTS = ["ss_time_days", "ll_time_days", "ss_value", "ll_value"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {"b": {"init": None}, "k": {"init": None}}

def _form(X, b, k):
    t_ss = X[:, 0]
    t_ll = X[:, 1]
    v_ss = X[:, 2]
    v_ll = X[:, 3]
    sv_ll = v_ll / (1.0 + k * t_ll)
    sv_ss = v_ss / (1.0 + k * t_ss)
    z = np.clip(b * (sv_ll - sv_ss), -500.0, 500.0)
    return 1.0 / (1.0 + np.exp(-z))

def fit(X_fit, y_fit):
    X_fit = np.asarray(X_fit, dtype=float)
    y_fit = np.asarray(y_fit, dtype=float)
    v_scale = max(float(np.mean(np.abs(X_fit[:, 3]))), 1e-9)
    best = None
    for b0 in (0.1 / v_scale, 1.0 / v_scale, 10.0 / v_scale):
        for k0 in (1e-4, 1e-2, 1e0):
            try:
                popt, _ = curve_fit(
                    lambda X, b, k: _form(X, b, k), X_fit, y_fit,
                    p0=[b0, k0],
                    bounds=([1e-12, 1e-12], [1e12, 1e12]),
                    maxfev=5000,
                )
                pred = _form(X_fit, popt[0], popt[1])
                sse = float(np.sum((pred - y_fit) ** 2))
                if np.isfinite(sse) and (best is None or sse < best[0]):
                    best = (sse, float(popt[0]), float(popt[1]))
            except Exception:
                continue
    if best is None:
        return {"b": 1.0 / v_scale, "k": 0.01}
    return {"b": best[1], "k": best[2]}

def predict(X, b, k):
    X = np.asarray(X, dtype=float)
    return _form(X, b, k)