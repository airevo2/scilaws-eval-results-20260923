"""SIR-type biweekly growth: g_t = K0 - rho*ln(I_{t-1}+1) + beta0*ln(z_t+1) + season(biweek),
with season(b) = A*cos(2*pi*(b-1)/26) + B*sin(2*pi*(b-1)/26), one annual harmonic.
The -rho*ln(I+1) term captures declining log-growth with epidemic size (depletion of
susceptibles / reporting saturation), ln(z+1) encodes the susceptible-deviation proxy,
and the harmonic encodes term-time measles seasonality. All five coefficients are
re-fit per city (cluster) by least squares; the functional shape is shared."""
import numpy as np

USED_INPUTS = ["cases_prev", "biweek", "z_t"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {
    "K0": {"init": None},
    "rho": {"init": None},
    "beta0": {"init": None},
    "A": {"init": None},
    "B": {"init": None},
}

def _design(X):
    I = np.asarray(X[:, 0], dtype=float)
    b = np.asarray(X[:, 1], dtype=float)
    z = np.asarray(X[:, 2], dtype=float)
    th = 2.0 * np.pi * (b - 1.0) / 26.0
    return np.column_stack([
        np.ones_like(I),
        -np.log(I + 1.0),
        np.log(np.maximum(z, 0.0) + 1.0),
        np.cos(th),
        np.sin(th),
    ])

def fit(X_fit, y_fit):
    X_fit = np.asarray(X_fit, dtype=float)
    y = np.asarray(y_fit, dtype=float)
    M = _design(X_fit)
    try:
        coef, _, _, _ = np.linalg.lstsq(M, y, rcond=None)
        coef = np.asarray(coef, dtype=float)
        if not np.all(np.isfinite(coef)):
            raise ValueError
    except Exception:
        coef = np.array([np.mean(y) if len(y) else 0.0, 0.05, 0.0, 0.15, 0.1])
    return {"K0": float(coef[0]), "rho": float(coef[1]), "beta0": float(coef[2]),
            "A": float(coef[3]), "B": float(coef[4])}

def predict(X, K0, rho, beta0, A, B):
    M = _design(np.asarray(X, dtype=float))
    coef = np.array([K0, rho, beta0, A, B], dtype=float)
    return (M @ coef).astype(float)