"""Saturating approach to a per-cluster ceiling: e0 rises toward an asymptote
as a negative exponential in calendar year, with a shared relaxation rate.
Form: e0(t) = A - B*exp(-k*(t-1950)), k universal, (A,B) fit per cluster.
A = ceiling (asymptotic e0), A-B = level at 1950. Concave/saturating trend
matches the decelerating rise seen across clusters (some near-flat => B~0).
"""
import numpy as np

USED_INPUTS = ["year"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {"k": 0.02}   # universal decay/growth rate (1/yr), shared by all clusters
LOCAL_FITTABLE = {"A": {"init": None}, "B": {"init": None}}

def _basis(t, k):
    return np.exp(-k * (t - 1950.0))

def fit(X_fit, y_fit):
    t = X_fit[:, 0].astype(float)
    k = float(OTHER_CONSTANTS["k"])
    u = _basis(t, k)
    # linear least squares for y = A - B*u  => design [1, -u]
    D = np.column_stack([np.ones_like(u), -u])
    try:
        coef, *_ = np.linalg.lstsq(D, y_fit, rcond=None)
        A, B = float(coef[0]), float(coef[1])
    except Exception:
        A = float(np.max(y_fit)); B = 0.0
    if not np.isfinite(A): A = float(np.mean(y_fit))
    if not np.isfinite(B): B = 0.0
    return {"A": A, "B": B}

def predict(X, A, B):
    t = X[:, 0].astype(float)
    k = float(OTHER_CONSTANTS["k"])
    return A - B * _basis(t, k)