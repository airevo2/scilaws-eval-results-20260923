"""Piecewise-linear (hinge) law in log-log space: ln S = c0 + b1*ln p + b2*max(ln p - tau, 0), with all four parameters re-fit per cluster. Motivated by observed slope changes between the very top tail (p < ~1%) and the broader top bracket; the breakpoint tau and slope change vary by country/cluster."""
import numpy as np

USED_INPUTS = ["log_p_above"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {"c0": {"init": None}, "b1": {"init": None}, "tau": {"init": None}, "b2": {"init": None}}

def _design(x, tau):
    return np.column_stack([np.ones_like(x), x, np.maximum(x - tau, 0.0)])

def _fit_at_tau(x, y, tau):
    A = _design(x, tau)
    coef, res, _, _ = np.linalg.lstsq(A, y, rcond=None)
    r = y - A @ coef
    return float(np.sum(r * r)), coef

def fit(X_fit, y_fit):
    x = np.asarray(X_fit[:, 0], dtype=float)
    y = np.asarray(y_fit, dtype=float)
    best = None
    # coarse grid over breakpoint, then local refinement
    for tau in np.arange(-9.0, -2.35, 0.10):
        ss, coef = _fit_at_tau(x, y, tau)
        if best is None or ss < best[0]:
            best = (ss, tau, coef)
    ss0, tau0, coef0 = best
    for tau in np.arange(tau0 - 0.12, tau0 + 0.121, 0.01):
        ss, coef = _fit_at_tau(x, y, tau)
        if ss < best[0]:
            best = (ss, tau, coef)
    ss, tau, coef = best
    return {"c0": float(coef[0]), "b1": float(coef[1]), "tau": float(tau), "b2": float(coef[2])}

def predict(X, c0, b1, tau, b2):
    x = np.asarray(X[:, 0], dtype=float)
    return c0 + b1 * x + b2 * np.maximum(x - tau, 0.0)