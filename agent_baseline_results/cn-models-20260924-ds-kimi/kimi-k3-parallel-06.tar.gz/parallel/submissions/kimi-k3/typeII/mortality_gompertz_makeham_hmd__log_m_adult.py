"""Gompertz mortality law: ln m(x) = a + b*x, with per-cluster level (a) and senescence rate (b)."""
import numpy as np

USED_INPUTS = ["age"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {"a": {"init": None}, "b": {"init": None}}

def fit(X_fit, y_fit):
    x = np.asarray(X_fit[:, 0], dtype=float)
    y = np.asarray(y_fit, dtype=float)
    # Closed-form least squares for ln m = a + b*x (Gompertz).
    A = np.vstack([np.ones_like(x), x]).T
    try:
        coef, *_ = np.linalg.lstsq(A, y, rcond=None)
        a_hat, b_hat = float(coef[0]), float(coef[1])
        if not np.isfinite(a_hat) or not np.isfinite(b_hat):
            raise ValueError
    except Exception:
        b_hat = 0.09
        a_hat = float(np.mean(y - b_hat * x)) if len(y) else -9.5
    return {"a": a_hat, "b": b_hat}

def predict(X, a, b):
    x = np.asarray(X[:, 0], dtype=float)
    return a + b * x