"""Latent heat flux via a blended energy-balance / Penman-Monteith-style form:
LE = (delta*(Rnet - Qg) + w_eff*VPD) / (delta + gamma + w_eff),
where the aerodynamic coupling w_eff = c*Ga is modulated by a VPD-stress
factor (1 + b*VPD) that captures the observed high-VPD decline, and the
per-cluster physiological coupling constants are fitted per cluster."""
import numpy as np
from scipy.optimize import curve_fit

USED_INPUTS = ["SWdown", "VPD", "RH", "Rnet", "Qg", "Ga", "delta", "theta_FC"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {"gamma": {"init": None}, "c": {"init": None}, "b": {"init": None}}

def _form(Rn, G, d, V, Ga, gamma, c, b):
    A = Rn - G
    w = c * Ga * (1.0 + b * V)
    return (d * A + w * V) / (d + gamma + w)

def fit(X_fit, y_fit):
    V = X_fit[:, 1]; Rn = X_fit[:, 3]; G = X_fit[:, 4]
    Ga = X_fit[:, 5]; d = X_fit[:, 6]
    fallback = {"gamma": 0.129, "c": 17.88, "b": 0.241}
    try:
        def f(Xx, gamma, c, b):
            return _form(Xx[3], Xx[4], Xx[6], Xx[1], Xx[5], gamma, c, b)
        popt, _ = curve_fit(f, X_fit.T, y_fit, p0=[0.129, 17.88, 0.241],
                            maxfev=5000)
        return {"gamma": float(popt[0]), "c": float(popt[1]), "b": float(popt[2])}
    except Exception:
        return fallback

def predict(X, gamma, c, b):
    return _form(X[:, 3], X[:, 4], X[:, 6], X[:, 1], X[:, 5], gamma, c, b)