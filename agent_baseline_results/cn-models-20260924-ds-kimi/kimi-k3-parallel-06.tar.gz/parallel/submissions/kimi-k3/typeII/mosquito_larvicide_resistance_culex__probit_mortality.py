"""Probit dose-response (Finney's bioassay model): corrected mortality is the
standard normal CDF of the standardized natural-log concentration,
P = Phi((ln(C) - LC50)/slope), with per-cluster LC50 and slope."""
import numpy as np
from scipy.optimize import curve_fit
from scipy.stats import norm

USED_INPUTS = ["log_conc_ppb"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {"LC50": {"init": None}, "slope": {"init": None}}

def _form(x, LC50, slope):
    return norm.cdf((x - LC50) / slope)

def fit(X_fit, y_fit):
    x = np.asarray(X_fit[:, 0], dtype=float)
    y = np.asarray(y_fit, dtype=float)
    # Initial LC50: x whose mean response is closest to 0.5
    x0_init = float(np.median(x))
    try:
        order = np.argsort(x)
        xs, ys = x[order], y[order]
        uniq_x = np.unique(xs)
        m = np.array([ys[xs == ux].mean() for ux in uniq_x])
        x0_init = float(uniq_x[np.argmin(np.abs(m - 0.5))])
    except Exception:
        pass
    p0 = [x0_init, 0.8]
    try:
        popt, _ = curve_fit(_form, x, y, p0=p0, maxfev=5000)
        LC50 = float(popt[0]); slope = float(abs(popt[1]))
        if not np.isfinite(LC50) or not np.isfinite(slope) or slope <= 0:
            raise ValueError
        return {"LC50": LC50, "slope": slope}
    except Exception:
        return {"LC50": x0_init, "slope": 0.8}

def predict(X, LC50, slope):
    x = np.asarray(X[:, 0], dtype=float)
    return _form(x, LC50, slope)