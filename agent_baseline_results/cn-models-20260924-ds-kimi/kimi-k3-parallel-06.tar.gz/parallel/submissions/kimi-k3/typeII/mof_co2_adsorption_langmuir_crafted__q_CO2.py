"""Shared adsorption-isotherm mechanism for CO2 uptake in MOFs.

Functional form: a saturation (Langmuir-type) isotherm generalized to a
heterogeneous (Sips) law, fit per cluster:

    q(P) = q_sat * (b*P)^n / (1 + (b*P)^n)

This recovers the simulator mechanism across clusters:
 - Low P: q ~ q_sat * b^n * P^n  (Henry / power-law approach)
 - High P: q -> q_sat            (saturation plateau)
 - n=1 reduces exactly to the single-site Langmuir isotherm
   q = q_sat*b*P/(1+b*P); linear (Henry-regime) clusters correspond to
   b*P << 1 over the whole window (q ~ q_sat*b*P).

Per-cluster parameters (all refit from one cluster's data): q_sat, b, n.
"""
import numpy as np
from scipy.optimize import curve_fit

USED_INPUTS = ["P_bar"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {
    "q_sat": {"init": None},
    "b": {"init": None},
    "n": {"init": None},
}

def _sips(P, q_sat, b, n):
    P = np.asarray(P, dtype=float)
    Pc = np.clip(P, 1e-12, None)
    x = (b * Pc) ** n
    return q_sat * x / (1.0 + x)

def fit(X_fit, y_fit):
    P = np.asarray(X_fit[:, 0], dtype=float)
    y = np.asarray(y_fit, dtype=float)
    # robust starting guesses
    q0 = float(np.nanmax(y)) if np.isfinite(np.nanmax(y)) else 1.0
    q0 = max(q0, 1e-3) * 1.2
    p0 = [q0, 1.0, 1.0]
    bounds = ([1e-8, 1e-8, 1e-3], [np.inf, np.inf, 5.0])
    try:
        popt, _ = curve_fit(_sips, P, y, p0=p0, bounds=bounds, maxfev=8000)
        q_sat, b, n = float(popt[0]), float(popt[1]), float(popt[2])
    except Exception:
        # fallback: two-stage Henry+plateau heuristic
        try:
            slope = np.polyfit(np.log(np.clip(P,1e-12,None)), np.log(np.clip(y,1e-12,None)), 1)[0]
        except Exception:
            slope = 1.0
        n = float(np.clip(slope, 0.05, 4.0))
        q_sat = float(max(np.nanmax(y), 1e-3) * 1.1)
        b = 1.0
    # safety
    if not (np.isfinite(q_sat) and q_sat > 0): q_sat = max(float(np.nanmax(y)), 1.0)
    if not (np.isfinite(b) and b > 0): b = 1.0
    if not (np.isfinite(n) and n > 0): n = 1.0
    return {"q_sat": q_sat, "b": b, "n": n}

def predict(X, q_sat, b, n):
    P = np.asarray(X[:, 0], dtype=float)
    y = _sips(P, q_sat, b, n)
    y = np.where(np.isfinite(y), y, 0.0)
    return y