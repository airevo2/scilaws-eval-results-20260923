"""Gompertz–Makeham log-mortality law: ln m(x) = ln( exp(c) + exp(a + b x) ), with
age-independent Makeham background term exp(c) and Gompertz exponential senescent
component exp(a + b x). All three parameters (log-background c, Gompertz
log-level a, Gompertz slope b) are re-fit per cluster by nonlinear least squares
(reparametrized to level-at-60 for robust, fast, well-conditioned fits)."""
import numpy as np
from scipy.optimize import least_squares

USED_INPUTS = ["age"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {"lc": {"init": None}, "a": {"init": None}, "b": {"init": None}}

def _form(x, lc, a, b):
    # ln m(x) = log( exp(lc) + exp(a + b*(x-60)) )
    return np.log(np.exp(lc) + np.exp(a + b * (x - 60.0)))

def fit(X_fit, y_fit):
    x = np.asarray(X_fit[:, 0], dtype=float)
    y = np.asarray(y_fit, dtype=float)
    p0 = [-8.0, float(np.interp(60.0, np.sort(x), y[np.argsort(x)])) if 30 <= 60 <= 95 else -4.5, 0.10]
    try:
        sol = least_squares(lambda p: _form(x, p[0], p[1], p[2]) - y,
                            x0=[-8.0, -4.5, 0.10], max_nfev=2000)
        lc, a, b = sol.x
        if not (np.isfinite(lc) and np.isfinite(a) and np.isfinite(b)):
            raise ValueError
        return {"lc": float(lc), "a": float(a), "b": float(b)}
    except Exception:
        # Fallback: pure Gompertz line fit (Makeham term pushed to zero)
        A = np.vstack([np.ones_like(x), x - 60.0]).T
        c, *_ = np.linalg.lstsq(A, y, rcond=None)
        return {"lc": -12.0, "a": float(c[0]), "b": float(c[1])}

def predict(X, lc, a, b):
    x = np.asarray(X[:, 0], dtype=float)
    return np.log(np.exp(lc) + np.exp(a + b * (x - 60.0)))