"""Corresponding-states extended power law: sigma = A * (1 - T/T_c)^1.2 * rho_liq^(2/3), with one per-substance amplitude A refit per cluster. Exponents 1.2 (Guggenheim-type reduced-temperature dependence) and 2/3 (density/molar-volume surface-tension dependence, Vm^(-2/3)) are universal; only the amplitude varies across substances."""
import numpy as np

USED_INPUTS = ["T_K", "rho_liq", "T_c", "M_mol"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {"a": {"init": None}}

def _predict(X, a):
    T = X[:, 0]
    rho = X[:, 1]
    Tc = X[:, 2]
    t = 1.0 - T / Tc
    t = np.clip(t, 1e-12, None)
    return a * np.power(t, 1.2) * np.power(np.clip(rho, 1e-12, None), 2.0 / 3.0)

def fit(X_fit, y_fit):
    T = X_fit[:, 0]
    rho = X_fit[:, 1]
    Tc = X_fit[:, 2]
    t = np.clip(1.0 - T / Tc, 1e-12, None)
    basis = np.power(t, 1.2) * np.power(np.clip(rho, 1e-12, None), 2.0 / 3.0)
    # Least-squares amplitude through the origin; robust fallback to median ratio.
    num = float(np.dot(basis, y_fit))
    den = float(np.dot(basis, basis))
    if den <= 0 or not np.isfinite(num) or not np.isfinite(den):
        ratio = y_fit / np.maximum(basis, 1e-30)
        finite = np.isfinite(ratio)
        a_hat = float(np.median(ratio[finite])) if np.any(finite) else 1.0
    else:
        a_hat = num / den
    if not np.isfinite(a_hat) or a_hat <= 0:
        a_hat = 1.0
    return {"a": a_hat}

def predict(X, a):
    return np.asarray(_predict(X, a), dtype=float)