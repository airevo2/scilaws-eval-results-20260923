"""Generalized Lotz electron-impact ionization law, fit per cluster.

Shared shape (all clusters):  sigma(E) = A * ln(E/I) / E^q * (1 - b*exp(-c*(E/I - 1)))
for E > I, and 0 at/below threshold I.  This combines a Bethe-type ln(E/I)/E^q
high-energy tail with a Lotz near-threshold correction factor.  Experiments
showed: (i) tail E>=100 eV follows ln(E/B)/E closely, (ii) a hard threshold
whose location varies per cluster (group supports 13.5-17 eV), (iii) a large
per-cluster amplitude variation (~25x).  A, I, q, b, c are therefore local.
"""
import numpy as np
from scipy.optimize import least_squares

USED_INPUTS = ["electron_energy_eV"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {
    "A": {"init": None},
    "I": {"init": None},
    "q": {"init": None},
    "b": {"init": None},
    "c": {"init": None},
}

def _form(E, A, I, q, b, c):
    E = np.asarray(E, dtype=float)
    u = np.maximum(E / I, 1.0 + 1e-12)
    base = A * np.log(u) / np.power(np.maximum(E, 1e-12), q)
    corr = 1.0 - b * np.exp(-c * np.maximum(u - 1.0, 0.0))
    out = np.where(E > I, base * corr, 0.0)
    return np.maximum(out, 0.0)

def fit(X_fit, y_fit):
    E = np.asarray(X_fit[:, 0], dtype=float)
    y = np.asarray(y_fit, dtype=float)
    m = y > 0
    E, y = E[m], y[m]
    if len(E) < 4:
        return {"A": 100.0, "I": 14.0, "q": 1.0, "b": 0.8, "c": 0.3}
    e_min = float(np.min(E))
    ly = np.log(y)

    def resid(p):
        A, I, q, b, c = p
        f = _form(E, A, I, q, b, c)
        f = np.maximum(f, 1e-12)
        return np.log(f) - ly

    lb = [1e-3, 3.0, 0.6, 0.0, 0.01]
    ub = [1e6, max(3.0, e_min - 0.5), 1.4, 1.5, 6.0]
    best = None
    for I0 in [min(13.0, e_min - 1.0), max(3.5, e_min - 3.0), max(3.5, e_min * 0.7)]:
        for q0 in [0.95, 1.0]:
            p0 = [100.0, I0, q0, 0.7, 0.3]
            p0 = [min(max(a, l), u) for a, l, u in zip(p0, lb, ub)]
            try:
                r = least_squares(resid, p0, bounds=(lb, ub), max_nfev=4000)
                cost = float(np.sum(r.fun ** 2))
                if best is None or cost < best[0]:
                    best = (cost, r.x)
            except Exception:
                pass
    if best is None:
        return {"A": 100.0, "I": 14.0, "q": 1.0, "b": 0.8, "c": 0.3}
    A, I, q, b, c = best[1]
    return {"A": float(A), "I": float(I), "q": float(q), "b": float(b), "c": float(c)}

def predict(X, A, I, q, b, c):
    E = np.asarray(X[:, 0], dtype=float)
    out = _form(E, A, I, q, b, c)
    return np.nan_to_num(out, nan=0.0, posinf=0.0, neginf=0.0)