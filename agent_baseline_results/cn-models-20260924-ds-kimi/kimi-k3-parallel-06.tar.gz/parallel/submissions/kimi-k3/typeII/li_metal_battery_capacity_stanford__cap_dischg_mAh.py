"""Per-cycle discharge capacity fade: gentle linear loss plus an extra linear
loss that switches on after a threshold cycle (two-slope piecewise-linear fade,
with a smooth transition around the onset). Q(k) = Q0 - b*k - c*softplus(k-k0).
Shared shape across all cells; per-cell constants (initial capacity Q0, early
fade rate b, added late fade rate c, onset cycle k0) are refit per cluster."""
import numpy as np
from scipy.optimize import curve_fit

USED_INPUTS = ["cycle_index"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {
    "Q0": {"init": None},
    "b": {"init": None},
    "c": {"init": None},
    "k0": {"init": None},
}

def _softplus(z):
    return np.logaddexp(0.0, z)

def _form(k, Q0, b, c, k0):
    # smooth(=1 cycle scale) threshold at k0: below k0 slope ~ -b, above ~ -(b+c)
    return Q0 - b * k - c * _softplus(k - k0)

def fit(X_fit, y_fit):
    k = np.asarray(X_fit[:, 0], dtype=float)
    y = np.asarray(y_fit, dtype=float)
    # fallback parameters: flat at median with tiny linear fade
    y0 = float(np.median(y))
    kmax = max(float(np.max(k)), 2.0)
    fb = {"Q0": y0, "b": 0.001 * y0 / kmax, "c": 0.002 * y0 / kmax,
          "k0": 0.5 * kmax}
    # initial guesses from a coarse two-piece analysis
    try:
        m_early = k <= 0.25 * kmax
        if m_early.sum() >= 2:
            A = np.column_stack([np.ones(int(m_early.sum())), -k[m_early]])
            b0 = float(np.linalg.lstsq(A, y[m_early], rcond=None)[0][1])
        else:
            b0 = 0.0
        b0 = max(b0, 0.0)
        a0 = float(np.median(y[m_early])) + b0 * float(np.median(k[m_early])) if m_early.sum() >= 1 else y0
        k0_0 = max(1.0, 0.3 * kmax)
        span = max(y0, 1e-3)
        p0 = [a0, b0, b0 + span * 1e-4, k0_0]
        bounds = ([0.0, 0.0, 0.0, 1.0],
                  [np.inf, np.inf, np.inf, np.inf])
        popt, _ = curve_fit(_form, k, y, p0=p0, bounds=bounds, maxfev=8000)
        return {"Q0": float(popt[0]), "b": float(popt[1]),
                "c": float(popt[2]), "k0": float(popt[3])}
    except Exception:
        return fb

def predict(X, Q0, b, c, k0):
    k = np.asarray(X[:, 0], dtype=float)
    return _form(k, Q0, b, c, k0)