"""Clipped linear cloud cover using sqrt(condensate), RH powers, T and height."""
import numpy as np

USED_INPUTS = ["q_c", "q_i", "RH", "T", "z_g"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    ql5 = (X[:, 0] + X[:, 1]) * 1e5
    RHc = np.clip(X[:, 2], 0.0, 1.2)
    Tn = (X[:, 3] - 273.15) / 50.0
    zg4 = X[:, 4] / 1e4
    lin = (0.21152832
           + 0.29812919 * np.sqrt(ql5)
           + 7.35583117 * RHc**2
           - 15.93882048 * RHc**3
           - 0.28750102 * np.sqrt(ql5) * RHc**2
           + 9.73874269 * RHc**4
           - 1.92679065 * Tn
           - 2.13618283 * zg4
           - 0.32380627 * zg4**2
           + 1.05704440 * RHc * zg4)
    return np.clip(lin, 0.0, 1.0)