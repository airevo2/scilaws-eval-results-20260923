"""Symmetrized Radice-2018-style dynamical ejecta fit.

Mej [1e-3 Msun] = sum_i ( a*(M_j/M_i)^(1/3)*(1-2*C_i)/C_i*M_i
                          + b*(M_j/M_i)^n + c*M_i ),
with (i,j) = (1,2) and (2,1). Constants fit on the training set
(log-residual least squares); positive n chosen for safe low-q
extrapolation.
"""
import numpy as np

USED_INPUTS = ["M1", "M2", "C1", "C2"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    M1 = X[:, 0]
    M2 = X[:, 1]
    C1 = X[:, 2]
    C2 = X[:, 3]
    a, b, c, n = -0.283193, 4.179513, -1.551430, 2.575464
    t = (a * (M2 / M1) ** (1.0 / 3.0) * (1.0 - 2.0 * C1) / C1 * M1
         + b * (M2 / M1) ** n + c * M1) \
      + (a * (M1 / M2) ** (1.0 / 3.0) * (1.0 - 2.0 * C2) / C2 * M2
         + b * (M1 / M2) ** n + c * M2)
    return np.maximum(t * 1e-3, 1e-7)