"""Van't Hoff DNA duplex melting temperature:
Tm(K) = dH / (dS + R*ln(4/C_DNA) - c*(N-1)*ln[Na+]),
with dH = a*E*N + a0*N and dS = b*E*N + d*N (E = mean dinucleotide step strength).
5 fitted constants; train RMSE 1.64 C, CV 1.67 C."""
import numpy as np

USED_INPUTS = ["E", "N", "salt_M", "dna_conc_M"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    E = X[:, 0]
    N = X[:, 1]
    salt = X[:, 2]
    C = X[:, 3]
    R = 1.9872e-3  # gas constant, kcal/(mol*K)
    num = 0.55580848 * E * N + 3.14616909 * N
    den = (0.00117119 * E * N + 0.01110089 * N
           + R * np.log(4.0 / C)
           - 0.00032358 * (N - 1.0) * np.log(salt))
    return num / den - 273.15