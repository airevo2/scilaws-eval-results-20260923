"""Au-197(n,gamma) log10 capture cross section vs neutron energy.
Model: 1/v thermal background plus two Breit-Wigner resonances (known Au-197
levels at 4.906 eV and 58.9 eV) sharing a single width, in barns.
4 fitted constants: A1 (res1 amplitude), B (1/v bg), g (shared half-width), A2 (res2 amplitude).
"""
import numpy as np

USED_INPUTS = ["E_eV"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    E = np.asarray(X[:, 0], dtype=float)
    E = np.maximum(E, 1e-12)
    A1 = 3.08630708e4
    B = 6.38724180e-1
    g = 7.19666530e-2
    A2 = 2.25465415e4
    E0, E2 = 4.906, 58.9
    g2 = g * g
    bw1 = A1 * np.sqrt(E0 / E) * g2 / ((E - E0) ** 2 + g2)
    bw2 = A2 * np.sqrt(E2 / E) * g2 / ((E - E2) ** 2 + g2)
    sigma = bw1 + bw2 + B / np.sqrt(E)
    sigma = np.maximum(sigma, 1e-12)
    return np.log10(sigma)