"""Piecewise-linear mass-luminosity law in log-log space with two breakpoints and a linear metallicity term."""
import numpy as np

USED_INPUTS = ["log_M_Msun", "metallicity"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    logM = X[:, 0]
    feh = X[:, 1]
    return (-1.020227
            + 2.046907 * logM
            + 3.279759 * np.maximum(logM - (-0.276949), 0.0)
            - 1.810830 * np.maximum(logM - 0.223755, 0.0)
            - 0.713631 * feh)