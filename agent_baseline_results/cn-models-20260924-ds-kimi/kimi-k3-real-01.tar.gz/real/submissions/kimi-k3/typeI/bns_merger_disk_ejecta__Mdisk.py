"""Post-merger accretion-disk mass: compactness-driven exponential times tidal/mass powers, with a soft physical saturation cap at 0.25 M_sun."""
import numpy as np

USED_INPUTS = ["M1", "M2", "C1", "C2", "q", "Lambda_tilde"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    M1 = X[:, 0]
    M2 = X[:, 1]
    C1 = X[:, 2]
    C2 = X[:, 3]
    Lt = X[:, 5]
    Mt = M1 + M2
    raw = 5.1906782927e+10 * np.exp(-1.4957170439e+02 * C1 + 2.0275857433e+00 * C2) * np.power(Lt, -4.8552317653e-01) * np.power(Mt, -7.6984370013e-01)
    Mcap = 0.25
    return raw / np.sqrt(1.0 + (raw / Mcap) ** 2)