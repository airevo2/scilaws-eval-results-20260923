"""Pythagenpat win percentage: exponent x = ((R+RA)/G)^0.2765, W% = R^x/(R^x+RA^x)."""
import numpy as np

USED_INPUTS = ["R", "RA", "G"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    R = X[:, 0]
    RA = X[:, 1]
    G = X[:, 2]
    x = ((R + RA) / G) ** 0.2765
    Rx = R ** x
    RAx = RA ** x
    return Rx / (Rx + RAx)