"""Elevation-adjusted Fu Budyko curve.

E/P = Fu(phi_eff, omega) with the Turc-Pike exponent omega = 2.63 and an
effective aridity index phi_eff = phi * (1 + k * ln(Z + 1)), where phi = Ep/P
and Z is mean catchment elevation [m]. Higher (snowier, terrain-driven)
catchments evaporate less at a given aridity, captured by the single fitted
constant k = -0.0266876068. The form satisfies both water and energy limits,
is bounded in [0, 1], and increases monotonically with aridity, so it
extrapolates sensibly to the arid test regime (phi up to 4.5).

One fitted constant total; fitted by least squares on the 840 training rows
(train RMSE 0.0680, 10-fold CV RMSE 0.0681).
"""
import numpy as np

USED_INPUTS = ["pet_over_p", "elev_mean_m"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    phi = X[:, 0]
    elev = X[:, 1]
    phi_eff = phi * (1.0 - 0.0266876068 * np.log(elev + 1.0))
    phi_eff = np.clip(phi_eff, 1e-6, None)
    w = 2.63
    return 1.0 + phi_eff - (1.0 + phi_eff ** w) ** (1.0 / w)