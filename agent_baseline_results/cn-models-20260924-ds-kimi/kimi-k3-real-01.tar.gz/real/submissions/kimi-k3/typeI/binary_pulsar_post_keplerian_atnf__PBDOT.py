"""Peters (1964) GR quadrupole orbital-period decay for a canonical double
neutron star (m1 = m2 = 1.4 Msun):

  PBDOT = -(192*pi/5) * (2*pi)^(5/3) * (G*Msun/c^3)^(5/3)
          * (m1*m2)/(m1+m2)^(1/3) * Pb^(-5/3)
          * (1 + 73/24 e^2 + 37/96 e^4) / (1 - e^2)^(7/2)

with Pb in seconds. Verified against Hulse-Taylor (-2.4026e-12) and the
Double Pulsar (-1.2478e-12). Uses zero fitted constants; purely physical
reference law. Inputs: Pb (days), e (dimensionless)."""
import numpy as np

USED_INPUTS = ["Pb", "e"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    Pb = np.asarray(X[:, 0], dtype=float) * 86400.0   # days -> seconds
    e = np.asarray(X[:, 1], dtype=float)
    Tsun = 4.925490947e-6                              # G*Msun/c^3 in s
    e2 = e * e
    F = (1.0 + (73.0/24.0)*e2 + (37.0/96.0)*e2*e2) / np.power(1.0 - e2, 3.5)
    m1, m2 = 1.4, 1.4                                  # canonical DNS masses (Msun)
    f = m1*m2/np.power(m1 + m2, 1.0/3.0)               # chirp factor
    C = (192.0*np.pi/5.0) * np.power(2.0*np.pi, 5.0/3.0) * np.power(Tsun, 5.0/3.0) * f
    return -C * np.power(Pb, -5.0/3.0) * F