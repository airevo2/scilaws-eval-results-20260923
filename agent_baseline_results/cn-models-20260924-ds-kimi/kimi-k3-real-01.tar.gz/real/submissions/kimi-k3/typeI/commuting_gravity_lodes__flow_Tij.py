"""Intervening-opportunity commuting law: T_ij = A * m_i^(a_i) * m_j^(a_j(m_j)) / [(m_i+s_ij)^g (m_i+m_j+s_ij)^g d_ij^h], with a low-mass boost of the destination exponent below ~10^3.9 workers; log10(T+1) predicted."""
import numpy as np

USED_INPUTS = ["m_i", "m_j", "d_ij_km", "s_ij"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    mi = X[:, 0]
    mj = X[:, 1]
    d = X[:, 2]
    s = X[:, 3]
    lmj = np.log10(mj)
    piv = 3.896626119537776  # log10 of the 25th-percentile destination mass
    c = 0.02429643234349283
    ej = (0.8757035676565072 - c) + 0.45 * np.clip(1.0 - lmj / piv, 0.0, 1.0)
    T = (0.35449697974549393
         * mi ** (0.7 + c)
         * mj ** ej
         / ((mi + s) ** 0.22 * (mi + mj + s) ** 0.22 * d ** 1.05))
    return np.log10(T + 1.0)