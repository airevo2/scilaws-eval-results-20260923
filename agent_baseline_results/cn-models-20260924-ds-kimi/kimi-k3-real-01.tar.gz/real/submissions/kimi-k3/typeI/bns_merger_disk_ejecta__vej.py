"""Mass-averaged terminal ejecta velocity: relativistic surface-escape scale
sE = sqrt(2*Ebar) (Ebar = mass-weighted 1/sqrt(1-2C)-1 of the two stars),
modulated by log10(Lambda_tilde) and a saturating sqrt(q-1) asymmetry term."""
import numpy as np

USED_INPUTS = ["q", "Lambda_tilde", "M1", "M2", "C1", "C2"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    q = X[:, 0]
    logL = np.log10(np.maximum(X[:, 1], 1e-9))
    M1 = X[:, 2]
    M2 = X[:, 3]
    C1 = X[:, 4]
    C2 = X[:, 5]
    E1 = 1.0 / np.sqrt(1.0 - 2.0 * C1) - 1.0
    E2 = 1.0 / np.sqrt(1.0 - 2.0 * C2) - 1.0
    Ebar = (M1 * E1 + M2 * E2) / (M1 + M2)
    sE = np.sqrt(2.0 * Ebar)
    return sE * (0.329933 + 0.003071 * logL - 0.045970 * np.sqrt(np.maximum(q - 1.0, 0.0)))