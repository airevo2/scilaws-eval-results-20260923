"""Cruising airspeed of flapping migratory birds: Ue = a*sqrt(m/S) + b, i.e. cruising speed scales with the square root of wing loading (Pennycuick flight mechanics, U ~ sqrt(2 m g /(rho S C_L))), with a fitted intercept capturing the offset from the pure minimum-power speed. Two fitted constants; grows as sqrt(wing loading) so it stays physically sensible when extrapolated to larger birds."""
import numpy as np

USED_INPUTS = ["mass_kg", "wing_area_m2"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    m = X[:, 0]
    S = X[:, 1]
    return 2.643450 * np.sqrt(m / S) + 8.450320