"""Isolation-by-distance: Rousset's linearised F_ST regressed on ln(distance).
M = a + b*ln(d); fitted a=-0.08523, b=0.01892 on 828 training pairs.
At d=1 km (ln d=0) the linear form would go slightly negative, so the
prediction is floored at 0 to remain physically sensible (M >= 0)."""
import numpy as np

USED_INPUTS = ["log_distance_km", "distance_km"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    ld = X[:, 0]
    y = -0.085235 + 0.018921 * ld
    return np.maximum(y, 0.0)