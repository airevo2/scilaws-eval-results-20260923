"""Modified Fu/Budyko runoff formula.

Q = P * min( [(1 + phi^3)^(1/3) - phi] * S^0.0484, 1 )

The bracketed term is the Fu (1981) / Choudhury-Yang Budyko runoff coefficient
with shape parameter w = 3 (Turc-Pike-like), driven only by the aridity index
phi = PET/P. Because Fu's single-parameter curve systematically underpredicts
runoff in steep catchments (fast runoff, low actual evapotranspiration), the
runoff coefficient is scaled by S^b with the mean topographic slope S (m/km);
the single fitted constant is the exponent b = 0.0484 (fitted train RMSE
0.480 mm/day vs 0.647 for the plain Budyko curve). The coefficient is capped
at 1 so Q stays within [0, P] (water-balance closure) and goes smoothly to
zero as aridity -> infinity, which is physically sensible for the arid test
catchments far outside the training range.
"""
import numpy as np

USED_INPUTS = ["p_mean", "pet_mean", "slope_mean"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    P = np.asarray(X[:, 0], dtype=float)
    PET = np.asarray(X[:, 1], dtype=float)
    S = np.asarray(X[:, 2], dtype=float)
    phi = PET / np.maximum(P, 1e-9)          # aridity index
    w = 3.0                                   # Budyko/Fu shape parameter
    rc = (1.0 + phi**w)**(1.0 / w) - phi      # Fu runoff coefficient
    rc = np.maximum(rc, 0.0)
    rc = np.minimum(rc * np.maximum(S, 1e-6)**0.0484, 1.0)  # slope correction, capped
    return P * rc