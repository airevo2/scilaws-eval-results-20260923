"""Classical Cepheid Gaia Wesenheit period-luminosity(-metallicity) relation.

M_W = -2.90*log_P - 0.33*[Fe/H] - 3.08

The period slope (-2.90) is a compromise between the flat OLS slope fitted to
these 24 nearby training stars (-2.61, very uncertain at sigma~0.4 because the
training periods span only log_P 0.49-0.99) and the canonical, physically
established Galactic Cepheid Wesenheit P-L slope (~-3.2 to -3.3). The metallicity
coefficient (-0.33) and zero point (-3.08) are least-squares fitted with the
slope held fixed; the train RMSE (0.2505) is within 0.003 mag of the free fit
while extrapolating far more sensibly into the test range (log_P up to 1.65).
The linear-in-log_P, linear-in-[Fe/H] form is the standard PLZ law used in the
literature and remains monotonic and physically reasonable everywhere.
"""
import numpy as np

USED_INPUTS = ["log_P", "feh"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    log_P = X[:, 0]
    feh = X[:, 1]
    return -2.90 * log_P - 0.328 * feh - 3.079