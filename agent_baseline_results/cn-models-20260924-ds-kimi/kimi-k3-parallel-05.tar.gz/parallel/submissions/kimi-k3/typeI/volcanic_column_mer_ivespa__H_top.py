"""Eruption-column top height: three-regime piecewise power law of MER.
Weak-plume (buoyant rise ~ MER^0.09) at low MER, convective strong-plume
regime (H ~ MER^1/4, Morton-Turner-Wilson) at mid MER, and wind/stratosphere-
limited flattening (~ MER^0.18) at high MER. Breaks at 10^3 and 10^7 kg/s;
regimes joined with softplus smoothing (s=0.25 dex)."""
import numpy as np

USED_INPUTS = ["MER_kg_per_s"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    M = np.maximum(X[:, 0], 1e-30)
    lM = np.log10(M)
    a1, a2, a3 = 0.09, 0.25, 0.18
    k1, k2 = 3.0, 7.0
    s = 0.25
    b = 0.16
    sp = lambda z: s * np.logaddexp(0.0, z)
    logH = b + a1 * lM + (a2 - a1) * sp((lM - k1) / s) + (a3 - a2) * sp((lM - k2) / s)
    return 10.0 ** logH