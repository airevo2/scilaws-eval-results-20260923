"""IEC-style wind turbine power curve: below cut-in the cubic-with-losses
k*v^3 + a is negative and clipped to 0; above cut-in it rises cubically and is
capped at rated power Pm; a logistic ramp in v blends the curve smoothly
through the transition region (region II-1/2 to III), reproducing the gradual
approach to the rated plateau observed between ~11 and ~14 m/s.

P(v) = clip(k*v^3 + a, 0, Pm) / (1 + exp(-s*(v - vm)))

Constants fitted from my simulator experiments (means over 253 wind speeds,
3 samples each): cut-in where k*v^3+a = 0 at v ~ 3.1 m/s, plateau ~2018 kW.
"""
import numpy as np

USED_INPUTS = ["wind_speed_mps"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    v = X[:, 0]
    base = np.clip(11.8475265 * v**3 - 349.005567, 0.0, 2018.31094)
    return base / (1.0 + np.exp(-0.599017411 * (v - 8.60528162)))