"""Nonlinear Boussinesq/ROR baseflow recession: Q(t) = Q0 * (1 + a*Q0^(1-n)*t)^(1/(1-n)),
equivalently dQ/dt = -a*Q^(2-n) (Coutagne/power-law storage-discharge). Per cluster we fit
the recession rate coefficient a and the exponent n. This is the classic nonlinear-reservoir
recession; the data showed super-exponential decay with a Q0-dependent rate, consistent with
this power-law form (n>1 giving concave log-log recession)."""
import numpy as np
from scipy.optimize import least_squares

USED_INPUTS = ["t", "Q_0"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {"a": {"init": [0.05]}, "n": {"init": [1.5]}}

def _form(t, Q0, a, n):
    t = np.asarray(t, float); Q0 = np.asarray(Q0, float)
    if abs(n - 1.0) < 1e-6:
        return Q0 * np.exp(-a * t)
    z = 1.0 + a * np.power(np.maximum(Q0, 1e-9), 1.0 - n) * t
    z = np.clip(z, 1e-12, None)
    return Q0 * np.power(z, 1.0 / (1.0 - n))

def fit(X_fit, y_fit):
    t = X_fit[:, 0].astype(float)
    Q0 = X_fit[:, 1].astype(float)
    y = np.asarray(y_fit, float)
    def resid(p):
        a, n = p
        pred = _form(t, Q0, a, n)
        denom = np.maximum(np.abs(y), 1e-9)
        return (pred - y) / denom
    best = None
    for a0 in [0.01, 0.05, 0.1, 0.3]:
        for n0 in [1.0, 1.5, 2.0]:
            try:
                res = least_squares(resid, [a0, n0],
                                    bounds=([1e-6, 0.2], [10.0, 4.0]),
                                    max_nfev=2000)
                c = np.sum(res.fun**2)
                if best is None or c < best[1]:
                    best = (res.x, c)
            except Exception:
                pass
    if best is None:
        return {"a": 0.05, "n": 1.5}
    a, n = best[0]
    return {"a": float(a), "n": float(n)}

def predict(X, a, n):
    return _form(X[:, 0], X[:, 1], a, n)