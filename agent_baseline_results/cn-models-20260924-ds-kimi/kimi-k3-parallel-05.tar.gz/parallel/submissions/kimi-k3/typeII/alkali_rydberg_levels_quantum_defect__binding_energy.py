"""Generalized Rydberg/Ritz binding energy: E = R / (n - d0 - d2/(n-d0) - d4/(n-d0)^3)^2, with R the universal Rydberg constant in cm^-1 and (d0, d2, d4) per-cluster defect coefficients."""
import numpy as np
from scipy.optimize import curve_fit

USED_INPUTS = ["n_qm"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {"R_RYDBERG_CM1": 109737.31568539}
LOCAL_FITTABLE = {"d0": {"init": 1.0}, "d2": {"init": 0.0}, "d4": {"init": 0.0}}

def _form(n, d0, d2, d4):
    m = n - d0
    delta = d0 + d2 / m + d4 / m**3
    return OTHER_CONSTANTS["R_RYDBERG_CM1"] / (n - delta)**2

def fit(X_fit, y_fit):
    n = np.asarray(X_fit[:, 0], dtype=float)
    y = np.asarray(y_fit, dtype=float)
    best = None
    # robust multi-start over d0 scale
    for p0 in ([1.0, 0.0, 0.0], [0.5, 0.0, 0.0], [2.0, 0.0, 0.0],
               [1.0, -1.0, 0.0], [3.0, -1.0, 0.0], [0.3, -1.0, 0.0]):
        try:
            popt, _ = curve_fit(_form, n, y, p0=p0, maxfev=20000)
            res = np.max(np.abs((_form(n, *popt) - y) / np.maximum(np.abs(y), 1e-12)))
            if best is None or res < best[1]:
                best = (popt, res)
        except Exception:
            continue
    if best is not None:
        p = best[0]
        return {"d0": float(p[0]), "d2": float(p[1]), "d4": float(p[2])}
    # fallback: single-parameter quantum defect via least squares on n*
    R = OTHER_CONSTANTS["R_RYDBERG_CM1"]
    d0 = float(np.mean(n - np.sqrt(R / np.maximum(y, 1e-12))))
    return {"d0": d0, "d2": 0.0, "d4": 0.0}

def predict(X, d0, d2, d4):
    n = np.asarray(X[:, 0], dtype=float)
    return _form(n, d0, d2, d4)