"""Regime-switching Cobb-Douglas in per-worker terms:
log_Y = c + a(r)*ln(K/L) + m*(1-a(r))*ln(h), with a(r) = 0.5*(1+tanh(ahat*(ln(K/L) - 2*h))).
The effective capital share switches smoothly between the capital regime and the
human-capital regime as ln(K/L) crosses a threshold proportional to h (mu=2).
Per-cluster params: c (log-TFP intercept), m (hc-regime slope), ahat (switch sharpness)."""
import numpy as np
from scipy.optimize import least_squares

USED_INPUTS = ["cn", "emp", "hc"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {"c": {"init": None}, "m": {"init": None}, "ahat": {"init": None}}

MU = 2.0

def _predict_core(X, c, m, ahat):
    K = np.asarray(X[:, 0], dtype=float)
    L = np.asarray(X[:, 1], dtype=float)
    h = np.asarray(X[:, 2], dtype=float)
    K = np.clip(K, 1e-9, None); L = np.clip(L, 1e-9, None); h = np.clip(h, 1e-9, None)
    lk = np.log(K / L)
    lh = np.log(h)
    r = np.clip(lk - MU * h, -30.0, 30.0)
    a = 0.5 * (1.0 + np.tanh(np.clip(ahat, -20.0, 20.0) * r))
    return c + a * lk + m * (1.0 - a) * lh

def fit(X_fit, y_fit):
    y = np.asarray(y_fit, dtype=float)
    X = np.asarray(X_fit, dtype=float)
    c0 = float(np.mean(y)) - 0.5 * float(np.mean(np.log(np.clip(X[:, 0], 1e-9, None) / np.clip(X[:, 1], 1e-9, None))))
    best = None
    for a0 in (-3.0, -1.0, 0.0, 1.0, 3.0):
        try:
            res = least_squares(
                lambda p: _predict_core(X, p[0], p[1], p[2]) - y,
                [c0, 1.0, a0], max_nfev=3000)
            if best is None or res.cost < best.cost:
                best = res
        except Exception:
            continue
    if best is None or not np.all(np.isfinite(best.x)):
        return {"c": c0, "m": 1.0, "ahat": 0.0}
    c, m, ahat = (float(best.x[0]), float(best.x[1]), float(best.x[2]))
    return {"c": c, "m": m, "ahat": ahat}

def predict(X, c, m, ahat):
    out = _predict_core(np.asarray(X, dtype=float), c, m, ahat)
    return np.nan_to_num(out, nan=float(np.nanmean(out)) if np.any(np.isfinite(out)) else 0.0)