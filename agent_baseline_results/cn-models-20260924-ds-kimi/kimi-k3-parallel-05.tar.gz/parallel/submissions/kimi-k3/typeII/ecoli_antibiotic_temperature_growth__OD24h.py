"""Split (two-sided) Gaussian thermal-niche law, fit per antibiotic-background cluster.

Shared mechanism across clusters: OD24h(T) follows an asymmetric Gaussian
('split-normal'-style) thermal performance curve,

    OD24h(T) = A * exp( -(T - Topt)^2 / s(T) ),
    s(T) = s1 for T < Topt,  s2 for T >= Topt,

which captures the observed slow low-temperature rise, an optimum that shifts
per cluster (~30-41 degC), and the abrupt high-temperature collapse (narrow
right width) characteristic of growth under sub-lethal antibiotic stress.
The four quantities (peak height A, optimum Topt, left/right widths s1, s2)
vary with the antibiotic background and are refit per cluster.
"""
import numpy as np
from scipy.optimize import least_squares

USED_INPUTS = ["T"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {"A": {"init": None}, "Topt": {"init": None},
                  "s1": {"init": None}, "s2": {"init": None}}

def _form(T, A, Topt, s1, s2):
    T = np.asarray(T, dtype=float)
    s = np.where(T < Topt, np.maximum(s1, 1e-6), np.maximum(s2, 1e-6))
    return A * np.exp(-((T - Topt) ** 2) / s)

def fit(X_fit, y_fit):
    T = np.asarray(X_fit[:, 0], dtype=float)
    y = np.asarray(y_fit, dtype=float)
    yc = np.clip(y, 0.0, None)
    Amax = max(float(np.max(yc)), 1e-3)
    Tpk = float(T[int(np.argmax(yc))])
    best, best_r = None, np.inf
    bounds = ([1e-6, 20.0, 0.5, 0.5], [1e3, 50.0, 3000.0, 3000.0])
    starts = []
    for mu0 in [Tpk, 31.0, 34.0, 37.0, 39.0, 41.0]:
        starts.append([Amax, mu0, 60.0, 15.0])
        starts.append([Amax, mu0, 20.0, 60.0])
    for p0 in starts:
        try:
            out = least_squares(lambda p: _form(T, *p) - y, p0,
                                bounds=bounds, max_nfev=4000)
            r = float(np.sqrt(np.mean(out.fun ** 2)))
            if np.isfinite(r) and r < best_r:
                best_r, best = r, out.x
        except Exception:
            continue
    if best is None:
        # moments-based fallback
        w = yc + 1e-9
        mu = float(np.sum(T * w) / np.sum(w))
        var = float(np.sum(w * (T - mu) ** 2) / np.sum(w))
        best = np.array([Amax, mu, max(var, 4.0), max(var, 4.0)])
    return {"A": float(best[0]), "Topt": float(best[1]),
            "s1": float(best[2]), "s2": float(best[3])}

def predict(X, A, Topt, s1, s2):
    y = _form(X[:, 0], A, Topt, s1, s2)
    return np.asarray(y, dtype=float)