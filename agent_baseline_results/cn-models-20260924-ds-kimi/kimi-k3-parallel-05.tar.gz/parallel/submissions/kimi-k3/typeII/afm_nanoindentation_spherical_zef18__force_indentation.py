"""Hertz contact mechanics for a spherical AFM probe indenting an elastic
half-space: F = (4/3) * E* * sqrt(R) * delta^(3/2). The reduced modulus E*
is the single per-cluster parameter (each cluster = a sample/spot with its
own stiffness); the 3/2 power of indentation and the sqrt(R) tip-radius
scaling are universal across clusters."""
import numpy as np

USED_INPUTS = ["indentation_m", "R_m"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {"E": {"init": None}}

def fit(X_fit, y_fit):
    d = np.asarray(X_fit[:, 0], dtype=float)
    R = np.asarray(X_fit[:, 1], dtype=float)
    t = (4.0 / 3.0) * np.sqrt(np.maximum(R, 0.0)) * np.power(np.maximum(d, 0.0), 1.5)
    denom = float(np.dot(t, t))
    if denom <= 0.0 or not np.isfinite(denom):
        return {"E": 100.0}
    E_hat = float(np.dot(t, y_fit) / denom)
    if not np.isfinite(E_hat):
        E_hat = 100.0
    return {"E": E_hat}

def predict(X, E):
    d = np.asarray(X[:, 0], dtype=float)
    R = np.asarray(X[:, 1], dtype=float)
    t = (4.0 / 3.0) * np.sqrt(np.maximum(R, 0.0)) * np.power(np.maximum(d, 0.0), 1.5)
    return E * t