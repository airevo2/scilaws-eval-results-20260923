"""Geiger–Nuttall law: log10(T_1/2) = a + b / sqrt(Q_alpha), with a per-cluster intercept (fittable) and one universal slope."""
import numpy as np

USED_INPUTS = ["Q_alpha_MeV"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {"a": {"init": None}, "b": {"init": None}}

def _form(Q, a, b):
    return a + b / np.sqrt(Q)

def fit(X_fit, y_fit):
    Q = X_fit[:, 0]
    x = 1.0 / np.sqrt(Q)
    # Weighted by nothing; simple OLS per cluster
    A = np.column_stack([np.ones_like(x), x])
    try:
        coef, *_ = np.linalg.lstsq(A, y_fit, rcond=None)
        a_hat, b_hat = float(coef[0]), float(coef[1])
    except Exception:
        a_hat, b_hat = -50.0, 134.0
    return {"a": a_hat, "b": b_hat}

def predict(X, a, b):
    Q = X[:, 0]
    return _form(Q, a, b)