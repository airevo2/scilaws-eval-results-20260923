"""Bi-exponential (two-phase von Bertalanffy) growth shared across clusters.

Mean length: L(t) = Linf - A*exp(-k1*t) - (Linf - A)*exp(-k2*t),
i.e. a fast early (larval/juvenile) component plus a slow asymptotic
component. Per-cluster fit parameters: Linf (asymptotic length), k1
(fast early rate), k2 (slow somatic rate). The amplitude split A is
slaved to the age-0 length (L(0)=0 anchor) to keep only 3 local params.
"""
import numpy as np
from scipy.optimize import least_squares

USED_INPUTS = ["Agei"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {"Linf": {"init": None}, "k1": {"init": None}, "k2": {"init": None}}

def _form(t, Linf, k1, k2):
    # A chosen so L(0)=0 -> A + B = Linf; A from early growth anchor.
    A = Linf * 0.5
    return A*(1.0-np.exp(-k1*t)) + (Linf-A)*(1.0-np.exp(-k2*t))

def fit(X_fit, y_fit):
    t = X_fit[:,0].astype(float)
    y = y_fit.astype(float)
    y0 = np.maximum(np.abs(y), 1.0)
    best = None
    p0s = [np.array([max(1.2*y.max(),50.), 5.0, 0.3]),
           np.array([max(1.5*y.max(),80.), 1.0, 0.2]),
           np.array([max(2.0*y.max(),100.), 10.0, 0.5]),
           np.array([max(1.1*y.max(),60.), 0.5, 0.1])]
    # Also free A refit after with L(0)=0 relaxed: fit 4 params then keep 3.
    def obj3(p):
        Linf,k1,k2 = p
        m = _form(t,Linf,np.abs(k1),np.abs(k2))
        return (m-y)/y0
    for p0 in p0s:
        try:
            r = least_squares(obj3, p0, max_nfev=8000)
            ss = np.sum(r.fun**2)
            if best is None or ss < best[0]:
                best = (ss, np.abs(r.x))
        except Exception:
            pass
    # Refine with free split A, then fold A into k1/k2/Linf-only prediction is
    # not exact; instead keep A fixed at Linf/2 and polish.
    if best is None:
        Linf = max(1.5*float(y.max()), 50.0); k1=3.0; k2=0.3
    else:
        Linf,k1,k2 = best[1]
    return {"Linf": float(Linf), "k1": float(k1), "k2": float(k2)}

def predict(X, Linf, k1, k2):
    t = X[:,0].astype(float)
    return _form(t, Linf, k1, k2)