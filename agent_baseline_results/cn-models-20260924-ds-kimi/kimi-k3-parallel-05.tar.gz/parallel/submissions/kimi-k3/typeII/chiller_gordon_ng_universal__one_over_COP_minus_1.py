"""Gordon-Ng-style chiller model: 1/COP - 1 = (T_ci/T_ei) * W/Q_e - 1, where the
compressor-side power W is a quadratic-in-load polynomial with additive linear
temperature terms: W = w0 + w1*T_ci + w2*T_ei + w3*Q_e + w4*Q_e^2.
Equivalently y = (Tci/Tei)*(w0 + w1*Tci + w2*Tei + w3*Qe + w4*Qe^2)/Qe - 1.
Probing showed W := (y+1)*Qe*Tei/Tci is ~linear in Tci and Tei and quadratic in Qe.
The 5 coefficients are re-fit per cluster by linear least squares."""
import numpy as np

USED_INPUTS = ["T_ei", "T_ci", "Q_e"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {
    "w0": {"init": None},
    "w1": {"init": None},
    "w2": {"init": None},
    "w3": {"init": None},
    "w4": {"init": None},
}

def fit(X_fit, y_fit):
    Tei = np.asarray(X_fit[:, 0], dtype=float)
    Tci = np.asarray(X_fit[:, 1], dtype=float)
    Qe = np.asarray(X_fit[:, 2], dtype=float)
    y = np.asarray(y_fit, dtype=float)
    # Invert the structure: W = (y+1) * Qe * Tei / Tci, linear in the w's.
    Wt = (y + 1.0) * Qe * Tei / Tci
    A = np.column_stack([np.ones_like(Qe), Tci, Tei, Qe, Qe * Qe])
    try:
        coef, *_ = np.linalg.lstsq(A, Wt, rcond=None)
        if not np.all(np.isfinite(coef)):
            raise ValueError
    except Exception:
        coef = np.array([-225.0, 1.3, -0.5, 0.07, 2.0e-4])
    return {"w0": float(coef[0]), "w1": float(coef[1]), "w2": float(coef[2]),
            "w3": float(coef[3]), "w4": float(coef[4])}

def predict(X, w0, w1, w2, w3, w4):
    Tei = np.asarray(X[:, 0], dtype=float)
    Tci = np.asarray(X[:, 1], dtype=float)
    Qe = np.asarray(X[:, 2], dtype=float)
    W = w0 + w1 * Tci + w2 * Tei + w3 * Qe + w4 * Qe * Qe
    return (Tci / Tei) * W / Qe - 1.0