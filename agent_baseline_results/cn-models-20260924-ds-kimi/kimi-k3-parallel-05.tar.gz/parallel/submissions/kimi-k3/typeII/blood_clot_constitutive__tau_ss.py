"""Odd Mooney-Rivlin-type shear law: tau_ss = a*gamma + b*gamma^3 + c*gamma^5.
The simple-shear Cauchy stress of the fibrin clot is an odd function of the
engineering shear amount (isotropy => only odd powers), with three per-cluster
coefficients capturing the cluster-specific stiffness/hardening."""
import numpy as np

USED_INPUTS = ["gamma"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {"a": {"init": None}, "b": {"init": None}, "c": {"init": None}}

def fit(X_fit, y_fit):
    g = np.asarray(X_fit[:, 0], dtype=float)
    y = np.asarray(y_fit, dtype=float)
    A = np.vstack([g, g**3, g**5]).T
    try:
        coef, *_ = np.linalg.lstsq(A, y, rcond=None)
        a, b, c = float(coef[0]), float(coef[1]), float(coef[2])
    except Exception:
        a, b, c = 0.0, 0.0, 0.0
    if not (np.isfinite(a) and np.isfinite(b) and np.isfinite(c)):
        a, b, c = 0.0, 0.0, 0.0
    return {"a": a, "b": b, "c": c}

def predict(X, a, b, c):
    g = np.asarray(X[:, 0], dtype=float)
    return a * g + b * g**3 + c * g**5