"""Sigmoid (Homma/Chick-Watson-style) inactivation law: LRV = a + b * (-ln(1 - 2^-CT)),
shared across clusters; per-cluster scale a (intercept) and b (slope) are refit."""
import numpy as np

USED_INPUTS = ["CT"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {"a": {"init": None}, "b": {"init": None}}

_LN2 = np.log(2.0)

def _basis(ct):
    # -ln(1 - 2^-CT), computed stably; ~ 2^-CT/ln(... ) for small CT, ~ CT*ln2 for large CT
    ct = np.asarray(ct, dtype=float)
    z = np.empty_like(ct)
    big = ct > 20.0
    z[big] = ct[big] * _LN2
    z[~big] = -np.log1p(-np.exp(-ct[~big] * _LN2))
    return z

def fit(X_fit, y_fit):
    ct = np.asarray(X_fit[:, 0], dtype=float)
    y = np.asarray(y_fit, dtype=float)
    B = _basis(ct)
    A = np.column_stack([np.ones_like(B), B])
    try:
        coef, *_ = np.linalg.lstsq(A, y, rcond=None)
        a, b = float(coef[0]), float(coef[1])
        if not (np.isfinite(a) and np.isfinite(b)):
            raise ValueError
    except Exception:
        a = float(np.mean(y)) if len(y) else 0.0
        b = 0.0
    return {"a": a, "b": b}

def predict(X, a, b):
    ct = np.asarray(X[:, 0], dtype=float)
    return a + b * _basis(ct)