"""Toth adsorption isotherm (heterogeneous-site generalisation of Langmuir):
n_ads = n_s * K*P / (1 + (K*P)^t)^(1/t), fit per adsorbent cluster.
Recovered as the best-fitting 3-parameter mechanism across 18 probed groups;
t -> 1 recovers Langmuir, and the exponent t captures surface heterogeneity."""
import numpy as np
from scipy.optimize import least_squares

USED_INPUTS = ["P_bar"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {"n_s": {"init": None}, "K": {"init": None}, "t": {"init": None}}

def _form(P, n_s, K, t):
    KP = K * P
    return n_s * KP / (1.0 + KP**t)**(1.0 / t)

def fit(X_fit, y_fit):
    P = np.asarray(X_fit[:, 0], dtype=float)
    y = np.asarray(y_fit, dtype=float)
    y_max = float(np.max(y)) if y.size else 1.0
    best = (np.inf, None)
    for p0 in ([1.3 * y_max, 5.0, 0.5],
               [1.3 * y_max, 50.0, 0.5],
               [1.3 * y_max, 1.0, 0.8],
               [2.0 * y_max, 200.0, 0.4]):
        try:
            res = least_squares(
                lambda p: _form(P, p[0], np.exp(p[1]), np.exp(p[2])) - y,
                [p0[0], np.log(p0[1]), np.log(p0[2])],
                max_nfev=8000)
            rms = float(np.sqrt(np.mean(res.fun**2)))
            if rms < best[0]:
                best = (rms, (res.x[0], np.exp(res.x[1]), np.exp(res.x[2])))
        except Exception:
            pass
    if best[1] is None:
        best = (0.0, (1.3 * y_max, 5.0, 0.5))
    n_s, K, t = best[1]
    return {"n_s": float(n_s), "K": float(K), "t": float(t)}

def predict(X, n_s, K, t):
    P = np.asarray(X[:, 0], dtype=float)
    KP = K * P
    y = n_s * KP / (1.0 + KP**t)**(1.0 / t)
    return np.where(np.isfinite(y), y, 0.0)