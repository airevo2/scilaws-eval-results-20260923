"""Bacterial batch-culture growth as a baseline-offset logistic curve.

OD600(t) = c + K / (1 + exp(-r (t - t0)))

c  = background/blank OD baseline (~0.08, the no-growth absorbance floor);
K  = growth amplitude (carrying-capacity increase above baseline, ~0.24);
r  = maximum specific growth rate (1/h);
t0 = inflection/mid-growth time (h).

Blank wells (no growth) are recovered as K -> 0, leaving the flat baseline c.
One shared functional form holds for every cluster; the four parameters are
re-fit per cluster."""
import numpy as np
from scipy.optimize import curve_fit

USED_INPUTS = ["time_h"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {
    "c":  {"init": None},
    "K":  {"init": None},
    "r":  {"init": None},
    "t0": {"init": None},
}

def _form(t, c, K, r, t0):
    z = np.clip(-r * (t - t0), -500.0, 500.0)
    return c + K / (1.0 + np.exp(z))

def fit(X_fit, y_fit):
    t = np.asarray(X_fit[:, 0], dtype=float)
    y = np.asarray(y_fit, dtype=float)
    y_min = float(np.min(y))
    y_max = float(np.max(y))
    amp = max(y_max - y_min, 1e-3)
    t_half = float(t[np.argmin(np.abs(y - (y_min + 0.5 * amp)))]) if len(t) else 10.0
    p0 = [y_min, amp, 1.0, t_half]
    bounds = ([-1.0, 0.0, 0.0, -10.0], [2.0, 5.0, 20.0, 100.0])
    try:
        popt, _ = curve_fit(_form, t, y, p0=p0, bounds=bounds, maxfev=8000)
        c, K, r, t0 = [float(v) for v in popt]
        if not np.all(np.isfinite(popt)):
            raise RuntimeError
    except Exception:
        c, K, r, t0 = y_min, amp, 1.0, t_half
    return {"c": c, "K": K, "r": r, "t0": t0}

def predict(X, c, K, r, t0):
    t = np.asarray(X[:, 0], dtype=float)
    out = _form(t, c, K, r, t0)
    return np.asarray(out, dtype=float)