"""Gaisser-Hillas longitudinal shower profile: dE/dX = Nmax * ((X-X0)/(Xmax-X0))^((Xmax-X0)/lam) * exp((Xmax-X)/lam), fit per cluster. The four GH parameters (Nmax, Xmax, X0, lam) vary per shower/cluster."""
import numpy as np
from scipy.optimize import least_squares

USED_INPUTS = ["X"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {"Nmax": {"init": None}, "Xmax": {"init": None}, "X0": {"init": None}, "lam": {"init": None}}

def _gh(X, Nmax, Xmax, X0, lam):
    Xmax = np.where(np.abs(Xmax - X0) < 1e-6, X0 + 1e-6, Xmax)
    t = np.clip((X - X0) / (Xmax - X0), 1e-12, None)
    p = (Xmax - X0) / lam
    return np.exp(np.log(np.clip(Nmax, 1e-12, None)) + p * np.log(t) + (Xmax - X) / lam)

def fit(X_fit, y_fit):
    X = np.asarray(X_fit[:, 0], dtype=float)
    y = np.asarray(y_fit, dtype=float)
    y = np.clip(y, 1e-12, None)
    xpk = float(X[np.argmax(y)]); npk = float(np.max(y))
    lny = np.log(y)

    def res(p):
        Nmax, Xmax, X0, lam = p
        if Xmax - X0 < 5 or lam <= 1:
            return 1e6 * np.ones_like(lny)
        return np.log(np.clip(_gh(X, Nmax, Xmax, X0, lam), 1e-12, None)) - lny

    lo = [0.02 * npk, xpk - 200, -300, 5.0]
    hi = [50 * npk, xpk + 200, xpk, 900.0]
    starts = [(xpk - 250, 80.0), (xpk - 400, 150.0), (xpk - 150, 50.0), (xpk - 300, 250.0), (max(xpk - 350, 0.0), 70.0)]
    best = None
    for X0s, lams in starts:
        p0 = [npk, xpk, min(X0s, xpk - 5), lams]
        p0 = [min(max(p0[i], lo[i] + 1e-6), hi[i] - 1e-6) for i in range(4)]
        try:
            out = least_squares(res, p0, bounds=(lo, hi), max_nfev=8000)
            c = float(np.sum(out.fun ** 2))
            if np.all(np.isfinite(out.x)) and (best is None or c < best[0]):
                best = (c, out.x)
        except Exception:
            pass
    if best is None:
        return {"Nmax": npk, "Xmax": xpk, "X0": xpk - 250.0, "lam": 80.0}
    p = best[1]
    return {"Nmax": float(p[0]), "Xmax": float(p[1]), "X0": float(p[2]), "lam": float(p[3])}

def predict(X, Nmax, Xmax, X0, lam):
    Xv = np.asarray(X[:, 0], dtype=float)
    out = _gh(Xv, float(Nmax), float(Xmax), float(X0), float(lam))
    return np.where(np.isfinite(out), out, 0.0)