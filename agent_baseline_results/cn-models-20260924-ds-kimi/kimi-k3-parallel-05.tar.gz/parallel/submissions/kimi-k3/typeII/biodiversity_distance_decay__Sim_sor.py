"""Distance-decay power law for Sorensen taxonomic similarity:
S(d) = a * env_dist^(-b), the classic ecological distance-decay of similarity.
'a' is the similarity at unit environmental distance and 'b' the decay exponent;
both vary per ecological dataset (cluster), so both are LOCAL_FITTABLE.
Validated on 7 clusters: monotone decaying, log-log linear, rel-RMSE 1.6-7.5%."""
import numpy as np

USED_INPUTS = ["env_dist"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {"a": {"init": None}, "b": {"init": None}}

def fit(X_fit, y_fit):
    d = np.asarray(X_fit[:, 0], dtype=float)
    y = np.asarray(y_fit, dtype=float)
    mask = np.isfinite(d) & np.isfinite(y) & (d > 0) & (y > 0)
    d, y = d[mask], y[mask]
    if len(d) < 2:
        return {"a": float(np.mean(y)) if len(y) else 0.5, "b": 0.5}
    ld, ly = np.log(d), np.log(y)
    A = np.vstack([ld, np.ones_like(ld)]).T
    slope, intercept = np.linalg.lstsq(A, ly, rcond=None)[0]
    a = float(np.exp(intercept))
    b = float(-slope)
    # Guard rails: keep similarity positive and decay exponent non-negative.
    if not np.isfinite(a) or a <= 0:
        a = float(np.exp(np.mean(ly)))
    if not np.isfinite(b) or b < 0:
        b = 0.0
    return {"a": a, "b": b}

def predict(X, a, b):
    d = np.asarray(X[:, 0], dtype=float)
    d = np.maximum(d, 1e-9)
    return a * np.power(d, -b)