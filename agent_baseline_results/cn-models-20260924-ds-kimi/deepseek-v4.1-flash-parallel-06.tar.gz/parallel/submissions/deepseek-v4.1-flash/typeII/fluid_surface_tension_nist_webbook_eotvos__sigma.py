"""Surface tension as a critical-scaling power law in reduced temperature times a
molar-volume (Eötvös/Guggenheim) density term, with one per-substance prefactor.

    sigma = A * (1 - T/Tc)^n * Vm^(-2/3),   Vm = M_mol / rho_liq

The exponent n on the reduced temperature (1 - T/Tc) is a structural constant of
the mechanism (~1.217, recovered consistently within every cluster), and the
density enters with the classic 2/3 power of molar volume. Only the per-substance
prefactor A = sigma0 varies between clusters.
"""
import numpy as np

USED_INPUTS = ["T_K", "rho_liq", "T_c", "M_mol"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {"A": {"init": None}}

# Structural (universal) critical-scaling exponent on (1 - T/Tc).
_N_EXP = 1.217
_DENS_EXP = -2.0 / 3.0


def _basis(X):
    X = np.asarray(X, dtype=float)
    T = X[:, 0]
    rho = X[:, 1]
    Tc = X[:, 2]
    M = X[:, 3]
    Vm = M / rho
    frac = 1.0 - T / Tc
    frac = np.clip(frac, 1e-12, None)
    return np.power(frac, _N_EXP) * np.power(Vm, _DENS_EXP)


def fit(X_fit, y_fit):
    X_fit = np.asarray(X_fit, dtype=float)
    y_fit = np.asarray(y_fit, dtype=float)
    b = _basis(X_fit)
    denom = float(np.sum(b * b))
    if (not np.isfinite(denom)) or denom <= 0.0:
        return {"A": 1.0e-4}
    A = float(np.sum(b * y_fit) / denom)
    if (not np.isfinite(A)) or A <= 0.0:
        A = 1.0e-4
    return {"A": A}


def predict(X, A):
    X = np.asarray(X, dtype=float)
    return A * _basis(X)