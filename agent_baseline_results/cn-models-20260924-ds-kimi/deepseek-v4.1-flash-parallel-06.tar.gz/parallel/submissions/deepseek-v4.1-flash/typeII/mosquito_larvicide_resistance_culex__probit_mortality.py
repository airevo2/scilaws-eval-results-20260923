"""Symmetric four-parameter logistic (Hill) dose-response in log-dose:
P = lo + (hi - lo) / (1 + exp(-k*(lnC - x0))).
Per-cluster parameters: x0 (log EC50), k (slope), lo (lower asymptote / control
correction), hi (upper asymptote). Fitted per cluster by least squares."""
import numpy as np
from scipy.optimize import curve_fit

USED_INPUTS = ["log_conc_ppb"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {
    "x0": {"init": [3.5]},
    "k":  {"init": [1.5]},
    "lo": {"init": [0.0]},
    "hi": {"init": [1.0]},
}


def _form(x, x0, k, lo, hi):
    return lo + (hi - lo) / (1.0 + np.exp(-k * (x - x0)))


def fit(X_fit, y_fit):
    x = np.asarray(X_fit[:, 0], dtype=float)
    y = np.asarray(y_fit, dtype=float)
    # sensible initial guesses from the data
    hi0 = float(np.percentile(y, 90))
    lo0 = float(np.percentile(y, 10))
    x0_0 = float(np.median(x))
    k0 = 1.5
    p0 = [x0_0, k0, lo0, hi0]
    lo_b = [-np.inf, 1e-3, -1.0, 0.1]
    hi_b = [np.inf, np.inf, 1.0, 2.0]
    try:
        popt, _ = curve_fit(_form, x, y, p0=p0, bounds=(lo_b, hi_b), maxfev=20000)
        x0, k, lo, hi = [float(v) for v in popt]
    except Exception:
        x0, k, lo, hi = x0_0, k0, lo0, hi0
    return {"x0": x0, "k": k, "lo": lo, "hi": hi}


def predict(X, x0, k, lo, hi):
    x = np.asarray(X[:, 0], dtype=float)
    return _form(x, x0, k, lo, hi)