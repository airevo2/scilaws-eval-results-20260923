"""Fung-type exponential (biaxial skin) mechanism, shared across clusters.

The first principal Cauchy stress is modelled as the (exponential-family)
derivative of a Fung strain-energy in Green strains
    E1 = (lambda11**2 - 1)/2 ,   E2 = (lambda22**2 - 1)/2
with exponent quadratic in the two strains:
    Q = a1*E1**2 + a2*E2**2 + 2*a3*E1*E2
    sigma11 = C * (2*a1*E1 + 2*a3*E2) * exp(Q)

C (scale, MPa) and the three material coefficients (a1,a2,a3) are the only
things re-fit per cluster; the functional shape is identical for every cluster.
"""
import numpy as np
from scipy.optimize import least_squares

USED_INPUTS = ["lambda11", "lambda22"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {
    "C":  {"init": [0.002]},
    "a1": {"init": [2.5]},
    "a2": {"init": [1.0]},
    "a3": {"init": [2.0]},
}


def _model(X, C, a1, a2, a3):
    l1 = X[:, 0]
    l2 = X[:, 1]
    E1 = (l1 ** 2 - 1.0) / 2.0
    E2 = (l2 ** 2 - 1.0) / 2.0
    Q = a1 * E1 ** 2 + a2 * E2 ** 2 + 2.0 * a3 * E1 * E2
    # guard against overflow of the exponent
    Q = np.clip(Q, -50.0, 50.0)
    return C * (2.0 * a1 * E1 + 2.0 * a3 * E2) * np.exp(Q)


def fit(X_fit, y_fit):
    X_fit = np.asarray(X_fit, float)
    y_fit = np.asarray(y_fit, float)
    n = len(y_fit)

    # sensible scale from data
    scale = float(np.max(np.abs(y_fit))) if n else 0.01
    p0 = [max(scale / 5.0, 1e-5), 3.0, 1.0, 2.0]

    def resid(p):
        return _model(X_fit, *p) - y_fit

    best = None
    for guess in (p0,
                  [max(scale / 10.0, 1e-6), 6.0, 2.0, 3.0],
                  [max(scale / 2.0, 1e-5), 1.5, 0.5, 1.0]):
        try:
            res = least_squares(resid, guess, max_nfev=6000)
            if best is None or res.cost < best.cost:
                best = res
        except Exception:
            continue

    if best is None:
        return {"C": p0[0], "a1": p0[1], "a2": p0[2], "a3": p0[3]}

    C, a1, a2, a3 = best.x
    # keep parameters physically sane / finite
    C = float(C) if np.isfinite(C) else p0[0]
    a1 = float(a1) if np.isfinite(a1) else p0[1]
    a2 = float(a2) if np.isfinite(a2) else p0[2]
    a3 = float(a3) if np.isfinite(a3) else p0[3]
    return {"C": C, "a1": a1, "a2": a2, "a3": a3}


def predict(X, C, a1, a2, a3):
    X = np.asarray(X, float)
    return _model(X, C, a1, a2, a3)