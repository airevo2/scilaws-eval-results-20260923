"""Gompertz law of adult mortality: log of the central death rate is linear in age,
with a per-cluster (calendar-year) intercept and slope: ln m(x) = a + b*x."""
import numpy as np

USED_INPUTS = ["age"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {"a": {"init": None}, "b": {"init": None}}

def fit(X_fit, y_fit):
    x = np.asarray(X_fit[:, 0], dtype=float)
    y = np.asarray(y_fit, dtype=float)
    # Ordinary least squares line ln m = a + b*age
    A = np.column_stack([np.ones_like(x), x])
    try:
        coef, _, _, _ = np.linalg.lstsq(A, y, rcond=None)
        a, b = float(coef[0]), float(coef[1])
        if not (np.isfinite(a) and np.isfinite(b)):
            raise ValueError
    except Exception:
        a = float(np.mean(y))
        b = 0.0
    return {"a": a, "b": b}

def predict(X, a, b):
    x = np.asarray(X[:, 0], dtype=float)
    return a + b * x