"""Measles one-step log growth rate.

Shared mechanism (identical shape for every city/cluster):

    g_t = ln(I_t + 1) - ln(I_{t-1} + 1)
        = c0 + c1*sin(2*pi*s/26) + c2*cos(2*pi*s/26)
              + c3*ln(cases_prev + 1) + c4*ln(z_t + 1)

i.e. the log-growth is an annual (26-biweek) sinusoid, linearly reduced by
the log of the current case count (susceptible-depletion / saturation of the
outbreak) and modulated by the log of the susceptible-deviation proxy z_t.
Only the five coefficients c0..c4 are re-estimated per cluster; they are all
obtained by ordinary least squares from one cluster's rows.

The form is completely linear in its parameters, so per-cluster calibration
is a single robust least-squares solve.
"""
import numpy as np

USED_INPUTS = ["cases_prev", "biweek", "z_t"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {
    "c0": {"init": None},
    "c1": {"init": None},
    "c2": {"init": None},
    "c3": {"init": None},
    "c4": {"init": None},
}


def _design(cases_prev, biweek, z_t):
    th = 2.0 * np.pi * np.asarray(biweek, dtype=float) / 26.0
    return np.column_stack([
        np.ones_like(th),
        np.sin(th),
        np.cos(th),
        np.log(np.asarray(cases_prev, dtype=float) + 1.0),
        np.log(np.asarray(z_t, dtype=float) + 1.0),
    ])


def fit(X_fit, y_fit):
    X_fit = np.asarray(X_fit, dtype=float)
    y_fit = np.asarray(y_fit, dtype=float).ravel()
    cp, s, z = X_fit[:, 0], X_fit[:, 1], X_fit[:, 2]
    A = _design(cp, s, z)
    # plain least squares with a mean fallback
    try:
        coef, _, _, _ = np.linalg.lstsq(A, y_fit, rcond=None)
        if not np.all(np.isfinite(coef)):
            raise ValueError
    except Exception:
        coef = np.zeros(5)
        coef[0] = float(np.mean(y_fit)) if y_fit.size else 0.0
    return {
        "c0": float(coef[0]),
        "c1": float(coef[1]),
        "c2": float(coef[2]),
        "c3": float(coef[3]),
        "c4": float(coef[4]),
    }


def predict(X, c0, c1, c2, c3, c4):
    X = np.asarray(X, dtype=float)
    cp, s, z = X[:, 0], X[:, 1], X[:, 2]
    th = 2.0 * np.pi * s / 26.0
    g = (c0
         + c1 * np.sin(th)
         + c2 * np.cos(th)
         + c3 * np.log(cp + 1.0)
         + c4 * np.log(z + 1.0))
    return g