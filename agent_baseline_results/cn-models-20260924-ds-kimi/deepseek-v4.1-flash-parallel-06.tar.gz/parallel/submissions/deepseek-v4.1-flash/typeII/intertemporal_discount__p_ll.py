"""Hyperbolic-discounting value model with logistic choice.

Each option's subjective value is its reward discounted hyperbolically:
    U(t, V) = V / (1 + k t)
The probability of choosing the larger-later option is a softmax over the
difference of subjective values:
    p_LL = 1 / (1 + exp(-beta * (U_LL - U_SS)))

The functional shape is shared by every cluster; only the two parameters
(beta: choice sensitivity, k: discount rate) are re-fit per cluster.
"""
import numpy as np
from scipy.optimize import least_squares

USED_INPUTS = ["ss_time_days", "ll_time_days", "ss_value", "ll_value"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {"beta": {"init": None}, "k": {"init": None}}


def _sig(z):
    return 1.0 / (1.0 + np.exp(-np.clip(z, -500.0, 500.0)))


def _pred(X, beta, k):
    t_ss = X[:, 0]
    t_ll = X[:, 1]
    V_ss = X[:, 2]
    V_ll = X[:, 3]
    U_ss = V_ss / (1.0 + k * t_ss)
    U_ll = V_ll / (1.0 + k * t_ll)
    return _sig(beta * (U_ll - U_ss))


def fit(X_fit, y_fit):
    X_fit = np.asarray(X_fit, dtype=float)
    y_fit = np.asarray(y_fit, dtype=float)
    span = float(np.max(y_fit) - np.min(y_fit)) if y_fit.size else 1.0
    # sensible starting scale for beta from the spread of discounted differences
    V_ll = X_fit[:, 3]
    V_ss = X_fit[:, 2]
    du = np.abs(V_ll - V_ss)
    scale = float(np.median(du[du > 0])) if np.any(du > 0) else 1.0
    beta0 = max(2.0 / max(scale, 1e-6), 1e-4)

    def resid(p):
        return _pred(X_fit, p[0], p[1]) - y_fit

    best = None
    for k0 in (1e-4, 1e-3, 1e-2, 1e-1):
        try:
            r = least_squares(resid, [beta0, k0],
                              bounds=([1e-8, 1e-12], [1e6, 10.0]),
                              max_nfev=2000)
            rmse = float(np.sqrt(np.mean(r.fun ** 2)))
            if best is None or rmse < best[0]:
                best = (rmse, r.x)
        except Exception:
            continue
    if best is None:
        return {"beta": beta0, "k": 1e-3}
    return {"beta": float(best[1][0]), "k": float(best[1][1])}


def predict(X, beta, k):
    X = np.asarray(X, dtype=float)
    return _pred(X, beta, k)