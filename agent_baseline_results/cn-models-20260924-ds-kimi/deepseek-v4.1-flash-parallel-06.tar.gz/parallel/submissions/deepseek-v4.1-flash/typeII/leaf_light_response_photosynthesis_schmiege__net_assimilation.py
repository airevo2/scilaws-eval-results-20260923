"""Non-rectangular hyperbola (NRH) light-response curve for leaf photosynthesis.

A_n(Q) = [ alpha*Q + Amax - sqrt((alpha*Q + Amax)^2 - 4*theta*alpha*Q*Amax) ] / (2*theta) - Rd

alpha  : initial quantum yield (slope at low light)
Amax   : light-saturated gross assimilation asymptote
theta  : dimensionless curvature / convexity factor (0..1)
Rd     : dark respiration (positive number; A_n(Q=0) = -Rd)

All four are per-cluster parameters; the functional form is shared.
"""
import numpy as np
from scipy.optimize import least_squares

USED_INPUTS = ["Qin"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {
    "alpha": {"init": None},
    "Amax": {"init": None},
    "theta": {"init": None},
    "Rd": {"init": None},
}


def _nrh(Q, alpha, Amax, theta, Rd):
    Q = np.asarray(Q, dtype=float)
    theta = np.clip(theta, 1e-6, 1.0)
    s = alpha * Q + Amax
    disc = s * s - 4.0 * theta * alpha * Q * Amax
    disc = np.maximum(disc, 0.0)
    return (s - np.sqrt(disc)) / (2.0 * theta) - Rd


def _resid(par, Q, A):
    return _nrh(Q, par[0], par[1], par[2], par[3]) - A


def fit(X_fit, y_fit):
    Q = np.asarray(X_fit[:, 0], dtype=float)
    A = np.asarray(y_fit, dtype=float)

    # Robust initialisation from the data itself.
    Rd0 = max(-float(np.min(A)), 1e-3)          # A(0) approx -Rd
    Amax0 = max(float(np.max(A)) + Rd0, 1.0)    # asymptote above Rd
    # slope at low light from the steepest early segment
    order = np.argsort(Q)
    Qs, As = Q[order], A[order]
    lo = Qs <= np.percentile(Qs, 40)
    alpha0 = 0.05
    if np.sum(lo) >= 2:
        q_lo, a_lo = Qs[lo], As[lo]
        denom = (q_lo[-1] - q_lo[0])
        if denom > 0:
            slope = (a_lo[-1] - a_lo[0]) / denom
            if slope > 0:
                alpha0 = float(np.clip(slope, 1e-4, 1.0))

    p0 = [alpha0, Amax0, 0.6, Rd0]
    lb = [1e-5, 1e-3, 1e-4, 0.0]
    ub = [2.0, 1e3, 1.0, 1e3]

    try:
        sol = least_squares(_resid, p0, args=(Q, A), bounds=(lb, ub),
                            max_nfev=2000)
        p = sol.x
    except Exception:
        p = p0

    return {"alpha": float(p[0]), "Amax": float(p[1]),
            "theta": float(p[2]), "Rd": float(p[3])}


def predict(X, alpha, Amax, theta, Rd):
    return _nrh(X[:, 0], alpha, Amax, theta, Rd)