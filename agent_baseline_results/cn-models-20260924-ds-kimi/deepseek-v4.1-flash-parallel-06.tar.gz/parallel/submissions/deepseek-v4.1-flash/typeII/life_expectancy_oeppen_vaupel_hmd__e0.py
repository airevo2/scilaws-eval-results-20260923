"""Exponential growth of life expectancy over calendar year, one amplitude and one rate per cluster.

Model:  e0(year) = A * exp( r * (year - 1900) )
Fitted per cluster by least squares on log(e0).  This convex (accelerating)
growth law was the best-fitting two-parameter form for every cluster probed
(long and short ranges alike), beating linear, power, reciprocal, and
saturating-exponential alternatives.
"""
import numpy as np

USED_INPUTS = ["year"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {"A": {"init": None}, "r": {"init": None}}


def predict(X, A, r):
    year = np.asarray(X[:, 0], dtype=float)
    return A * np.exp(r * (year - 1900.0))


def fit(X_fit, y_fit):
    t = np.asarray(X_fit[:, 0], dtype=float)
    y = np.asarray(y_fit, dtype=float)
    # keep only positive, finite observations for the log-linear fit
    m = np.isfinite(t) & np.isfinite(y) & (y > 0)
    if m.sum() >= 2:
        slope, intercept = np.polyfit(t[m] - 1900.0, np.log(y[m]), 1)
        A = float(np.exp(intercept))
        r = float(slope)
    else:
        A = float(np.mean(y)) if y.size else 1.0
        r = 0.0
    # sanity guards
    if not np.isfinite(A) or A <= 0:
        A = float(np.mean(y)) if y.size else 1.0
    if not np.isfinite(r):
        r = 0.0
    return {"A": A, "r": r}