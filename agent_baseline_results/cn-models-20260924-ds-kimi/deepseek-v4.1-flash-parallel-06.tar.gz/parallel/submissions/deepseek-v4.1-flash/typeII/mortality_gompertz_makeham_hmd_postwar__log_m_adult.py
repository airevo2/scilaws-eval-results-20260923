"""Gompertz-Makeham law of adult mortality: m(x) = A*exp(B*x) + C, so
ln m = ln(A*exp(B*x) + C). A and B are the Gompertz (senescent) parameters
and C is the age-independent Makeham background term; all three are re-fit
per cluster (country-calendar-year)."""
import numpy as np
from scipy.optimize import curve_fit

USED_INPUTS = ["age"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {"A": {"init": None}, "B": {"init": None}, "C": {"init": None}}


def _form(x, A, B, C):
    return np.log(A * np.exp(B * x) + C)


def fit(X_fit, y_fit):
    x = np.asarray(X_fit[:, 0], dtype=float)
    y = np.asarray(y_fit, dtype=float)
    # fallback: linear Gompertz ln m = a + b x  -> A=exp(a), B=b, C tiny
    A_l, B_l = 1e-5, 0.09
    try:
        lin = np.vstack([np.ones_like(x), x]).T
        c, *_ = np.linalg.lstsq(lin, y, rcond=None)
        A_l = float(np.exp(c[0]))
        B_l = float(c[1])
    except Exception:
        pass
    A0 = min(max(A_l, 1e-8), 1.0)
    B0 = min(max(B_l, 1e-4), 1.0)
    C0 = A0 * np.exp(B0 * np.min(x)) * 0.1
    C0 = max(C0, 1e-8)
    try:
        popt, _ = curve_fit(
            _form, x, y, p0=[A0, B0, C0],
            bounds=([1e-12, 1e-6, 0.0], [1.0, 1.0, 1.0]),
            maxfev=20000,
        )
        return {"A": float(popt[0]), "B": float(popt[1]), "C": float(popt[2])}
    except Exception:
        return {"A": A0, "B": B0, "C": C0}


def predict(X, A, B, C):
    x = np.asarray(X[:, 0], dtype=float)
    return np.log(A * np.exp(B * x) + C)