"""Incompressible Fung-type exponential membrane, plane-stress Cauchy stress in direction 2.

Strain energy density W = c * exp(Q) - 1 with a quadratic (Fung) exponent in the
incompressible Green strains.  With incompressibility the out-of-plane stretch is
lambda3 = 1/(lambda1*lambda2), so

  sigma22 = lambda2^2 * dW/dE22 - lambda3^2 * dW/dE33

which is the standard biaxial membrane expression.  The exponent keeps the
dominant couplings; c and the four modulus-like coefficients are re-fit per specimen
(cluster).
"""
import numpy as np
from scipy.optimize import least_squares

USED_INPUTS = ["lambda11", "lambda22"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {"c": {"init": None}, "A2": {"init": None},
                  "A3": {"init": None}, "A4": {"init": None},
                  "A6": {"init": None}}


def _stress(X, c, A2, A3, A4, A6):
    l1 = X[:, 0]
    l2 = X[:, 1]
    E11 = 0.5 * (l1 ** 2 - 1.0)
    E22 = 0.5 * (l2 ** 2 - 1.0)
    l3 = 1.0 / (l1 * l2)
    E33 = 0.5 * (l3 ** 2 - 1.0)

    Q = (A2 * E22 ** 2 + A3 * E33 ** 2
         + 2.0 * A4 * E11 * E22 + 2.0 * A6 * E22 * E33)
    e = c * np.exp(Q)

    dQdE22 = 2.0 * A2 * E22 + 2.0 * A4 * E11 + 2.0 * A6 * E33
    dQdE33 = 2.0 * A3 * E33 + 2.0 * A6 * E22

    return l2 ** 2 * e * dQdE22 - l3 ** 2 * e * dQdE33


def fit(X_fit, y_fit):
    l1 = X_fit[:, 0]
    l2 = X_fit[:, 1]
    E11 = 0.5 * (l1 ** 2 - 1.0)
    E22 = 0.5 * (l2 ** 2 - 1.0)

    best = None
    for p0 in ([2e-4, 20.0, 84.0, 11.5, 31.7],
               [1e-3, 8.0, 20.0, 3.0, 8.0],
               [5e-4, 25.0, 50.0, 20.0, 20.0]):
        try:
            r = least_squares(
                lambda p: _stress(X_fit, *p) - y_fit, p0, max_nfev=4000)
            if best is None or np.sum(r.fun ** 2) < best[0]:
                best = (np.sum(r.fun ** 2), r.x)
        except Exception:
            continue
    if best is None:
        return {"c": 1e-3, "A2": 10.0, "A3": 20.0, "A4": 5.0, "A6": 10.0}
    p = best[1]
    return {"c": float(p[0]), "A2": float(p[1]), "A3": float(p[2]),
            "A4": float(p[3]), "A6": float(p[4])}


def predict(X, c, A2, A3, A4, A6):
    return _stress(np.asarray(X, dtype=float), c, A2, A3, A4, A6)