"""Heligman-Pollard mortality law applied to log central death rate (3-term
competing-hazards form): an infant term A^((x)^C), a young/mid-life log-normal
'accident hump' term D*exp(-E*(ln(x/F))^2), and a Gompertz old-age term G*H^x.
The shared mechanism is ln(m) = ln( sum of the three terms ); only the seven
term coefficients are re-fit per cluster (B fixed to 0, which the data support)."""
import numpy as np
from scipy.optimize import curve_fit

USED_INPUTS = ["age"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {
    "A": {"init": None},
    "C": {"init": None},
    "D": {"init": None},
    "E": {"init": None},
    "F": {"init": None},
    "G": {"init": None},
    "H": {"init": None},
}

def _mu(x, A, C, D, E, F, G, H):
    xm = np.maximum(x, 0.5)
    infant = A ** (xm ** C)
    hump = D * np.exp(-E * (np.log(xm / F)) ** 2)
    gompertz = G * (H ** xm)
    return infant + hump + gompertz

def _logmu(x, A, C, D, E, F, G, H):
    m = _mu(x, A, C, D, E, F, G, H)
    return np.log(np.maximum(m, 1e-12))

def fit(X_fit, y_fit):
    x = np.asarray(X_fit[:, 0], dtype=float)
    y = np.asarray(y_fit, dtype=float).ravel()
    # typical magnitudes from mortality tables
    p0 = [1.0e-3, 0.15, 6.0e-4, 8.0, 22.0, 3.0e-5, 1.10]
    lo = [1e-12, 1e-3, 1e-9, 0.1, 1.0, 1e-12, 1.0]
    hi = [1.0, 1.0, 1.0, 50.0, 80.0, 1.0, 2.0]
    try:
        popt, _ = curve_fit(_logmu, x, y, p0=p0, bounds=(lo, hi),
                            maxfev=20000)
        A, C, D, E, F, G, H = [float(v) for v in popt]
    except Exception:
        A, C, D, E, F, G, H = p0
    return {"A": A, "C": C, "D": D, "E": E, "F": F, "G": G, "H": H}

def predict(X, A, C, D, E, F, G, H):
    x = np.asarray(X[:, 0], dtype=float)
    return _logmu(x, A, C, D, E, F, G, H)