"""Toth heterogeneous-surface isotherm: q = qs * b*P / (1 + (b*P)^t)^(1/t).
Three per-cluster parameters (qs, b, t); the same mechanism for every cluster.
"""
import numpy as np
from scipy.optimize import curve_fit

USED_INPUTS = ["P_bar"]          # X[:, 0] = P_bar
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {"qs": {"init": None}, "b": {"init": None}, "t": {"init": None}}


def _toth(P, qs, b, t):
    x = b * P
    return qs * x / np.power(1.0 + np.power(x, t), 1.0 / t)


def fit(X_fit, y_fit):
    P = np.asarray(X_fit[:, 0], dtype=float).ravel()
    y = np.asarray(y_fit, dtype=float).ravel()
    qs0 = max(float(np.max(y)) * 1.05, 1e-3)

    best_err = None
    best_p = None
    for t0 in (0.7, 1.0, 1.5, 0.5, 2.0):
        for b0 in (1.0, 5.0, 0.3, 20.0):
            try:
                popt, _ = curve_fit(
                    _toth, P, y, p0=[qs0, b0, t0], maxfev=20000,
                    bounds=([0.0, 0.0, 0.05], [1e6, 1e8, 8.0]))
                err = float(np.sum((_toth(P, *popt) - y) ** 2))
                if best_err is None or err < best_err:
                    best_err = err
                    best_p = popt
            except Exception:
                continue

    if best_p is None:
        return {"qs": qs0, "b": 1.0, "t": 0.7}
    return {"qs": float(best_p[0]), "b": float(best_p[1]), "t": float(best_p[2])}


def predict(X, qs, b, t):
    P = np.asarray(X[:, 0], dtype=float).ravel()
    return _toth(P, qs, b, t)