"""Penman-Monteith latent heat flux with an exponentially VPD-limited surface conductance.

LE = [ Δ·(Rn − G) + a·Ga·VPD ] / [ Δ + b·(1 + Ga/Gs) ],   Gs = Gs0·exp(−VPD/V0)

Shared mechanism (identical algebraic form for every cluster):
  - denominator contains the psychrometric-type term b·(1 + Ga/Gs) = b·(1 + rs·Ga),
  - numerator contains the equilibrium term Δ·(Rn−G) and the aerodynamic term a·Ga·VPD,
  - surface conductance Gs decays exponentially with VPD (stomatal closure).
Only a, b, Gs0, V0 are re-fit per cluster.
"""
import numpy as np
from scipy.optimize import curve_fit

USED_INPUTS = ["SWdown", "VPD", "RH", "Rnet", "Qg", "Ga", "delta", "theta_FC"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {
    "a":   {"init": 1200.0},
    "b":   {"init": 0.07},
    "Gs0": {"init": 0.005},
    "V0":  {"init": 2.5},
}


def _pm(X, a, b, Gs0, V0):
    D = X[:, 6]      # delta
    VPD = X[:, 1]
    Rn = X[:, 3]
    G = X[:, 4]
    Ga = X[:, 5]
    Gs = Gs0 * np.exp(-VPD / V0)
    Gs = np.maximum(Gs, 1e-9)
    return (D * (Rn - G) + a * Ga * VPD) / (D + b * (1.0 + Ga / Gs))


def fit(X_fit, y_fit):
    X = np.asarray(X_fit, float)
    y = np.asarray(y_fit, float)
    p0 = [1200.0, 0.07, 0.005, 2.5]
    bounds = ([0.0, 1e-4, 1e-6, 1e-3], [1e6, 5.0, 5.0, 1e3])
    try:
        popt, _ = curve_fit(_pm, X, y, p0=p0, bounds=bounds, maxfev=20000)
        a, b, Gs0, V0 = [float(v) for v in popt]
    except Exception:
        a, b, Gs0, V0 = p0
    return {"a": a, "b": b, "Gs0": Gs0, "V0": V0}


def predict(X, a, b, Gs0, V0):
    X = np.asarray(X, float)
    return _pm(X, a, b, Gs0, V0)