"""Bethe-like electron-impact ionization form with threshold I:
sigma(E) = A * ln(E/I) / (E + b).  Per-cluster parameters A, I, b are re-fit;
one shared functional shape holds across all clusters."""
import numpy as np
from scipy.optimize import curve_fit

USED_INPUTS = ["electron_energy_eV"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {"A": {"init": None}, "I": {"init": None}, "b": {"init": None}}


def _form(E, A, I, b):
    E = np.clip(E, 1e-9, None)
    I = max(float(I), 1e-6)
    core = np.log(np.clip(E / I, 1e-12, None))
    return A * core / (E + b)


def fit(X_fit, y_fit):
    E = np.asarray(X_fit[:, 0], dtype=float)
    y = np.asarray(y_fit, dtype=float)
    ymax = float(np.max(y)) if y.size else 1.0
    # threshold estimate: first energy where y reaches a few % of peak
    try:
        I0 = float(np.interp(0.02 * ymax, y, E))
    except Exception:
        I0 = float(np.min(E))
    p0 = [max(ymax * 5.0, 1.0), max(I0, 1.0), 50.0]
    try:
        popt, _ = curve_fit(_form, E, y, p0=p0, maxfev=10000)
        A, I, b = popt
        if not np.all(np.isfinite([A, I, b])):
            raise ValueError
        return {"A": float(A), "I": float(I), "b": float(b)}
    except Exception:
        return {"A": float(p0[0]), "I": float(p0[1]), "b": float(p0[2])}


def predict(X, A, I, b):
    return _form(np.asarray(X[:, 0], dtype=float), A, I, b)