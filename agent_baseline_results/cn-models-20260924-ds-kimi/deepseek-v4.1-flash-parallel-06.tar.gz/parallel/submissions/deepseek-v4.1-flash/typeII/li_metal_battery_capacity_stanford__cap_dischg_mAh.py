"""Capacity fade follows a Hill/saturating decline Q(k) = Q0 / (1 + (k/k0)^p)."""
import numpy as np
from scipy.optimize import curve_fit

USED_INPUTS = ["cycle_index"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {"Q0": {"init": None}, "k0": {"init": None}, "p": {"init": None}}


def _form(k, Q0, k0, p):
    return Q0 / (1.0 + np.power(k / k0, p))


def fit(X_fit, y_fit):
    k = np.asarray(X_fit[:, 0], dtype=float)
    y = np.asarray(y_fit, dtype=float)
    m = k > 0
    k = k[m]
    y = y[m]
    Q0_0 = max(float(np.max(y)), 1e-6)
    p0 = [Q0_0, max(0.5 * float(np.max(k)), 1.0), 1.3]
    bounds = ([0.0, 1e-6, 0.1], [np.inf, np.inf, 5.0])
    try:
        popt, _ = curve_fit(_form, k, y, p0=p0, bounds=bounds, maxfev=10000)
        return {"Q0": float(popt[0]), "k0": float(popt[1]), "p": float(popt[2])}
    except Exception:
        return {"Q0": p0[0], "k0": p0[1], "p": p0[2]}


def predict(X, Q0, k0, p):
    k = np.asarray(X[:, 0], dtype=float)
    k = np.where(k > 0, k, 1.0)
    return Q0 / (1.0 + np.power(k / k0, p))