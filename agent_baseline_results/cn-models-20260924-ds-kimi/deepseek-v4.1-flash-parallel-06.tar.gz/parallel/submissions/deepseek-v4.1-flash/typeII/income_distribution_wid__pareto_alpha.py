"""Upper-tail income share as a power law in the top fraction:
ln S(p) = a + b * ln p  (equivalently S(p) = exp(a) * p**b).
Each cluster has its own power-law level a and exponent b; the log-log
linear structure is shared by every cluster."""
import numpy as np

USED_INPUTS = ["log_p_above"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {"a": {"init": None}, "b": {"init": None}}


def _form(x, a, b):
    return a + b * x


def fit(X_fit, y_fit):
    x = np.asarray(X_fit[:, 0], dtype=float)
    y = np.asarray(y_fit, dtype=float)
    # Ordinary least squares for the affine log-log law.
    n = x.size
    sx = np.sum(x)
    sy = np.sum(y)
    sxx = np.sum(x * x)
    sxy = np.sum(x * y)
    denom = n * sxx - sx * sx
    if abs(denom) < 1e-12:
        b = 0.0
        a = sy / n if n else 0.0
    else:
        b = (n * sxy - sx * sy) / denom
        a = (sy - b * sx) / n
    if not np.isfinite(a):
        a = 0.0
    if not np.isfinite(b):
        b = 0.0
    return {"a": float(a), "b": float(b)}


def predict(X, a, b):
    x = np.asarray(X[:, 0], dtype=float)
    return a + b * x