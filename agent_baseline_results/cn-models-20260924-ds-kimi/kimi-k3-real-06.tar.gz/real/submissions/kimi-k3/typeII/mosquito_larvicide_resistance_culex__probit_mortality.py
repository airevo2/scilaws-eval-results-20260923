"""Finney probit dose-response with Abbott-style upper asymptote, fit per cluster.
P = Fmax * Phi(slope * (log10_conc_ppb - logLC50)); monotone, bounded in [0,1]."""
import numpy as np
from scipy.optimize import curve_fit
from scipy.stats import norm

USED_INPUTS = ["log10_conc_ppb"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {
    "logLC50": {"init": None},
    "slope": {"init": None},
    "Fmax": {"init": None},
}

def _form(x, m, s, F):
    return F * norm.cdf(np.clip(s * (x - m), -8.0, 8.0))

def fit(X_fit, y_fit):
    x = np.asarray(X_fit[:, 0], dtype=float)
    y = np.asarray(y_fit, dtype=float)
    if x.size == 0:
        return {"logLC50": 1.5, "slope": 1.5, "Fmax": 1.0}
    lo = float(np.min(x)); hi = float(np.max(x)); med = float(np.median(x))
    if hi - lo < 1e-9:
        off = -1.0 if float(np.mean(y)) > 0.5 else 1.0
        return {"logLC50": lo + off, "slope": 2.0, "Fmax": 1.0}
    bounds = ([lo - 3.0, 0.1, 0.4], [hi + 3.0, 40.0, 1.0])
    starts = [[med, 1.5, 1.0], [med, 3.0, 1.0],
              [lo + 0.3 * (hi - lo), 1.0, 1.0],
              [lo + 0.7 * (hi - lo), 2.0, 1.0],
              [med, 1.5, 0.9]]
    best = None
    for p0 in starts:
        try:
            p, _ = curve_fit(_form, x, y, p0=p0, bounds=bounds, maxfev=2500)
            # binomial-style weighted refit for stability on replicate data
            pr = np.clip(_form(x, *p), 1e-3, 1.0 - 1e-3)
            sig = np.sqrt(pr * (1.0 - pr)) + 0.05
            p, _ = curve_fit(_form, x, y, p0=p, bounds=bounds, sigma=sig, maxfev=2500)
            r = float(np.sum((_form(x, *p) - y) ** 2))
            if best is None or r < best[0]:
                best = (r, p)
        except Exception:
            continue
    if best is None:
        return {"logLC50": med, "slope": 1.5, "Fmax": 1.0}
    p = best[1]
    return {"logLC50": float(p[0]), "slope": float(p[1]), "Fmax": float(p[2])}

def predict(X, logLC50, slope, Fmax):
    x = np.asarray(X[:, 0], dtype=float)
    return np.clip(_form(x, logLC50, slope, Fmax), 0.0, 1.0)