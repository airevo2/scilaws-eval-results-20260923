"""Logistic (softmax) intertemporal-choice rule: the probability of choosing the
larger-later option is a sigmoid of a linear index in the log amount ratio and the
log delay difference, p_ll = logistic(a + b*ln(V_LL/V_SS) + c*log1p(Delta_t)).
The log1p delay transform mimics hyperbolic discounting (diminishing sensitivity to
longer delays). Per cluster, (a,b,c) are re-fit by regularized logistic least
squares that shrink lightly toward the init (an empirical-Bayes prior over subjects),
and the amount-ratio slope b is constrained non-negative (more reward never lowers
preference for the larger-later option). Sensible on extrapolation: monotone in both
inputs, bounded in [0,1]."""
import numpy as np
from scipy.optimize import least_squares

USED_INPUTS = ["log_amount_ratio", "delay_diff_days"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {
    "a": {"init": 0.76},    # baseline preference / bias
    "b": {"init": 1.16},    # sensitivity to log amount ratio (>= 0)
    "c": {"init": -0.35},   # sensitivity to log delay difference (<= 0)
}

def _index(X):
    lar = np.asarray(X[:, 0], dtype=float)
    dt = np.clip(np.asarray(X[:, 3], dtype=float), 0.0, None)
    return lar, np.log1p(dt)

def _sigmoid(z):
    return 1.0 / (1.0 + np.exp(-np.clip(z, -30.0, 30.0)))

def fit(X_fit, y_fit):
    a0 = float(LOCAL_FITTABLE["a"]["init"])
    b0 = float(LOCAL_FITTABLE["b"]["init"])
    c0 = float(LOCAL_FITTABLE["c"]["init"])
    try:
        lar, ldt = _index(X_fit)
        y = np.asarray(y_fit, dtype=float)

        def resid(p):
            a, b, c = p
            m = _sigmoid(a + b * lar + c * ldt)
            # mild generic shrinkage toward init (delay slope most conserved,
            # baseline preference most subject-specific)
            pen = np.array([0.10 * (a - a0), 0.10 * (b - b0), 0.35 * (c - c0)])
            return np.concatenate([m - y, pen])

        sol = least_squares(resid, [a0, b0, c0], max_nfev=2000)
        a, b, c = (float(v) for v in sol.x)
        b = max(b, 0.0)  # larger reward share should not reduce P(larger-later)
        return {"a": a, "b": b, "c": c}
    except Exception:
        return {"a": a0, "b": b0, "c": c0}

def predict(X, a, b, c):
    lar, ldt = _index(X)
    return _sigmoid(a + b * lar + c * ldt)