"""Per-cluster capacity-fade law: Q(k) = Qs - a1*k - a2*k^2 (cycle-count polynomial fade,
two cluster-specific fade rates plus initial capacity). Captures linear loss and
super-linear late-life knee; fit per cluster by least squares on the cluster's window."""
import numpy as np
from scipy.optimize import least_squares

USED_INPUTS = ["cycle_index"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {"Qs": {"init": None}, "a1": {"init": None}, "a2": {"init": None}}

def _form(k, Qs, a1, a2):
    return Qs - a1*k - a2*np.power(k, 2.0)

def fit(X_fit, y_fit):
    k = np.asarray(X_fit[:, 0], dtype=float)
    y = np.asarray(y_fit, dtype=float)
    ymax = float(np.max(y)) if y.size else 1.0
    if ymax <= 0:
        ymax = 1.0
    # data-driven init: polynomial lstsq, then bounded refinement
    p0 = np.array([ymax*1.01, 1e-4*ymax, 1e-7*ymax], dtype=float)
    lb = np.array([0.0, 0.0, 0.0])
    ub = np.array([5.0*ymax, 1e1*ymax, 1e1*ymax])
    try:
        sol = least_squares(lambda p: _form(k, *p) - y, p0, bounds=(lb, ub), max_nfev=4000)
        Qs, a1, a2 = sol.x
    except Exception:
        Qs, a1, a2 = p0
    # numerical safety / fallbacks
    if not np.isfinite(Qs) or Qs <= 0:
        Qs = ymax
    if not np.isfinite(a1) or a1 < 0:
        a1 = 0.0
    if not np.isfinite(a2) or a2 < 0:
        a2 = 0.0
    return {"Qs": float(Qs), "a1": float(a1), "a2": float(a2)}

def predict(X, Qs, a1, a2):
    k = np.asarray(X[:, 0], dtype=float)
    y = _form(k, Qs, a1, a2)
    # keep physically sensible (non-negative) on extrapolation
    return np.maximum(y, 0.0)