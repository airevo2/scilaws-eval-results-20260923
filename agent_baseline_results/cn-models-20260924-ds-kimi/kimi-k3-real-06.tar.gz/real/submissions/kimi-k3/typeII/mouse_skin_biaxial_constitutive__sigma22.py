"""Generalized Fung exponential in Green strains: sigma22 = a*(exp(b*e2 + c*e1 + d*e1*e2 + f*e2^2) - 1),
with e1 = lambda11^2 - 1, e2 = lambda22^2 - 1. Coefficients are fit per cluster and constrained
non-negative so the response is monotone and stays physically sane (no sign flips / blow-ups)
when extrapolated beyond the fit window."""
import numpy as np
from scipy.optimize import least_squares

USED_INPUTS = ["lambda11", "lambda22"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {
    "a": {"init": [1e-3, 1e-2, 1e-4, 1e-1]},
    "b": {"init": [5.0, 10.0, 2.0, 20.0]},
    "c": {"init": [2.0, 5.0, 0.5, 10.0]},
    "d": {"init": [0.0, 1.0, 5.0, 10.0]},
    "f": {"init": [0.0, 1.0, 3.0, 8.0]},
}

_BOUNDS_LO = np.array([1e-9, 0.0, 0.0, 0.0, 0.0])
_BOUNDS_HI = np.array([50.0, 80.0, 80.0, 80.0, 80.0])

def _form(X, p):
    a, b, c, d, f = p
    l1 = X[:, 0]; l2 = X[:, 1]
    e1 = l1 * l1 - 1.0
    e2 = l2 * l2 - 1.0
    E = b * e2 + c * e1 + d * e1 * e2 + f * e2 * e2
    E = np.clip(E, -50.0, 50.0)
    return a * (np.exp(E) - 1.0)

def fit(X_fit, y_fit):
    X_fit = np.asarray(X_fit, dtype=float)
    y_fit = np.asarray(y_fit, dtype=float)
    starts = [
        np.array([1e-3, 5.0, 2.0, 0.0, 0.0]),
        np.array([1e-3, 10.0, 5.0, 0.0, 0.0]),
        np.array([1e-2, 5.0, 2.0, 1.0, 1.0]),
    ]
    best = None
    best_cost = np.inf
    for p0 in starts:
        p0 = np.clip(p0, _BOUNDS_LO, _BOUNDS_HI)
        try:
            r = least_squares(
                lambda p: _form(X_fit, p) - y_fit,
                p0, bounds=(_BOUNDS_LO, _BOUNDS_HI), max_nfev=3000,
            )
            cost = float(np.sum(r.fun ** 2))
            if np.all(np.isfinite(r.x)) and cost < best_cost:
                best_cost = cost
                best = r.x
        except Exception:
            continue
    if best is None:
        # Guaranteed-stable fallback: simple axial exponential.
        best = np.array([1e-3, 5.0, 0.0, 0.0, 0.0])
        try:
            r = least_squares(
                lambda p: _form(X_fit, [p[0], p[1], 0.0, 0.0, 0.0]) - y_fit,
                [1e-3, 5.0], bounds=([1e-9, 0.0], [50.0, 80.0]), max_nfev=2000,
            )
            best = np.array([r.x[0], r.x[1], 0.0, 0.0, 0.0])
        except Exception:
            pass
    return {"a": float(best[0]), "b": float(best[1]), "c": float(best[2]),
            "d": float(best[3]), "f": float(best[4])}

def predict(X, a, b, c, d, f):
    X = np.asarray(X, dtype=float)
    y = _form(X, np.array([a, b, c, d, f], dtype=float))
    return np.nan_to_num(y, nan=0.0, posinf=0.0, neginf=0.0)