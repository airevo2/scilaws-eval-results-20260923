"""Piecewise-linear (hinge at log=1) mean-reversion of the biweekly log growth rate
on the previous interval's log case count: g = a + b_lo*min(log(I_prev+1),1) + b_hi*max(log(I_prev+1)-1,0).
Captures the strong fadeout-driven growth at very low prevalence (I_prev ~ 0-1) and the
weaker mean reversion at higher prevalence; all three coefficients are re-fit per city."""
import numpy as np

USED_INPUTS = ["cases_prev"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {
    "a": {"init": None},
    "b_lo": {"init": None},
    "b_hi": {"init": None},
}

def _design(I_prev):
    l = np.log(np.maximum(I_prev, 0.0) + 1.0)
    return np.column_stack([np.ones_like(l), np.minimum(l, 1.0), np.maximum(l - 1.0, 0.0)])

def fit(X_fit, y_fit):
    I_prev = np.asarray(X_fit[:, 0], dtype=float)
    y = np.asarray(y_fit, dtype=float)
    Xd = _design(I_prev)
    # lightly regularized least squares, robust to tiny/degenerate fit windows
    ridge = 1e-3
    A = Xd.T @ Xd + ridge * np.eye(3)
    A[0, 0] -= ridge
    try:
        beta = np.linalg.solve(A, Xd.T @ y)
        if not np.all(np.isfinite(beta)):
            raise ValueError
    except Exception:
        beta = np.array([float(np.mean(y)) if len(y) else 0.0, 0.0, 0.0])
    return {"a": float(beta[0]), "b_lo": float(beta[1]), "b_hi": float(beta[2])}

def predict(X, a, b_lo, b_hi):
    I_prev = np.asarray(X[:, 0], dtype=float)
    l = np.log(np.maximum(I_prev, 0.0) + 1.0)
    y = a + b_lo * np.minimum(l, 1.0) + b_hi * np.maximum(l - 1.0, 0.0)
    return np.asarray(y, dtype=float)