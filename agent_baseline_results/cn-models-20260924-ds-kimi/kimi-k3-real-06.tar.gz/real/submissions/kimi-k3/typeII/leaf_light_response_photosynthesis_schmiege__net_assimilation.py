"""Non-rectangular hyperbola (NRH) light-response model: A_n(Qin) = (phi*Qin + Amax - sqrt((phi*Qin + Amax)^2 - 4*theta*phi*Qin*Amax)) / (2*theta) - Rd, with per-cluster quantum yield phi, light-saturated gross assimilation Amax, convexity theta, and dark respiration Rd."""
import numpy as np
from scipy.optimize import curve_fit

USED_INPUTS = ["Qin"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {
    "phi": {"init": None},
    "Amax": {"init": None},
    "theta": {"init": None},
    "Rd": {"init": None},
}

def _form(Q, phi, Amax, theta, Rd):
    Q = np.asarray(Q, dtype=float)
    s = phi * Q + Amax
    disc = np.maximum(s * s - 4.0 * theta * phi * Q * Amax, 0.0)
    return (s - np.sqrt(disc)) / (2.0 * theta) - Rd

def fit(X_fit, y_fit):
    Q = np.asarray(X_fit[:, 0], dtype=float)
    y = np.asarray(y_fit, dtype=float)
    ymax = max(float(np.max(y)), 0.5)
    amax_hi = 2.5 * ymax + 2.0
    starts = [[0.05, 1.0, 0.7, 0.5], [0.03, 1.2, 0.85, 1.0],
              [0.08, 1.0, 0.5, 0.3], [0.02, 1.5, 0.95, 0.2],
              [0.06, 0.9, 0.3, 0.8], [0.04, 2.0, 0.7, 0.4]]
    best, bcost = None, np.inf
    for p0 in starts:
        p0 = [p0[0], min(p0[1] * ymax, 0.9 * amax_hi), p0[2], p0[3]]
        try:
            popt, _ = curve_fit(_form, Q, y, p0=p0,
                                bounds=([1e-4, 0.0, 0.3, 0.0],
                                        [0.3, amax_hi, 0.999, 5.0]),
                                maxfev=8000)
            cost = float(np.sum((_form(Q, *popt) - y) ** 2))
            if cost < bcost and np.all(np.isfinite(popt)):
                bcost, best = cost, popt
        except Exception:
            continue
    if best is None:
        best = np.array([0.05, ymax, 0.7, 0.5])
    return {"phi": float(best[0]), "Amax": float(best[1]),
            "theta": float(best[2]), "Rd": float(best[3])}

def predict(X, phi, Amax, theta, Rd):
    theta = min(max(float(theta), 1e-3), 0.999)
    return _form(X[:, 0], phi, Amax, theta, Rd)