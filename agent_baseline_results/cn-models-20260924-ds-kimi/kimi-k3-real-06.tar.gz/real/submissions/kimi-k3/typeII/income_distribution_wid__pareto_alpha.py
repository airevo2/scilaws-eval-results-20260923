"""Log top-income-share: quadratic in ln p with a per-cluster slope drift over time.

ln S(p,t) = a0 + a1*lnp + a2*lnp^2 + a3*lnp*(t-2000)/20

The quadratic in ln p captures the Pareto-type tail shape (share curve),
while the final term lets the tail slope drift slowly with year (rising/falling
concentration). Four parameters fit per cluster by least squares.
"""
import numpy as np

USED_INPUTS = ["log_p_above", "top_pct", "year"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {
    "a0": {"init": None},
    "a1": {"init": None},
    "a2": {"init": None},
    "a3": {"init": None},
}

def _design(X):
    x = np.asarray(X[:, 0], dtype=float)
    t = (np.asarray(X[:, 2], dtype=float) - 2000.0) / 20.0
    return np.column_stack([np.ones_like(x), x, x * x, x * t])

def fit(X_fit, y_fit):
    X_fit = np.asarray(X_fit, dtype=float)
    y_fit = np.asarray(y_fit, dtype=float)
    try:
        A = _design(X_fit)
        beta, *_ = np.linalg.lstsq(A, y_fit, rcond=None)
        beta = np.asarray(beta, dtype=float)
        if not np.all(np.isfinite(beta)):
            raise ValueError
    except Exception:
        m = float(np.mean(y_fit)) if y_fit.size else -2.0
        beta = np.array([m, 0.45, 0.0, 0.0])
    return {"a0": float(beta[0]), "a1": float(beta[1]),
            "a2": float(beta[2]), "a3": float(beta[3])}

def predict(X, a0, a1, a2, a3):
    x = np.asarray(X[:, 0], dtype=float)
    t = (np.asarray(X[:, 2], dtype=float) - 2000.0) / 20.0
    return a0 + a1 * x + a2 * x * x + a3 * x * t