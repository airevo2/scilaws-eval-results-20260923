"""Penman-Monteith-combination form: LE = a*Eeq*(L/(L+b))*(1+h*(T-298.15)/25) + c*Ea + d,
with equilibrium term Eeq = delta*(Rnet-Qg)/(delta+0.066) and aerodynamic term
Ea = rho*cp*Ga*VPD/(delta+0.066); rho = P/(R_d*T) with P=101325 Pa (physical constants).
Five parameters (a, b, h, c, d) are refit per cluster by bounded nonlinear least squares."""
import numpy as np
from scipy.optimize import least_squares

USED_INPUTS = ["VPD", "Tair", "Rnet", "Qg", "LAI", "Ga", "delta"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {"gamma_kPa_per_K": 0.066, "P_Pa": 101325.0, "R_d": 287.05, "cp": 1004.0}
LOCAL_FITTABLE = {"a": {"init": 1.0}, "b": {"init": 2.0}, "h": {"init": 0.0}, "c": {"init": 0.3}, "d": {"init": 30.0}}

_GAMMA = 0.066
_P = 101325.0
_RD = 287.05
_CP = 1004.0

def _terms(X):
    VPD = X[:, 0]; T = X[:, 1]; Rn = X[:, 2]; G = X[:, 3]
    LAI = X[:, 4]; Ga = X[:, 5]; delta = X[:, 6]
    den = delta + _GAMMA
    rho = _P / (_RD * T)
    Eeq = delta * (Rn - G) / den
    Ea = rho * _CP * Ga * VPD / den
    return Eeq, Ea, LAI, T

def _model(X, p):
    a, b, h, c, d = p
    Eeq, Ea, LAI, T = _terms(X)
    Ts = (T - 298.15) / 25.0
    return a * Eeq * (LAI / (LAI + b)) * (1.0 + h * Ts) + c * Ea + d

def fit(X_fit, y_fit):
    x0 = [1.0, 2.0, 0.0, 0.3, 30.0]
    lb = [0.0, 0.05, -2.0, -3.0, -300.0]
    ub = [4.0, 30.0, 2.0, 3.0, 300.0]
    try:
        sol = least_squares(lambda p: _model(X_fit, p) - y_fit, x0=x0,
                            bounds=(lb, ub), max_nfev=600)
        p = sol.x
        if not np.all(np.isfinite(p)):
            raise ValueError
    except Exception:
        p = np.array(x0)
    return {"a": float(p[0]), "b": float(p[1]), "h": float(p[2]),
            "c": float(p[3]), "d": float(p[4])}

def predict(X, a, b, h, c, d):
    y = _model(X, np.array([a, b, h, c, d], dtype=float))
    return np.asarray(np.clip(y, 0.0, None), dtype=float)