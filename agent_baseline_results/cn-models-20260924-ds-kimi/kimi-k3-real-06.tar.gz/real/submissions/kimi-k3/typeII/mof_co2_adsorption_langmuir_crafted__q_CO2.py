"""Toth adsorption isotherm: q = q_sat * b*P / (1 + (b*P)^t)^(1/t).
Three per-cluster parameters (saturation capacity q_sat, affinity b,
heterogeneity t) refit per cluster; the functional form is shared by all.
Toth reduces to Langmuir at t=1 and to Henry's law (q ~ q_sat*b*P) at low P,
and saturates at q_sat at high P, so it extrapolates physically."""

import numpy as np
from scipy.optimize import least_squares

USED_INPUTS = ["P_bar"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {
    "q_sat": {"init": None},
    "b": {"init": None},
    "t": {"init": None},
}

def _toth(P, q_sat, b, t):
    P = np.asarray(P, dtype=float)
    bP = b * P
    return q_sat * bP / (1.0 + bP**t)**(1.0 / t)

def fit(X_fit, y_fit):
    P = np.asarray(X_fit[:, 0], dtype=float)
    y = np.asarray(y_fit, dtype=float)
    ymax = float(np.max(y)) if y.size else 1.0
    order = np.argsort(P)
    Ps, ys = P[order], y[order]
    # Henry-region slope -> initial affinity b0
    slope = ys[0] / max(Ps[0], 1e-12)
    if Ps.size >= 3:
        slope = max(slope, ys[1] / max(Ps[1], 1e-12))
    b0 = max(slope / max(ymax, 1e-6), 1e-6)
    q0 = max(ymax * 1.3, 0.3)
    lb0 = float(np.log(b0))
    lo = [max(ymax, 0.05), lb0 - 10.0, 0.05]
    hi = [max(ymax * 10.0, 5.0), lb0 + 10.0, 8.0]

    def resid(th):
        qm, lb, tt = th
        return _toth(P, qm, np.exp(lb), tt) - y

    f_scale = max(ymax * 0.05, 1e-3)
    best = None
    for t0 in (0.5, 1.0, 2.0):
        try:
            r = least_squares(resid, [q0, lb0, t0], bounds=(lo, hi),
                              loss="soft_l1", f_scale=f_scale, max_nfev=1500)
            ss = float(np.sum(r.fun**2))
            if best is None or ss < best[0]:
                qm, lb, tt = r.x
                best = (ss, (float(qm), float(np.exp(lb)), float(tt)))
        except Exception:
            pass
    if best is None:
        q_sat, b, t = q0, b0, 1.0
    else:
        q_sat, b, t = best[1]
    return {"q_sat": q_sat, "b": b, "t": t}

def predict(X, q_sat, b, t):
    y = _toth(np.asarray(X[:, 0], dtype=float), q_sat, b, t)
    return np.asarray(y, dtype=float)