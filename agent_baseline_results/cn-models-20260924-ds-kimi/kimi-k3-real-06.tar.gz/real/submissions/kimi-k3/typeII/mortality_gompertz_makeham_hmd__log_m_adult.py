"""Gompertz-Makeham-family log-mortality law for adult ages:
ln m(x,t) = a + b*(x-62.5) + c*(t-1980) + 5*b*((x-62.5)/40)^2.

A Gompertz line in age (level a, senescence slope b) plus a linear period
mortality-improvement term c, with an intrinsic U-shaped age curvature tied
to the Gompertz slope b (curvature = 5*b on the scaled quadratic). The tied
curvature captures the systematic deviation from log-linearity (excess at
young adult and oldest ages) without an extra free parameter, keeping the
per-cluster parameter count at 3. Fit per cluster by nonlinear least squares,
initialised from a fast linear Gompertz+time fit. Form is identical across
clusters; only (a, b, c) vary. Extrapolation is well-behaved: polynomial in
age, linear in year."""
import numpy as np
from scipy.optimize import least_squares

USED_INPUTS = ["age", "year"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {
    "a": {"init": -3.9},
    "b": {"init": 0.09},
    "c": {"init": -0.012},
}

_X0 = 62.5   # age centering (mid-range; structural)
_T0 = 1980.0  # year centering (structural)
_QR = 5.0     # curvature-to-slope ratio (structural part of the form)
_QS = 40.0    # quadratic age scaling (structural)

def _form(x, t, a, b, c):
    xc = x - _X0
    return a + b * xc + c * (t - _T0) + _QR * b * (xc / _QS) ** 2

def fit(X_fit, y_fit):
    x = np.asarray(X_fit[:, 0], dtype=float)
    t = np.asarray(X_fit[:, 1], dtype=float)
    y = np.asarray(y_fit, dtype=float)
    # Fast linear Gompertz + time fit for initialisation.
    p0 = [-3.9, 0.09, -0.012]
    try:
        A = np.vstack([np.ones_like(x), x - _X0, t - _T0]).T
        coef, *_ = np.linalg.lstsq(A, y, rcond=None)
        if np.all(np.isfinite(coef)):
            p0 = [float(coef[0]), float(coef[1]), float(coef[2])]
    except Exception:
        pass
    try:
        r = least_squares(lambda p: _form(x, t, *p) - y, p0, max_nfev=4000)
        a, b, c = (float(v) for v in r.x)
        if not (np.isfinite(a) and np.isfinite(b) and np.isfinite(c)):
            raise ValueError
    except Exception:
        a, b, c = p0
    return {"a": a, "b": b, "c": c}

def predict(X, a, b, c):
    x = np.asarray(X[:, 0], dtype=float)
    t = np.asarray(X[:, 1], dtype=float)
    return _form(x, t, a, b, c)