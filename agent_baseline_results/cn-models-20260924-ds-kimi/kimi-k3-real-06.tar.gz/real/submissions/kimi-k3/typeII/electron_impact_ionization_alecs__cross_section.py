"""Electron-impact single-ionization cross-section (Bethe-style with threshold onset).

Form: sigma(E) = A * (1 - exp(-a*(E-Et)))^b * ln(E/Et) / E^d   for E>Et (0 below).

Rationale: above the ionization threshold Et the cross-section rises from zero
with a threshold-law onset factor (1-exp(-a x))^b, and the high-energy tail
follows the Bethe/Born behaviour ~ ln(E)/E with a mild correction exponent d.
This single shape holds across all clusters; only the five parameters
(A, Et, a, b, d) are re-fit per cluster. It is finite, non-negative, rises
from threshold, peaks near ~100 eV, and decays physically at high E.
"""
import numpy as np
from scipy.optimize import curve_fit

USED_INPUTS = ["electron_energy_eV"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {
    "A":  {"init": None},
    "Et": {"init": None},
    "a":  {"init": None},
    "b":  {"init": None},
    "d":  {"init": None},
}

_LB = [0.0, 1.0, 1e-5, 0.05, 0.05]
_UB = [1e8, 60.0, 20.0, 15.0, 8.0]
_P0S = [
    [50.0, 13.0, 0.05, 1.5, 1.2],
    [200.0, 13.0, 0.02, 1.0, 1.0],
    [10.0, 11.0, 0.10, 2.0, 1.4],
    [100.0, 13.0, 0.02, 1.0, 0.85],
    [500.0, 13.0, 0.013, 1.3, 1.0],
    [3.0, 12.0, 0.20, 2.5, 1.0],
    [1000.0, 10.0, 0.01, 1.0, 0.9],
]

def _form(E, A, Et, a, b, d):
    E = np.asarray(E, dtype=float)
    x = np.maximum(E - Et, 0.0)
    t = np.maximum(E / np.maximum(Et, 1e-9), 1.0)
    return A * (1.0 - np.exp(-a * x))**b * np.log(t) / np.power(np.maximum(E, 1e-9), d)

def fit(X_fit, y_fit):
    E = np.asarray(X_fit[:, 0], dtype=float)
    y = np.asarray(y_fit, dtype=float)
    best = None
    best_r = np.inf
    for p0 in _P0S:
        try:
            popt, _ = curve_fit(_form, E, y, p0=p0, bounds=(_LB, _UB), maxfev=100000)
            r = float(np.sqrt(np.mean((_form(E, *popt) - y)**2)))
            if np.isfinite(r) and r < best_r:
                best_r = r
                best = popt
        except Exception:
            pass
    if best is None:
        # Robust fallback: scale amplitude to the data, keep generic shape.
        A = float(max(np.max(y), 1e-3) * max(np.median(E), 1.0))
        best = np.array([A, 15.0, 0.05, 1.0, 1.0])
    return {"A": float(best[0]), "Et": float(best[1]), "a": float(best[2]),
            "b": float(best[3]), "d": float(best[4])}

def predict(X, A, Et, a, b, d):
    y = _form(np.asarray(X[:, 0], dtype=float), A, Et, a, b, d)
    return np.nan_to_num(y, nan=0.0, posinf=0.0, neginf=0.0)