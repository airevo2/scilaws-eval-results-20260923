"""Lee-Carter-style log-mortality surface: log m(x,t) = B(x,t)·theta, where B is a
fixed transformed-age basis {1, u, v, w, v·w} with u=(x-47.5)/50, v=ln(x+1)/2,
w=ln(1-x/110) (Gompertz-like curvature capturing the infant drop, childhood minimum,
accident hump and old-age rise), plus a linear calendar-time drift z=(t-1997.5)/30 with
age-varying improvement rates {z, z·u, z·v}. The 8 coefficients are re-fit per cluster
by ordinary least squares (linear in parameters: fast, robust). Extrapolation in year
is linear in log-mortality (mortality keeps declining at the cluster's estimated
age-specific rates); age behaviour is bounded over the fixed 0-95 range."""
import numpy as np

USED_INPUTS = ["age", "year"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {f"p{i}": {"init": None} for i in range(8)}

def _basis(X):
    a = np.asarray(X[:, 0], dtype=float)
    yr = np.asarray(X[:, 1], dtype=float)
    u = (a - 47.5) / 50.0
    v = np.log1p(a) / 2.0
    w = np.log(np.clip(1.0 - a / 110.0, 1e-3, None))
    z = (yr - 1997.5) / 30.0
    return np.column_stack([np.ones_like(a), u, v, w, v * w, z, z * u, z * v])

def fit(X_fit, y_fit):
    B = _basis(X_fit)
    y = np.asarray(y_fit, dtype=float)
    try:
        c, *_ = np.linalg.lstsq(B, y, rcond=None)
        if not np.all(np.isfinite(c)):
            raise ValueError
    except Exception:
        c = np.zeros(8)
        c[0] = float(np.mean(y)) if len(y) else -5.5
    return {f"p{i}": float(c[i]) for i in range(8)}

def predict(X, **kw):
    c = np.array([kw[f"p{i}"] for i in range(8)], dtype=float)
    return _basis(X) @ c