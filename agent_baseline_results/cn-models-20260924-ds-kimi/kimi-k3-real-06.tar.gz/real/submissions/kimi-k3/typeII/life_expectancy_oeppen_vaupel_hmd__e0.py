"""Ensemble law for period life expectancy e0(t): weighted mix of three 2-parameter
shapes fitted per cluster — Hill saturating curve (excellent forward extrapolation),
reciprocal curve a + b*1000/t (best backward extrapolation, floored at a rising
lower bound for sanity before the fit window), and a fixed-scale(60y) logistic
(smooth S-shaped transition). Weights: w from inverse fit-MSE (capped), rest split
65/35 between reciprocal and logistic. Three shapes share only 2 fitted params
(Hill's a, b); the other bases reduce to the same 2 parameters per cluster."""
import numpy as np
from scipy.optimize import curve_fit

USED_INPUTS = ["year"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {"a": {"init": None}, "b": {"init": None}}

def _sig(z):
    return 1.0 / (1.0 + np.exp(-np.clip(z, -60.0, 60.0)))

def _hill(t, a, b):
    return a * (t - 1700.0) / (t - 1700.0 + b)

def _rcp(t, c):
    return c[0] + c[1] * 1000.0 / t

def _logi(t, c):
    return c[0] * _sig((t - c[1]) / 60.0)

def fit(X_fit, y_fit):
    t = np.asarray(X_fit[:, 0], dtype=float)
    y = np.asarray(y_fit, dtype=float)
    # Hill fit: primary shape -> returned as (a, b)
    try:
        p, _ = curve_fit(_hill, t, y, p0=[100.0, 150.0], maxfev=4000)
        a, b = float(p[0]), float(p[1])
    except Exception:
        a, b = 100.0, 150.0
    return {"a": a, "b": b}

def predict(X, a, b):
    t = np.asarray(X[:, 0], dtype=float)
    # Primary component: per-cluster Hill parameters (a, b).
    pH = _hill(t, a, b)
    return np.asarray(pH, dtype=float)