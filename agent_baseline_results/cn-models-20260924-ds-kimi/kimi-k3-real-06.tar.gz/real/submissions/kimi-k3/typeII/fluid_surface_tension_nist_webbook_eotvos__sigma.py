"""Eotvos-Ramsay-Shields scaling law for surface tension along the saturation curve.

    sigma = a * (T_c - T) * (rho_liq / M_mol)^(2/3)

The classical Eotvos rule states sigma * V_m^(2/3) = a * (T_c - T), i.e. the
molar surface energy decreases linearly with temperature and vanishes at T_c.
With molar volume V_m = M_mol/rho_liq this becomes the form above. The 2/3
exponent is the published (non-fitted) Eotvos constant; only the
substance-specific constant a (which absorbs the Eotvos coefficient) is fit
per cluster by linear least squares through the origin."""
import numpy as np

USED_INPUTS = ["T_K", "rho_liq", "T_c", "M_mol"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {"a": {"init": [2.0e-7]}}

def _shape(X):
    T = X[:, 0]
    rho = X[:, 1]
    Tc = X[:, 2]
    M = X[:, 3]
    Vm_inv23 = np.power(np.maximum(rho, 1e-12) / np.maximum(M, 1e-12), 2.0 / 3.0)
    return (Tc - T) * Vm_inv23

def fit(X_fit, y_fit):
    f = _shape(X_fit)
    y = np.asarray(y_fit, dtype=float)
    denom = float(f @ f)
    if not np.isfinite(denom) or denom <= 0.0:
        return {"a": 2.0e-7}
    a = float((f @ y) / denom)
    if not np.isfinite(a) or a <= 0.0:
        a = 2.0e-7
    return {"a": a}

def predict(X, a):
    return a * _shape(X)