"""Lee-Carter-style log-mortality surface: a0 + b*(age-62.5) + c*C(age) + e*Q(age) + k*T(year),
where C(age) is a universal smooth adult mortality-curvature shape (cubic spline through the
cross-cluster mean age-profile residual, tabulated 30..95), Q(age)=0.5*((age-62.5)/30)^2, and
T(year) is a universal quadratic time trend B*(t-1985)+D*(t-1985)^2/400. Per cluster, the five
coefficients are obtained by one ordinary least-squares fit (fit returns a0,b,k; the remaining
shape coefficients are kept at their universal values inside predict)."""
import numpy as np

USED_INPUTS = ["age", "year"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {
    "B_TIME": -0.14054,
    "D_TIME": -0.36706,
    "AGE_MID": 62.5,
    "YEAR_MID": 1985.0,
    "C_CURVE": [
        0.24935, 0.1997, 0.15603, 0.11797, 0.08515, 0.05721, 0.03377, 0.01445,
        -0.0011, -0.01326, -0.02241, -0.02891, -0.03313, -0.03545, -0.03623, -0.03584,
        -0.03466, -0.03306, -0.03141, -0.03007, -0.02942, -0.02975, -0.031, -0.03305,
        -0.03575, -0.03898, -0.04261, -0.04649, -0.0505, -0.0545, -0.05837, -0.06196,
        -0.06519, -0.06796, -0.07017, -0.07173, -0.07254, -0.07252, -0.07157, -0.06958,
        -0.06648, -0.0622, -0.05679, -0.05037, -0.04303, -0.03486, -0.02596, -0.01643,
        -0.00636, 0.00414, 0.01498, 0.02602, 0.03702, 0.04767, 0.05769, 0.06678,
        0.07464, 0.08098, 0.08552, 0.08795, 0.08799, 0.08534, 0.07971, 0.07081,
        0.05834, 0.04201,
    ],
}
LOCAL_FITTABLE = {
    "a0": {"init": None},
    "b": {"init": None},
    "k": {"init": None},
}


def _features(X):
    age = np.asarray(X[:, 0], dtype=float)
    year = np.asarray(X[:, 1], dtype=float)
    ac = age - OTHER_CONSTANTS["AGE_MID"]
    yc = year - OTHER_CONSTANTS["YEAR_MID"]
    # universal curvature shape, clamped to the tabulated 30..95 age window
    ctab = np.asarray(OTHER_CONSTANTS["C_CURVE"], dtype=float)
    ai = np.clip(np.rint(age).astype(int), 30, 95) - 30
    cvec = ctab[ai]
    qvec = 0.5 * (ac / 30.0) ** 2
    tvec = OTHER_CONSTANTS["B_TIME"] * yc + OTHER_CONSTANTS["D_TIME"] * yc ** 2 / 400.0
    return ac, cvec, qvec, tvec


def fit(X_fit, y_fit):
    ac, cvec, qvec, tvec = _features(X_fit)
    y = np.asarray(y_fit, dtype=float)
    # y = a0 + b*ac + c*cvec + e*qvec + k*tvec ; solve the 5-parameter OLS
    A = np.column_stack([np.ones_like(ac), ac, cvec, qvec, tvec])
    try:
        coef, *_ = np.linalg.lstsq(A, y, rcond=None)
        a0, b, k = float(coef[0]), float(coef[1]), float(coef[4])
        if not (np.isfinite(a0) and np.isfinite(b) and np.isfinite(k)):
            raise ValueError
    except Exception:
        a0, b, k = float(np.mean(y)), 0.093, -0.013
    return {"a0": a0, "b": b, "k": k}


def predict(X, a0, b, k):
    ac, cvec, qvec, tvec = _features(X)
    # universal shape coefficients c=1, e=1; per-cluster a0,b,k
    return a0 + b * ac + cvec + qvec + k * tvec