"""Anisotropic Fung-type exponential hyperelastic law for biaxial skin.

sigma11 = c * lambda11^2 * exp(Q) * (a1*E11 + a3*E22),
with E11 = 0.5*(lambda11^2 - 1), E22 = 0.5*(lambda22^2 - 1) the Green strains and
Q = a1*E11^2 + a2*E22^2 + 2*a3*E11*E22 the quadratic anisotropic strain measure.
Stress vanishes in the undeformed state. Four parameters are re-fit per cluster."""
import numpy as np
from scipy.optimize import least_squares

USED_INPUTS = ["lambda11", "lambda22"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {
    "c":  {"init": [0.001, 0.005, 0.01, 0.02]},
    "a1": {"init": [2.0, 4.0, 8.0, 10.0]},
    "a2": {"init": [2.0, 4.0, 8.0, 10.0]},
    "a3": {"init": [0.0, -1.0, -2.0, -0.5]},
}

def _green(lam):
    return 0.5 * (np.asarray(lam, dtype=float) ** 2 - 1.0)

def _form(l1, l2, c, a1, a2, a3):
    E1 = _green(l1)
    E2 = _green(l2)
    Q = a1 * E1 ** 2 + a2 * E2 ** 2 + 2.0 * a3 * E1 * E2
    return c * np.asarray(l1, dtype=float) ** 2 * np.exp(np.clip(Q, -40.0, 50.0)) * (a1 * E1 + a3 * E2)

def fit(X_fit, y_fit):
    l1 = np.asarray(X_fit[:, 0], dtype=float)
    l2 = np.asarray(X_fit[:, 1], dtype=float)
    y = np.asarray(y_fit, dtype=float)
    E1 = _green(l1)
    E2 = _green(l2)

    def resid(p):
        c, a1, a2, a3 = p
        Q = a1 * E1 ** 2 + a2 * E2 ** 2 + 2.0 * a3 * E1 * E2
        return c * l1 ** 2 * np.exp(np.clip(Q, -40.0, 50.0)) * (a1 * E1 + a3 * E2) - y

    best = None
    for c0 in LOCAL_FITTABLE["c"]["init"]:
        for a0 in LOCAL_FITTABLE["a1"]["init"]:
            for t0 in LOCAL_FITTABLE["a3"]["init"]:
                try:
                    sol = least_squares(resid, [c0, a0, a0, t0], max_nfev=4000)
                    r = float(np.sqrt(np.mean(sol.fun ** 2)))
                    if best is None or r < best[0]:
                        best = (r, sol.x)
                except Exception:
                    pass
    if best is None:
        return {"c": 0.005, "a1": 4.0, "a2": 4.0, "a3": 0.0}
    p = best[1]
    return {"c": float(p[0]), "a1": float(p[1]), "a2": float(p[2]), "a3": float(p[3])}

def predict(X, c, a1, a2, a3):
    return np.asarray(_form(X[:, 0], X[:, 1], c, a1, a2, a3), dtype=float)