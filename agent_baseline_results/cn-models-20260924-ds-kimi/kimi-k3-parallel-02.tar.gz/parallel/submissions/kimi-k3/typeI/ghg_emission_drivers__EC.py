"""Annual national primary energy consumption EC (TJ).

Mechanism (separable multiplicative / log-additive), identified from targeted
one-factor sweeps and verified by a joint log-space fit (R^2 ~ 0.99):

  EC = C * [G/(1+G/Gs)]^a        # saturating (concave) per-capita income effect
         * P^p                    # near-proportional population scaling
         * exp(bA*(AP-65))        # working-age share raises energy demand
         * exp(bU*(UR-60))        # urbanization raises energy demand
         * D^d                    # weak positive density effect
         * exp(q1*(AT-T0)+q2*(AT-T0)^2)  # U-shaped temperature response

All constants were fitted jointly on the collected experiment data by
least squares in log(EC).
"""
import numpy as np

USED_INPUTS = ["GDP", "TP", "AP", "DP", "UR", "AT"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    G = np.asarray(X[:, 0], dtype=float)
    P = np.asarray(X[:, 1], dtype=float)
    A = np.asarray(X[:, 2], dtype=float)
    D = np.asarray(X[:, 3], dtype=float)
    U = np.asarray(X[:, 4], dtype=float)
    T = np.asarray(X[:, 5], dtype=float)

    c0 = -8.635392          # log scale constant
    a = 0.736926            # GDP elasticity (low-income regime)
    Gs = np.exp(9.817617)   # GDP saturation scale (~1.84e4 USD)
    p = 0.966881            # population elasticity
    bA = 0.048479           # working-age share effect (per %-point)
    bU = 0.014174           # urban share effect (per %-point)
    d = 0.032705            # density elasticity
    T0 = 36.051274          # temperature vertex (deg C)
    q1 = -0.000711
    q2 = 0.000285

    logG_term = a * np.log(G / (1.0 + G / Gs))
    logEC = (c0
             + logG_term
             + p * np.log(P)
             + bA * (A - 65.0)
             + bU * (U - 60.0)
             + d * np.log(D)
             + q1 * (T - T0) + q2 * (T - T0) ** 2)
    return np.exp(logEC)