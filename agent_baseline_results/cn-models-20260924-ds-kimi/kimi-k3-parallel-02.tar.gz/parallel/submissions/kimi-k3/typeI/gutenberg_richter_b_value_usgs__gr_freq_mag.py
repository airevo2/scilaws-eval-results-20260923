"""Tapered Gutenberg-Richter (Kagan-type) magnitude-frequency law:
log10_N = a - b*M - log10(1 + 10^(beta*(M - M_t))),
i.e. a pure GR power law (b ~ 1.0) multiplied by an exponential moment
taper that rolls the cumulative rate off smoothly above corner magnitude M_t."""
import numpy as np

USED_INPUTS = ["M_threshold"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    M = X[:, 0]
    a = 8.1052      # GR productivity intercept
    b = 1.0069      # GR b-value
    beta = 0.5397   # taper sharpness (log10-units per magnitude)
    Mt = 8.30       # corner magnitude of the exponential taper
    return a - b * M - np.log10(1.0 + 10.0 ** (beta * (M - Mt)))