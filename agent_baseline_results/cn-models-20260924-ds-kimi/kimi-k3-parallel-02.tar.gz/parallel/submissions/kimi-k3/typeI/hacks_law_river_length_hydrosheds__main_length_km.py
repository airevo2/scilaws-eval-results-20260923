"""Hack's law: main-stem length scales as a power of drainage area, L = c * A^h (lognormal multiplicative noise in the simulator; predict the median)."""
import numpy as np

USED_INPUTS = ["upland_area_skm"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    A = X[:, 0]
    return 1.6430266357122143 * np.power(A, 0.5519)