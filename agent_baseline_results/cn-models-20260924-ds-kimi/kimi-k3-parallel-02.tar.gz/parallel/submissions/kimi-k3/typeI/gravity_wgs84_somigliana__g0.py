"""Normal gravity on the WGS84 ellipsoid via the closed-form Somigliana
formula: g0 = ge*(1 + k*sin^2(phi))/sqrt(1 - e2*sin^2(phi)), with ge the
equatorial gravity, k the Somigliana constant, e2 the first eccentricity
squared (fitted to the simulator's level of ge, k, e2)."""
import numpy as np

USED_INPUTS = ["latitude"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    lat = X[:, 0]
    s2 = np.sin(np.deg2rad(lat))**2
    ge = 9.780328
    k = 0.0019317
    e2 = 0.0066944
    return ge * (1.0 + k * s2) / np.sqrt(1.0 - e2 * s2)