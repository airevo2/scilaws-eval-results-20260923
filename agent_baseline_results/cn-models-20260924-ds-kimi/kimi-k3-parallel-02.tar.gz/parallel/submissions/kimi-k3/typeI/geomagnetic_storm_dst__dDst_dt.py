"""Burton et al. (1975) Dst evolution ODE with constant offset:
dDst/dt = Q(Ey) - (Dst - b*sqrt(P_dyn) - c)/tau, i.e.
dDst_dt = a1*(Ey - Ec)*H(Ey - Ec) - pw*sqrt(P_dyn) + a0 + c0*Dst.
Constants fitted by least squares on simulator observations (378 rows).
"""
import numpy as np

USED_INPUTS = ["Dst", "Ey", "P_dyn"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    Dst = X[:, 0]
    Ey = X[:, 1]
    P_dyn = X[:, 2]
    Q = np.where(Ey > 0.10526159, -2.46316483 * (Ey - 0.10526159), 0.0)
    return Q - 0.45562891 * np.sqrt(P_dyn) + 1.16322908 - 0.05025848 * Dst