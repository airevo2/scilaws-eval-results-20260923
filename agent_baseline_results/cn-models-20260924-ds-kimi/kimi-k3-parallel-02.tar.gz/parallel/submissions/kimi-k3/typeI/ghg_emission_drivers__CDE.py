"""Kaya-style multiplicative power-law: CDE = TP * a * GDP^0.52 * AP^c * DP^d * UR^e * (AT+6)^f.

From replicated experiments: per-capita emissions scale as ~GDP^0.52 (log-log slope 0.524),
total emissions are linear in TP (elasticity ~1.0). Covariate elasticities from log-linear
regression on all 360 rows: AP ~ 2.2, UR ~ 0.53, DP ~ -0.10, AT ~ -0.11. The dominant,
robust mechanism is CDE ∝ TP * GDP^0.5 with positive AP and UR corrections and weak
negative DP and AT corrections. Constants fitted on the pooled experiment data.
"""
import numpy as np

USED_INPUTS = ["GDP", "TP", "AP", "DP", "UR", "AT"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    GDP = X[:, 0]
    TP  = X[:, 1]
    AP  = X[:, 2]
    DP  = X[:, 3]
    UR  = X[:, 4]
    AT  = X[:, 5]

    # Kaya-type multiplicative power law
    # per-capita emissions ~ 32 * GDP^0.52 (kg CO2 per person) at reference covariates
    # reference: AP=65, DP=100, UR=60, AT=15
    base_pc = 32.0 * np.power(np.maximum(GDP, 1e-6), 0.52)

    # covariate multiplicative adjustments (power-law elasticities, ref-normalized)
    adj = (
        np.power(np.maximum(AP, 1e-6) / 65.0, 2.2)
        * np.power(np.maximum(DP, 1e-6) / 100.0, -0.10)
        * np.power(np.maximum(UR, 1e-6) / 60.0, 0.53)
        * np.power(np.maximum(AT + 6.0, 1e-6) / 21.0, -0.11)
    )

    return TP * base_pc * adj