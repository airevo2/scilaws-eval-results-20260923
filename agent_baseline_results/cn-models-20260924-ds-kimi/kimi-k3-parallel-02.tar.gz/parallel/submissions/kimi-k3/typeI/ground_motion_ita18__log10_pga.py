"""AB10-style European GMPE for log10(RotD50 PGA, cm/s^2):
mu = a1 + a2*Mw + c1*log10(sqrt(R^2+h^2)) + c2*sqrt(R^2+h^2) + site terms.
Reference site is EC8 class A (rock); strike-slip is reference faulting (normal/reverse terms ~0).
Fitted by bounded nonlinear least squares on experiment means."""
import numpy as np

USED_INPUTS = ["Mw", "R_km", "ec8_B", "ec8_C", "ec8_D", "ec8_E", "sof_NF", "sof_TF"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    M = X[:, 0]
    R = X[:, 1]
    SB = X[:, 2]
    SC = X[:, 3]
    SD = X[:, 4]
    SE = X[:, 5]
    # sof_NF (X[:,6]) and sof_TF (X[:,7]) have ~zero fitted effect; omitted
    h = 7.82
    D = np.sqrt(R**2 + h**2)
    mu = (0.6565
          + 0.5403 * M
          - 1.5243 * np.log10(D)
          - 0.0018 * D
          + 0.1023 * SB
          + 0.1687 * SC
          + 0.2118 * SD
          + 0.2214 * SE)
    return np.asarray(mu, dtype=float)