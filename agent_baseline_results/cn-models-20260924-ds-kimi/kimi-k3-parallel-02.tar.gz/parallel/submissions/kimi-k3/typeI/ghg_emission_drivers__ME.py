"""National annual CH4 emissions: separable power-law intensity model.
ME = 10^c * GDP^a * TP^b * (UR/100)^d, with constants fitted by log-log least squares
on all probed observations (c=1.3395, a=0.1083, b=1.0029, d=0.4435)."""
import numpy as np

USED_INPUTS = ["GDP", "TP", "UR"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    gdp = X[:, 0]
    tp = X[:, 1]
    ur = X[:, 2] / 100.0
    return (10.0 ** 1.3395) * np.power(gdp, 0.1083) * np.power(tp, 1.0029) * np.power(ur, 0.4435)