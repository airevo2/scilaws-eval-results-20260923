"""NOE ~ population x GDP-per-capita log-gaussian x linear working-age x inverse density x temperature ramp.

Mechanism (multiplicative, lognormal noise): NOE = TP * exp(a + b*ln(GDP)) * (c + d*AP) * (e/DP) * (f + g*max(AT,0)). Constants fitted by median least squares on the structural scale, then renormalized to reproduce the observed conditional medians across all six input sweeps (GDP, TP, AP, DP, UR, AT). UR enters only through interaction with GDP/TP; the compact form below bakes the fitted regime averages."""
import numpy as np

USED_INPUTS = ["GDP", "TP", "AP", "DP", "UR", "AT"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    gdp = X[:, 0]
    tp = X[:, 1]
    ap = X[:, 2]
    dp = X[:, 3]
    ur = X[:, 4]
    at = X[:, 5]
    intensity = np.exp(-0.85 + 0.118 * np.log(gdp))
    demographics = 1.72 - 0.0133 * ap
    land = 1325.0 / dp
    climate = 0.716 + 0.0329 * np.maximum(at, 0.0)
    urban = 0.72 + 0.0055 * ur
    return tp * intensity * demographics * land * climate * urban