"""Mass-metallicity relation: logistic rise in dex (Tremonti et al. 2004 form),
12+log(O/H) = a - b / (1 + 10**((M0 - logM*) / width)), with constants fitted by
least squares on 888 simulated observations (8.5 <= log_Mstar <= 11.5)."""
import numpy as np

USED_INPUTS = ["log_Mstar"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    m = X[:, 0]
    return 8.22232 - (-0.89485) / (1.0 + np.power(10.0, (9.31628 - m) / 1.21627))