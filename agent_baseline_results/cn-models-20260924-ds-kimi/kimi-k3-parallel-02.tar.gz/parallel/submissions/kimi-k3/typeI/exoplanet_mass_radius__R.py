"""Sub-stellar mass-radius relation (Earth radii vs Earth masses).

Recovered mechanism: three physically distinct regimes joined smoothly:
 (1) Rocky/terrestrial core: self-compressed differentiated solid, R ~ M^0.27
     (Earth-like iron-core scaling, R~R_earth at M~M_earth).
 (2) Ice/ocean (Neptune-like) volatile objects: R ~ M^0.59 (water/ice EOS),
     giving radii of a few R_earth through the Neptune/sub-Saturn range.
 (3) Gas giants & brown dwarfs (H/He, electron-degeneracy supported):
     R peaks at ~13.4 R_earth near M~1.6 M_J (~500 M_earth) then declines
     gently (~M^-0.06) as degeneracy pressure dominates at larger mass.

The simulator adds composition stochasticity (random envelope/core fractions)
around these branches; predict returns the deterministic branch centers,
selecting the dominant radius branch per mass via the maximum of the
regime-specific scalings (continuous, single-input, no fitting at eval time).
"""
import numpy as np

USED_INPUTS = ["M"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    M = np.asarray(X[:, 0], dtype=float)

    # (1) Rocky terrestrial branch: R ~ M^0.27 (R ~ 1 R_earth at 1 M_earth)
    R_rock = 0.90 * np.power(M, 0.27)

    # (2) Ice / Neptune-like volatile branch: R ~ M^0.59 (water-ice EOS)
    R_ice = 0.90 * np.power(M, 0.59)

    # (3) Gas-giant / brown-dwarf branch: degenerate H/He, log-quadratic
    #     peaking at R~13.4 R_earth near M~500 M_earth then declining.
    logM = np.log(np.maximum(M, 1e-6))
    logR_giant = -0.01767 * logM**2 + 0.22066 * logM + 1.90359
    R_giant = np.exp(logR_giant)

    # Take the physically relevant (largest supportable) branch.
    R = np.maximum(np.maximum(R_rock, R_ice), R_giant)
    return np.asarray(R, dtype=float)