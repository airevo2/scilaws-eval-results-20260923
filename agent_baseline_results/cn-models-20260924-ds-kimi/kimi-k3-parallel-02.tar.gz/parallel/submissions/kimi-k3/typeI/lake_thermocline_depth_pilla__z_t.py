"""Thermocline depth as a logarithmic function of lake surface area (wind-fetch scaling): z_t = a + b*log10(A_s), fitted to ~360 simulated observations spanning A_s in [0.1, 895.5] km^2."""
import numpy as np

USED_INPUTS = ["A_s_km2"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    A = X[:, 0]
    return 7.4322 + 2.3952 * np.log10(A)