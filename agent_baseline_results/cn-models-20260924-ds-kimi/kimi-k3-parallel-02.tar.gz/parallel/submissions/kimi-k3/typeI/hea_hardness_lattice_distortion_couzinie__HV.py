"""Multiplicative mechanism: HV = (a*VEC + b) * (1 + k*dHmix), with multiplicative measurement noise. A linear valence-electron-concentration term sets the base hardness (solid-solution strengthening), and a linear enthalpy-of-mixing factor scales it (negative dHmix raises hardness). Fitted in log-space over 138 experimental rows: a=71.18, b=69.72, k=-0.0173."""
import numpy as np

USED_INPUTS = ["VEC", "dHmix"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    vec = X[:, 0]
    dh = X[:, 1]
    return (71.18 * vec + 69.72) * (1.0 - 0.0173 * dh)