"""Stellar mass from SDSS light: log10 M* = -0.4*M_i + 0.4*(g-r) + const,
i.e. luminosity (i-band absolute magnitude from distance modulus) plus a
color (mass-to-light) term linear in (g-r)."""
import numpy as np

USED_INPUTS = ["g", "r", "i", "DM"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    g = X[:, 0]
    r = X[:, 1]
    i = X[:, 2]
    DM = X[:, 3]
    return 0.4 * DM - 0.4 * i + 0.4 * (g - r) + 1.29