"""Exponential decay of arthropod species richness with anthropogenic disturbance, toward a baseline richness of ~1 species: S = 1.05 + 30.3 * exp(-0.092 * d)."""
import numpy as np

USED_INPUTS = ["d"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    d = X[:, 0]
    return 1.0466 + 30.3008 * np.exp(-0.09195 * d)