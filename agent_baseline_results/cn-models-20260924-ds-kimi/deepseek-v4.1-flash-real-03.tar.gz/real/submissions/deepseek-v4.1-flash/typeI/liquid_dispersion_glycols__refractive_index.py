"""Refractive index of ethylene glycol: Cauchy dispersion with linear temperature dependence.
n = A + B/l^2 + C/l^4 + D/l^6 + E*T + F*T/l^2,
with l = wavelength (um) and T = temperature (degC). Coefficients fitted by
least squares over the full training set.
"""
import numpy as np

USED_INPUTS = ["lambda_um", "temperature_C"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    lam = X[:, 0].astype(float)
    T = X[:, 1].astype(float)
    l2 = lam ** 2
    A = 1.4235797
    B = 6.1963e-3
    C = -5.927e-4
    D = 4.61e-5
    E = -2.685e-4
    F = -4.70e-6
    return A + B / l2 + C / l2**2 + D / l2**3 + E * T + F * T / l2