"""Semi-empirical mass formula (Bethe-Weizsacker droplet) for binding energy per nucleon B/A.
Physical basis: volume + surface (A^-1/3, A^-2/3, A^-1) terms, Coulomb repulsion
(Z(Z-1)/A^(4/3) and Z^2/A), and symmetry (N-Z)^2/A^2. Constants fitted by least squares
on the full training set; form chosen because it extrapolates most stably to the
neutron-rich superheavy region (Z=83-110, A=186-270)."""
import numpy as np

USED_INPUTS = ["Z", "N", "A"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    Z = X[:, 0].astype(float)
    N = X[:, 1].astype(float)
    A = X[:, 2].astype(float)
    a_v   = 13.79469      # volume term
    a_s   = -14.64861     # surface term (A^-1/3)
    a_s2  = 1.67510       # surface/curvature correction (A^-1)
    a_ca  = -0.20338      # Coulomb (Z(Z-1)/A^(4/3))
    a_cc  = -0.05443      # Coulomb (Z^2/A)
    a_sym = -14.26042     # symmetry (N-Z)^2/A^2
    return (a_v
            + a_s  * A ** (-1.0 / 3.0)
            + a_s2 * A ** (-1.0)
            + a_ca * Z * (Z - 1.0) / A ** (4.0 / 3.0)
            + a_cc * Z ** 2 / A
            + a_sym * (N - Z) ** 2 / A ** 2)