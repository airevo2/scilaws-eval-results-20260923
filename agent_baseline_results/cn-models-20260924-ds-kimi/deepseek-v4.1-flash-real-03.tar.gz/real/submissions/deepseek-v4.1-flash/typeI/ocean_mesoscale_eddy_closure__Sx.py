"""Linear closure: Sx from the zonal divergence of the subgrid eddy stress tensor,
expressed as a linear combination of the three coarse-grained stress-divergence
candidates (enstrophy gradient and vorticity-deformation gradients)."""
import numpy as np

USED_INPUTS = ["d_zeta2_dx", "d_zetaD_dx", "d_zetaDtilde_dy"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    dz2 = X[:, 0]     # d_zeta2_dx
    dzD = X[:, 1]     # d_zetaD_dx
    dzDt = X[:, 2]    # d_zetaDtilde_dy
    return -6.77444283e8 * dz2 + 1.06409009e9 * dzD - 1.12014764e9 * dzDt