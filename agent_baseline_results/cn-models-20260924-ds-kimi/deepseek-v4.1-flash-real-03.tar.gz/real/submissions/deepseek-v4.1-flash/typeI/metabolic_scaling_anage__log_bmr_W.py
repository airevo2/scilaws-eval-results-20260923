"""Allometric scaling of basal metabolic rate with body mass.

log10(B) = b * log10(M) + a, a classic power law B = a' * M^b.
Fitted on the training set (assuming allometric scaling).
"""
import numpy as np

USED_INPUTS = ["body_mass_g"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    M = X[:, 0].astype(float)
    lm = np.log10(M)
    return 0.689034 * lm + (-1.664570)