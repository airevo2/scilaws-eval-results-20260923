"""Cubic polynomial fit in log10(D) vs log10(N) space."""
import numpy as np

USED_INPUTS = ["D_lower_km"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    D = X[:, 0]
    x = np.log10(D)
    # cubic coefficients (highest degree first)
    c3, c2, c1, c0 = -0.52843732, 1.23369969, -1.90854969, -2.56908592
    logN = ((c3 * x + c2) * x + c1) * x + c0
    return 10.0 ** logN