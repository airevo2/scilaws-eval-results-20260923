"""Mincer-style wage equation with schooling polynomial/sheepskin terms and experience term plus sqrt(experience)."""
import numpy as np

USED_INPUTS = ["SCHL_years", "exp"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    s = X[:, 0].astype(float)
    x = X[:, 1].astype(float)
    col2 = np.maximum(0.0, s - 16.0) ** 2
    grad = np.maximum(0.0, s - 18.0)
    return (9.085425046636466
            + 2.65397248e-04 * s ** 3
            - 6.35556151e-02 * col2
            + 2.78495631e-01 * grad
            - 2.71307321e-02 * x
            + 3.48911627e-01 * np.sqrt(x))