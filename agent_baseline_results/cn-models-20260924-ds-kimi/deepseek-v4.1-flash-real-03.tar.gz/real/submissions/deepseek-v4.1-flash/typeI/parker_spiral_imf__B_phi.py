"""Parker spiral relation fit: B_phi = k * B_r / v_sw (r=1 AU folded into k)."""
import numpy as np

USED_INPUTS = ["B_r_nT", "v_sw_km_s"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    br = X[:, 0]
    v = X[:, 1]
    return -311.5 * br / v