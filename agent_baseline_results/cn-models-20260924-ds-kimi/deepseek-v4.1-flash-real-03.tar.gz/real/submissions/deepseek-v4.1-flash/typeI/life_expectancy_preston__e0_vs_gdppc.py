"""Saturating life-expectancy curve fitted to the Preston cross-section.

Form: e0 = a - b * gdppc^(-c), which rises from low income and asymptotes
smoothly toward a as income grows (a ~ 75 years), staying physically sensible
on extrapolation. Three fitted constants: a, b, c.
"""
import numpy as np

USED_INPUTS = ["gdppc"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    x = np.asarray(X[:, 0], dtype=float)
    a = 75.1673
    b = 749.6841
    c = 0.73862
    return a - b * np.power(x, -c)