"""Capacity fade of 18650 Li-ion cells modeled by the standard SEI-growth
square-root law: Q(k) = Q0 - a*sqrt(k), with Q0 the fresh-cell capacity and
a the fade coefficient. Monotone-decreasing, stays positive, and behaves
sensibly at k=1 and beyond the observed cycle range."""
import numpy as np

USED_INPUTS = ["cycle_index"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    k = X[:, 0].astype(float)
    Q0 = 2.238200
    a = 0.075737
    return Q0 - a * np.sqrt(k)