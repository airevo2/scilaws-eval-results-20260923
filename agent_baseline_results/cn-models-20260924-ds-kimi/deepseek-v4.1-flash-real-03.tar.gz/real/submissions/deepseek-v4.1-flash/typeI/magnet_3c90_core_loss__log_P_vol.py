"""Physical Steinmetz-style core-loss model: hysteresis term (∝ f·B^b) plus
eddy-current term (∝ f²·B²), scaled by a linear temperature factor.
Fitted on the full training set by nonlinear least squares.
USED_INPUTS = f_Hz, B_peak_T, T_C.
log10(P_vol) = log10( 10^c1 · f · B^b  +  10^c2 · f² · B² ) + log10(1 + d·(T-25))
with c1=-0.199, b=3.0752, c2=-6.4264, d=-0.0057.
"""
import numpy as np

USED_INPUTS = ["f_Hz", "B_peak_T", "T_C"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    f = X[:, 0]
    B = X[:, 1]
    T = X[:, 2]
    hyst = (10.0 ** -0.199) * f * (B ** 3.0752)
    eddy = (10.0 ** -6.4264) * (f ** 2) * (B ** 2)
    temp = 1.0 - 0.0057 * (T - 25.0)
    P = (hyst + eddy) * temp
    return np.log10(P)