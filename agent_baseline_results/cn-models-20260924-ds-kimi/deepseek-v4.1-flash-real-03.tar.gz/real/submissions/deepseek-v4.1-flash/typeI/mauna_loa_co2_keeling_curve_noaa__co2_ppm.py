"""Mauna Loa CO2: quadratic secular trend plus two annual harmonics with
linearly growing amplitude (captures both the accelerating rise and the
amplifying seasonal cycle)."""
import numpy as np

USED_INPUTS = ["year_decimal"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    t = X[:, 0]
    tc = t - 2000.0
    y = 369.5171379710696 + 1.853215181402206 * tc + 0.01281464145901073 * tc * tc
    c1 = np.cos(2 * np.pi * t); s1 = np.sin(2 * np.pi * t)
    c2 = np.cos(4 * np.pi * t); s2 = np.sin(4 * np.pi * t)
    y += (-0.9458474137704681) * c1 + 2.7498474984358725 * s1
    y += 0.004770870699040647 * tc * c1 + 0.009706200123712953 * tc * s1
    y += 0.6773806122211202 * c2 + (-0.48769752860096127) * s2
    y += 0.0020907617235201748 * tc * c2 + (-0.003966888692274301) * tc * s2
    return y