"""Melt-pool depth scaling with normalized energy density psi = P/(V*D)."""
import numpy as np

USED_INPUTS = ["laser_power_W", "scan_velocity_mm_per_s", "beam_diameter_um"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    P = X[:, 0]
    V = X[:, 1]
    D = X[:, 2]
    psi = P / (V * D)
    return 2.5033e5 * np.power(psi, 1.3766)