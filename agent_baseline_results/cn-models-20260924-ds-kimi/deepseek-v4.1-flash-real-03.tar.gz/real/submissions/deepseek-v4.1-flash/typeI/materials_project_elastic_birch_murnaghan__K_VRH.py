"""Single power-law fit K_VRH = a * (M_avg^(2/3) / V_atomic^2)^b."""
import numpy as np

USED_INPUTS = ["V_atomic_A3", "M_avg_amu"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    V = X[:, 0]
    M = X[:, 1]
    z = M ** (2.0 / 3.0) / V ** 2
    return 1817.9969 * z ** 0.9766