"""Cumulative NEO count vs H: log10(N) = a + b/H (curvature in the H-logN plane).
Fitted on the H in [13.9,17.6] window (a=9.85855, b=-122.40019)."""
import numpy as np

USED_INPUTS = ["H_upper"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    H = X[:, 0]
    logN = 9.85855 + (-122.40019) / H
    return np.power(10.0, logN)