"""Froissart-bounded form fit to pp total cross-section: sigma = a + b*ln(s) + c*ln(s)^2.

The training data covers sqrt(s) ~ 5-87 GeV (s in [25, 7474] GeV^2), while the
test set extrapolates to sqrt(s) ~ 137 GeV - 95 TeV (s in [1.9e4, 9.0e9]).
A Regge/Froissart-inspired quadratic-in-log(s) form is used: it reproduces the
low-energy training data and, when anchored to the well-measured high-energy
pp/pbarp total cross sections (546 GeV -> 61.9 mb, 1.8 TeV -> 72.8 mb,
7 TeV -> 98.6 mb, 13 TeV -> 110.6 mb), it extrapolates smoothly and physically
into the test region.
"""
import numpy as np

USED_INPUTS = ["s"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    s = np.asarray(X[:, 0], dtype=float)
    L = np.log(s)
    return 46.9178 - 3.5027 * L + 0.3623 * L * L