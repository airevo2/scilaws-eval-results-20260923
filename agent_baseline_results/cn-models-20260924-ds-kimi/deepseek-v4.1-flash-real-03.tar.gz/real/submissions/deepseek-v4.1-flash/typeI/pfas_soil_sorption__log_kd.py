"""Organic-carbon normalized PFAS sorption: log Kd = log foc + a*(MW*logKow) + b*frac_neutral.

log Kd is modelled as organic-carbon partitioning (full OC normalization, coefficient 1 on
log foc) driven by a hydrophobicity/size term MW*log Kow, plus a bounded enhancement for the
neutral (protonated) species of high-pKa PFAS.  The neutral fraction
frac_neu = 1/(1+10^(pH-pKa1)) is in [0,1], so this correction cannot blow up on extrapolation.
Two fitted constants (a, b) are baked in as literals.
"""
import numpy as np

USED_INPUTS = ["MW", "pKa1", "log_Kow", "pH", "foc"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    MW = X[:, 0]
    pKa1 = X[:, 1]
    log_Kow = X[:, 6]
    pH = X[:, 7]
    foc = X[:, 13]

    logfoc = np.log10(np.clip(foc, 1e-6, None))
    frac_neu = 1.0 / (1.0 + 10.0 ** (pH - pKa1))

    return logfoc + 0.00067 * MW * log_Kow + 1.22 * frac_neu