"""Curved Gutenberg-Richter-type rate law: log10 N = a - b*M^2.
The low-magnitude data (very low scatter) shows the local slope
d(log10 N)/dM is not constant but grows in magnitude with M
(e.g. -0.97 near M=5.6 rising smoothly toward ~-1.3 near M=9),
i.e. the log-rate is a downward parabola in M rather than a straight
line. A pure linear GR law is rejected (systematic ~0.15 dex residuals,
far beyond noise), while log10 N = a - b*M^2 captures the curvature over
the full range. Constants a (log10 of the extrapolated reference rate at
M=0) and b (curvature) are the two fitted parameters."""
import numpy as np

USED_INPUTS = ["M_threshold"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    M = X[:, 0]
    return 4.868 - 0.07871 * M**2