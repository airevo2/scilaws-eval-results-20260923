"""Mixed log-Tafel (HOR, anodic) / exponential-Tafel (HER, cathodic) hydrogen kinetics
on Pt, scaled by a P_H2-activity, a temperature (Arrhenius-like) prefactor and a weak
HClO4-concentration correction. Reference state: T=298 K, P_H2=0.99 bar, c=0.5 M."""

import numpy as np

USED_INPUTS = ["eta", "T", "P_H2", "c_acid"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}


def predict(X):
    eta = X[:, 0]
    T = X[:, 1]
    P_H2 = X[:, 2]
    c_acid = X[:, 3]

    # activity / temperature / acid prefactor  (unity at the reference state)
    scale = (P_H2 / 0.99) \
        * np.exp(1745.0 * (1.0 / 298.0 - 1.0 / T)) \
        * (c_acid / 0.5) ** (-0.25)

    # anodic (HOR) branch: logarithmic Tafel-like
    anodic = 289.0 * np.log1p(32.2 * np.maximum(eta, 0.0))
    # cathodic (HER) branch: exponential Tafel-like
    cathodic = 267.0 * (np.exp(39.2 * np.maximum(-eta, 0.0)) - 1.0)

    return scale * (anodic - cathodic)