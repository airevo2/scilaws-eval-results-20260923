"""Power-law (STIRPAT-like) multiplicative emissions model: CDE = C * GDP^0.5 * TP * AP^3 * UR^0.5. Constant calibrated at the baseline point (GDP=1e4, TP=1e7, AP=65, UR=60 -> CDE=5.33e10)."""
import numpy as np

USED_INPUTS = ["GDP", "TP", "AP", "UR"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    GDP = X[:, 0]
    TP = X[:, 1]
    AP = X[:, 2]
    UR = X[:, 4]
    C = 2.506e-5
    return C * np.power(GDP, 0.5) * TP * np.power(AP, 3.0) * np.power(UR, 0.5)