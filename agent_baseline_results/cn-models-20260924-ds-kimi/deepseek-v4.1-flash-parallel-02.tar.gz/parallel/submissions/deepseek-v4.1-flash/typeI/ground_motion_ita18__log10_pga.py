"""GMPE-style log10(PGA) model: magnitude-dependent geometric spreading over
effective distance sqrt(R^2 + h^2), plus additive site-class and
style-of-faulting terms. Reference (all-zero) category is site class A / unknown
faulting. Constants fitted by least squares on simulator experiments."""
import numpy as np

USED_INPUTS = ["Mw", "R_km", "ec8_B", "ec8_C", "ec8_D", "ec8_E", "sof_NF", "sof_TF"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    M = X[:, 0]
    R = X[:, 1]
    B = X[:, 2]
    C = X[:, 3]
    D = X[:, 4]
    E = X[:, 5]
    NF = X[:, 6]
    TF = X[:, 7]

    h = 10.581
    Rh = np.sqrt(R * R + h * h)
    logRh = np.log10(Rh)

    y = (3.4134
         + 0.1218 * M
         - 3.3744 * logRh
         + 0.2757 * M * logRh
         + 0.0194 * B
         + 0.2499 * C
         + 0.2221 * D
         + 0.2853 * E
         - 0.0041 * NF
         + 0.1000 * TF)
    return y