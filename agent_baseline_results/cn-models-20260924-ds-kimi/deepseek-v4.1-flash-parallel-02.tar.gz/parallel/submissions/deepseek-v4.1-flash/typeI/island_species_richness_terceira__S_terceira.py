"""Exponential decay of arthropod species richness with habitat disturbance plus a constant floor.

Mechanism recovered from targeted probes on the disturbance gradient:
species richness decreases monotonically from ~9 (undisturbed forest, d≈15) to an
asymptotic floor near ~1.1 (intensively managed pasture, d≈77). Log-space fits
(multiplicative noise) selected a constant floor term c; the decaying part is
best described by an exponential in d rather than a pure power law:

    S(d) = c + a * exp(-d / tau)

with c ≈ 1.10, a ≈ 36.4, tau ≈ 9.77.
"""
import numpy as np

USED_INPUTS = ["d"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}


def predict(X):
    d = X[:, 0]
    return 1.0981 + 36.4443 * np.exp(-d / 9.765)