"""Log-linear power-law (Cobb-Douglas-style) energy consumption model recovered from probing the simulator.

Structure: EC = exp(k0) * GDP^a * TP^b * AP^c * UR^d * exp(e*AT)
i.e. a multiplicative power law in GDP, population, working-age share and
urbanization, with an exponential temperature factor. DP has a
statistically-negligible exponent (~-0.01) and is omitted.
"""
import numpy as np

USED_INPUTS = ["GDP", "TP", "AP", "DP", "UR", "AT"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}


def predict(X):
    GDP = X[:, 0]
    TP = X[:, 1]
    AP = X[:, 2]
    UR = X[:, 4]
    AT = X[:, 5]
    k0 = -23.9734
    a = 0.6022    # GDP elasticity
    b = 0.9835    # population elasticity
    c = 3.4645    # working-age share elasticity
    d = 0.5047    # urbanization elasticity
    e = -0.0226   # temperature coefficient
    return np.exp(k0 + a * np.log(GDP) + b * np.log(TP)
                  + c * np.log(AP) + d * np.log(UR) + e * AT)