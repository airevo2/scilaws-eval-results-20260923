"""STIRPAT-style log-linear (power law) mechanism for national CH4 emissions.

Recovered structure: ln(ME) = a + b*ln(GDP) + c*ln(TP) + d*ln(UR),
i.e. a multiplicative IPAT/STIRPAT impact law.

Fitted constants (from point-mean log-log regression over all experiments):
  C = exp(0.935) ~ 2.55, GDP elasticity ~ 0.18, TP elasticity ~ 0.93,
  UR elasticity ~ 0.64.
"""
import numpy as np

USED_INPUTS = ["GDP", "TP", "UR"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    gdp = X[:, 0]
    tp = X[:, 1]
    ur = X[:, 2]
    C = 2.547
    return C * (gdp ** 0.182) * (tp ** 0.926) * (ur ** 0.638)