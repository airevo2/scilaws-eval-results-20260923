"""Thermocline depth scales logarithmically with lake surface area: z_t = a + b*ln(A_s)."""
import numpy as np

USED_INPUTS = ["A_s_km2"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    A = X[:, 0]
    # z_t = a + b * ln(A_s), fitted on all simulated observations
    a = 7.36
    b = 1.07
    return a + b * np.log(A)