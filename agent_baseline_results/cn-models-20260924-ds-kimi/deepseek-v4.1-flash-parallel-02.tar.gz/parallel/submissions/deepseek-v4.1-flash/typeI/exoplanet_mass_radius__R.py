"""Radius as a smoothly-broken two-regime power law in mass.

R rises as a sub-linear power law M^b for low masses (rocky/terrestrial to
Neptune regime) and flattens/turns over to a nearly constant, slightly
declining radius for the most massive gas giants and brown dwarfs (electron
degeneracy support). Captured by a smooth double power law:

    R = A * M^b / (1 + (M/Mc)^c)^((b-e)/c)

where b is the low-mass slope, e the high-mass slope and Mc the turnover.
"""
import numpy as np

USED_INPUTS = ["M"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    M = X[:, 0]
    A = 1.0264
    b = 0.4822
    Mc = 242.0
    c = 3.2618
    e = -0.0579
    return A * M**b / (1.0 + (M / Mc)**c)**((b - e) / c)