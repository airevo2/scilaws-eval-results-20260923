"""Hack's law power law: main-stem length scales as a power of upstream area."""
import numpy as np

USED_INPUTS = ["upland_area_skm"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    A = X[:, 0]
    return 1.6105 * A ** 0.5541