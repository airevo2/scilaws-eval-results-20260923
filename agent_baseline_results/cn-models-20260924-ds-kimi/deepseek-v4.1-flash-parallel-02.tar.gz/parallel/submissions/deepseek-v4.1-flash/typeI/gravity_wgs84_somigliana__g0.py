"""WGS84 Somigliana normal gravity formula.

    g(phi) = ge * (1 + k*sin^2(phi)) / sqrt(1 - e^2*sin^2(phi))

with the WGS84 defining constants:
    ge = 9.7803253359 m/s^2  (equatorial normal gravity)
    k  = 0.00193185265241    (Somigliana's constant)
    e^2 = 0.00669437999013   (first eccentricity squared of the ellipsoid)
"""
import numpy as np

USED_INPUTS = ["latitude"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    phi = np.deg2rad(X[:, 0])
    s2 = np.sin(phi) ** 2
    ge = 9.7803253359
    k = 0.00193185265241
    e2 = 0.00669437999013
    return ge * (1.0 + k * s2) / np.sqrt(1.0 - e2 * s2)