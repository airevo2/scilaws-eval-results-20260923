"""Exponential model: HV = A * exp(b*VEC) * exp(c*dHmix)."""
import numpy as np

USED_INPUTS = ["VEC", "dHmix"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    VEC = X[:, 0]
    dHmix = X[:, 1]
    A = 184.37        # exp(5.217)
    b = 0.16613       # VEC exponent
    c = -0.01343      # dHmix coupling (kJ/mol)^-1
    return A * np.exp(b * VEC) * np.exp(c * dHmix)