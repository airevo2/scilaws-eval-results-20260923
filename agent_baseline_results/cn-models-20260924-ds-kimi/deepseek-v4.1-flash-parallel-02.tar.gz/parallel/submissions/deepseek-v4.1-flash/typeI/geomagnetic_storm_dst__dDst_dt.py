"""Dst tendency: ring-current injection driven by rectified Ey, exponential-like
linear decay of Dst on a ~20.7 h timescale, plus a solar-wind dynamic-pressure
correction entering as -b*sqrt(P_dyn) on the decayed (pressure-corrected) Dst.

Discovered mechanism (probed by varying Dst, Ey and P_dyn independently):
  dDst/dt = -alpha*max(Ey,0) - (Dst + b*sqrt(P_dyn) - c)/tau
with alpha ~ 2.45 nT/hr per mV/m (injection is half-wave rectified: Ey<0 gives
no injection), tau ~ 20.7 hr, and the pressure term b*sqrt(P_dyn) making the
effective recovery variable more negative with increasing dynamic pressure.
"""
import numpy as np

USED_INPUTS = ["Dst", "Ey", "P_dyn"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}


def predict(X):
    Dst = X[:, 0]
    Ey = X[:, 1]
    P = X[:, 2]
    alpha = 2.45      # nT/hr per mV/m injection efficiency (rectified Ey)
    tau = 20.7        # hr recovery timescale
    b = 9.0           # dynamic-pressure coupling  (nT / sqrt(nPa))
    c = 16.5          # pressure-correction offset (nT)
    injection = -alpha * np.maximum(Ey, 0.0)
    recovery = -(Dst + b * np.sqrt(P) - c) / tau
    return injection + recovery