"""National N2O emissions scale with population, GDP per capita, and population density as a multiplicative power law: NOE = k * TP * GDP^a * DP^b (an emission = population times a per-capita intensity that rises with affluence and falls with density). AP, UR and AT showed no resolvable systematic effect above the simulator's large multiplicative noise, so they enter with zero exponent."""
import numpy as np

USED_INPUTS = ["GDP", "TP", "DP"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    GDP = X[:, 0]
    TP = X[:, 1]
    DP = X[:, 3]
    GDP = np.clip(GDP, 1.0, None)
    DP = np.clip(DP, 1e-6, None)
    return 0.084 * TP * GDP ** 0.45 * DP ** (-0.35)