"""Stellar-mass estimator: linear in (g-r) colour plus i-band absolute magnitude.

Mechanism recovered: log10 M* is a linear function of a rest-frame colour term
(g - r) and the i-band absolute magnitude M_i = i - DM (equivalently a
luminosity term), i.e. the classic colour-based mass-to-light scaling
    log M* = a + b (g - r) - 0.4 (i - DM).
The i- and DM-scans give a clean +-0.4 slope (the -0.4 * M_i luminosity term),
and the colour scan fixes b.
"""
import numpy as np

USED_INPUTS = ["g", "r", "i", "DM"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}


def predict(X):
    g = X[:, 0]
    r = X[:, 1]
    i = X[:, 2]
    DM = X[:, 3]
    color = g - r
    M_i = i - DM
    return 1.70 + 0.42 * color - 0.40 * M_i