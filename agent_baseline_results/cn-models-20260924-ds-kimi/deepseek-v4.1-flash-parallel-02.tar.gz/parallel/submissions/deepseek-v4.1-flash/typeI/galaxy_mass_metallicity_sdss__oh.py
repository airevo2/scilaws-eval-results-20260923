"""Sigmoidal (logistic in log-stellar-mass) mass-metallicity relation.

The galaxy gas-phase oxygen abundance rises from a low-mass plateau (~8.27)
to a high-mass plateau (~9.12) as a smooth monotonic saturation curve of
log10(M*). The transition is symmetric in log10(M*) about a characteristic
mass x0 = 9.367 (M0 ~ 2.3e9 Msun) with width w = 0.524 dex, i.e. a logistic
(Hill) function in stellar mass. This is the classic asymptotic
mass-metallicity relation: oh = a + (b-a)/(1 + (M0/M)^g) with g=1/(w ln10).
"""
import numpy as np

USED_INPUTS = ["log_Mstar"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}


def predict(X):
    x = X[:, 0]
    a = 8.2664      # low-mass plateau (dex)
    b = 9.1183      # high-mass plateau (dex)
    x0 = 9.3673     # characteristic log10(M*)
    w = 0.5242      # transition width (dex)
    return a + (b - a) / (1.0 + np.exp(-(x - x0) / w))