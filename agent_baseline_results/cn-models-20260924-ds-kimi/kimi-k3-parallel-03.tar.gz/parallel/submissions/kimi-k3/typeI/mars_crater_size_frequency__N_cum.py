"""Mars crater cumulative SFD: Neukum/Ivanov production-function form —
log10(N_cum) is a high-degree polynomial in log10(D). Fitted degree-10
coefficients (least squares on log-log, noise ~0.02 dex, MAE ~0.007)."""
import numpy as np

USED_INPUTS = ["D_lower_km"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

# degree-10 polynomial coefficients, increasing powers of log10(D)
_C = [-2.62540e+00, -7.91300e-01, -5.36980e+00,  1.89025e+01, -3.20996e+01,
       3.06302e+01, -1.64555e+01,  4.32220e+00, -1.60900e-01, -1.58400e-01,
       2.39000e-02]

def predict(X):
    D = np.asarray(X[:, 0], dtype=float)
    D = np.clip(D, 1.0, 664.0)
    x = np.log10(D)
    y = np.zeros_like(x)
    for c in reversed(_C):
        y = y * x + c
    return 10.0 ** y