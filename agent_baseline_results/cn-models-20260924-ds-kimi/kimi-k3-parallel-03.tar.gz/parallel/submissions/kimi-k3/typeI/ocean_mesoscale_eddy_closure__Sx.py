"""Zonal SGS eddy momentum forcing: sum of independent saturating (tanh) responses
to each vorticity-gradient input, sharing a common saturation scale 1e-16 (s^-2 m^-1).
Sx = A1*tanh(x1/1e-16) + A2*tanh(x2/1e-16) + A3*tanh(x3/1e-16),
with fitted amplitudes A1=-7.07e-8, A2=+1.05e-7, A3=-1.10e-7 (m s^-2).
Each term is odd, linear with slope A_i/1e-16 near zero, and saturates at large |x_i|;
the responses add linearly across inputs (verified against multi-input probes)."""
import numpy as np

USED_INPUTS = ["d_zeta2_dx", "d_zetaD_dx", "d_zetaDtilde_dy"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    x1 = X[:, 0]
    x2 = X[:, 1]
    x3 = X[:, 2]
    b = 1e-16
    return (-7.07e-8 * np.tanh(x1 / b)
            + 1.05e-7 * np.tanh(x2 / b)
            - 1.10e-7 * np.tanh(x3 / b))