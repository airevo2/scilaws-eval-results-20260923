"""Cumulative NEO count N(<H): quadratic in log10-space (smooth power-law rollover in diameter)."""
import numpy as np

USED_INPUTS = ["H_upper"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    H = np.asarray(X[:, 0], dtype=float)
    log10N = -0.01188 * H**2 + 0.85877 * H - 8.51138
    return 10.0 ** log10N