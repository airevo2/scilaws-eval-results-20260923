"""Laser melt-pool depth as a power law in the process variables (normalized energy-density scaling), fitted to per-condition medians: d = A * P^a / (V^b * D^c). The simulator output is multiplicatively scattered across discrete regime levels (~x1.25 spacing), so the formula represents the underlying smooth mechanism."""
import numpy as np

USED_INPUTS = ["laser_power_W", "scan_velocity_mm_per_s", "beam_diameter_um"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    P = X[:, 0]
    V = X[:, 1]
    D = X[:, 2]
    return 362345.986 * np.power(P, 0.5454) / (np.power(V, 0.8620) * np.power(D, 1.2119))