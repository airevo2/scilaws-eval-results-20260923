"""Mauna Loa CO2: quadratic long-term trend plus a single annual sinusoidal cycle.

Mechanism: c(t) = a0 + a1*(t-1990) + a2*(t-1990)^2 + A*cos(2*pi*(t - phi)),
matching the standard decomposition of the Mauna Loa record into an
accelerating (quadratic) rise and a stable annual seasonal oscillation.
Constants were fit to the simulator observations by least squares.
"""
import numpy as np

USED_INPUTS = ["year_decimal"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    t = X[:, 0]
    tc = t - 1990.0
    trend = 352.177 + 1.59181 * tc + 0.0136539 * tc**2
    seasonal = -0.398979 * np.cos(2.0 * np.pi * (t - 0.0562591))
    return trend + seasonal