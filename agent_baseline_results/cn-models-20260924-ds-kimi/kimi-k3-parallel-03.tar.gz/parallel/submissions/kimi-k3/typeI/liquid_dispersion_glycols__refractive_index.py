"""Ethylene glycol refractive index: two-term Sellmeier dispersion in wavelength,
plus an additive thermo-optic term linear in (T - 20 degC) whose coefficient has a
Cauchy-like wavelength dependence (k0 + k1/lambda^2). Fitted jointly to simulator
data; residual std ~1.9e-4 vs measurement noise ~1.6e-4."""
import numpy as np

USED_INPUTS = ["lambda_um", "temperature_C"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    lam = X[:, 0]
    T = X[:, 1]
    l2 = lam * lam
    n2 = 1.0 + 1.023608456 * l2 / (l2 - 0.009299128802) + 0.007577321358 * l2 / (l2 - 2.386802513)
    n = np.sqrt(n2)
    return n + (-2.689628952e-4 + -4.517052339e-6 / l2) * (T - 20.0)