"""Semi-empirical mass formula (Bethe-Weizsaecker liquid-drop):
BE/A = av - as*A^(-1/3) - ac*Z^2*A^(-4/3) - aasy*(N-Z)^2/A^2 + ap*pair*A^(-3/4).
The simulator inputs Z, N, A, NZ_diff=N-Z and pair (delta=+1 even-even, 0 odd-A,
-1 odd-odd) map directly onto the five classic liquid-drop terms: volume, surface,
Coulomb, asymmetry, and pairing. Constants are least-squares fits of the standard
textbook coefficient values to the probed observations."""
import numpy as np

USED_INPUTS = ["Z", "N", "A", "NZ_diff", "pair"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    Z = X[:, 0]
    A = X[:, 2]
    I = X[:, 3]          # NZ_diff = N - Z
    pair = X[:, 4]       # +1 even-even, 0 odd-A, -1 odd-odd
    return (15.75
            - 19.35 * A**(-1.0/3.0)
            - 0.662 * Z**2 * A**(-4.0/3.0)
            - 19.42 * I**2 / A**2
            + 12.6 * pair * A**(-1.0))