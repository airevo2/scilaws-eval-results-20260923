"""Parker-spiral-like IMF azimuthal component at L1.

B_phi is anti-aligned with B_r with a speed-dependent ratio:
B_phi = -B_r * c0 / (v_sw + c2), a saturating function of solar-wind speed.
Fitted from simulator experiments (c0, c2 baked in). No r-dependence at r=1 AU.
"""
import numpy as np

USED_INPUTS = ["B_r_nT", "v_sw_km_s", "r_AU"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    B_r = X[:, 0]
    v_sw = X[:, 1]
    return -B_r * (813.5254 / (v_sw + 686.1573))