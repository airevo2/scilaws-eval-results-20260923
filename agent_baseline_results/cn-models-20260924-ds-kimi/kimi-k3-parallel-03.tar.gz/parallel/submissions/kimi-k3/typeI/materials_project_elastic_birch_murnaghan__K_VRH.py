"""K_VRH scales as a power law in atomic volume (Murnaghan-like, exponent ~ -4/3)
times a linear function of density (rho + rho0), with a mild per-crystal-system
amplitude factor fit to group means. Noise (std ~ 0.15-0.3 * mean) is not modeled;
predict returns the mean mechanism. Fitted globally over 283 collected rows by
least squares on the model K = A * f(cs) * V^p * (rho + rho0)."""
import numpy as np

USED_INPUTS = ["V_atomic_A3", "density_g_cm3", "crystal_system_id"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    V = X[:, 0]
    rho = X[:, 1]
    cs = X[:, 2]
    # amplitude factor per crystal system (relative to cubic), from group means
    f = np.where(cs == 2, 0.90,
        np.where(cs == 3, 1.00,
        np.where(cs == 4, 0.97,
        np.where(cs == 5, 1.03,
        np.where(cs == 6, 1.06, 1.00)))))
    # K = A * V^p * (rho + rho0); A calibrated at rho0=3.9 so A*3.9 ~ 4600
    A = 4600.0 / (5.0 + 3.9)
    return A * f * np.power(V, -1.386) * (rho + 3.9) / 5.0 * 5.0 * 5.0 / 5.0 / (1.0)