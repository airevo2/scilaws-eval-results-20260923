"""Basal metabolic rate vs body mass: smooth two-regime allometric transition.
log10(B/W) = a + b*log10(M) + log10(1 + (M/Mc)^d), transitioning from exponent b
at low mass to b+d at high mass; fitted constants baked in."""
import numpy as np

USED_INPUTS = ["body_mass_g"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    M = np.asarray(X[:, 0], dtype=float)
    logM = np.log10(M)
    # fitted via inverse-variance weighted least squares on collected observations
    a = -1.2793
    b = 0.2016
    c = -0.8650   # log10(Mc) location of the transition
    d = 0.6426
    return a + b * logM + np.log10(1.0 + 10.0 ** (c + d * logM))