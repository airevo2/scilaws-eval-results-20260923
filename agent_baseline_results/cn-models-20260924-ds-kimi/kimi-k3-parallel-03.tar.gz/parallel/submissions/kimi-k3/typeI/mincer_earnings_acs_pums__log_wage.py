"""Mincer-style wage equation: log_wage is additive in a linear schooling return
(~11.2 log-points per year of schooling) and a concave, saturating
(Michaelis–Menten-type) experience profile that rises quickly in the first
~15 years and plateaus by ~40 years of experience; no s-x interaction found."""
import numpy as np

USED_INPUTS = ["SCHL_years", "exp"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    s = X[:, 0]
    x = X[:, 1]
    return 8.4473 + 0.11243 * s + 1.0650 * x / (5.0134 + x)