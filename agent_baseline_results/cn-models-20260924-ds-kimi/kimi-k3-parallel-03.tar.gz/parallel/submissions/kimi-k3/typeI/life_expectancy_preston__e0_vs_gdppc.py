"""Sex-averaged life expectancy vs GDP per head: logistic saturation in log income (Preston-curve style), e0 = L / (1 + exp(-(ln Y - ln Y50)/s))."""
import numpy as np

USED_INPUTS = ["gdppc"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    Y = np.asarray(X[:, 0], dtype=float)
    return 78.39 / (1.0 + np.exp(-(np.log(Y) - 3.856) / 0.887))