"""18650 capacity fade vs cycle index: linear fade Q = a - b*k, the dominant
mechanism consistent with all 276 pooled observations (smooth nonlinear
alternatives gave no significant improvement; residual scatter is
heteroscedastic measurement noise, ~5% of capacity)."""
import numpy as np

USED_INPUTS = ["cycle_index"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    k = X[:, 0]
    return 1.898119 - 0.003898 * k