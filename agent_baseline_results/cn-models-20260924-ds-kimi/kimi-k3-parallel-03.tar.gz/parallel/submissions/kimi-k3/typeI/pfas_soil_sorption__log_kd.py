"""PFAS soil-water partitioning: log Kd is bilinear in log Kow and log10(foc)
(polyQSPR-style relation: sorption scales with hydrophobicity and organic-carbon
fraction). Experiments showed perfect linearity in both log_Kow and log10(foc)
across the full domain (chi2/dof ~ 1, no interaction or curvature), with fitted
coefficients 0.51 for log_Kow, 0.53 for log10(foc), intercept -0.55."""
import numpy as np

USED_INPUTS = ["log_Kow", "foc"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    log_kow = X[:, 0]
    foc = X[:, 1]
    return 0.51 * log_kow + 0.53 * np.log10(foc) - 0.55