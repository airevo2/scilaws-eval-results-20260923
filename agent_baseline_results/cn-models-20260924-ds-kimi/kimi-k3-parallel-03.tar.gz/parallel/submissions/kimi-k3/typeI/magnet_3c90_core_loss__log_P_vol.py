"""Volumetric ferrite core loss: composite Steinmetz law.
P_vol(kW/m^3) = K1*f^a1*B^b1 + K2*f^a2*B^b2 captures the smooth transition of the
effective B-exponent from ~1.6-1.8 at low peak flux density to ~2.6-2.7 at high
flux density, while the frequency exponent stays ~1.65 across the whole range."""
import numpy as np

USED_INPUTS = ["f_Hz", "B_peak_T"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    f = X[:, 0]
    B = X[:, 1]
    # Two-component loss: low-B (hysteresis-like, weaker B dependence)
    # plus high-B (strongly nonlinear, ~B^3.3) term sharing f-exponent ~1.65.
    P = 10**(-4.55) * f**1.65 * B**1.72 + 10**(-4.02) * f**1.65 * B**3.30
    return np.log10(P)