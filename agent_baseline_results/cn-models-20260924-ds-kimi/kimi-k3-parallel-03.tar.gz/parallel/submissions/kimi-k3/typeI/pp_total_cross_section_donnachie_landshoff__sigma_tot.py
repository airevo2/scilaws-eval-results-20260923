"""Proton-proton total cross-section: Froissart-Martin log-squared rise plus a
Regge subtraction term. sigma_tot = a + b*ln(s/s0)^2 + c*s^(-eta)."""
import numpy as np

USED_INPUTS = ["s"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    s = X[:, 0]
    a = 37.2516
    b = 0.3186
    s0 = 48.0546
    c = 14.6764
    eta = 0.5928
    return a + b * np.log(s / s0) ** 2 + c * np.power(s, -eta)