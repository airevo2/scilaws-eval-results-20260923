"""Urban-economics scaling law (Bettencourt-style): log_GMP is linear in log_pop with a
universal superlinear elasticity beta (~1.11-1.12) shared by every cluster; each cluster
only shifts the productivity level via its intercept alpha. Form: y = alpha + beta*x."""
import numpy as np

USED_INPUTS = ["log_pop"]
LAW_CONSTANTS = {"beta": 1.115}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {"alpha": {"init": None}}

def fit(X_fit, y_fit):
    x = np.asarray(X_fit[:, 0], dtype=float)
    y = np.asarray(y_fit, dtype=float)
    if y.size == 0 or not np.all(np.isfinite(y)):
        return {"alpha": -4.5}
    alpha = float(np.mean(y - LAW_CONSTANTS["beta"] * x))
    if not np.isfinite(alpha):
        alpha = -4.5
    return {"alpha": alpha}

def predict(X, alpha):
    x = np.asarray(X[:, 0], dtype=float)
    return alpha + LAW_CONSTANTS["beta"] * x