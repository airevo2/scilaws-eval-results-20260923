"""Tilting sharp-crested weir (lab flume): free overfall weir law with an
approach-velocity (velocity-head) correction that depends only on the
dimensionless head ratio h/p, plus a per-cluster discharge coefficient Cd
that absorbs the plate tilt angle for that cluster.

Shared mechanism (all clusters):
    Q = Cd * (2/3) * sqrt(2 g) * b * h^{3/2} * (1 + c_a * h/p)
        with g = 9.81 m/s^2 and a single universal constant c_a.

Only Cd varies between clusters (it encodes the tilted-plate contraction);
the h^{3/2} power, the linear-in-h/p approach correction, and c_a are
identical for every cluster."""
import numpy as np

USED_INPUTS = ["h_m", "p_m", "b_m"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {"g": 9.81, "c_a": 0.163}

LOCAL_FITTABLE = {"Cd": {"init": [0.62]}}

def _form(X, Cd, c_a=OTHER_CONSTANTS["c_a"], g=OTHER_CONSTANTS["g"]):
    h = X[:, 0]; p = X[:, 1]; b = X[:, 2]
    hp = np.clip(h / np.maximum(p, 1e-9), 0.0, None)
    return Cd * (2.0 / 3.0) * np.sqrt(2.0 * g) * b * np.power(np.maximum(h, 0.0), 1.5) * (1.0 + c_a * hp)

def fit(X_fit, y_fit):
    h = X_fit[:, 0]; p = X_fit[:, 1]; b = X_fit[:, 2]
    g = OTHER_CONSTANTS["g"]; c_a = OTHER_CONSTANTS["c_a"]
    hp = np.clip(h / np.maximum(p, 1e-9), 0.0, None)
    base = (2.0 / 3.0) * np.sqrt(2.0 * g) * b * np.power(np.maximum(h, 0.0), 1.5) * (1.0 + c_a * hp)
    denom = float(np.dot(base, base))
    Cd = float(np.dot(base, y_fit) / denom) if denom > 0 else 0.62
    if not np.isfinite(Cd) or Cd <= 0:
        Cd = 0.62
    return {"Cd": Cd}

def predict(X, Cd):
    return np.asarray(_form(X, Cd), dtype=float)