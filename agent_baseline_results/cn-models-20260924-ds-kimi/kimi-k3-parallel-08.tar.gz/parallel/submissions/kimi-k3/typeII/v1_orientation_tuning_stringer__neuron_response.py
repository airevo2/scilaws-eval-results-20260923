"""V1 orientation tuning: circular (wrapped) Gaussian on the 180-deg orientation
domain. R(theta) = A * exp(-0.5 * (d/sig)^2) + B, where d is the signed minimal
angular distance between theta and the preferred orientation modulo 180 deg.
Per-cluster params: A (amplitude), pref (preferred orientation), sig (width),
B (baseline). Fits on low-noise clusters gave residuals consistent with noise
and a fitted exponent ~2 (Gaussian beat von Mises and Cauchy on every group)."""
import numpy as np
from scipy.optimize import curve_fit

USED_INPUTS = ["orientation_deg"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {"A": {"init": None}, "pref": {"init": None},
                  "sig": {"init": None}, "B": {"init": None}}

def _dang(th, pref):
    d = np.mod(th - pref, 180.0)
    return np.where(d > 90.0, d - 180.0, d)

def _form(th, A, pref, sig, B):
    return A * np.exp(-0.5 * (_dang(th, pref) / sig) ** 2) + B

def fit(X_fit, y_fit):
    th = np.asarray(X_fit[:, 0], dtype=float)
    y = np.asarray(y_fit, dtype=float)
    span = float(np.max(y) - np.min(y))
    p0 = [max(span, 1e-6), float(th[int(np.argmax(y))]), 13.0, float(np.min(y))]
    try:
        popt, _ = curve_fit(_form, th, y, p0=p0, maxfev=8000)
        A, pref, sig, B = [float(v) for v in popt]
        pref = float(np.mod(pref, 180.0))
        sig = abs(sig) if np.isfinite(sig) and sig != 0 else 13.0
        if not np.all(np.isfinite([A, pref, sig, B])):
            raise ValueError
        return {"A": A, "pref": pref, "sig": sig, "B": B}
    except Exception:
        return {"A": p0[0], "pref": p0[1], "sig": 13.0, "B": p0[3]}

def predict(X, A, pref, sig, B):
    th = np.asarray(X[:, 0], dtype=float)
    sig = sig if (np.isfinite(sig) and abs(sig) > 1e-9) else 13.0
    out = _form(th, A, pref, sig, B)
    return np.where(np.isfinite(out), out, B)