"""Gompertz tumor-growth law, shared across all clusters:
V(t) = K * exp(-A * exp(-b * t)).
Per-cluster Richards fits collapse to the Gompertz limit (nu -> 0), and the
Gompertz form gives the best 3-parameter fit on the group-mean growth curves.
A, b, K are re-fit per cluster (per-animal growth curve)."""
import numpy as np

USED_INPUTS = ["time_day"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {"A": {"init": None}, "b": {"init": None}, "K": {"init": None}}

def _form(t, A, b, K):
    return K * np.exp(-A * np.exp(-b * t))

def fit(X_fit, y_fit):
    t = np.asarray(X_fit[:, 0], dtype=float)
    y = np.asarray(y_fit, dtype=float)
    y_pos = np.clip(y, 1e-6, None)
    ly = np.log(y_pos)
    best = None
    # Gompertz is linear in (log K, A) for fixed b: ly = logK - A*exp(-b t).
    for b in np.linspace(0.02, 0.35, 34):
        u = -np.exp(-b * t)
        M = np.column_stack([np.ones_like(t), u])
        try:
            coef, _, _, _ = np.linalg.lstsq(M, ly, rcond=None)
        except Exception:
            continue
        pred = np.exp(M @ coef)
        sse = float(np.sum((pred - y) ** 2))
        if np.isfinite(sse) and (best is None or sse < best[0]):
            best = (sse, b, coef[0], coef[1])
    if best is None:
        K_fb = max(float(np.nanmax(y_pos)), 1.0) * 2.0
        return {"A": 8.0, "b": 0.1, "K": K_fb}
    _, b_hat, logK, minusA = best
    K_hat = float(np.exp(logK))
    A_hat = float(max(-minusA, 1e-8))
    return {"A": A_hat, "b": float(b_hat), "K": K_hat}

def predict(X, A, b, K):
    t = np.asarray(X[:, 0], dtype=float)
    return _form(t, A, b, K)