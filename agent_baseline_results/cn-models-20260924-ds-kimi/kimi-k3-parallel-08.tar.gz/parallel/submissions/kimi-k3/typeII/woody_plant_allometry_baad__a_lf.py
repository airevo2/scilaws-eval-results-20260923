"""Leaf area from sapwood area and height: log a_lf = L + log(a_ssbh) - log(h_t) - d/(h_t*sqrt(a_ssbh)).

Structure identified from multi-cluster probing: at large a_ssbh all clusters converge to
a_lf ~ L0 * a_ssbh / h_t (unit exponents in sapwood area and inverse height). Deviations at
small a_ssbh follow a single curvature term d/(h*sqrt(a_ssbh)) with d universal across
clusters (identical h-curves at different a_ssbh collapse under this transform, and it
explains increasing, flat, and decreasing height-response clusters with one constant).
L is the only cluster-varying parameter (log leaf area per unit sapwood conducting area).
"""
import numpy as np

USED_INPUTS = ["a_ssbh", "h_t"]
LAW_CONSTANTS = {"d": 0.14}   # universal curvature constant (same across all clusters)
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {"L": {"init": None}}   # per-cluster log-scale of leaf area per sapwood area

_D = LAW_CONSTANTS["d"]

def fit(X_fit, y_fit):
    s = np.asarray(X_fit[:, 0], dtype=float)
    h = np.asarray(X_fit[:, 1], dtype=float)
    y = np.asarray(y_fit, dtype=float)
    s = np.clip(s, 1e-12, None)
    h = np.clip(h, 1e-12, None)
    y = np.clip(y, 1e-12, None)
    # closed-form per-cluster intercept given the shared form
    r = np.log(y) - np.log(s) + np.log(h) + _D / (h * np.sqrt(s))
    r = r[np.isfinite(r)]
    if r.size == 0:
        L = 11.1
    else:
        L = float(np.mean(r))
    if not np.isfinite(L):
        L = 11.1
    return {"L": L}

def predict(X, L):
    s = np.asarray(X[:, 0], dtype=float)
    h = np.asarray(X[:, 1], dtype=float)
    s = np.clip(s, 1e-12, None)
    h = np.clip(h, 1e-12, None)
    log_y = L + np.log(s) - np.log(h) - _D / (h * np.sqrt(s))
    log_y = np.clip(log_y, -30.0, 30.0)
    return np.exp(log_y)