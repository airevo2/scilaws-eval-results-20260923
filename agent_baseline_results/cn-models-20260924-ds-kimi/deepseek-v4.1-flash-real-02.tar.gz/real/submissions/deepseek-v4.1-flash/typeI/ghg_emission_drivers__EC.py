"""Power-law energy model: EC ~ TP * GDP-elasticity with temperature, age, urbanization effects."""
import numpy as np

USED_INPUTS = ["GDP", "TP", "AP", "UR", "AT"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    GDP = X[:, 0]
    TP = X[:, 1]
    AP = X[:, 2]
    UR = X[:, 3]
    AT = X[:, 4]
    L = np.log(GDP)
    log_EC = (1.0180 * np.log(TP) - 26.724
              + 2.5672 * L
              - 0.0405 * AT
              + 0.2810 * AP
              + 0.0090 * UR
              - 0.0298 * L * AP)
    return np.exp(log_EC)