"""Quadratic fit of gas-phase metallicity on stellar mass and SFR.

Physically motivated: the mass-metallicity relation (positive slope in M*),
a secondary SFR dependence (the fundamental metallicity relation), and mild
curvature/saturation represented by quadratic and cross terms. Centered at
log M* = 10 to keep coefficients well-conditioned.
"""
import numpy as np

USED_INPUTS = ["log_Mstar", "log_SFR"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    M = X[:, 0]
    S = X[:, 1]
    mc = M - 10.0
    return (8.9152
            + 0.217903 * mc
            + 0.048565 * S
            - 0.156053 * mc ** 2
            - 0.043886 * S ** 2
            + 0.119728 * mc * S)