"""Vickers hardness from lattice distortion, VEC, and mixing enthalpy.

Empirical model selected by cross-validation over polynomial feature
candidates built from delta, VEC and dHmix:
    HV = a*delta^2 + b*VEC^2*delta*dHmix + c*sqrt(VEC)
"""
import numpy as np

USED_INPUTS = ["delta", "VEC", "dHmix"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}


def predict(X):
    d = X[:, 0]      # delta (%)
    V = X[:, 1]      # VEC
    H = X[:, 2]      # dHmix (kJ/mol)
    a = -1.49210207
    b = -0.04468600
    c = 211.532972
    return a * d * d + b * (V * V * d * H) + c * np.sqrt(V)