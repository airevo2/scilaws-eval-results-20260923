"""Saturating power-law: national CH4 emissions scale with population and
per-capita income (with income saturation via a quadratic log term),
modulated by population density.
log(ME) = c0 + b*log(TP) + c*log(GDP) + d*log(GDP)^2 + e*log(DP)
"""
import numpy as np

USED_INPUTS = ["GDP", "TP", "DP"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    GDP = X[:, 0]
    TP = X[:, 1]
    DP = X[:, 3]
    lGDP = np.log(GDP)
    lTP = np.log(TP)
    lDP = np.log(DP)
    logME = 1.2506 + 1.0593 * lTP + 0.5114 * lGDP - 0.0178 * lGDP ** 2 - 0.3448 * lDP
    return np.exp(logME)