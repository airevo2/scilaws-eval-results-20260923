"""STIRPAT-style EKC model: log CDE = 1.0334*log(TP) + 2.9618*log(GDP) - 0.1378*log(GDP)^2 + 0.4074*log(UR) + 0.0407*AP - 0.0381*AT - 11.0746.
Per-capita emissions follow a concave (Environmental Kuznets) path in log GDP, with urbanisation,
working-age share, and temperature effects. Quadratic in log GDP keeps extrapolation flat/sensible
beyond the training range (test GDP extends well past train max)."""
import numpy as np

USED_INPUTS = ["GDP", "TP", "AP", "UR", "AT"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    GDP = X[:, 0]
    TP = X[:, 1]
    AP = X[:, 2]
    UR = X[:, 4]
    AT = X[:, 5]
    lg = np.log(GDP)
    ltp = np.log(TP)
    lur = np.log(UR)
    logCDE = (1.0334 * ltp
              + 2.9618 * lg
              - 0.1378 * lg ** 2
              + 0.4074 * lur
              + 0.0407 * AP
              - 0.0381 * AT
              - 11.0746)
    return np.exp(logCDE)