"""Stellar-mass estimator: physical absolute-magnitude + color + redshift (K-correction) model.

log10(M*/Msun) = a + b * F,  with F = (i - DM) - 1.5*(g - z) + 3.0*redshift
The -0.4-like luminosity scaling, the color coefficient (-1.5) and the redshift
K-correction weighting (3.0) are fixed physical structure; a and b are the two
fitted constants. Validated by a forward-chaining (low-z train -> high-z val)
experiment, which reproduces the extrapolation regime of the test set.
"""
import numpy as np

USED_INPUTS = ["u", "g", "r", "i", "z_mag", "redshift", "DM"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    g = X[:, 1]
    i = X[:, 3]
    zmag = X[:, 4]
    zred = X[:, 5]
    DM = X[:, 6]
    Mi = i - DM
    gz = g - zmag
    F = Mi - 1.5 * gz + 3.0 * zred
    return 1.799 - 0.3737 * F