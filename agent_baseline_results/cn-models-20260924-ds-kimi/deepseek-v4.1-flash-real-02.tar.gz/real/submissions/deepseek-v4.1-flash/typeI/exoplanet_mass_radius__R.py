"""Smooth double broken power law (Chen-Kipping style) mass-radius relation.

R = C * M^a * (1+(M/M1)^s)^((b-a)/s) * (1+(M/M2)^s)^((c-b)/s)

This reproduces the standard piecewise planet/brown-dwarf mass-radius relation:
terrestrial planets (R ~ M^0.28), a transition near ~2 M_earth, a giant-planet
plateau region, and a mild decline above ~130 M_earth (brown dwarf / massive
giant regime). The soft transition width s keeps the curve continuous and
well behaved when extrapolated beyond the training range.
"""
import numpy as np

USED_INPUTS = ["M"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}


def predict(X):
    M = np.asarray(X[:, 0], dtype=float)
    C = 1.00774
    a = 0.281980
    b = 0.589060
    c = -0.044151
    M1 = 2.05850
    M2 = 132.238915
    s = 48.96871
    R = (C * M ** a
         * (1.0 + (M / M1) ** s) ** ((b - a) / s)
         * (1.0 + (M / M2) ** s) ** ((c - b) / s))
    return R