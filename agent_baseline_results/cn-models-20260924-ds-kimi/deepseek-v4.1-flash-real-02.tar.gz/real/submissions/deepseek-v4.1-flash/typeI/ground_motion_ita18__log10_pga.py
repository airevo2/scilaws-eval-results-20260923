"""GMPE-style log10(PGA) with linear-Mw source term, Mw-dependent geometric
attenuation, anelastic attenuation, EC8 site-class and style-of-faulting terms.
"""
import numpy as np

USED_INPUTS = ["Mw", "R_km", "depth_km", "ec8_A", "ec8_B", "ec8_C", "ec8_D",
               "ec8_E", "sof_NF", "sof_TF", "sof_SS"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}


def predict(X):
    Mw = X[:, 0]
    R = X[:, 1]
    B = X[:, 4]
    C = X[:, 5]
    D = X[:, 6]
    E = X[:, 7]
    NF = X[:, 8]
    TF = X[:, 9]

    Re = np.sqrt(R ** 2 + 25.0)

    c0 = 1.82566
    c1 = 0.24729
    c3 = -2.47675
    c4 = 0.23373
    c5 = -0.00359
    sB = 0.05168
    sC = 0.24674
    sD = 0.10866
    sE = 0.39035
    fN = 0.00568
    fT = -0.12673

    y = (c0 + c1 * Mw
         + (c3 + c4 * Mw) * np.log10(Re)
         + c5 * Re
         + sB * B + sC * C + sD * D + sE * E
         + fN * NF + fT * TF)
    return y