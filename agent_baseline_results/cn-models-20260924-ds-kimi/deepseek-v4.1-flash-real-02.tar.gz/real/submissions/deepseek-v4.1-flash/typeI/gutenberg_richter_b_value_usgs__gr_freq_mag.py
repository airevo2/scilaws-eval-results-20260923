"""Gutenberg-Richter relation: log10_N = a - b*M, fitted by least squares."""
import numpy as np

USED_INPUTS = ["M_threshold"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    M = X[:, 0]
    return 8.135243 - 1.019130 * M