"""Physically-motivated Dst tendency: solar-wind injection (rectified V*Bs scaled by
sqrt(P_dyn) plus a Newell-type coupling) minus a ring-current recovery term
proportional to Dst, plus mild solar-wind-speed and Ey rectified contributions.
Linear least-squares fit on the full training set (7 fitted constants)."""
import numpy as np

USED_INPUTS = ["Dst", "Ey", "P_dyn", "V_sw", "Bz_GSM"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}


def predict(X):
    Dst = X[:, 0]
    Ey = X[:, 1]
    P = X[:, 2]
    V = X[:, 3]
    Bz = X[:, 4]

    sp = np.sqrt(P)
    VBs = V * np.minimum(Bz, 0.0)
    VBs_sp = VBs * sp
    Ep = np.maximum(Ey, 0.0)
    EpV = Ep * V

    BT = np.sqrt(V ** 2 * Bz ** 2 + Ey ** 2) / V
    newell = (V ** (4.0 / 3.0)) * (BT ** (2.0 / 3.0))

    return (1.996809
            + 7.84e-4 * VBs_sp
            - 5.2507e-2 * Dst
            + 9.1e-5 * newell
            - 4.777e-3 * V
            - 2.588123 * Ep
            + 3.142e-3 * EpV)