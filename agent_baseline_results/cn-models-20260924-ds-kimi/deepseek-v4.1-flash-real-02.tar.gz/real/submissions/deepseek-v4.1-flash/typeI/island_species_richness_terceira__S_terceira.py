"""Arthropod species richness declines exponentially with the anthropogenic
habitat-modification index (a saturating loss of native-forest species as
disturbance increases). Fitted on the 34 Terceira sites."""

import numpy as np

USED_INPUTS = ["d"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}


def predict(X):
    d = X[:, 0]
    return 15.85780259 * np.exp(-0.04778472 * d)