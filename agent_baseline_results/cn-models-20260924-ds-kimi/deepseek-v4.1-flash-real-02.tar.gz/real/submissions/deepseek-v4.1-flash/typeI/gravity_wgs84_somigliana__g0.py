"""Normal gravity via WGS84 Somigliana formula plus a fitted small systematic offset.

g(phi) = a*(1 + k*sin^2(phi)) / sqrt(1 - e2*sin^2(phi)) + c

The functional form is the standard Somigliana closed formula for normal gravity on
the WGS84 reference ellipsoid (physically motivated, behaves sensibly at all
latitudes). A single fitted constant `c` captures a small systematic bias present
in the observations, and empirically improves RMSE both in-sample and under
latitude extrapolation.
"""
import numpy as np

USED_INPUTS = ["latitude"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}


def predict(X):
    phi = X[:, 0]
    s2 = np.sin(np.deg2rad(phi)) ** 2
    # WGS84 normal gravity (Somigliana)
    a = 9.7803253359
    k = 0.00193185265241
    e2 = 0.00669437999013
    g = a * (1.0 + k * s2) / np.sqrt(1.0 - e2 * s2)
    # fitted systematic offset
    return g + 6.2734e-04