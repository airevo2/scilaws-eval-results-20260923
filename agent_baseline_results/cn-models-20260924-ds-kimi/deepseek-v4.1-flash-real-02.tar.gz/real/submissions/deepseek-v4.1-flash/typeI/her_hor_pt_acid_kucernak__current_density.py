"""Butler-Volmer HOR/HER with pressure- and temperature-dependent exchange current density.

j = j0 * [exp(alpha_a * F/(R T) * eta) - exp(-alpha_c * F/(R T) * eta)]
ln(j0) = a0 + a1*ln(P_H2) + a2/T

Fitted on training data (rmse ~ 8.4 A/cm^2).
"""
import numpy as np

USED_INPUTS = ["eta", "T", "P_H2"]   # X[:,0], X[:,1], X[:,2]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

F = 96485.0   # C/mol
Rs = 8.314    # J/(mol K)

def predict(X):
    eta = X[:, 0]
    T = X[:, 1]
    PH = X[:, 2]

    a0 = 12.0683
    a1 = 0.9058
    a2 = -1963.4123
    alpha_a = 0.2268
    alpha_c = 0.3868

    lnj0 = a0 + a1 * np.log(PH) + a2 / T
    j0 = np.exp(lnj0)
    f = F / (Rs * T)
    return j0 * (np.exp(alpha_a * f * eta) - np.exp(-alpha_c * f * eta))