"""Saturating thermocline depth vs lake morphometry.

Physically the summertime thermocline deepens with wind fetch (large surface
area) and is bounded by available depth.  A simple asymptotically saturating
form in the combined morphometric scale S = A_s + Z_max captures this:

    z_t = a * (1 - exp(-b * S^0.7))

with fitted constants a (asymptotic thermocline depth) and b (rate).
Two free constants only; fully extrapolation-safe (monotone, bounded).
"""
import numpy as np

USED_INPUTS = ["A_s_km2", "Z_max_m"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    A = X[:, 0]
    Zm = X[:, 1]
    S = A + Zm
    a = 13.150448287263568
    b = 0.08636439366717191
    return a * (1.0 - np.exp(-b * S ** 0.7))