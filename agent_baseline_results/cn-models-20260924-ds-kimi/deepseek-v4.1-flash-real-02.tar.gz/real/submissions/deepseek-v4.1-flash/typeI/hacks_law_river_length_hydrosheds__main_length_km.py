"""Main-stem river length: Hack's law on the upstream (crown) area plus terminal segment length.

Physically motivated form:
  L ≈ C * (A - A_c)^h + L_s
where (A - A_c) is the area contributing upstream of the outlet segment (the
"trunk" drainage that builds the main stem), h≈0.545 is the Hack exponent,
and L_s is the terminal reach length added back. Two fitted constants (C, h).
"""
import numpy as np

USED_INPUTS = ["upland_area_skm", "catch_area_skm", "segment_length_km"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    A = X[:, 0]
    Ac = X[:, 1]
    Ls = X[:, 2]
    Au = np.maximum(A - Ac, 1.0)
    C = 1.5714
    h = 0.545
    return C * Au ** h + Ls