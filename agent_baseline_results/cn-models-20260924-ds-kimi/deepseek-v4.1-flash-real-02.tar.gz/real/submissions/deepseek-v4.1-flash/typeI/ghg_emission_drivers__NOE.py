"""Log-linear N2O emission model: log(NOE) = a + b*log(TP) + c*log(GDP) + d*log(DP) + e*AP + f*AT + g*UR.
Emissions scale with population and land area (log DP enters negatively), with GDP, and with
demographic/climate covariates. Fitted by least squares on log(y/TP)."""
import numpy as np

USED_INPUTS = ["GDP", "TP", "AP", "DP", "UR", "AT"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    gdp = X[:, 0]
    tp = X[:, 1]
    ap = X[:, 2]
    dp = X[:, 3]
    ur = X[:, 4]
    at = X[:, 5]
    gdp = np.maximum(gdp, 1e-6)
    tp = np.maximum(tp, 1e-6)
    dp = np.maximum(dp, 1e-6)
    log_noe = (-0.062
               + 1.046 * np.log(tp)
               + 0.247 * np.log(gdp)
               - 0.305 * np.log(dp)
               - 0.012 * ap
               - 0.021 * at
               - 0.001 * ur)
    return np.exp(log_noe)