"""Hathaway (1994) asymmetric solar-cycle profile: each cluster (one Schwabe
cycle) follows ssn(t) = A*(t-t0)^3 / (exp((t-t0)^2/b^2) - 1) for t > t0,
zero before cycle start t0. A, t0, b are re-fit per cluster by least squares."""
import numpy as np
from scipy.optimize import curve_fit

USED_INPUTS = ["t_year"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {"A": {"init": None}, "t0": {"init": None}, "b": {"init": None}}

def _form(t, A, t0, b):
    t = np.asarray(t, dtype=float)
    x = t - t0
    out = np.zeros_like(x)
    m = x > 1e-9
    bb = max(abs(b), 1e-3)
    out[m] = A * x[m]**3 / np.expm1((x[m]/bb)**2)
    return out

def fit(X_fit, y_fit):
    t = np.asarray(X_fit[:, 0], dtype=float)
    y = np.asarray(y_fit, dtype=float)
    best = None
    for t0g in np.linspace(t.min() - 4.0, t.min() + 0.5, 13):
        for b0 in (2.5, 4.0, 6.0):
            try:
                popt, _ = curve_fit(_form, t, y, p0=[max(y.max(), 1.0)/10.0, t0g, b0], maxfev=4000)
                r = np.mean((y - _form(t, *popt))**2)
                if best is None or r < best[0]:
                    best = (r, popt)
            except Exception:
                pass
    if best is not None:
        p = best[1]
        return {"A": float(p[0]), "t0": float(p[1]), "b": float(p[2])}
    return {"A": float(max(y.max(), 1.0)/10.0), "t0": float(t.min() - 2.0), "b": 4.0}

def predict(X, A, t0, b):
    return np.nan_to_num(_form(np.asarray(X[:, 0], dtype=float), A, t0, b), nan=0.0, posinf=0.0, neginf=0.0)