"""van Genuchten (Mualem-constrained) soil-water retention curve:
theta(h) = theta_r + (theta_s - theta_r) / (1 + (alpha*h)^n)^m, m = 1 - 1/n.
All four parameters vary per cluster (soil)."""
import numpy as np
from scipy.optimize import least_squares

USED_INPUTS = ["lab_head_m"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {"theta_s": {"init": None}, "theta_r": {"init": None},
                  "alpha": {"init": None}, "n": {"init": None}}

def _form(h, theta_s, theta_r, alpha, n):
    h = np.maximum(h, 1e-12)
    n = max(n, 1.0001)
    m = 1.0 - 1.0/n
    return theta_r + (theta_s - theta_r) / (1.0 + (alpha*h)**n)**m

def fit(X_fit, y_fit):
    h = np.asarray(X_fit[:, 0], dtype=float)
    y = np.asarray(y_fit, dtype=float)
    ts0 = max(float(np.max(y)), 0.05)
    tr0 = max(min(float(np.min(y))*0.5, ts0*0.8), 0.0)
    best = None
    for p0 in ([ts0, tr0, 1.0, 1.3],
               [ts0, tr0, 10.0, 2.0],
               [ts0, tr0, 0.1, 1.1],
               [ts0, tr0, 2.0, 4.0],
               [ts0, 0.0, 3.0, 1.5]):
        try:
            r = least_squares(lambda p: _form(h, *p) - y, p0,
                              bounds=([1e-4, -0.5, 1e-5, 1.001], [3.0, 2.0, 1e6, 100.0]),
                              max_nfev=20000)
            if best is None or np.sum(r.fun**2) < np.sum(best.fun**2):
                best = r
        except Exception:
            continue
    if best is None:
        return {"theta_s": ts0, "theta_r": tr0, "alpha": 1.0, "n": 1.3}
    ts, tr, a, nn = best.x
    return {"theta_s": float(ts), "theta_r": float(tr), "alpha": float(a), "n": float(nn)}

def predict(X, theta_s, theta_r, alpha, n):
    return np.asarray(_form(np.asarray(X[:, 0], dtype=float),
                            theta_s, theta_r, alpha, n), dtype=float)