"""Depth-offset Chezy resistance law: V = C * sqrt(S_f * (R + c0)), shared across clusters.

Within-cluster scans of V vs hydraulic depth R show a clean square-root law with a
universal additive offset c0 (~0.085 m): V rises as sqrt(R) at large depth but flattens
to a nonzero floor at small depth, which a pure power law (R^a) or Manning form
(R^(2/3)) cannot reproduce (Manning SSE 0.38 vs 0.06 for the offset-Chezy form).
The bed slope S_f enters under the same square root (friction slope driving stress),
and each reach/cluster carries a single resistance coefficient C (= Chezy C = sqrt(8g/f),
equivalently a 1/n-type factor) that varies strongly between clusters. c0 and the
exponent 1/2 are universal; only C is refit per cluster by least squares.
"""
import numpy as np

USED_INPUTS = ["R_m", "SLOPE"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {"c0": 0.085}   # universal additive depth offset (m), shared by all clusters
LOCAL_FITTABLE = {"C": {"init": None}}   # per-cluster Chezy resistance coefficient

_C0 = 0.085

def fit(X_fit, y_fit):
    R = np.asarray(X_fit[:, 0], dtype=float)
    S = np.asarray(X_fit[:, 1], dtype=float)
    t = np.sqrt(np.clip(S, 0.0, None) * np.clip(R + _C0, 1e-9, None))
    tt = float(np.sum(t * t))
    if tt <= 0.0:
        return {"C": 1.0}
    C = float(np.sum(y_fit * t) / tt)
    if not np.isfinite(C) or C <= 0.0:
        C = 1.0
    return {"C": C}

def predict(X, C):
    R = np.asarray(X[:, 0], dtype=float)
    S = np.asarray(X[:, 1], dtype=float)
    t = np.sqrt(np.clip(S, 0.0, None) * np.clip(R + _C0, 1e-9, None))
    return np.asarray(C, dtype=float) * t