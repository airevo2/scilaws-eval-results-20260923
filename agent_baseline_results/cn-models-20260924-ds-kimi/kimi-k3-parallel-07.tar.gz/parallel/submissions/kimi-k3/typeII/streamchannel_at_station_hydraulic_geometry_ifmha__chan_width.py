"""At-a-station hydraulic geometry (Leopold & Maddock): water-surface width is a
power law of discharge, w = a * Q^b, with both the coefficient a and exponent b
varying per station (cluster). Multiplicative ~lognormal scatter; a and b are
negatively correlated across stations but not deterministically linked, so both
are fit per cluster via linear regression on log(w) vs log(Q)."""
import numpy as np

USED_INPUTS = ["chan_discharge"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {"a": {"init": None}, "b": {"init": None}}

def fit(X_fit, y_fit):
    Q = np.asarray(X_fit[:, 0], dtype=float)
    w = np.asarray(y_fit, dtype=float)
    mask = (Q > 0) & (w > 0) & np.isfinite(Q) & np.isfinite(w)
    if mask.sum() >= 2:
        logQ = np.log(Q[mask]); logw = np.log(w[mask])
        b, ln_a = np.polyfit(logQ, logw, 1)
        a = float(np.exp(ln_a)); b = float(b)
        if not (np.isfinite(a) and a > 0):
            a = float(np.exp(np.mean(logw))); b = 0.5
    else:
        a = float(np.max(np.mean(w), 1e-3)); b = 0.5
    return {"a": a, "b": b}

def predict(X, a, b):
    Q = np.asarray(X[:, 0], dtype=float)
    Q = np.clip(Q, 1e-12, None)
    return a * np.power(Q, b)