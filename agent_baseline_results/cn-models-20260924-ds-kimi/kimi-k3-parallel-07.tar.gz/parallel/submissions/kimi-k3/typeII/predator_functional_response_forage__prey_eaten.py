"""Generalized Holling disc equation: Na = a*N^q / (1 + a*Th*N^q), fit per cluster."""
import numpy as np
from scipy.optimize import curve_fit

USED_INPUTS = ["prey_density"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {"a": {"init": 1.0}, "Th": {"init": 0.05}}

_Q = 1.2  # shared shape exponent (type-II -> 1, type-III -> 2; best shared fit ~1.2)

def _form(N, a, Th):
    Nq = np.power(np.maximum(N, 1e-9), _Q)
    return a * Nq / (1.0 + a * Th * Nq)

def fit(X_fit, y_fit):
    N = np.asarray(X_fit[:, 0], dtype=float)
    y = np.asarray(y_fit, dtype=float)
    best = (1.0, 0.05)
    best_err = np.inf
    for a0, t0 in [(1.0, 0.05), (0.5, 0.02), (2.0, 0.1), (0.2, 0.005)]:
        try:
            popt, _ = curve_fit(_form, N, y, p0=[a0, t0],
                                bounds=([1e-6, 1e-6], [1e3, 1e3]), maxfev=8000)
            err = float(np.mean((y - _form(N, *popt)) ** 2))
            if err < best_err:
                best_err = err
                best = (float(popt[0]), float(popt[1]))
        except Exception:
            continue
    return {"a": best[0], "Th": best[1]}

def predict(X, a, Th):
    N = np.asarray(X[:, 0], dtype=float)
    return _form(N, a, Th)