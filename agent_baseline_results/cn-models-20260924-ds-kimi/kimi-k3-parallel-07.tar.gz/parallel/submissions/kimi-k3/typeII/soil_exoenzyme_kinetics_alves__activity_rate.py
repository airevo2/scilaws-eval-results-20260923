"""Michaelis-Menten enzyme kinetics: v = Vmax * S / (Km + S).
Shared functional form across all clusters; per-cluster Vmax and Km fit by NLS."""
import numpy as np
from scipy.optimize import curve_fit

USED_INPUTS = ["substrate_conc"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {"Vmax": {"init": None}, "Km": {"init": None}}

def _mm(S, Vmax, Km):
    return Vmax * S / (Km + S)

def fit(X_fit, y_fit):
    S = np.asarray(X_fit[:, 0], dtype=float)
    v = np.asarray(y_fit, dtype=float)
    vmax0 = max(float(np.max(v)) * 1.5, 1.0)
    km0 = max(float(np.median(S[S > 0])) if np.any(S > 0) else 50.0, 1.0)
    try:
        popt, _ = curve_fit(_mm, S, v, p0=[vmax0, km0],
                            bounds=([0.0, 1e-6], [np.inf, np.inf]), maxfev=20000)
        Vmax, Km = float(popt[0]), float(popt[1])
        if not (np.isfinite(Vmax) and np.isfinite(Km)):
            raise ValueError
    except Exception:
        Vmax, Km = vmax0, km0
    return {"Vmax": Vmax, "Km": Km}

def predict(X, Vmax, Km):
    S = np.asarray(X[:, 0], dtype=float)
    return _mm(S, Vmax, Km)