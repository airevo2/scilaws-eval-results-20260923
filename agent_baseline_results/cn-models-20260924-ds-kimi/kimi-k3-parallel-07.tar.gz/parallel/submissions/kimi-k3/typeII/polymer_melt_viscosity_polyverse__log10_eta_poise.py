"""Per-cluster Arrhenius law: log10(eta) = a + B/T, with intercept a and
activation slope B re-fit per cluster. Tg is a constant covariate within each
cluster and is not needed as a regressor once a and B are fit per cluster."""
import numpy as np

USED_INPUTS = ["Temperature_K", "Tg_K"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {"a": {"init": None}, "B": {"init": None}}

def fit(X_fit, y_fit):
    T = np.asarray(X_fit[:, 0], dtype=float)
    y = np.asarray(y_fit, dtype=float)
    x = 1.0 / T
    A = np.column_stack([np.ones_like(x), x])
    try:
        coef, *_ = np.linalg.lstsq(A, y, rcond=None)
        a_hat = float(coef[0]); B_hat = float(coef[1])
        if not (np.isfinite(a_hat) and np.isfinite(B_hat)):
            raise ValueError
    except Exception:
        B_hat = 2000.0
        a_hat = float(np.mean(y) - B_hat * np.mean(x))
    return {"a": a_hat, "B": B_hat}

def predict(X, a, B):
    T = np.asarray(X[:, 0], dtype=float)
    return a + B / T