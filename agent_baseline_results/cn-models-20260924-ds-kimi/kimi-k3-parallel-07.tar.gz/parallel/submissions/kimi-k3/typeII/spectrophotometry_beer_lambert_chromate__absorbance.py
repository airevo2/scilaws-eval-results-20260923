"""Beer-Lambert law with a second-order (quadratic-in-concentration) deviation.

A = a*c*l + b*c^2*l = a*l*(c + (b/a)*c^2)

The absorbance is linear in path length (l enters only as an overall factor),
but the effective absorptivity A/(c*l) increases linearly with concentration c,
i.e. a positive second-order deviation from the ideal Beer-Lambert law. The two
constants (a = first-order absorptivity, b = quadratic deviation coefficient)
are re-fit per cluster; both vary smoothly across clusters while the functional
form is shared.
"""
import numpy as np

USED_INPUTS = ["concentration", "path_length"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {"a": {"init": None}, "b": {"init": None}}

def _design(c, l):
    return np.column_stack([c * l, c * c * l])

def fit(X_fit, y_fit):
    c = np.asarray(X_fit[:, 0], dtype=float)
    l = np.asarray(X_fit[:, 1], dtype=float)
    y = np.asarray(y_fit, dtype=float)
    G = _design(c, l)
    try:
        coef, *_ = np.linalg.lstsq(G, y, rcond=None)
        a, b = float(coef[0]), float(coef[1])
        if not (np.isfinite(a) and np.isfinite(b)) or a <= 0:
            raise ValueError
        return {"a": a, "b": b}
    except Exception:
        cl = c * l
        denom = float(np.dot(cl, cl))
        a = float(np.dot(cl, y) / denom) if denom > 0 else 1.0
        if not np.isfinite(a) or a <= 0:
            a = 1.0
        return {"a": a, "b": 0.0}

def predict(X, a, b):
    c = np.asarray(X[:, 0], dtype=float)
    l = np.asarray(X[:, 1], dtype=float)
    return a * c * l + b * c * c * l