"""Vogel-Fulcher-Tammann (VFT) law for silicate-melt viscosity:
log10(eta) = A + B / (T - C), with per-cluster A, B, C (C = VFT singular temperature).
Narrow-range clusters fit this form to ~1e-3; wide-range clusters show heteroscedastic
noise around the same VFT shape (mid-range scatter, tight low/high-T ends).
"""
import numpy as np

USED_INPUTS = ["T"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {"A": {"init": None}, "B": {"init": None}, "C": {"init": None}}

def _ab_given_C(T, y, C):
    u = 1.0 / (T - C)
    M = np.column_stack([np.ones_like(u), u])
    coef, *_ = np.linalg.lstsq(M, y, rcond=None)
    r = y - M @ coef
    return float(np.sum(r * r)), float(coef[0]), float(coef[1])

def fit(X_fit, y_fit):
    T = np.asarray(X_fit[:, 0], dtype=np.float64)
    y = np.asarray(y_fit, dtype=np.float64)
    c_max = float(np.min(T)) - 1.0
    best = (np.inf, -3.0, 5000.0, 700.0)
    # coarse scan over the VFT temperature C, linear LSQ for A, B
    lo = c_max - 2000.0
    for C in np.arange(lo, c_max, 5.0):
        sse, A, B = _ab_given_C(T, y, C)
        if sse < best[0]:
            best = (sse, A, B, C)
    # refine around the best C
    C0 = best[3]
    for step in (1.0, 0.1):
        lo2 = max(C0 - 6.0 * step, c_max - 2000.0)
        hi2 = min(C0 + 6.0 * step, c_max - 1e-6)
        if hi2 <= lo2:
            continue
        for C in np.arange(lo2, hi2, step):
            sse, A, B = _ab_given_C(T, y, C)
            if sse < best[0]:
                best = (sse, A, B, C)
        C0 = best[3]
    return {"A": float(best[1]), "B": float(best[2]), "C": float(best[3])}

def predict(X, A, B, C):
    T = np.asarray(X[:, 0], dtype=np.float64)
    denom = T - C
    denom = np.where(np.abs(denom) < 1e-6, np.sign(denom) * 1e-6 + 1e-12, denom)
    return A + B / denom