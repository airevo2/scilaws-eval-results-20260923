"""Mean-normalized income model with a Pareto upper tail:
S(p) = p * (1 + c*(p^(-b) - 1)), so ln S = ln p + ln(1 + c*(p^-b - 1)).
The average quantile above p is qbar(p) = 1 - c + c*p^(-b): a power-law
(Pareto, tail index 1/b) tail anchored so that S(1)=1. Per-cluster scale c
and tail exponent b; identical functional shape for every cluster."""
import numpy as np
from scipy.optimize import least_squares

USED_INPUTS = ["log_p_above"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {"c": {"init": None}, "b": {"init": None}}

def _form(lp, c, b):
    p = np.exp(lp)
    inner = 1.0 + c * (np.power(p, -b) - 1.0)
    inner = np.maximum(inner, 1e-12)
    return lp + np.log(inner)

def fit(X_fit, y_fit):
    lp = np.asarray(X_fit[:, 0], dtype=float)
    y = np.asarray(y_fit, dtype=float)
    best = None
    for c0, b0 in ((1.0, 0.40), (2.0, 0.50), (1.5, 0.55), (0.8, 0.60), (2.5, 0.45)):
        try:
            r = least_squares(lambda t: _form(lp, t[0], t[1]) - y,
                              x0=[c0, b0],
                              bounds=([1e-3, 0.02], [50.0, 0.98]),
                              max_nfev=2000)
            ss = float(np.sum(r.fun ** 2))
            if best is None or ss < best[0]:
                best = (ss, r.x)
        except Exception:
            continue
    if best is None:
        return {"c": 1.5, "b": 0.5}
    return {"c": float(best[1][0]), "b": float(best[1][1])}

def predict(X, c, b):
    lp = np.asarray(X[:, 0], dtype=float)
    return _form(lp, float(c), float(b))