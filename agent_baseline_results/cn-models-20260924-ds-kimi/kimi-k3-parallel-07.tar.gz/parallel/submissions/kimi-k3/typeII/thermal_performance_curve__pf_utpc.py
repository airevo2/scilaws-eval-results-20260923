"""Sharpe-Schoolfield thermal performance curve: Arrhenius rise times high-temperature deactivation.
P(T) = A * exp(-(Eh/R)(1/Tk - 1/Tref)) / (1 + exp(-(Ed/R)(1/Tk - 1/Thd)))
Per-cluster params: scale A (absorbs unit), activation energy Eh, deactivation energy Ed, deactivation temp Thd."""
import numpy as np
from scipy.optimize import least_squares

USED_INPUTS = ["temperature"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {"R": 8.314e-3, "Tref": 298.15}
LOCAL_FITTABLE = {"A": {"init": None}, "Eh": {"init": None}, "Ed": {"init": None}, "Thd": {"init": None}}

_R = 8.314e-3
_Tref = 298.15

def _form(t, A, Eh, Ed, Thd):
    Tk = np.asarray(t, float) + 273.15
    ThdK = Thd + 273.15
    rise = np.exp(-(Eh/_R)*(1.0/Tk - 1.0/_Tref))
    den = 1.0 + np.exp(-(Ed/_R)*(1.0/Tk - 1.0/ThdK))
    return A * rise / den

def fit(X_fit, y_fit):
    t = np.asarray(X_fit[:, 0], float)
    y = np.asarray(y_fit, float)
    ymax = float(np.max(np.abs(y))) if y.size and np.max(np.abs(y)) > 0 else 1.0
    tmax = float(np.max(t)) if t.size else 25.0

    def resid(p):
        return _form(t, p[0], p[1], p[2], p[3]) - y

    starts = [
        [ymax, 0.5, 2.0, tmax + 8.0],
        [ymax, 0.7, 3.0, tmax + 5.0],
        [ymax, 0.4, 1.5, tmax + 12.0],
        [ymax, 1.0, 4.0, tmax + 3.0],
    ]
    best = None
    for s in starts:
        try:
            r = least_squares(resid, s, method="lm", max_nfev=20000)
            ss = float(np.sum(r.fun ** 2))
            if best is None or ss < best[0]:
                best = (ss, r.x)
        except Exception:
            continue
    if best is None:
        return {"A": ymax, "Eh": 0.6, "Ed": 2.0, "Thd": tmax + 8.0}
    p = best[1]
    return {"A": float(p[0]), "Eh": float(p[1]), "Ed": float(p[2]), "Thd": float(p[3])}

def predict(X, A, Eh, Ed, Thd):
    y = _form(X[:, 0], A, Eh, Ed, Thd)
    return np.where(np.isfinite(y), y, 0.0)