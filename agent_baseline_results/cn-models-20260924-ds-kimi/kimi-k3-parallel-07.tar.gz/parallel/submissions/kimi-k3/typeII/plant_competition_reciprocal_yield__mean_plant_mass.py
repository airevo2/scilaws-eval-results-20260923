"""Law of constant final yield: mean per-plant mass w = a / N.

Total above-ground dry mass per pot approaches a cluster-specific constant a
(resource-limited carrying capacity), so the mean mass per surviving plant
scales as the reciprocal of harvest density N (plants/pot). The pot-area-to-
plants/m^2 conversion is absorbed into the per-cluster amplitude a, which is
re-fit for every cluster. Fitting is robust: a is the median of w*N within a
cluster (stable against the heavy-tailed observation noise seen at high N).
"""
import numpy as np

USED_INPUTS = ["density"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {"a": {"init": None}}

def fit(X_fit, y_fit):
    N = np.asarray(X_fit[:, 0], dtype=float)
    y = np.asarray(y_fit, dtype=float)
    prod = y * N  # = a + noise*N under w = a/N
    prod = prod[np.isfinite(prod)]
    if prod.size == 0:
        return {"a": 1.0}
    a = float(np.median(prod))
    if not np.isfinite(a) or a <= 0.0:
        # fallback: least squares on w = a/N
        denom = float(np.sum(1.0 / (N * N)))
        a = float(np.sum(y / N) / denom) if denom > 0 else 1.0
    if not np.isfinite(a) or a <= 0.0:
        a = 1.0
    return {"a": a}

def predict(X, a):
    N = np.asarray(X[:, 0], dtype=float)
    N = np.maximum(N, 1e-9)
    return a / N