"""Logistic time-trend with linear age interaction, per-cluster amplitude/midpoint/slope.

ln(sex ratio) = L * S(year) * (1 + b*(age-60)), S = 1/(1+exp(-k*(year-t0))),
with shared constants k and b, and per-cluster L, t0, and a cluster-specific
calibration of scale. We fit per cluster: L (amplitude), t0 (midpoint year),
and b (age interaction); k is shared via a fixed constant estimated from data.
"""
import numpy as np
from scipy.optimize import curve_fit

USED_INPUTS = ["age", "year"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {"L": {"init": None}, "t0": {"init": None}, "b": {"init": None}}

_K = 0.022  # shared logistic rate (estimated across groups)

def _S(year, t0):
    return 1.0/(1.0 + np.exp(-_K*(year - t0)))

def _form(X, L, t0, b):
    age = X[:, 0]; year = X[:, 1]
    return L*_S(year, t0)*(1.0 + b*(age - 60.0))

def fit(X_fit, y_fit):
    age = X_fit[:, 0]; year = X_fit[:, 1]
    def f(X, L, t0, b):
        a, y = X
        return L*(1.0/(1.0+np.exp(-_K*(y-t0))))*(1.0 + b*(a-60.0))
    p0 = [max(0.6, float(np.nanmax(y_fit))+0.1), 1950.0, -0.008]
    try:
        popt, _ = curve_fit(f, (age, year), y_fit, p0=p0, maxfev=20000)
        L, t0, b = float(popt[0]), float(popt[1]), float(popt[2])
    except Exception:
        L, t0, b = p0[0], p0[1], p0[2]
    return {"L": L, "t0": t0, "b": b}

def predict(X, L, t0, b):
    return _form(X, L, t0, b)