"""Solar spectral radiance: single-temperature Planck (blackbody) law,
L = A * lambda^-5 / (exp(C2/(lambda*T)) - 1), with the second radiation
constant C2 = hc/k = 1.4387769e7 nm*K fixed as a universal physical
constant. The amplitude A (emissivity/solid-angle scale) is re-fit per
cluster; T is fixed at the shared effective solar temperature (~5527 K)
recovered from the cross-cluster consensus spectrum. Per-cluster fit
solves the linear least-squares amplitude against the cluster's
wavelength/radiance window."""
import numpy as np

USED_INPUTS = ["wavelength_nm"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {"C2_nm_K": 1.4387769e7, "T_eff_K": 5526.6}
LOCAL_FITTABLE = {"A": {"init": None}}

def _planck_shape(wl_nm):
    wl = np.asarray(wl_nm, dtype=float)
    wl = np.maximum(wl, 1.0)
    C2 = OTHER_CONSTANTS["C2_nm_K"]
    T = OTHER_CONSTANTS["T_eff_K"]
    x = C2 / (wl * T)
    x = np.clip(x, 1e-12, 700.0)
    return wl**-5 / np.expm1(x)

def fit(X_fit, y_fit):
    wl = np.asarray(X_fit[:, 0], dtype=float)
    y = np.asarray(y_fit, dtype=float)
    f = _planck_shape(wl)
    m = np.isfinite(y) & np.isfinite(f) & (f > 0)
    if m.sum() < 1:
        return {"A": 1.4e20}
    # linear least squares for amplitude
    A_hat = float(np.dot(f[m], y[m]) / np.dot(f[m], f[m]))
    if not np.isfinite(A_hat) or A_hat <= 0:
        A_hat = 1.4e20
    return {"A": A_hat}

def predict(X, A):
    wl = np.asarray(X[:, 0], dtype=float)
    y = A * _planck_shape(wl)
    y = np.where(np.isfinite(y), y, 0.0)
    return y