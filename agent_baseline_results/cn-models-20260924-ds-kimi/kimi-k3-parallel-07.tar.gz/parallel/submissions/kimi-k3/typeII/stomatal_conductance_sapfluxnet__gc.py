"""Shared declining canopy-conductance law: Gc = a / (1 + b*D) (a saturating/Michaelis
form in VPD), with per-cluster reference conductance a and VPD-sensitivity b.
Across groups the response is a smooth, gently convex decline from a group-specific
reference level; this two-parameter form captures both the flat (b->0) and strongly
declining clusters with one shared shape."""
import numpy as np
from scipy.optimize import curve_fit

USED_INPUTS = ["vpd"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {"a": {"init": None}, "b": {"init": None}}

def _form(D, a, b):
    return a / (1.0 + b * D)

def fit(X_fit, y_fit):
    D = np.asarray(X_fit[:, 0], dtype=float)
    y = np.asarray(y_fit, dtype=float)
    a0 = float(max(np.max(y), 1e-3))
    b0 = 0.3
    try:
        popt, _ = curve_fit(_form, D, y, p0=[a0, b0], maxfev=8000)
        a, b = float(popt[0]), float(popt[1])
        if not (np.isfinite(a) and np.isfinite(b)):
            raise ValueError
        return {"a": a, "b": b}
    except Exception:
        return {"a": a0, "b": 0.0}

def predict(X, a, b):
    D = np.asarray(X[:, 0], dtype=float)
    return a / (1.0 + b * D)