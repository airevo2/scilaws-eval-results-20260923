"""Apparent-absorbance law for aqueous potassium dichromate.

The blank-subtracted absorbance obeys A = l * h(c): the measured signal is the
optical path length times a function of concentration only (verified: at fixed
c, A/l is identical across all path lengths to <2%). The concentration response
is a saturating (Michaelis-type) law h(c) = a*c/(1+b*c), which reduces to the
linear Beer-Lambert law a*c*l at low concentration and bends over at high
concentration as the dichromate/chromate speciation shifts. One shared
functional form is used for every cluster; only the amplitude `a` (effective
absorptivity) and the curvature `b` are re-fit per cluster.
"""
import numpy as np
from scipy.optimize import minimize_scalar

USED_INPUTS = ["concentration", "path_length"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {"a": {"init": None}, "b": {"init": None}}

def _u(c, b):
    return c / (1.0 + b * c)

def fit(X_fit, y_fit):
    c = np.asarray(X_fit[:, 0], dtype=float)
    l = np.asarray(X_fit[:, 1], dtype=float)
    A = np.asarray(y_fit, dtype=float)

    def sse(b):
        u = _u(c, b)
        x = l * u
        den = float(np.sum(x * x))
        if den <= 1e-12:
            return 1e18
        a = float(np.sum(x * A) / den)
        return float(np.sum((l * a * u - A) ** 2))

    a_hat, b_hat = 5.0, 0.0
    try:
        res = minimize_scalar(sse, bounds=(-0.9, 5.0), method="bounded")
        b_hat = float(res.x)
        u = _u(c, b_hat)
        x = l * u
        den = float(np.sum(x * x))
        if den > 1e-12:
            a_hat = float(np.sum(x * A) / den)
        if not (np.isfinite(a_hat) and np.isfinite(b_hat)):
            a_hat, b_hat = 5.0, 0.0
    except Exception:
        # Fallback: plain Beer-Lambert linear fit (b = 0).
        try:
            x = l * c
            den = float(np.sum(x * x))
            a_hat = float(np.sum(x * A) / den) if den > 1e-12 else 5.0
            b_hat = 0.0
        except Exception:
            a_hat, b_hat = 5.0, 0.0
    return {"a": a_hat, "b": b_hat}

def predict(X, a, b):
    c = np.asarray(X[:, 0], dtype=float)
    l = np.asarray(X[:, 1], dtype=float)
    a = float(a); b = float(b)
    den = 1.0 + b * c
    # Guard against a pole inside the queried concentration range.
    tiny = 1e-9
    den = np.where(np.abs(den) < tiny, np.sign(den) * tiny + (den == 0) * tiny, den)
    y = l * a * c / den
    return np.asarray(y, dtype=float)