"""Chezy-type resistance law: V = C * sqrt(R * S_f), with one robustly
fitted per-cluster conveyance coefficient C (equivalently 1/n-style or
Chezy-C per reach). SLOPE is constant within each cluster, so the
per-cluster coefficient absorbs any slope-exponent deviation; the
sqrt(R*S) shape is monotone and extrapolates safely."""
import numpy as np

USED_INPUTS = ["R_m", "SLOPE"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {"C": {"init": None}}

def _shape(X):
    R = np.maximum(X[:, 0], 0.0)
    S = np.maximum(X[:, 1], 0.0)
    return np.sqrt(R * S)

def fit(X_fit, y_fit):
    f = _shape(X_fit)
    y = np.asarray(y_fit, dtype=float)
    den = float(np.sum(f * f))
    if den <= 0.0:
        return {"C": 0.0}
    a = float(np.sum(f * y) / den)
    # Huber IRLS refinement for robustness to measurement outliers
    for _ in range(6):
        res = y - a * f
        s = 1.4826 * float(np.median(np.abs(res))) + 1e-12
        w = np.minimum(1.0, 1.345 * s / np.abs(res + 1e-18))
        den2 = float(np.sum(w * f * f))
        if den2 <= 0.0:
            break
        a = float(np.sum(w * f * y) / den2)
    return {"C": a}

def predict(X, C):
    return C * _shape(X)