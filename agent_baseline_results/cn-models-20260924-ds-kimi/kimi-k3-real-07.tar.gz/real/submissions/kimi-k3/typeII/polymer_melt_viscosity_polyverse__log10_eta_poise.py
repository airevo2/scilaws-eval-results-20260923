"""Polymer melt viscosity: per-cluster 2-param temperature law (VFT/Andrade
intercept A and slope B with Tg-shifted universal divergence offset delta),
plus universal entanglement crossover in Mw (Mc) and universal Carreau-Yasuda
shear-thinning tied to the zero-shear viscosity. Only A and B vary per cluster.

  log10_eta0 = A + B/(T - Tg + delta) + log10(Mw/Mc) + 2.4*log10(1+(Mw/Mc))
  log10_eta  = log10_eta0 - log10(1 + (10^logk * eta0 * gamma_dot)^m)
"""
import numpy as np
from scipy.optimize import least_squares

USED_INPUTS = ["Temperature_K", "log10_Mw", "Shear_Rate", "Tg_K"]

LAW_CONSTANTS = {}

# Universal (shared across all clusters) constants.
OTHER_CONSTANTS = {
    "delta": 176.468,   # Tg-shifted Vogel offset (K), shared temperature shape
    "logMc": 4.774,     # log10 entanglement crossover molecular weight (g/mol)
    "logk": -4.459,     # log10 Carreau relaxation-time prefactor (per unit eta0)
    "m": 0.2,           # Carreau-Yasuda shear-thinning exponent
}

LOCAL_FITTABLE = {
    "a": {"init": None},   # per-cluster intercept (log10 poise)
    "b": {"init": None},   # per-cluster Vogel slope (K)
}

def _fM(logMw, logMc):
    # Entanglement crossover: slope 1 below Mc -> 3.4 above Mc (softplus blend),
    # centred so it vanishes at the reference (kept inside A implicitly).
    return logMw + 2.4 * np.log10(1.0 + 10.0 ** (logMw - logMc))

def fit(X_fit, y_fit):
    T = X_fit[:, 0].astype(float)
    logMw = X_fit[:, 1].astype(float)
    sr = np.maximum(X_fit[:, 2].astype(float), 0.0)
    Tg = X_fit[:, 3].astype(float)

    d = OTHER_CONSTANTS["delta"]
    logMc = OTHER_CONSTANTS["logMc"]
    logk = OTHER_CONSTANTS["logk"]
    m = OTHER_CONSTANTS["m"]

    fT = 1.0 / (T - Tg + d)
    fM = _fM(logMw, logMc)

    a, b = 0.0, 500.0
    shear = np.zeros_like(y_fit)
    # Alternating least squares: linear (a,b) given shear term; shear from eta0.
    for _ in range(12):
        resid = y_fit - fM - shear
        Xd = np.column_stack([np.ones(len(T)), fT])
        try:
            coef, *_ = np.linalg.lstsq(Xd, resid, rcond=None)
            a, b = float(coef[0]), float(coef[1])
        except Exception:
            a, b = float(np.mean(resid)), 0.0
        eta0 = 10.0 ** (a + b * fT + fM)
        lam = (10.0 ** logk) * eta0
        shear = -np.log10(1.0 + (lam * sr) ** m)

    if not (np.isfinite(a) and np.isfinite(b)):
        a, b = float(np.mean(y_fit)), 0.0
    return {"a": a, "b": b}

def predict(X, a, b):
    T = X[:, 0].astype(float)
    logMw = X[:, 1].astype(float)
    sr = np.maximum(X[:, 2].astype(float), 0.0)
    Tg = X[:, 3].astype(float)

    d = OTHER_CONSTANTS["delta"]
    logMc = OTHER_CONSTANTS["logMc"]
    logk = OTHER_CONSTANTS["logk"]
    m = OTHER_CONSTANTS["m"]

    fT = 1.0 / (T - Tg + d)
    fM = _fM(logMw, logMc)

    eta0 = 10.0 ** (a + b * fT + fM)
    lam = (10.0 ** logk) * eta0
    y_pred = (a + b * fT + fM) - np.log10(1.0 + (lam * sr) ** m)
    return np.asarray(y_pred, dtype=float)