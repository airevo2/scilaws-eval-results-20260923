"""Fredlund-Xing soil-water characteristic curve: theta(h) = theta_r + (theta_s - theta_r)/ln(e + (h/a)^n). Four per-cluster parameters (theta_s, theta_r, a, n) fit by robust multi-start softplus-parameterized least squares."""
import numpy as np
from scipy.optimize import least_squares

USED_INPUTS = ["lab_head_m"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {
    "theta_s": {"init": None},
    "theta_r": {"init": None},
    "a": {"init": None},
    "n": {"init": None},
}

def _softplus(x):
    return np.logaddexp(0.0, x)

def _form(h, theta_s, theta_r, la, ln_):
    a = _softplus(la)
    n = 0.05 + _softplus(ln_)
    h = np.asarray(h, dtype=float)
    return theta_r + (theta_s - theta_r) / np.log(np.e + (h / a) ** n)

def fit(X_fit, y_fit):
    h = np.asarray(X_fit[:, 0], dtype=float)
    t = np.asarray(y_fit, dtype=float)
    h = np.clip(h, 1e-9, None)
    tmax = float(np.max(t))
    tmin = float(np.min(t))
    lb = np.array([tmax * 0.9, 0.0, -12.0, -6.0])
    ub = np.array([max(tmax * 2.5, tmax + 1e-3), max(tmax * 1.05, 1e-3), 10.0, 4.0])
    best = None
    for p2_0 in (-3.0, 0.0):
        p0 = np.array([tmax * 1.02, max(1e-4, 0.3 * tmin), p2_0, 0.0])
        p0 = np.minimum(np.maximum(p0, lb + 1e-9), ub - 1e-9)
        try:
            r = least_squares(lambda p: _form(h, *p) - t, p0, bounds=(lb, ub),
                              method="trf", max_nfev=400)
            ss = float(np.sum(r.fun ** 2))
            if best is None or ss < best[0]:
                best = (ss, r.x)
        except Exception:
            pass
    if best is None:
        p = np.array([max(tmax, 1e-3), max(1e-4, 0.3 * tmin), np.log(0.1), np.log(0.5)])
    else:
        p = best[1]
    return {
        "theta_s": float(p[0]),
        "theta_r": float(p[1]),
        "a": float(p[2]),
        "n": float(p[3]),
    }

def predict(X, theta_s, theta_r, a, n):
    h = np.clip(np.asarray(X[:, 0], dtype=float), 1e-9, None)
    y = _form(h, theta_s, theta_r, a, n)
    return np.clip(np.nan_to_num(y, nan=theta_s, posinf=theta_s, neginf=theta_r), 0.0, None)