"""Generalized Ivlev functional response, fit per cluster.

Na = A*(1 - exp(-b*N)), with a smooth linear guard A*b*N for very low
prey density (N < 1/sqrt(b)) so the slope stays finite at the origin and
predictions extrapolate sensibly. A (asymptote) and b (rate) are re-fit
per cluster by Nelder-Mead on (A, log b); b>0 is enforced via the log.
"""
import numpy as np
from scipy.optimize import minimize

USED_INPUTS = ["prey_density"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {"A": {"init": None}, "b": {"init": None}}

def _form(N, A, b):
    N = np.asarray(N, dtype=float)
    c = np.sqrt(np.abs(b)) + 1e-300
    return np.where(N < 1.0/c, A*b*N, A*(1.0 - np.exp(-b*N)))

def fit(X_fit, y_fit):
    N = np.asarray(X_fit[:, 0], dtype=float)
    y = np.asarray(y_fit, dtype=float)
    A0 = max(float(np.max(y)) * 1.3, 1e-3)
    def obj(p):
        A, lb = p
        b = np.exp(np.clip(lb, -30, 10))
        pred = _form(N, A, b)
        if not np.all(np.isfinite(pred)):
            return 1e18
        return float(np.sum((pred - y) ** 2))
    try:
        r = minimize(obj, [A0, np.log(0.05)], method="Nelder-Mead",
                     options={"maxiter": 2000, "xatol": 1e-8, "fatol": 1e-10})
        if r.success and np.isfinite(r.fun):
            A = float(r.x[0]); b = float(np.exp(np.clip(r.x[1], -30, 10)))
            if A > 0 and b > 0:
                return {"A": A, "b": b}
    except Exception:
        pass
    return {"A": A0, "b": 0.05}

def predict(X, A, b):
    return _form(X[:, 0], A, b)