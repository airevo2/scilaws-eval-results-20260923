"""Solar-cycle sunspot model (Hathaway et al. 1994 functional form).

Each cluster is one ~11-year solar cycle. Within a cycle the monthly mean SSN
follows a skewed rise-and-decline curve driven by cycle phase (t - t0):

    ssn(t) = A * ((t-t0)/b)^3 / exp(((t-t0)/b)^2),   for t > t0 (else ~0)

Per-cluster parameters: A (amplitude), t0 (cycle start time), b (width/period
scale). The cubic-over-exponential shape captures the rapid rise and slow decay
of solar cycles; it is bounded, non-negative, and decays sensibly when
extrapolated beyond the observed window.
"""
import numpy as np
from scipy.optimize import least_squares

USED_INPUTS = ["t_year"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {
    "A":  {"init": [100.0, 300.0, 600.0]},
    "t0": {"init": [0.5, 2.0, 5.0]},     # offset (yr) before window start
    "b":  {"init": [2.5, 4.0, 5.5]},
}

def _model(t, A, t0, b):
    x = np.maximum((np.asarray(t, float) - t0) / b, 1e-6)
    return A * x**3 / np.exp(np.clip(x**2, 0.0, 60.0))

def fit(X_fit, y_fit):
    t = np.asarray(X_fit[:, 0], float)
    y = np.asarray(y_fit, float)
    tmin = float(t.min())
    ymx = float(max(y.max(), 40.0))

    def resid(p):
        A = np.exp(p[0]); t0 = tmin - 12.0 + np.exp(p[1]); b = 0.3 + np.exp(p[2])
        return _model(t, A, t0, b) - y

    best = None
    for A0 in (ymx*0.5, ymx, ymx*2.0):
        for off0 in (0.5, 2.0, 5.0):
            for b0 in (2.5, 4.0, 5.5):
                try:
                    r = least_squares(resid, [np.log(A0), np.log(off0), np.log(b0-0.3)],
                                      loss="soft_l1", f_scale=15.0, max_nfev=2500)
                    if best is None or r.cost < best.cost:
                        best = r
                except Exception:
                    pass
    if best is None:
        return {"A": ymx, "t0": tmin - 2.0, "b": 4.0}
    p = best.x
    A = float(np.exp(p[0]))
    t0 = float(tmin - 12.0 + np.exp(p[1]))
    b = float(0.3 + np.exp(p[2]))
    # keep parameters in a sane physical range for stable extrapolation
    A = float(np.clip(A, 1.0, 3000.0))
    b = float(np.clip(b, 0.5, 12.0))
    return {"A": A, "t0": t0, "b": b}

def predict(X, A, t0, b):
    t = np.asarray(X[:, 0], float)
    y = _model(t, A, t0, b)
    y = np.where(np.isfinite(y), y, 0.0)
    return np.maximum(y, 0.0)