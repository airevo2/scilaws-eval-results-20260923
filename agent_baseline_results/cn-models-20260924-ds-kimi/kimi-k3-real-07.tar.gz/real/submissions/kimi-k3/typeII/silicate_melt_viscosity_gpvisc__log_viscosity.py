"""Per-cluster Vogel-Fulcher-Tammann (VFT) law for silicate-melt viscosity.

log10(eta) = a + b / (T - c)

Composition is essentially constant within each experimental cluster (the
temperature series), so the physically correct generalizing law is the VFT
temperature dependence, with its three parameters re-fit on each cluster's
fit window. This transfers to unseen clusters because VFT is universal for
silicate melts; no global fitted constants are required (within the cap).
Falls back to an Arrhenius form (c=0) or a constant when the fit window is
too small or the VFT fit is unstable, and predictions are clamped to stay
finite and physically sensible under extrapolation.
"""
import numpy as np
from scipy.optimize import curve_fit

USED_INPUTS = ["T"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {
    "a": {"init": [-5.0]},
    "b": {"init": [5000.0]},
    "c": {"init": [0.0]},
}


def _vft(T, a, b, c):
    den = T - c
    den = np.where(np.abs(den) < 1e-6, np.sign(den) * 1e-6 + 1e-6, den)
    return a + b / den


def fit(X_fit, y_fit):
    T = np.asarray(X_fit[:, 0], dtype=float)
    y = np.asarray(y_fit, dtype=float)
    ok = np.isfinite(T) & np.isfinite(y)
    T = T[ok]; y = y[ok]
    if T.size == 0:
        return {"a": 5.0, "b": 0.0, "c": 0.0}
    if T.size < 4 or float(np.ptp(T)) < 20.0:
        # too little temperature variation: Arrhenius (c=0) or constant
        if T.size >= 2 and float(np.ptp(T)) > 1e-9:
            G = np.column_stack([np.ones_like(T), 1.0 / T])
            coef, _, _, _ = np.linalg.lstsq(G, y, rcond=None)
            return {"a": float(coef[0]), "b": float(coef[1]), "c": 0.0}
        return {"a": float(np.mean(y)), "b": 0.0, "c": 0.0}

    tmin = float(np.min(T))
    ymean = float(np.mean(y))
    best = None  # (sse, a, b, c)
    starts = [
        (ymean - 6.0, 5000.0, tmin - 400.0),
        (ymean - 6.0, 3000.0, tmin - 200.0),
        (-4.55, 8000.0, tmin - 600.0),
        (-3.0, 1500.0, tmin - 100.0),
        (ymean - 3.0, 10000.0, tmin - 800.0),
    ]
    lo = [-60.0, 1e-6, -5000.0]
    hi = [30.0, 5e6, tmin - 1e-3]
    for p0 in starts:
        p0 = [min(max(p0[0], lo[0]), hi[0]),
              min(max(p0[1], lo[1]), hi[1]),
              min(max(p0[2], lo[2]), hi[2])]
        try:
            p, _ = curve_fit(_vft, T, y, p0=p0, bounds=(lo, hi), maxfev=20000)
            r = y - _vft(T, *p)
            sse = float(np.sum(r * r))
            if np.isfinite(sse) and (best is None or sse < best[0]):
                best = (sse, float(p[0]), float(p[1]), float(p[2]))
        except Exception:
            pass
    if best is None:
        # Arrhenius fallback (c = 0)
        G = np.column_stack([np.ones_like(T), 1.0 / T])
        coef, _, _, _ = np.linalg.lstsq(G, y, rcond=None)
        return {"a": float(coef[0]), "b": float(coef[1]), "c": 0.0}
    return {"a": best[1], "b": best[2], "c": best[3]}


def predict(X, a, b, c):
    T = np.asarray(X[:, 0], dtype=float)
    den = T - c
    # keep denominator away from zero with the correct (positive) side
    den = np.where(den < 1.0, 1.0, den)
    y = a + b / den
    y = np.clip(y, -10.0, 25.0)
    return np.where(np.isfinite(y), y, 5.0)