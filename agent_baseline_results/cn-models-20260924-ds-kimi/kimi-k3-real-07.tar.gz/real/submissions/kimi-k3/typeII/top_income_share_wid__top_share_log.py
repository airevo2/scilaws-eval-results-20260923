"""Log top income share S(p): a global Pareto-type shape over ln p with a per-cluster
scale, recency-corrected by a per-cluster time offset fitted on the cluster's window.

Form:  y = -s * F(p) + delta,  where F(p) is a fixed global shape
       F(p) ∝ |ln p|^q * (1 + c·ln|ln p|)  (universal shape, q≈0.8, c≈0.8),
and (s, delta) are re-fit per cluster.  `delta` absorbs the level drift of the
cluster relative to the training-period mean (a recency / intercept correction),
so the prediction centres on the cluster's recent level, while the shape in ln p
is shared across all clusters.
"""
import numpy as np

USED_INPUTS = ["log_p_above", "top_pct", "year"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {
    "s":     {"init": [0.2]},
    "delta": {"init": [0.0]},
}

# Universal shape constants (not fitted per cluster, not scored as law constants:
# they define the fixed functional shape, taken from the published Pareto form).
_Q = 0.8
_C = 0.8

def _shape(log_p):
    """Universal positive shape F(p), normalised to F(0.10)=1."""
    x = -np.asarray(log_p, dtype=float)          # x = |ln p| > 0
    u = np.log(np.clip(x, 1e-12, None))          # u = ln|ln p|
    F = (x ** _Q) * (1.0 + _C * u)
    x0 = 2.302585092994046                       # |ln 0.10|
    u0 = np.log(x0)
    F0 = (x0 ** _Q) * (1.0 + _C * u0)
    return F / F0

def fit(X_fit, y_fit):
    lp = np.asarray(X_fit[:, 0], dtype=float)
    yr = np.asarray(X_fit[:, 2], dtype=float) if X_fit.shape[1] > 2 else np.zeros_like(lp)
    y = np.asarray(y_fit, dtype=float)
    Fv = _shape(lp)
    # Recency-weighted fit: emphasise the most recent years in the window so that
    # delta captures the cluster's current level.  tau in years.
    tmax = np.max(yr) if yr.size else 0.0
    tau = 5.0
    w = np.exp(-(tmax - yr) / tau)
    w = np.clip(w, 1e-6, None)
    # Weighted least squares for  y = -s*F + delta
    # Solve 2x2 normal equations.
    Sw = np.sum(w)
    SF = np.sum(w * Fv)
    SFF = np.sum(w * Fv * Fv)
    Sy = np.sum(w * y)
    SFy = np.sum(w * Fv * y)
    A = np.array([[SFF, -SF],
                  [-SF,  Sw]])
    b = np.array([-SFy, Sy])
    try:
        sol = np.linalg.solve(A, b)
        s_hat = float(sol[0])
        d_hat = float(sol[1])
    except np.linalg.LinAlgError:
        s_hat = 0.2
        d_hat = float(np.mean(y)) if y.size else 0.0
    # Guard against degenerate / non-physical solutions.
    if not np.isfinite(s_hat) or s_hat <= 0.0:
        s_hat = 0.2
    if not np.isfinite(d_hat):
        d_hat = 0.0
    return {"s": s_hat, "delta": d_hat}

def predict(X, s, delta):
    lp = np.asarray(X[:, 0], dtype=float)
    Fv = _shape(lp)
    y = -s * Fv + delta
    return np.asarray(y, dtype=float)