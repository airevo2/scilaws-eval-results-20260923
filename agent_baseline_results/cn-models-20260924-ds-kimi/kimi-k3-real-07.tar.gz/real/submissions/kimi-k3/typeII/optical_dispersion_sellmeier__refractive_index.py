"""Single-UV-pole Sellmeier with a linear-lambda^2 infrared correction:

    n(lambda)^2 = a + b * lambda^2 / (lambda^2 - c) - d * lambda^2

This is the standard one-resonance Sellmeier dispersion (electronic UV pole at
sqrt(c) um, kept strictly below every observed wavelength) plus a '-d*lambda^2'
term that captures the long-wavelength roll-over toward the far-IR phonon
resonance while remaining finite and well-behaved on extrapolation. Four
per-cluster parameters (a, b, c, d) are re-fit for each crystal; the functional
shape is universal across all clusters. The fit keeps the UV pole below the
minimum fit wavelength via a sigmoid reparametrization, and shrinks the IR slope
d toward zero when the fit window spans too little wavelength range to constrain
it, which makes both short- and long-wavelength extrapolation robust.
"""
import numpy as np
from scipy.optimize import least_squares

USED_INPUTS = ["wavelength_um"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {
    "a": {"init": None},
    "b": {"init": None},
    "c": {"init": None},
    "d": {"init": None},
}


def _predict(X, a, b, c, d):
    lam = np.asarray(X[:, 0], dtype=float)
    L2 = lam * lam
    c_safe = min(float(c), 0.14)
    denom = L2 - c_safe
    denom = np.where(np.abs(denom) < 1e-6,
                     np.where(denom >= 0.0, 1e-6, -1e-6), denom)
    v = a + b * L2 / denom - d * L2
    v = np.clip(v, 1e-6, None)
    return np.sqrt(v)


def fit(X_fit, y_fit):
    x = np.asarray(X_fit[:, 0], dtype=float)
    y = np.asarray(y_fit, dtype=float)
    if x.size == 0:
        return {"a": 2.0, "b": 1.0, "c": 0.02, "d": 0.0}
    # UV pole must sit strictly below the smallest fit wavelength.
    lmin2 = min(float(x.min() ** 2) * 0.995, 0.13)
    span = float(x.max() - x.min())
    # Shrink the IR slope to zero when the window is too short to constrain it.
    shrink = float(np.clip((1.5 - span) / 1.5, 0.0, 1.0))
    lam_d = 8.0 * shrink
    ymed2 = max(float(np.median(y)) ** 2, 0.5)

    def to_phys(p):
        a, b, q, d = p
        c = lmin2 / (1.0 + np.exp(np.clip(q, -30, 30)))
        return a, b, c, d

    def resid(p):
        a, b, c, d = to_phys(p)
        L2 = x * x
        v = a + b * L2 / (L2 - c) - d * L2
        pred = np.sqrt(np.clip(v, 1e-12, None)) - y
        reg = [lam_d * d,
               0.03 * np.clip(-a, 0, None),
               0.03 * np.clip(-b, 0, None)]
        grid = np.linspace(max(0.3, x.min() * 0.9), max(6.0, x.max() * 1.2), 25)
        g2 = grid * grid
        vv = a + b * g2 / (g2 - c) - d * g2
        pen = np.clip(0.5 - vv, 0, None) * 1.0
        return np.concatenate([pred, reg, pen])

    best = None
    starts = ([ymed2 * 0.6, ymed2 * 0.4, 2.0, 0.0], [1.5, 1.0, 2.0, 0.0],
              [2.0, 1.5, 1.0, 0.0], [1.2, 2.0, 0.0, 0.0],
              [2.5, 1.0, 3.0, 0.0], [3.0, 2.5, 1.0, 0.0])
    for p0 in starts:
        try:
            res = least_squares(resid, p0,
                                bounds=([-30, 0.0, -12, -0.5], [80, 150, 12, 0.5]),
                                max_nfev=2500)
            a, b, c, d = to_phys(res.x)
            pred = _predict(X_fit, a, b, c, d)
            r = float(np.sqrt(np.mean((pred - y) ** 2)))
            if best is None or r < best[0]:
                best = (r, (a, b, c, d))
        except Exception:
            pass
    if best is None:
        return {"a": ymed2, "b": 0.0, "c": 0.01, "d": 0.0}
    a, b, c, d = best[1]
    return {"a": float(a), "b": float(b), "c": float(c), "d": float(d)}


def predict(X, a, b, c, d):
    return _predict(X, a, b, c, d)