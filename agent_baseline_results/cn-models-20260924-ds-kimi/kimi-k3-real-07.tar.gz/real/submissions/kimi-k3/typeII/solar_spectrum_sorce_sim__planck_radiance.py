"""Solar spectral radiance approximated by a Planck blackbody curve per unit wavelength (radiance form, W m^-2 nm^-1 sr^-1) with only the two radiation constants h, c, k_B fixed; the effective temperature T is the single per-cluster parameter, re-fit per cluster by nonlinear least squares. This shape generalises across clusters and extrapolates physically (falls ~exp(-c2/(lam T)) in the UV, ~Rayleigh-Jeans in the IR)."""
import numpy as np

USED_INPUTS = ["wavelength_nm"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {"T": {"init": None}}

# Physical constants (exact SI definitions): h c^2 and h c / k_B
_C1 = 1.191042972e-16   # 2 h c^2  [W m^2 sr^-1]
_C2 = 1.438776877e-2    # h c / k_B [m K]

def _planck_per_nm(lam_nm, T):
    lam = np.asarray(lam_nm, dtype=float) * 1e-9
    T = float(T)
    x = np.clip(_C2 / (lam * T), 1e-12, 700.0)
    return 1e-9 * _C1 / np.power(lam, 5) / np.expm1(x)

def fit(X_fit, y_fit):
    from scipy.optimize import curve_fit
    lam = np.asarray(X_fit[:, 0], dtype=float)
    y = np.asarray(y_fit, dtype=float)
    try:
        popt, _ = curve_fit(_planck_per_nm, lam, y, p0=[5772.0],
                            bounds=([4000.0], [8000.0]), maxfev=4000)
        T = float(popt[0])
        if not np.isfinite(T):
            T = 5772.0
    except Exception:
        T = 5772.0
    return {"T": T}

def predict(X, T):
    return _planck_per_nm(np.asarray(X[:, 0], dtype=float), T)