"""At-a-station hydraulic geometry for width: w = a * Q^b (Leopold & Maddock
power law), with per-station coefficient a and exponent b re-fit by
least-squares in log-log space for each cluster."""
import numpy as np

USED_INPUTS = ["chan_discharge"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {"a": {"init": 50.0}, "b": {"init": 0.17}}

def fit(X_fit, y_fit):
    Q = np.asarray(X_fit[:, 0], dtype=float)
    w = np.asarray(y_fit, dtype=float)
    Q = np.maximum(Q, 1e-12)
    w = np.maximum(w, 1e-12)
    lx, ly = np.log(Q), np.log(w)
    mx, my = float(np.mean(lx)), float(np.mean(ly))
    vx = float(np.mean((lx - mx) ** 2))
    if vx < 1e-12:
        b = 0.17  # degenerate fit window: fall back to typical width exponent
    else:
        b = float(np.mean((lx - mx) * (ly - my)) / vx)
        b = float(np.clip(b, 0.0, 1.0))
    a = float(np.exp(my - b * mx))
    return {"a": a, "b": b}

def predict(X, a, b):
    Q = np.maximum(np.asarray(X[:, 0], dtype=float), 1e-12)
    return a * Q ** b