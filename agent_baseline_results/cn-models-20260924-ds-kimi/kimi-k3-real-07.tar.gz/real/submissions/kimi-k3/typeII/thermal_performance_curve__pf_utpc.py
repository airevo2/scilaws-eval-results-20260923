"""Shared thermal performance curve: a smooth asymmetric (soft-skew) Gaussian,
performance = r * exp(-(T-Topt)^2 / (2*sigma_eff^2)), where sigma_eff transitions
from sigma below Topt to sigma*(1+beta) above it via a logistic in T. This captures
the classic left-skewed rise-then-sharp-fall shape of thermal performance curves.
Per cluster we refit 4 params: peak height r, optimum Topt, width sigma, skew beta."""
import numpy as np
from scipy.optimize import least_squares

USED_INPUTS = ["temperature"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {"r": {"init": None}, "Topt": {"init": None}, "sigma": {"init": None}, "beta": {"init": None}}

def _form(T, r, Topt, sigma, beta):
    T = np.asarray(T, dtype=float)
    z = T - Topt
    sig = np.maximum(sigma * 0.5, 1e-3)
    w = 1.0 / (1.0 + np.exp(-np.clip(z / sig, -30.0, 30.0)))
    se = np.maximum(sigma * (1.0 + beta * w), 1e-6)
    return r * np.exp(-z ** 2 / (2.0 * se ** 2))

def fit(X_fit, y_fit):
    t = np.asarray(X_fit[:, 0], dtype=float)
    p = np.asarray(y_fit, dtype=float)
    scale = max(float(np.max(np.abs(p))), 1e-300)
    ys = p / scale
    tpk = float(t[int(np.argmax(p))])
    Tmin, Tmax = float(t.min()), float(t.max())
    thr = 0.6 * float(ys.max())
    mask = ys >= thr
    t_cent = float(np.sum(t[mask] * ys[mask]) / np.sum(ys[mask])) if mask.any() else tpk
    starts = [
        [1.0, tpk, 5.0, 0.0], [1.0, t_cent, 6.0, 0.0], [1.0, tpk, 8.0, 0.5],
        [1.0, tpk, 8.0, -0.3], [1.0, tpk, 12.0, 0.3], [1.0, float(np.median(t)), 9.0, 0.0],
    ]
    lo = np.array([0.0, Tmin - 25.0, 0.5, -0.9], dtype=float)
    hi = np.array([20.0, Tmax + 25.0, 60.0, 4.0], dtype=float)
    best = None
    for p0 in starts:
        p0 = np.clip(np.asarray(p0, dtype=float), lo, hi)
        try:
            res = least_squares(lambda q: _form(t, *q) - ys, p0, bounds=(lo, hi),
                                max_nfev=300, loss="soft_l1", f_scale=0.2)
            sse = float(np.sum((_form(t, *res.x) - ys) ** 2))
            if np.isfinite(sse) and (best is None or sse < best[0]):
                best = (sse, [float(x) for x in res.x])
        except Exception:
            pass
    if best is None:
        q = [scale, tpk, 8.0, 0.0]
    else:
        q = best[1]
        q[0] *= scale
    return {"r": float(q[0]), "Topt": float(q[1]), "sigma": float(q[2]), "beta": float(q[3])}

def predict(X, r, Topt, sigma, beta):
    out = _form(X[:, 0], r, Topt, sigma, beta)
    return np.nan_to_num(out, nan=0.0, posinf=0.0, neginf=0.0)