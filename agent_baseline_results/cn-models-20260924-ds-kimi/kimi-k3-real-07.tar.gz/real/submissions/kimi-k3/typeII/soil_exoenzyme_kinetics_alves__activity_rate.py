"""Soil enzyme kinetics: substrate-inhibition (Haldane) rate law
v = Vmax * S / (Km + S + S^2/Ki), fit per cluster.
When Ki >> Km this reduces to classic Michaelis-Menten; finite Ki captures the
downturn at high substrate seen in many clusters. A mild regulariser discourages
spurious strong inhibition on flat/small-window fits while leaving genuine
inhibition free."""
import numpy as np
from scipy.optimize import least_squares

USED_INPUTS = ["substrate_conc"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {
    "V": {"init": None},
    "K": {"init": None},
    "Ki": {"init": None},
}

def _rate(S, V, K, Ki):
    S = np.asarray(S, dtype=float)
    return V * S / (K + S + (S * S) / Ki)

def fit(X_fit, y_fit):
    S = np.asarray(X_fit[:, 0], dtype=float)
    y = np.asarray(y_fit, dtype=float)
    V0 = max(float(np.max(y)), 1e-6)
    K0 = max(float(np.median(S)), 5.0)
    Smax = max(float(np.max(S)), 1.0)
    scale = max(float(np.median(y)), 1e-9)
    lam = 0.15

    best = np.array([V0, K0, 1e9])
    best_cost = np.inf
    for Ki0 in (300.0, 3000.0, 1e6):
        try:
            def resid(p):
                pen = lam * max(0.0, 1.0 - p[2] / Smax) * scale
                return np.concatenate([_rate(S, p[0], p[1], p[2]) - y, [pen]])
            r = least_squares(
                resid, [V0, K0, Ki0],
                bounds=([1e-9, 1e-6, 10.0], [np.inf, np.inf, 1e9]),
                max_nfev=1500,
            )
            cost = float(np.sum(resid(r.x) ** 2))
            if cost < best_cost:
                best_cost = cost
                best = r.x
        except Exception:
            continue
    return {"V": float(best[0]), "K": float(best[1]), "Ki": float(best[2])}

def predict(X, V, K, Ki):
    S = np.asarray(X[:, 0], dtype=float)
    y = _rate(S, V, K, Ki)
    return np.maximum(y, 0.0)