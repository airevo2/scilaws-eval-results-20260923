"""Plant density-dependent yield: mean of the classic reciprocal yield law
w = a/(1+bN) and a competition-capped power law w = a*N^c (c <= -1 excluded),
with all parameters re-fit per cluster."""
import numpy as np
from scipy.optimize import curve_fit

USED_INPUTS = ["density"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {
    "ar": {"init": None},  # reciprocal-law potential mass (g at N->0)
    "b": {"init": None},   # reciprocal-law competition coefficient (per plant)
    "ap": {"init": None},  # power-law potential mass (g at N=1)
    "c": {"init": None},   # power-law competition exponent, bounded in [-1, 0]
}

def predict(X, ar, b, ap, c):
    N = np.maximum(np.asarray(X[:, 0], dtype=float), 1e-9)
    pr = float(ar) / (1.0 + float(b) * N)
    pp = float(ap) * np.power(N, float(c))
    out = 0.5 * (pr + pp)
    return np.clip(out, 1e-6, None)

def fit(X_fit, y_fit):
    N = np.maximum(np.asarray(X_fit[:, 0], dtype=float), 1e-9)
    w = np.asarray(y_fit, dtype=float)
    w1 = float(np.mean(w[N <= 1.5])) if np.any(N <= 1.5) else float(np.mean(w))
    # Reciprocal yield law fit
    ar, b = max(w1, 1e-6), 0.5
    try:
        p, _ = curve_fit(lambda N, a, bb: a / (1.0 + bb * N), N, w,
                         p0=[ar, b], bounds=([1e-12, 1e-12], [1e12, 1e12]),
                         maxfev=20000)
        ar, b = float(p[0]), float(p[1])
    except Exception:
        pass
    # Power law fit (exponent capped at -1 -> physically the reciprocal-law limit)
    ap, c = max(w1, 0.05), -0.7
    try:
        p, _ = curve_fit(lambda N, a, cc: a * np.power(N, cc), N, w,
                         p0=[ap, c], bounds=([1e-9, -1.0], [1e9, 0.0]),
                         maxfev=20000)
        ap, c = float(p[0]), float(p[1])
    except Exception:
        pass
    return {"ar": ar, "b": b, "ap": ap, "c": c}