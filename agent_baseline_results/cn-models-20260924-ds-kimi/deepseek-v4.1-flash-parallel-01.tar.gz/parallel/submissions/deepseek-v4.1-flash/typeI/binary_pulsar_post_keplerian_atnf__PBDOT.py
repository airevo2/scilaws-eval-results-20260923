"""Binary-pulsar orbital-period derivative: gravitational-wave driven orbital decay
(negative, ~Pb^(-5/3), eccentricity-enhanced) plus a positive kinematic-like plateau.
"""
import numpy as np

USED_INPUTS = ["Pb", "e"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    Pb = X[:, 0]
    e = X[:, 1]

    # --- gravitational-radiation orbital decay (sign negative, inspiralling) ---
    # Pb^{-5/3} scaling with strong eccentricity enhancement (1-e^2)^{-p}
    gr = -2.81e-14 * (Pb ** (-5.0 / 3.0)) * (1.0 - e ** 2) ** (-5.135)

    # --- positive kinematic/apparent term: roughly flat plateau for
    #     intermediate Pb, switching off for very small and very large Pb ---
    lpb = np.log(Pb)
    rise = 0.5 * (np.tanh((lpb + 0.90) / 0.22) + 1.0)
    fall = 0.5 * (1.0 - np.tanh((lpb - 1.07) / 0.13))
    pos = 1.35e-13 * rise * fall

    return gr + pos