"""Cepheid Wesenheit PLZ relation: linear in log P and [Fe/H]."""
import numpy as np

USED_INPUTS = ["log_P", "feh"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    logP = X[:, 0]
    feh = X[:, 1]
    return -2.74 + -3.32 * logP + -0.18 * feh