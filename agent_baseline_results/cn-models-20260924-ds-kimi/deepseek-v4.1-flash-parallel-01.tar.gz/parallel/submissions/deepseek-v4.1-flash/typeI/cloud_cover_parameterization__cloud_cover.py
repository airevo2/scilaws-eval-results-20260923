"""Logistic (sigmoid) cloud-fraction parameterization of the sub-grid cloud area
fraction C. Recovered mechanism: C is a bounded [0,1] sigmoid of a linear
predictor in the large-scale state — cloud water/ice mixing ratios (log in q_c),
relative humidity, temperature, and the vertical RH derivative. Constants were
fitted from targeted sweeps of the simulator.
"""
import numpy as np

USED_INPUTS = ["q_c", "q_i", "RH", "T", "dz_RH"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    q_c = X[:, 0]
    q_i = X[:, 1]
    RH = X[:, 2]
    T = X[:, 3]
    dz_RH = X[:, 4]

    # linear predictor (logit) of the cloud-area fraction
    z = (12.9
         + 0.5 * np.log(q_c + 1e-12)   # saturating (sqrt-like) response to cloud water
         + 3000.0 * q_i                # cloud ice contribution
         + 5.5 * RH                    # humidity dependence
         - 0.05 * T                    # temperature dependence
         - 900.0 * dz_RH)              # vertical RH-gradient dependence

    return 1.0 / (1.0 + np.exp(-z))