"""Isolation-by-distance: M_stat follows a power law in geographic distance.

Fitting the linearised differentiation statistic M = F_ST/(1-F_ST) against the
great-circle distance d gives a clean power-law mechanism M = A * d^b. This is
algebraically equivalent to an underlying logistic differentiation
F_ST = A*d^b / (1 + A*d^b), so that M = A*d^b. The exponent b ~ 0.547 is
robustly recovered (a pure square-root world, b=0.5, is decisively rejected by
both the grouped weighted fit and a Monte-Carlo check). Two global constants
(A, b) are used.
"""
import numpy as np

USED_INPUTS = ["distance_km"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    d = np.asarray(X[:, 0], dtype=float)
    A = 9.27e-4
    b = 0.5466
    return A * np.power(d, b)