"""Empirical disk-mass law: a compactness cutoff with a residual floor.

M_disk follows a power law in the distance to a critical compactness
C_th ~ 0.183, and saturates to a small residual F beyond it.

    M_disk = A * max(C_th - C1, 0)^n + F
"""
import numpy as np

USED_INPUTS = ["C1"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    C1 = np.asarray(X[:, 0], dtype=float)
    A = 12.756
    C_th = 0.1829
    n = 1.3833
    F = 0.0009
    return A * np.maximum(C_th - C1, 0.0) ** n + F