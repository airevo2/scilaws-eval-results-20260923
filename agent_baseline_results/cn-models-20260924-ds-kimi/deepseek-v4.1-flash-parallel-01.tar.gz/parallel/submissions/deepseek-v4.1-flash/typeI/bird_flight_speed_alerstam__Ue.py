"""Equivalent airspeed Ue from wing loading.

Mechanism recovered from probing the simulator: the squared mean equivalent
airspeed is affine in wing loading L = m/S (body mass / wing area):

    Ue^2 = a + b * (m / S)

Fitting log-log slopes gave exponents 0.994 on mass and -1.001 on area,
confirming a pure function of m/S. The slope b is the physical constant
2*g/rho = 2*9.81/1.225 = 16.016 (which matched the fitted slope 15.95).
The intercept a ~ 116 is a squared minimum-speed offset.

So:  Ue = sqrt(116.25 + 16.016 * m / S)
"""
import numpy as np

USED_INPUTS = ["mass_kg", "wing_area_m2"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    # column order follows USED_INPUTS
    m = X[:, 0]   # mass_kg
    S = X[:, 1]   # wing_area_m2
    a = 116.25    # squared minimum-speed offset (m^2/s^2)
    b = 16.016    # 2*g/rho  (m^2/s^2 per (kg/m^2))
    Ue2 = a + b * (m / S)
    return np.sqrt(np.maximum(Ue2, 0.0))