"""Budyko-framework evaporative fraction: the long-term mean annual E/P is a smooth
function of the climate aridity index phi = PET/P. Probing the simulator over
phi in [0.223, 4.51] shows the curve rises from ~0.19 to ~0.96, lies strictly
between the water (phi) and energy (1) limits, and is best described by the
Turc-Pike (Turc) Budyko curve, E/P = phi / sqrt(phi^2 + c^2). A single scale
constant c (fitted ~1.21) captures the whole range; setting c=2 (Choudhury/
Mezentsev form) or using Fu/Zhang/Schreiber variants fit markedly worse.
"""
import numpy as np

USED_INPUTS = ["pet_over_p"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    phi = X[:, 0]
    c = 1.21
    return phi / np.sqrt(phi**2 + c**2)