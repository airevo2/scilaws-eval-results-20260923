"""Two-state DNA duplex melting (van't Hoff): Tm = ΔH/ΔS, with the entropy
carrying a per-base term (length N times a per-base entropy that grows with the
sequence strength E) plus the usual strand-concentration and Na+ screening
corrections. ΔH = h·N (per-base enthalpy times length). Fit on 112 simulated rows.

1/Tm(K) = (s0 + s1·E)/h + [R·ln(C_DNA) + ks·(N-1)·ln([Na+])]/(h·N)
=> Tm(K) = ΔH/ΔS with ΔH = h·N and
   ΔS = (s0' + s1'·E)·N - R·ln(C_DNA) - ks·(N-1)·ln([Na+])."""
import numpy as np

USED_INPUTS = ["E", "N", "salt_M", "dna_conc_M"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    E = X[:, 0]        # per-base DNA strength
    N = X[:, 1]        # length (bp)
    S = X[:, 2]        # [Na+] (M)
    C = X[:, 3]        # strand concentration (M)
    R = 1.987
    # Enthalpy per duplex (per-base enthalpy times length)
    dH = 6759.0 * N
    # Entropy: per-base term (N * (s0 + s1*E)) corrected by concentration
    # and sodium screening (standard 0.368·(N-1)·ln[Na+] style term).
    dS = (21.85 - 0.4544 * E) * N - R * np.log(C) - 0.317 * (N - 1) * np.log(S)
    return dH / dS - 273.15