"""Cubic polynomial in log10(M) fitted to log10(L)."""
import numpy as np

USED_INPUTS = ["log_M_Msun"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    x = X[:, 0]
    return -1.247 * x**3 + 0.609 * x**2 + 4.755 * x + 0.088