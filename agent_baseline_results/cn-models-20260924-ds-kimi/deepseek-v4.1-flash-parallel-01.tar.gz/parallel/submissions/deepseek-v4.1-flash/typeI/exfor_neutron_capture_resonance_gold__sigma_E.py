"""Au-197(n,gamma) inclusive capture: a smooth thermal (epithermal) power-law
background plus a single Breit-Wigner/Lorentzian resonance near 4.87 eV.
sigma(E) = A * E^(-q)  +  C / ((E - E_r)^2 + W^2);  target = log10(sigma)."""
import numpy as np

USED_INPUTS = ["E_eV"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    E = np.clip(X[:, 0].astype(float), 1e-12, None)
    # thermal / epithermal background (steeper than pure 1/v over this window)
    bg = 5.64 * E ** (-0.68)
    # single-level Breit-Wigner capture resonance (Au-197, E_r ~ 4.87 eV)
    res = 141.8 / ((E - 4.87) ** 2 + 0.065 ** 2)
    return np.log10(bg + res)