"""Dynamical ejecta mass M_ej as a power-law in mass ratio q and effective tidal
deformability Lambda_tilde, with an exponential cutoff that grows with q:

    M_ej = A * q^a * Lambda_tilde^b * exp(-c * Lambda_tilde * q^d)

This reproduces the observed structure: a rising ~Lambda^b branch at small
Lambda, a turnover/peak near Lambda ~ 1/q^d, and the crossover in q
(increasing with q at low Lambda, decreasing with q at high Lambda)."""

import numpy as np

USED_INPUTS = ["q", "Lambda_tilde"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}


def predict(X):
    q = X[:, 0]
    L = X[:, 1]

    lnA = -26.673
    a = 2.2254
    b = 3.7589
    c = 0.006130
    d = 1.7639

    A = np.exp(lnA)
    return A * q ** a * L ** b * np.exp(-c * L * q ** d)