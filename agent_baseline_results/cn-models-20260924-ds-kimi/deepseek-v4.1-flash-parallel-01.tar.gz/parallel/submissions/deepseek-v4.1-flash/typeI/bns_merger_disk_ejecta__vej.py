"""Mass-averaged terminal ejecta velocity as sum of a tidal-deformability power law
and a mass-ratio power law: vej = A * Lambda_tilde^(-1/2) + B * q^(-3/4).

The q=1 slice is well described by an A*Lambda^-1/2 term plus a constant offset,
and the offset difference between mass ratios is independent of Lambda_tilde,
motivating the additive two-power-law mechanism.
"""
import numpy as np

USED_INPUTS = ["q", "Lambda_tilde"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}


def predict(X):
    q = X[:, 0]
    Lam = X[:, 1]
    return 1.042 * Lam ** (-0.5) + 0.190 * q ** (-0.75)