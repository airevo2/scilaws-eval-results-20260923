"""Long-term runoff via a modified-Schreiber (Budyko-type) runoff-ratio curve.

The runoff ratio r = Q/P collapses onto the aridity index phi = PET/P
(a data-collapse confirmed across the probe grid: very different P and PET
combinations sharing the same phi give the same Q/P).  The observed collapse
is steeper than the classical Schreiber curve (which needs the exponent 1),
and is captured by an exponential of a power of phi:

    Q/P = exp(-a * phi^b),   phi = PET/P

Fitting this family to the collected observations gives b ~ 1.4-1.5 and
a ~ 1.1, with b=1.5 the natural structural exponent.  The single free law
constant is the scale a = 1.13 (keeping only one free constant per the cap;
the power 1.5 is treated as the structural exponent of the mechanism).

Predictions are therefore bounded: Q -> P as phi -> 0 (energy-limited,
runoff equals precipitation) and Q -> 0 as phi grows (water-limited, arid
catchments approaching zero runoff).
"""
import numpy as np

USED_INPUTS = ["p_mean", "pet_mean"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}


def predict(X):
    P = X[:, 0]
    PET = X[:, 1]
    phi = PET / np.maximum(P, 1e-12)
    r = np.exp(-1.13 * phi ** 1.5)
    return P * r