"""Intervening-opportunities (Stouffer) model: T_ij = C * m_i * m_j / (s_ij + m_j)."""
import numpy as np

USED_INPUTS = ["m_i", "m_j", "s_ij"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

C = 0.076

def predict(X):
    m_i = X[:, 0]
    m_j = X[:, 1]
    s_ij = X[:, 2]
    # Stouffer intervening-opportunities form: cumulative opportunities up to and
    # including the destination are (s_ij + m_j); the chance of stopping at j is
    # proportional to m_j / (s_ij + m_j); scaled by origin workers m_i.
    T = C * m_i * m_j / (s_ij + m_j)
    return np.log10(T + 1.0)