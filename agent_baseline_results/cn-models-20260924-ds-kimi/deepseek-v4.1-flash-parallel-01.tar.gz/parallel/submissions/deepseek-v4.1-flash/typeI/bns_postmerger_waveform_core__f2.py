"""Power-law post-merger f2: f2 = A * kappa2T^p * M^q. Fitted on all collected simulator rows.
Log-log regression of ln f2 on ln(kappa2T) and ln(M) gave exponents p ~ -0.352 and q ~ -1.02
(ratio q/p ~ 3, i.e. f2 essentially scales with (kappa2T * M^3)^p). The dominant, well-identified
mechanism is a joint power law in tidal coupling and total mass."""
import numpy as np

USED_INPUTS = ["mass", "kap2t"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    M = X[:, 0]      # total mass (M_sun)
    K = X[:, 1]      # combined tidal coupling constant
    return 42.52 * np.power(K, -0.3515) * np.power(M, -1.023)