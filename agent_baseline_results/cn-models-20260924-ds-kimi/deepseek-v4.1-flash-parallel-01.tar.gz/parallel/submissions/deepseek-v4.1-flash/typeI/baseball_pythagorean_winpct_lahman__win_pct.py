"""Pythagenpat Pythagorean expectation: win_pct = R^e / (R^e + RA^e) with exponent e = ((R+RA)/G)^0.287."""
import numpy as np

USED_INPUTS = ["R", "RA", "G"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}


def predict(X):
    R = X[:, 0].astype(float)
    RA = X[:, 1].astype(float)
    G = X[:, 2].astype(float)
    rpg = (R + RA) / G
    e = rpg ** 0.287
    Re = R ** e
    RAe = RA ** e
    return Re / (Re + RAe)