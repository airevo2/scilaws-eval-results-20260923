"""Budyko-reciprocal runoff model: Q = P / (1 + c*phi^2), phi = PET/P.

Fitted single global constant c = 2.30 (least squares on the 469 training
catchments).  This is the water-balance-closed Budyko-type form: the runoff
coefficient is a decreasing function of aridity that tends to 1 when
phi -> 0 (energy-limited, P -> runoff) and decays as 1/(c*phi^2) when
phi -> infinity (water-limited, runoff -> 0).  Among single-parameter
families it gave the best in-sample fit and, crucially, the best
extrapolation to held-out high-aridity catchments (the test region lies
entirely beyond the training aridity range), while remaining physically
sensible (Q >= 0, Q <= P) everywhere.
"""
import numpy as np

USED_INPUTS = ["p_mean", "aridity"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    P = X[:, 0]      # p_mean
    phi = X[:, 1]    # aridity = PET / P
    return P / (1.0 + 2.30 * phi ** 2)