"""GR quadrupole (Peters) gravitational-wave orbital decay of a binary pulsar.

    dot_P_b = -(192*pi/5) * (P_b/2pi)^{-5/3}
              * (1 + 73/24 e^2 + 37/96 e^4) * (1 - e^2)^{-7/2}
              * (G M_chirp / c^3)^{5/3}

using canonical neutron-star masses m1 = m2 = 1.4 Msun, so the chirp factor is
M_chirp = m1*m2/(m1+m2)^{1/3}.  No fitted constants; only T_sun = G M_sun / c^3
(a physical constant) and the canonical masses appear.
"""
import numpy as np

USED_INPUTS = ["Pb", "e"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

# Physical constants (not fitted):
_TSUN = 4.925490947e-6          # G*M_sun/c^3 in seconds
_M1 = 1.4
_M2 = 1.4
_MCHIRP = (_M1 * _M2) / (_M1 + _M2) ** (1.0 / 3.0)

_PREFACTOR = -(192.0 * np.pi / 5.0) * (2.0 * np.pi) ** (5.0 / 3.0)
_SCALE = _PREFACTOR * _TSUN ** (5.0 / 3.0) * _MCHIRP


def predict(X):
    Pb = X[:, 0]                # orbital period (days)
    e = X[:, 1]                 # eccentricity
    Ps = Pb * 86400.0           # seconds
    f_e = 1.0 + (73.0 / 24.0) * e ** 2 + (37.0 / 96.0) * e ** 4
    g_e = (1.0 - e ** 2) ** (-3.5)
    return _SCALE * Ps ** (-5.0 / 3.0) * f_e * g_e