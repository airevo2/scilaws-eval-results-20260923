"""Post-merger f2 from tidal coupling and total mass.

Physically motivated: f2 falls with the tidal coupling constant kappa2T
(softer EOS -> lower frequency) and depends on total mass M. A power law in
kappa2T with a quadratic mass correction fits the NR data well and stays
sensible under extrapolation.

Fitted constants (102 training rows):
  a = 14.0122, b = -0.2998, c = 0.6583, d = -0.3051
"""
import numpy as np

USED_INPUTS = ["kap2t", "mass"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    kap2t = X[:, 0]
    mass = X[:, 1]
    a, b, c, d = 14.0122, -0.2998, 0.6583, -0.3051
    return a * np.power(kap2t, b) + c * mass + d * mass * mass