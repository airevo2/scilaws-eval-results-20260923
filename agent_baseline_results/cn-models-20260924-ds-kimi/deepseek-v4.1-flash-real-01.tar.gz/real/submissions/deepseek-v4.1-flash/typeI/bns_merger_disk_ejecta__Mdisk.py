"""Mdisk ~ power-law in (C_crit - C1) plus a log-linear tidal-deformability term.
Form: log10(Mdisk) = a + b*log10(max(Cc - C1, eps)) + d*log10(Lambda_tilde).
Compactness dominates the disk mass; higher Lambda_tilde (more deformable,
lower-mass stars) raises the remnant disk mass. Clipped for numeric safety so
the form extrapolates sensibly (predictions stay within [1e-4, 0.5] Msun)."""
import numpy as np

USED_INPUTS = ["C1", "Lambda_tilde"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    C1 = X[:, 0]
    Lam = X[:, 1]
    a = -0.5754
    b = 0.8455
    Cc = 0.1781
    d = 0.3456
    s = np.log10(np.maximum(Cc - C1, 1e-4))
    L = np.log10(np.maximum(Lam, 1.0))
    logM = a + b * s + d * L
    M = 10.0 ** logM
    return np.clip(M, 1e-4, 0.5)