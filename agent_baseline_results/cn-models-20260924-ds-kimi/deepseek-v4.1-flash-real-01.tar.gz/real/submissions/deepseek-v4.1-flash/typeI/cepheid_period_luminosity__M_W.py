"""Gaia Wesenheit PL relation for classical Cepheids: physically-anchored
period slope (-3.31 mag/dex), weak negative metallicity term, fitted zero point.
Extrapolates linearly and sensibly to longer periods (test range log_P up to 1.65)."""
import numpy as np

USED_INPUTS = ["log_P", "feh"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    log_P = X[:, 0]
    feh = X[:, 1]
    return -3.31 * log_P - 0.25 * feh - 2.76906