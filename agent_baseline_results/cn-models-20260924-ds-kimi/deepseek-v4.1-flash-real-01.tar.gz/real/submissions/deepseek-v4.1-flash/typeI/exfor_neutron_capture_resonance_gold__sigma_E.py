"""Au-197 neutron capture: 1/v thermal behavior with a resonance enhancement at ~4.9 eV.

sigma(E) = A * E^(-1/2) / (1 + b * E^(3/2)) * (1 + P / ((E-4.9)^2 + d))

Fitted on log10(sigma). Constants: A, b, P, d (4 free constants)."""
import numpy as np

USED_INPUTS = ["E_eV"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    E = np.clip(X[:, 0].astype(float), 1e-12, None)
    A = 0.78455
    b = -0.00264
    P = 434.47
    d = 0.0051
    denom = np.maximum(1.0 + b * E**1.5, 1e-6)
    res = 1.0 + P / ((E - 4.9)**2 + d)
    sigma = A * E**(-0.5) / denom * res
    sigma = np.maximum(sigma, 1e-15)
    return np.log10(sigma)