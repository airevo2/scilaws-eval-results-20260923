"""Generalized Schreiber (genexp) Budyko-type curve for evaporative fraction.

E/P = 1 - exp(-phi^a), with a single fitted shape constant a.
This form is monotone increasing in the aridity index phi, bounded in [0,1],
and extrapolates sensibly to large phi (approaches 1).
"""
import numpy as np

USED_INPUTS = ["pet_over_p"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    phi = X[:, 0]
    phi = np.clip(phi, 1e-6, None)
    a = 1.0731
    return 1.0 - np.exp(-np.power(phi, a))