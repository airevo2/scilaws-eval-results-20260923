"""Mass–luminosity relation with a metallicity cross-term.

Functional form (physically = metal-dependent power law in log-space,
expanded polynomially around the data centre):

  u = log10(M/Msun),  z = [M/H]

  log10(L/Lsun) = a1*u + a2*u^2 + a3*u^3 + a4*u^4
                + b1*z + b2*u*z + b3*u^2*z + b4*z^2 + c0

The degree-4 mass polynomial captures the curvature of the M-L relation
across the 0.1-27 Msun range (steep at low mass, flattening at high mass);
the small metallicity terms capture the residual offset/curvature that is
present in the eclipsing-binary sample.  Coefficients were fitted by
ordinary least squares on all 238 training rows; 9 fitted constants.
"""
import numpy as np

USED_INPUTS = ["log_M_Msun", "metallicity"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}


def predict(X):
    u = np.asarray(X[:, 0], dtype=float)
    z = np.asarray(X[:, 1], dtype=float)

    return (
        4.35930351 * u
        + 0.25872251 * u ** 2
        - 1.42961538 * u ** 3
        + 0.82851292 * u ** 4
        - 0.18028036 * z
        - 4.51861662 * u * z
        + 6.63571159 * u ** 2 * z
        + 0.76980919 * z ** 2
        - 0.03488184
    )