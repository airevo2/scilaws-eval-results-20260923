"""Pythagenpat-style formula: win% = R^e / (R^e + RA^e) with e = ((R+RA)/G)^0.2765."""
import numpy as np

USED_INPUTS = ["R", "RA", "G"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    R = X[:, 0]
    RA = X[:, 1]
    G = X[:, 2]
    e = ((R + RA) / G) ** 0.2765
    return R ** e / (R ** e + RA ** e)