"""Gravity model with asymmetric mass exponents, power-law distance decay,
and a mild intervening-opportunity (s) term. The four structural exponents
are baked in as fixed literals; only a single overall scale and intercept
are the two fitted constants.
"""
import numpy as np

USED_INPUTS = ["m_i", "m_j", "d_ij_km", "s_ij"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    mi = X[:, 0]
    mj = X[:, 1]
    d = X[:, 2]
    s = X[:, 3]
    lmi = np.log10(mi)
    lmj = np.log10(mj)
    ld = np.log10(d)
    ls = np.log10(s + 1.0)
    # structural log-gravity feature (fixed exponents)
    G = 0.86 * lmi + 1.00 * lmj - 1.75 * ld - 0.32 * ls
    return 0.625 * G + 0.1371