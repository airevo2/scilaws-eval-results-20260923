"""Cloud cover parameterization.

Physically-motivated combination of three contributions to sub-grid cloud
fraction, each floored at zero and the total clipped to [0,1]:

  * cloud liquid water  : a * q_c^b
  * cloud ice water     : e * q_i^f
  * excess relative humidity above a temperature-dependent critical value
    (Sundqvist-like):  c * ((RH - RHc)/(1 - RHc))^d  with
    RHc = rh0 + rhT*(T-273)
  * a small vertical-structure correction using z_g and dRH/dz.

All constants were fitted by least squares on the training set.
"""

import numpy as np

USED_INPUTS = ["q_c", "q_i", "RH", "T", "z_g", "dz_RH"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}


def predict(X):
    q_c = X[:, 0]
    q_i = X[:, 1]
    RH = X[:, 2]
    T = X[:, 3]
    z_g = X[:, 4]
    dz_RH = X[:, 5]

    # fitted constants
    a = 20.98728
    b = 0.41733
    c = 1.50069
    d = 1.21351
    rh0 = 0.97087
    rhT = 0.01440
    e = 3.03160
    f = 0.17748
    g = -0.02602
    h = 35.37427

    rhc = np.clip(rh0 + rhT * (T - 273.0), 0.05, 0.999)

    x = a * np.clip(q_c, 1e-12, None) ** b
    xi = e * np.clip(q_i, 1e-12, None) ** f
    y = c * np.clip((RH - rhc) / (1.0 - rhc), 0.0, None) ** d

    cc = x + xi + y + g * (z_g / 1000.0) + h * dz_RH
    return np.clip(cc, 0.0, 1.0)