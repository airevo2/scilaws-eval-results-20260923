"""Log-linear ejecta model in compactness and total mass."""
import numpy as np

USED_INPUTS = ["C1", "M1", "M2"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    C1 = X[:, 0]
    M1 = X[:, 1]
    M2 = X[:, 2]
    Mtot = M1 + M2
    log10_mej = 14.7475 * C1 - 1.635 * Mtot - 0.9755
    return 10.0 ** log10_mej