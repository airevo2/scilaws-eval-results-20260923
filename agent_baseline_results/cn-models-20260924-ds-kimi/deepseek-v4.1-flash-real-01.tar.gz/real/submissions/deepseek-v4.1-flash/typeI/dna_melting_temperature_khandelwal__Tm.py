"""Thermodynamic nearest-neighbor-style model: Tm(K) = dH/(dS + R*ln(CT/4)),
with dH = N*(h0 + h1*E) + c*N*ln[Na+], dS = N*(s0 + s1*E). Constants fit by
nonlinear least squares. dH scales with duplex length N and per-base stability E,
salt stabilizes via the enthalpy term, strand concentration via the entropy term."""
import numpy as np

USED_INPUTS = ["E", "N", "salt_M", "dna_conc_M"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    E = X[:, 0]
    N = X[:, 1]
    salt = X[:, 2]
    dna = X[:, 3]
    R = 1.987  # gas constant, cal/(mol*K)
    h0 = -3668.9232
    h1 = -524.4521
    s0 = -12.6773
    s1 = -1.0718
    c = -108.4523
    dH = N * (h0 + h1 * E) + c * N * np.log(salt)
    dS = N * (s0 + s1 * E)
    TmK = dH / (dS + R * np.log(dna / 4.0))
    return TmK - 273.15