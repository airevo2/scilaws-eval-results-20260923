"""Cruising equivalent airspeed vs wing loading: Ue = a*(m/S)^b."""
import numpy as np

USED_INPUTS = ["mass_kg", "wing_area_m2"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    m = X[:, 0]
    S = X[:, 1]
    return 10.5637 * (m / S) ** 0.19889