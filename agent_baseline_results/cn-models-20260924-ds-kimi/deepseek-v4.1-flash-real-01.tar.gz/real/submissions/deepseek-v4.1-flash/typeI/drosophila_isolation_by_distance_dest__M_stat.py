"""Isolation-by-distance: Rousset linear model M_stat = slope*ln(d) + intercept, clipped at 0."""
import numpy as np

USED_INPUTS = ["log_distance_km"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    ld = X[:, 0]
    y = 0.018920955588217964 * ld - 0.0852347819623475
    return np.clip(y, 0.0, None)