"""Power-law ejecta velocity in terms of neutron-star compactness.

Physically the mass-averaged terminal velocity of the dynamical ejecta is
driven by the compactness of the two stars (deeper gravitational wells ->
faster tidal ejection). A symmetric power law in the product of the two
compactnesses captures this and stays well behaved in extrapolation.
"""
import numpy as np

USED_INPUTS = ["C1", "C2"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    C1 = X[:, 4]
    C2 = X[:, 5]
    a = 0.835
    b = 0.370
    return a * (C1 * C2) ** b