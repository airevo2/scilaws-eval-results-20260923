"""Exponential capacity fade: Q(k) = Q0 * exp(-b * k)."""
import numpy as np

USED_INPUTS = ["cycle_index"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    k = X[:, 0].astype(float)
    Q0 = 1.9231
    b = 0.002484
    return Q0 * np.exp(-b * k)