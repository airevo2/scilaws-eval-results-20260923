"""Temperature-dependent Cauchy model for the refractive index of ethylene glycol:
n(lambda,T) = A0 + B0/lambda^2 + C0/lambda^4 + D*T + E*T/lambda^2
(A0,B0,C0 = Cauchy coefficients at 0 degC; D,E = linear temperature coefficients)."""
import numpy as np

USED_INPUTS = ["lambda_um", "temperature_C"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    lam = X[:, 0]
    T = X[:, 1]
    i2 = 1.0 / lam**2
    i4 = i2 * i2
    A0 = 1.4248132
    B0 = 0.00475997
    C0 = -0.00011232
    D = -0.00026308
    E = -5.759e-6
    return A0 + B0 * i2 + C0 * i4 + D * T + E * T * i2