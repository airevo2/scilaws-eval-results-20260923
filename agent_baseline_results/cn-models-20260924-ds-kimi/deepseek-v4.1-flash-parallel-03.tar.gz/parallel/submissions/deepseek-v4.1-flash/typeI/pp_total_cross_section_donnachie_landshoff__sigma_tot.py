"""Two-power (Regge/Pomeron-inspired) law for pp total cross-section."""
import numpy as np

USED_INPUTS = ["s"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    s = X[:, 0]
    return 18.8561 * s**0.0928 + 38.869 * s**-0.3141