"""Sx is a linear combination of the three stress-tensor derivative inputs (gradient of enstrophy and the two deformation-vorticity gradients), with no intercept."""
import numpy as np

USED_INPUTS = ["d_zeta2_dx", "d_zetaD_dx", "d_zetaDtilde_dy"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

# Fitted coefficients (least squares on all collected observations, noise-averaged):
#   Sx = a*d_zeta2_dx + b*d_zetaD_dx + c*d_zetaDtilde_dy
_A = -4.674e8
_B = 9.820e8
_C = -1.012e9

def predict(X):
    x0 = X[:, 0]
    x1 = X[:, 1]
    x2 = X[:, 2]
    return _A * x0 + _B * x1 + _C * x2