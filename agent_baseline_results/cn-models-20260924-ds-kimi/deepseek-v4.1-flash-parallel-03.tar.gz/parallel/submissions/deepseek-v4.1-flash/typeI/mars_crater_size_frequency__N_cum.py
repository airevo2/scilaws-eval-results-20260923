"""Smooth broken power law (standard crater SFD form):
N(>=D) = A * D^-a * (1 + (D/Dc)^w)^(-(b-a)/w).
Recovers the shallow small-diameter slope (~-1.1) rolling smoothly
into the steep large-diameter slope (~-2.66) around Dc~34 km."""
import numpy as np

USED_INPUTS = ["D_lower_km"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

# Fitted constants (log-space least squares on log10(N))
_A = 2.10e-3
_a = 1.1146
_b = 2.6604
_Dc = 33.5
_w = 4.7

def predict(X):
    D = np.asarray(X[:, 0], dtype=float)
    D = np.clip(D, 1e-9, None)
    y = _A * D ** (-_a) * (1.0 + (D / _Dc) ** _w) ** (-(_b - _a) / _w)
    return y