"""Semi-empirical mass formula (Bethe-Weizsäcker) for binding energy per nucleon.
B/A = aV - aS A^{-1/3} - aC Z^2 A^{-4/3} - aA (N-Z)^2 A^{-2} + aP*pair*A^{-3/4}
Recovered as the hidden mechanism from probing the simulator across Z,N,A and pairing."""
import numpy as np

USED_INPUTS = ["Z", "N", "A", "pair"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    Z = X[:, 0]
    N = X[:, 1]
    A = X[:, 2]
    pair = X[:, 3]
    aV = 14.3623
    aS = 14.1443
    aC = 0.6031
    aA = 19.2124
    aP = 2.1132
    return (aV
            - aS * A ** (-1.0 / 3.0)
            - aC * Z * Z * A ** (-4.0 / 3.0)
            - aA * (N - Z) ** 2 * A ** (-2.0)
            + aP * pair * A ** (-3.0 / 4.0))