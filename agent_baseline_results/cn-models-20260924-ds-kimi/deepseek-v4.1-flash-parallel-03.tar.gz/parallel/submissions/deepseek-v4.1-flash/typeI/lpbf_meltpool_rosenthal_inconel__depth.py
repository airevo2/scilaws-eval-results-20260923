"""Melt-pool depth power-law: d = C * P^a * V^b * D^c, fitted on log-mean data."""
import numpy as np

USED_INPUTS = ["laser_power_W", "scan_velocity_mm_per_s", "beam_diameter_um"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    P = X[:, 0]
    V = X[:, 1]
    D = X[:, 2]
    C = 26290.0
    a = 0.672
    b = -0.752
    c = -0.944
    return C * (P ** a) * (V ** b) * (D ** c)