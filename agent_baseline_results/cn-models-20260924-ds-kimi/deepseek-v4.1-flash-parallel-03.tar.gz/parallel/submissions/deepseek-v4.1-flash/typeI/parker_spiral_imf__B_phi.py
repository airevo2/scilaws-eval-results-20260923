"""Azimuthal IMF component: modified Parker-spiral-like scaling.
Evidence from experiments: B_phi is linear in B_r (sign-reversed), and the ratio
-B_phi/B_r scales as v_sw^(-1/2) (ratio ~0.89 at ~263 km/s falling to ~0.53 at
~740 km/s, i.e. factor 1.68 for a factor 2.81 speed change -> exponent -0.5).
The single fitted constant bundles the solar-rotation/heliocentric factor.
Structural form: B_phi = -C * B_r * sqrt(r / v_sw)."""
import numpy as np

USED_INPUTS = ["B_r_nT", "v_sw_km_s", "r_AU"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    B_r = X[:, 0]
    v_sw = X[:, 1]
    r = X[:, 2]
    C = 14.8
    return -C * B_r * np.sqrt(r / v_sw)