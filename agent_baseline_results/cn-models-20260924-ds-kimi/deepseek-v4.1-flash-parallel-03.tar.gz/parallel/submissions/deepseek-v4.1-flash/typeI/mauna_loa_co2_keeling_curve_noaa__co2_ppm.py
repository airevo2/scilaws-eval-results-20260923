"""Quadratic trend plus annual seasonal sinusoid (Mauna Loa CO2 model).

co2(t) = a + b*(t-2000) + c*(t-2000)^2 + A*sin(2*pi*t) + B*cos(2*pi*t)

The secular rise is captured by a constant, linear and quadratic term in
decimal year, and the seasonal cycle is one sinusoid at the annual frequency.
"""
import numpy as np

USED_INPUTS = ["year_decimal"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    t = X[:, 0]
    u = t - 2000.0
    a = 369.3161
    b = 1.86946
    c = 0.01383
    A = -0.3421
    B = -0.14888
    return a + b * u + c * u * u + A * np.sin(2.0 * np.pi * t) + B * np.cos(2.0 * np.pi * t)