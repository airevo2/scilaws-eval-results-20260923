"""Separable Steinmetz-type core-loss law.

The measured log10(P_vol) collapses onto

    log10(P_vol) = C + a*log10(f) + h(B)

with a constant frequency exponent a ~ 1.666 and a B-function that behaves
like B^2 (Rayleigh/hysteresis regime) at small B but grows faster at large B,
well described by B^2 * (1 + r*B).  Equivalently P_vol is a sum of two
power-law loss channels sharing the same frequency exponent.
"""
import numpy as np

USED_INPUTS = ["f_Hz", "B_peak_T"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    f = X[:, 0]
    B = X[:, 1]
    C = -4.772
    a = 1.666
    r = 10.88
    return C + a * np.log10(f) + 2.0 * np.log10(B) + np.log10(1.0 + r * B)