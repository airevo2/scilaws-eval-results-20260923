"""log Kd = c + s*(log10 Kow + log10 foc). Both inputs enter linearly with equal slope (~0.52)."""
import numpy as np

USED_INPUTS = ["log_Kow", "foc"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    lk = X[:, 0]
    foc = X[:, 1]
    lf = np.log10(foc)
    return -0.6359 + 0.5217 * (lk + lf)