"""Mincer earnings function: log wage linear in schooling, concave (saturating) in experience."""
import numpy as np

USED_INPUTS = ["SCHL_years", "exp"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    s = X[:, 0].astype(float)
    x = X[:, 1].astype(float)
    b0 = 8.4533
    b1 = 0.1119
    a  = 1.0775
    K  = 5.0169
    return b0 + b1 * s + a * x / (x + K)