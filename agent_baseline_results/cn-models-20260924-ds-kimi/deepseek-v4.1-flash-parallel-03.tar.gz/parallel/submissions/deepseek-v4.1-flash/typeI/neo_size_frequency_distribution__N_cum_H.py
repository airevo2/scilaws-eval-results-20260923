"""Cumulative NEO counts follow a power law in absolute magnitude:
N(<H) = C * 10^(a*H). Fitted over the complete regime H in [12,18]."""
import numpy as np

USED_INPUTS = ["H_upper"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    H = X[:, 0]
    C = 1.538e-06
    a = 0.4986
    return C * 10.0 ** (a * H)