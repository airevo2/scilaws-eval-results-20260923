"""Kleiber's law: BMR scales as body mass to the 3/4 power, B = a * M^(3/4), so
log10(B) = log10(a) + (3/4)*log10(M). Multiplicative (log-normal-like) scatter."""
import numpy as np

USED_INPUTS = ["body_mass_g"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    M = X[:, 0]
    a = 0.0191
    return np.log10(a) + 0.75 * np.log10(M)