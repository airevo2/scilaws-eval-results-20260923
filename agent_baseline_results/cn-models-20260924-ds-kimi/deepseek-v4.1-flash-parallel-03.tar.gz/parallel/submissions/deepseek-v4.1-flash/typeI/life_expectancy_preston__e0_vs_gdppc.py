"""Saturating sigmoid (logistic-in-log) life expectancy vs GDP per capita.
e0 = L / (1 + (K/gdppc)^n), recovering the S-shaped rise that flattens near ~73 years."""
import numpy as np

USED_INPUTS = ["gdppc"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    x = np.asarray(X[:, 0], dtype=float)
    x = np.clip(x, 1e-9, None)
    L = 73.12
    K = 50.33
    n = 1.124
    return L / (1.0 + (K / x) ** n)