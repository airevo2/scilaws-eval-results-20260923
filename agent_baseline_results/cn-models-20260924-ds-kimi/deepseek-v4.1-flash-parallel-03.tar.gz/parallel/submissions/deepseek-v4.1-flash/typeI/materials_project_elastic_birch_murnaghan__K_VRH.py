"""Power-law mechanism: K_VRH = C * V_atomic^b * density^c.

Log-log analysis of 1000+ simulator rows (grouped means to suppress the
~25% multiplicative noise) shows K_VRH is a pure multiplicative power law
of the atomic volume and the mass density, with no significant dependence
on the crystal-system id (ANOVA F-test p~0.06, offsets within noise).

Weighted least squares over the full design (V in [7,64], rho in [0.57,22])
gives exponents b ~ -1.47 and c ~ +0.62 and log C ~ 7.65.
"""
import numpy as np

USED_INPUTS = ["V_atomic_A3", "density_g_cm3"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}


def predict(X):
    V = X[:, 0]
    rho = X[:, 1]
    return 2100.0 * V ** (-1.47) * rho ** (0.62)