"""Population-proportional emissions with a log-quadratic affluence response, demographic power laws, and exponential temperature dependence."""
import numpy as np

USED_INPUTS = ["GDP", "TP", "AP", "DP", "UR", "AT"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    GDP, TP, AP, DP, UR, AT = X.T
    log_gdp = np.log(GDP)
    return TP * np.exp(
        -16.28204667
        + 2.18107089 * log_gdp
        - 0.09322178 * log_gdp**2
        + 2.83036268 * np.log(AP)
        - 0.14454759 * np.log(DP)
        + 0.46346273 * np.log(UR)
        - 0.01909036 * AT
    )