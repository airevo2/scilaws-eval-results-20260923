"""Saturating enstrophy-gradient and vorticity–deformation momentum closure."""
import numpy as np

USED_INPUTS = ["d_zeta2_dx", "d_zetaD_dx", "d_zetaDtilde_dy"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    return (
        -7.47970343e-8 * np.tanh(9.4900889e15 * X[:, 0])
        + 1.125494037e-7 * (
            np.tanh(9.4900889e15 * X[:, 1])
            - np.tanh(9.4900889e15 * X[:, 2])
        )
    )