"""Saturating spiral-angle projection of the radial magnetic field."""
import numpy as np

USED_INPUTS = ["B_r_nT", "v_sw_km_s", "r_AU"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    B_r = X[:, 0]
    v_sw = X[:, 1]
    r = X[:, 2]
    spiral_ratio = 474.27 * r / v_sw
    return -B_r * spiral_ratio / np.sqrt(1.0 + spiral_ratio**2)