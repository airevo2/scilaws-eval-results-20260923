"""A background height plus quarter-power buoyant-plume scaling with mass eruption rate."""
import numpy as np

USED_INPUTS = ["MER_kg_per_s"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    mer = X[:, 0]
    return 1.03705056 + 0.20726460 * np.power(mer, 0.25)