"""Distance-corrected i-band luminosity plus a saturating g-r color correction."""
import numpy as np

USED_INPUTS = ["g", "r", "i", "DM"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    g = X[:, 0]
    r = X[:, 1]
    i = X[:, 2]
    DM = X[:, 3]
    return 0.4 * (DM - i) + 1.25 * (1.0 + np.tanh(0.8 * (g - r)))