"""Quadratic dependence of logarithmic black-hole mass on logarithmic spheroid mass."""
import numpy as np

USED_INPUTS = ["log_M_sph"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    x = X[:, 0]
    return 2.21885970625 - 0.0121739679469 * x + 0.0536984931411 * x**2