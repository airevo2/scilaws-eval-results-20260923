"""Species richness declines as a power of habitat disturbance."""
import numpy as np

USED_INPUTS = ["d"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    d = X[:, 0]
    return 890.6075353245245 * d ** (-1.72363379)