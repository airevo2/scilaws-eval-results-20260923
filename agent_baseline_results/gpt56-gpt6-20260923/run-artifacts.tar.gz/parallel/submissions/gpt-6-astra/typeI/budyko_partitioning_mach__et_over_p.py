"""Saturating precipitation partition with linear and quadratic aridity contributions."""
import numpy as np

USED_INPUTS = ["pet_over_p"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    phi = X[:, 0]
    demand = phi * (1.0 + phi)
    return demand / (1.174 + demand)