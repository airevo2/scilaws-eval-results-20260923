"""Two fixed-exponent running components with sex-dependent amplitudes."""
import numpy as np

USED_INPUTS = ["distance_m", "sex_M"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    d = X[:, 0]
    s = X[:, 1]
    return (
        (11.93782548 + 1.38560454 * s) * d ** (-0.08)
        + (11.58475381 - 1.00479743 * s) * d ** (-0.6)
    )