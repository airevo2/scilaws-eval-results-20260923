"""Hardness with linear electronic strengthening and a VEC–mixing-enthalpy interaction."""
import numpy as np

USED_INPUTS = ["VEC", "dHmix"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    vec = X[:, 0]
    enthalpy = X[:, 1]
    return 82.31382543 + 68.74833090 * vec - 1.4570441684 * vec * enthalpy