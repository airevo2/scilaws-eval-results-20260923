"""Power-linear melt depth with inverse-square-root scan-speed scaling and a finite beam-size correction."""
import numpy as np

USED_INPUTS = ["laser_power_W", "scan_velocity_mm_per_s", "beam_diameter_um"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    P = X[:, 0]
    V = X[:, 1]
    D = X[:, 2]
    return 15484.2506658 * P / (np.sqrt(V * D) * (D + 46.70554142))