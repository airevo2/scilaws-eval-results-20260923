"""Inverse-mass tidal power law with a linear symmetric-mass-ratio correction."""
import numpy as np

USED_INPUTS = ["mass", "kap2t", "m1", "m2"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    mass = X[:, 0]
    kap2t = X[:, 1]
    m1 = X[:, 2]
    m2 = X[:, 3]
    eta = m1 * m2 / mass**2
    return (41.75769514 / mass) * kap2t**(-0.35249919) * (
        1.0 + 0.11056923 * (1.0 - 4.0 * eta)
    )