"""Large frequency separation follows a power law in peak oscillation frequency."""
import numpy as np

USED_INPUTS = ["nu_max"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    nu_max = X[:, 0]
    return 0.2875621346 * nu_max**0.7481147982