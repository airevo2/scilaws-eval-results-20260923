"""Thermocline depth increases logarithmically with lake surface area."""
import numpy as np

USED_INPUTS = ["A_s_km2"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    A_s = X[:, 0]
    return 7.27981244 + 1.09350707 * np.log(A_s)