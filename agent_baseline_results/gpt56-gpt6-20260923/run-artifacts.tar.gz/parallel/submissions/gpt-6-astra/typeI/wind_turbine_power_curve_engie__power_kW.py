"""Cut-in-clipped Weibull saturation law for turbine power."""
import numpy as np

USED_INPUTS = ["wind_speed_mps"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    v = X[:, 0]
    return np.maximum(
        1998.99414478
        - 2119.82504437 * np.exp(-(v / 9.31856866) ** 3.28733532),
        0.0,
    )