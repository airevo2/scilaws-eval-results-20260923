"""Power-law disk emission plus a fixed 3 mJy flux floor, in log space."""
import numpy as np

USED_INPUTS = ["log10_M_star_SDF00"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    x = X[:, 0]
    return np.log10(0.003 + 10.0 ** (-1.62805247 + 1.32188527 * x))