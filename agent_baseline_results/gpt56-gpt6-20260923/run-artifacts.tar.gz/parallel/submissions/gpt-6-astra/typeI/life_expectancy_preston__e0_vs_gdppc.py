"""Life expectancy approaches an upper limit exponentially in an inverse power of income."""
import numpy as np

USED_INPUTS = ["gdppc"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    Y = X[:, 0]
    return 74.3764033027838 * np.exp(-21.643571646686 * Y**(-0.873213150459427))