"""Linear period–Wesenheit–metallicity relation, pivoted at ten days."""
import numpy as np

USED_INPUTS = ["log_P", "feh"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    log_P = X[:, 0]
    feh = X[:, 1]
    return -6.0624679439 - 3.3039558153 * (log_P - 1.0) - 0.1279950980 * feh