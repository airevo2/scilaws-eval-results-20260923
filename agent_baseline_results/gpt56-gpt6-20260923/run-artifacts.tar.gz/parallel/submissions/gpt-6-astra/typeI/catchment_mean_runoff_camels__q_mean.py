"""Water-balance runoff after effective evaporative demand, clipped at zero."""
import numpy as np

USED_INPUTS = ["p_mean", "pet_mean"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    p = X[:, 0]
    pet = X[:, 1]
    return np.maximum(p - 0.7135 * pet, 0.0)