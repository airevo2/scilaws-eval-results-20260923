"""Multiplicative population–affluence scaling with demographic and density elasticities and an exponential temperature response."""
import numpy as np

USED_INPUTS = ["GDP", "TP", "AP", "DP", "UR", "AT"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    GDP, TP, AP, DP, UR, AT = X.T
    return np.exp(
        2.25606886
        + 0.27658265 * np.log(GDP)
        + 0.94881103 * np.log(TP)
        - 0.48804948 * np.log(AP)
        - 0.28182161 * np.log(DP)
        - 0.05745057 * np.log(UR)
        - 0.00971540 * AT
    )