"""Additive DNA stability law with finite-length, ionic-screening, and logarithmic concentration corrections."""
import numpy as np

USED_INPUTS = ["E", "N", "salt_M", "dna_conc_M"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    E = X[:, 0]
    N = X[:, 1]
    salt_M = X[:, 2]
    dna_conc_M = X[:, 3]
    return (63.02240924 + 7.33605290 * E
            - 462.89410849 / N
            - 4.84140351 / np.sqrt(salt_M)
            + 1.64226872 * np.log(dna_conc_M))