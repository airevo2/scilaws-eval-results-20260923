"""Pythagorean win expectation with a logarithmic run-environment exponent."""
import numpy as np

USED_INPUTS = ["R", "RA", "G"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    R = X[:, 0]
    RA = X[:, 1]
    G = X[:, 2]
    exponent = 0.88938216 + 0.39977287 * np.log((R + RA) / G)
    return 1.0 / (1.0 + (RA / R) ** exponent)