"""Cumulative magnitude distribution following a base-ten exponential law."""
import numpy as np

USED_INPUTS = ["H_upper"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    H = X[:, 0]
    return 10.0 ** (0.48778227 * H - 5.64271680)