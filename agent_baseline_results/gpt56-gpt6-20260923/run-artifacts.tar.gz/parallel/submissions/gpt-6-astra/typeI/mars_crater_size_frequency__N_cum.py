"""Cumulative crater density from a power-law population plus a smoothly broken power-law population."""
import numpy as np

USED_INPUTS = ["D_lower_km"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    D = X[:, 0]
    return (
        0.00162996471 * D**(-1.83522741)
        + 0.000773379607 * D**(-0.71226297)
        / (1.0 + (D / 32.6055425)**2.37109503)
    )