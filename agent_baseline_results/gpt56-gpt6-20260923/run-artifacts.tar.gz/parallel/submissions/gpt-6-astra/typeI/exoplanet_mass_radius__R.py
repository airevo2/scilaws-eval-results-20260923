"""Double smoothly broken mass–radius power law."""
import numpy as np

USED_INPUTS = ["M"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    M = X[:, 0]
    return (
        0.97703 * M**0.489413643452
        * (1.0 + (M / 228.762276544)**8.0)
          **((-0.038218052156 - 0.489413643452) / 8.0)
        * (1.0 + (M / 11328.4156364)**4.0)
          **((-0.165410760942 + 0.038218052156) / 4.0)
    )