"""Irradiance-proportional PV power with logarithmic irradiance efficiency and linear temperature derating."""
import numpy as np

USED_INPUTS = ["G_W_m2", "T_module_C"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    G = X[:, 0]
    T = X[:, 1]
    return (
        204.47614409243147 * (G / 1000.0)
        * (1.0 - 0.06846097449556225 * np.log(G / 1000.0))
        * (1.0 - 0.002454700227028966 * (T - 25.0))
    )