"""Clipped cloud fraction with a humidity–temperature polynomial, cubic vertical-gradient correction, and saturating condensate response."""
import numpy as np

USED_INPUTS = ["q_c", "q_i", "RH", "T", "dz_RH"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    q_c, q_i, RH, T, dz_RH = X.T
    temperature = T - 257.735787
    gradient = 1000.0 * dz_RH
    curvature = 0.503361137

    background = (
        -0.316504395
        + 0.352362136 * RH
        - 0.0121994603 * temperature
        + curvature * RH**2
        + 0.000406548520 * (RH - 0.596248758) * temperature**2
    )
    vertical = 0.702931014 * gradient**2 * (1.0 + curvature * gradient)
    condensate = 8765.07954 * q_c + 26389.6408 * q_i
    water = curvature * condensate / (1.0 + condensate)

    return np.where(
        q_c + q_i > 0.0,
        np.clip(background + vertical + water, 0.0, 1.0),
        0.0,
    )