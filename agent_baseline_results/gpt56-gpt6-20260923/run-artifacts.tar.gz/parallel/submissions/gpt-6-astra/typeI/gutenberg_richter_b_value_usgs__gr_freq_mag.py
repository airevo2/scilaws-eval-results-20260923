"""Gutenberg–Richter cumulative earthquake frequency–magnitude law."""
import numpy as np

USED_INPUTS = ["M_threshold"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    M = X[:, 0]
    return 8.88224252 - 1.13800752 * M