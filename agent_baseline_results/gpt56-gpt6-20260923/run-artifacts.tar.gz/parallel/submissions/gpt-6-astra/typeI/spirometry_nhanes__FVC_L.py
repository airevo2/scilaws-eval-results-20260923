"""Additive linear age dependence and cubic height scaling."""
import numpy as np

USED_INPUTS = ["age", "height_cm"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    age = X[:, 0]
    height_cm = X[:, 1]
    return -0.484266809 + 0.102980995 * age + 7.01769354e-7 * height_cm**3