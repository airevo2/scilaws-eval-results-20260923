"""FEV1 scales with squared stature and declines linearly with age."""
import numpy as np

USED_INPUTS = ["age", "height_cm"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    age = X[:, 0]
    height_cm = X[:, 1]
    return height_cm**2 * (0.000150445 - 0.00000101365 * age)