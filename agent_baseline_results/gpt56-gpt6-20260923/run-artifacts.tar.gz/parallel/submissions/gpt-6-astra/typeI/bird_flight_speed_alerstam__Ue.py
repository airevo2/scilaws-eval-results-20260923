"""Equivalent airspeed squared is affine in wing loading."""
import numpy as np

USED_INPUTS = ["mass_kg", "wing_area_m2"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    mass = X[:, 0]
    area = X[:, 1]
    return np.sqrt(115.45973072 + 15.97852371 * mass / area)