"""Pressure-linear, thermally activated hydrogen kinetics with potential-dependent acid inhibition."""
import numpy as np

USED_INPUTS = ["eta", "T", "P_H2", "c_acid"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    eta = X[:, 0]
    T = X[:, 1]
    P_H2 = X[:, 2]
    c_acid = X[:, 3]
    u = 96485.33212 * eta / (8.314462618 * T)
    rate = 143.645169 * np.exp(
        -16698.2626 / 8.314462618 * (1.0 / T - 1.0 / 298.0)
    )
    driving_force = np.exp(0.370968799 * u) * (-np.expm1(-2.0 * u))
    inhibition = 1.0 + 0.238090048 * c_acid * np.exp(-1.11430069 * u)
    return rate * P_H2 * driving_force / inhibition