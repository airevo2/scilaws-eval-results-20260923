"""Dipole-normalized rational form factor with two short-range exponential corrections."""
import numpy as np

USED_INPUTS = ["Q2_GeV2"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    q = X[:, 0]
    reference = (1.0 + q / 0.71) ** 2
    electric = (1.0 - 0.13036661 * q) / (
        1.0 + 3.23973961 * q + 1.44259489 * q**2 + 0.07911462 * q**3
    )
    return (
        reference * electric
        + 0.03138228 * np.expm1(-q / 0.01942269)
        - 0.08752601 * np.expm1(-q / 0.11533053)
    )