"""Flat Lambda-CDM luminosity distance and its distance modulus."""
import numpy as np

USED_INPUTS = ["z_hd"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    z = np.asarray(X[:, 0], dtype=float)
    nodes, weights = np.polynomial.legendre.leggauss(64)
    u = 0.5 * z[:, None] * (nodes + 1.0)
    expansion = np.sqrt(0.35183945 * (1.0 + u)**3 + (1.0 - 0.35183945))
    comoving_integral = 0.5 * z * np.sum(weights / expansion, axis=1)
    luminosity_distance_mpc = (299792.458 / 72.62051554) * (1.0 + z) * comoving_integral
    return 25.0 + 5.0 * np.log10(luminosity_distance_mpc)