"""Additive mass-ratio dependence and inverse-power tidal scaling."""
import numpy as np

USED_INPUTS = ["q", "Lambda_tilde"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    q = X[:, 0]
    Lambda_tilde = X[:, 1]
    return 0.27652563 - 0.08042646 * q + 1.47494260 * Lambda_tilde ** (-0.60412371)