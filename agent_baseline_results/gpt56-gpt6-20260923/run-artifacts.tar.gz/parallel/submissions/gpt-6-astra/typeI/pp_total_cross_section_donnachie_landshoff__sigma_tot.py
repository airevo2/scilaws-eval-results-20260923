"""Logarithmic high-energy growth with a decreasing Regge contribution."""
import numpy as np

USED_INPUTS = ["s"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    s = X[:, 0]
    return 37.550963 + 0.3356167 * np.log(s / 65.13249)**2 + 6.99869 / np.sqrt(s)