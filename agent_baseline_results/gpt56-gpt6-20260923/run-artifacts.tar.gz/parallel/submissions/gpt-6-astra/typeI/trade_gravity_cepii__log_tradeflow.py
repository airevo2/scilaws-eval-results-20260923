"""Log-gravity mechanism with GDP complementarity and amplified language effects for colonial pairs."""
import numpy as np

USED_INPUTS = ["log_gdp_o", "log_gdp_d", "log_dist", "contig", "comlang_off", "col_dep_ever", "fta_wto"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    o, d, distance, border, language, colonial, agreement = X.T
    return (
        -12.90579294
        + 0.81142667 * o
        + 0.54050852 * d
        - 1.06516847 * distance
        + 0.93038732 * (border + colonial + agreement)
        + 0.59842398 * language * (1 + colonial)
        + 0.019442 * o * d
    )