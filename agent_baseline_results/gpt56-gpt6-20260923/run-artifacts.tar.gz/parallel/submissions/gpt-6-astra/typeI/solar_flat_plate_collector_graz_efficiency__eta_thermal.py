"""Collector efficiency with an inlet-temperature-dependent heat-loss coefficient."""
import numpy as np

USED_INPUTS = ["G_W_m2", "T_in_C", "T_amb_C"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    G = X[:, 0]
    T_in = X[:, 1]
    T_amb = X[:, 2]
    return 0.70595746 - (0.06191086 * T_in - 0.54618005) * (T_in - T_amb) / G