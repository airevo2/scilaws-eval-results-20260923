"""Exponential quadratic law in inverse mass ratio and log tidal deformability."""
import numpy as np

USED_INPUTS = ["q", "Lambda_tilde"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    inverse_q = 1.0 / X[:, 0]
    log_lambda = np.log(X[:, 1])
    return np.exp(
        -34.65070199
        - 11.27777162 * inverse_q
        - 3.11982081 * inverse_q**2
        + 10.11033870 * log_lambda
        + 3.45205355 * inverse_q * log_lambda
        - 1.08405668 * log_lambda**2
    )