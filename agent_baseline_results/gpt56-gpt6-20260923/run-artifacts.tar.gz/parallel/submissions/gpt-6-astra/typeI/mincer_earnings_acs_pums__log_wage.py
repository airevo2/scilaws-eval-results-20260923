"""Linear schooling return with square-root experience gains and linear experience depreciation."""
import numpy as np

USED_INPUTS = ["SCHL_years", "exp"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    s = X[:, 0]
    x = X[:, 1]
    return 8.43015314 + 0.112503 * s + 0.29126968 * np.sqrt(x) - 0.02160120 * x