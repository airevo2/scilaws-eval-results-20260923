"""Separable density power law with inverse three-halves atomic-volume scaling."""
import numpy as np

USED_INPUTS = ["V_atomic_A3", "density_g_cm3"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    volume = X[:, 0]
    density = X[:, 1]
    return 2230.32642672 * density**0.64208763184 / (volume * np.sqrt(volume))