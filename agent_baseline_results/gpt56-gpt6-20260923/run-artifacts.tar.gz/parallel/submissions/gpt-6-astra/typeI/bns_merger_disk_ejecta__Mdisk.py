"""Disk mass follows an exponentiated Gompertz transition in compactness."""
import numpy as np

USED_INPUTS = ["C1"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    C1 = X[:, 0]
    return 0.000852730917448104 * np.exp(
        5.52304355111869
        * np.exp(-np.exp((C1 - 0.176374110486111) / 0.0102868435026693))
    )