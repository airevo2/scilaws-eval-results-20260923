"""Permeability follows a power law in porosity odds."""
import numpy as np

USED_INPUTS = ["phi"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    phi = X[:, 0]
    return 3.7752108063 + 4.0401910585 * np.log10(phi / (1.0 - phi))