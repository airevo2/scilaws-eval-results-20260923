"""Core-loss power law in frequency with a flux-dependent logarithmic exponent."""
import numpy as np

USED_INPUTS = ["f_Hz", "B_peak_T"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    log_f = np.log10(X[:, 0])
    log_B = np.log10(X[:, 1])
    return -3.58731642 + 1.66864995 * log_f + 3.19518688 * log_B + 0.31560339 * log_B**2