"""Orbital decay with inverse-period scaling and eccentricity enhancement."""
import numpy as np

USED_INPUTS = ["Pb", "e"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    Pb = X[:, 0]
    e = X[:, 1]
    return -2.84e-14 * Pb**(-5.0 / 3.0) * (1.0 - e**2)**(-5.13)