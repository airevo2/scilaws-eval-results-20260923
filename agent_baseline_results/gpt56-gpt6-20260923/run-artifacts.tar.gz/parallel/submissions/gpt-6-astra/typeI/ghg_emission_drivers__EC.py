"""Multiplicative socioeconomic scaling with exponential temperature dependence."""
import numpy as np

USED_INPUTS = ["GDP", "TP", "AP", "DP", "UR", "AT"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    GDP, TP, AP, DP, UR, AT = X.T
    return (
        3.894065148189032e-11
        * GDP**0.46045179
        * TP**0.984822272
        * AP**3.74770185
        * DP**(-0.0301933965)
        * UR**0.545951738
        * np.exp(-0.0190046788 * AT)
    )