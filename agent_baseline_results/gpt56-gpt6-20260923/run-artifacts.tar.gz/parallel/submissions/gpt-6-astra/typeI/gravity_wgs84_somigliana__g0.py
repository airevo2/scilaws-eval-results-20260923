"""WGS84 normal gravity follows Somigliana's ellipsoidal latitude law."""
import numpy as np

USED_INPUTS = ["latitude"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    sin2_phi = np.sin(np.deg2rad(X[:, 0])) ** 2
    return (
        9.7803253359
        * (1.0 + 0.00193185265241 * sin2_phi)
        / np.sqrt(1.0 - 0.00669437999013 * sin2_phi)
    )