"""Power-law partitioning in the product of organic carbon fraction and Kow."""
import numpy as np

USED_INPUTS = ["log_Kow", "foc"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    log_Kow = X[:, 0]
    foc = X[:, 1]
    return 0.5254521 * (log_Kow + np.log10(foc)) - 0.65062411