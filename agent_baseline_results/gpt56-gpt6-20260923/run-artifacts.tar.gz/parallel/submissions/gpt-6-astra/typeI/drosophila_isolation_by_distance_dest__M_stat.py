"""Genetic differentiation follows a sublinear power law in distance."""
import numpy as np

USED_INPUTS = ["distance_km"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    d = X[:, 0]
    return 0.0008563493443256398 * d ** 0.5555312922748957