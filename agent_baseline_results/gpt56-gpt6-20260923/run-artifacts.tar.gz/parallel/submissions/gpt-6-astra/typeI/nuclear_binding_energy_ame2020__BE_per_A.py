"""Liquid-drop binding energy with surface symmetry, Coulomb exchange, curvature, and even-even pairing."""
import numpy as np

USED_INPUTS = ["Z", "N", "A", "NZ_diff", "pair"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    Z = X[:, 0]
    A = X[:, 2]
    NZ_diff = X[:, 3]
    pair = X[:, 4]
    return (
        15.77914812
        - 19.51461303 / A**(1.0 / 3.0)
        + 2.40514130 / A**(2.0 / 3.0)
        - 0.70526801 * Z**2 / A**(4.0 / 3.0)
        + 0.53526712 * (Z / A)**(4.0 / 3.0)
        - (28.64599875 - 31.12322849 / A**(1.0 / 3.0))
          * (NZ_diff / A)**2
        + 13.34455156 * (pair > 0.5) / A**(4.0 / 3.0)
    )