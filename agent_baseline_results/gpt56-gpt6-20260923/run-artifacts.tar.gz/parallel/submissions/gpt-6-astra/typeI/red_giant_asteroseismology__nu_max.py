"""Power-law asteroseismic scaling between large separation and peak frequency."""
import numpy as np

USED_INPUTS = ["delta_nu"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    delta_nu = X[:, 0]
    return 4.88432767 * delta_nu ** 1.36031844