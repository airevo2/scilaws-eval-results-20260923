"""Modified Cauchy dispersion with a wavelength-dependent linear thermal correction."""
import numpy as np

USED_INPUTS = ["lambda_um", "temperature_C"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    wavelength = X[:, 0]
    temperature = X[:, 1]
    return (
        1.43014065
        + 0.00286036957 / wavelength**2
        + 0.000071580787 / wavelength**4
        - 0.00369520945 * wavelength**2
        + temperature * (-0.000304707112 + 0.0000350298414 * wavelength)
    )