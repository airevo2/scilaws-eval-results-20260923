"""Commuting flows scale with origin workers and destination jobs, attenuated by a power of competing opportunities."""
import numpy as np

USED_INPUTS = ["m_i", "m_j", "s_ij"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    m_i = X[:, 0]
    m_j = X[:, 1]
    s_ij = X[:, 2]
    flow = 0.0272748393 * m_i * m_j / (m_j + s_ij)**0.93684456
    return np.log10(1.0 + flow)