"""Greenberg traffic-flow law: speed decreases logarithmically with density."""
import numpy as np

USED_INPUTS = ["k_veh_km_lane"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    k = X[:, 0]
    return 13.25680207 * k * np.log(588.40227872 / k)