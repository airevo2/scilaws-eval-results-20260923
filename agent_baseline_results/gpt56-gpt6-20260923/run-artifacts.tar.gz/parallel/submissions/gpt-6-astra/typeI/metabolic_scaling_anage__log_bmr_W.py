"""Allometric basal metabolic rate: a power law in body mass."""
import numpy as np

USED_INPUTS = ["body_mass_g"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    return -1.7501957233 + 0.7718810174 * np.log10(X[:, 0])