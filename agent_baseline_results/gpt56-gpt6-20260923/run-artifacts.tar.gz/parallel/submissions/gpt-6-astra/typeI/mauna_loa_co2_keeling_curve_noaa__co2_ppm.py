"""Exponential atmospheric CO2 growth above a constant baseline."""
import numpy as np

USED_INPUTS = ["year_decimal"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    t = X[:, 0] - 1958.0
    return 313.6025565145497 + 56.75705839122521 * np.expm1(0.016285537889110916 * t)