"""Saturating logistic mass–metallicity relation in logarithmic stellar mass."""
import numpy as np

USED_INPUTS = ["log_Mstar"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    log_Mstar = X[:, 0]
    return 8.2669173 + 0.84250889 / (
        1.0 + np.exp(-1.98109625 * (log_Mstar - 9.36058104))
    )