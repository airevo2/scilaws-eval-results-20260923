"""Rectified electric-field injection, logarithmic modulation, linear recovery, and square-root pressure correction."""
import numpy as np

USED_INPUTS = ["Dst", "Ey", "P_dyn"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    Dst = X[:, 0]
    Ey = np.maximum(X[:, 1], 0.0)
    P_dyn = X[:, 2]
    return (
        -2.51682255 * Ey
        + 0.44001694 * np.log1p(Ey / 0.43891053)
        - 0.04916391 * Dst
        - 0.44031589 * np.sqrt(P_dyn)
        + 0.88613453
    )