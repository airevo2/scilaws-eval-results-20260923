"""Power-law capture background plus a Lorentzian resonance, summed before
taking log10. The Au-197 resonance energy is fixed at its physical value,
4.906 eV; four remaining coefficients are fitted."""
import numpy as np

USED_INPUTS = ["E_eV"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    E = X[:, 0]
    background = 5.047398 * E**(-0.717041)
    resonance = 151.274831 / ((E - 4.906)**2 + 0.075666**2)
    return np.log10(background + resonance)