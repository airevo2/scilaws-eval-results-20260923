"""Methane emissions follow GDP and urbanization power laws, with a quadratic population dependence in log space."""
import numpy as np

USED_INPUTS = ["GDP", "TP", "UR"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    GDP = X[:, 0]
    TP = X[:, 1]
    UR = X[:, 2]
    log_population = np.log(TP)
    return (
        0.00239458448
        * GDP ** 0.12882715449
        * UR ** 0.40682622557
        * np.exp(
            1.95657879392 * log_population
            - 0.0315095461 * log_population ** 2
        )
    )