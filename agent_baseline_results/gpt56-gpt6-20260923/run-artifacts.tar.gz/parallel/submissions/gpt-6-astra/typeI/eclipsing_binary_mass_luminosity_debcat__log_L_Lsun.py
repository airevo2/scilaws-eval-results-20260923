"""Cubic mass–luminosity relation in base-10 logarithmic coordinates."""
import numpy as np

USED_INPUTS = ["log_M_Msun"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    x = X[:, 0]
    return -0.11864 + 4.49247*x + 0.61535*x**2 - 1.03829*x**3