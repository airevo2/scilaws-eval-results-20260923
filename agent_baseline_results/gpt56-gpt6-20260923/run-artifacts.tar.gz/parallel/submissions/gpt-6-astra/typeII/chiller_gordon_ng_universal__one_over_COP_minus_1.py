"""Temperature-dependent fixed and inverse-load losses, plus a quadratic high-load penalty."""
import numpy as np

USED_INPUTS = ["T_ei", "T_ci", "Q_e"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {
    "a": {"init": None},
    "b": {"init": None},
    "c": {"init": None},
    "d": {"init": None},
    "e": {"init": None},
    "f": {"init": None},
    "g": {"init": None}
}

def _features(X):
    X = np.asarray(X, dtype=float)
    T_ei, T_ci, Q_e = X[:, 0], X[:, 1], X[:, 2]
    Q_e = np.maximum(Q_e, np.finfo(float).eps)
    return np.column_stack((
        np.ones(len(X)),
        T_ei,
        T_ci,
        1.0 / Q_e,
        T_ei / Q_e,
        T_ci / Q_e,
        Q_e**2
    ))

def fit(X_fit, y_fit):
    A = _features(X_fit)
    y = np.asarray(y_fit, dtype=float).reshape(-1)
    valid = np.isfinite(y) & np.all(np.isfinite(A), axis=1)
    A, y = A[valid], y[valid]
    if len(y) == 0:
        return dict(a=0.0, b=0.0, c=0.0, d=0.0, e=0.0, f=0.0, g=0.0)
    scale = np.linalg.norm(A, axis=0)
    scale = np.where(scale > 0, scale, 1.0)
    coefficients = np.linalg.lstsq(A / scale, y, rcond=None)[0] / scale
    return dict(zip(("a", "b", "c", "d", "e", "f", "g"),
                    map(float, coefficients)))

def predict(X, **params):
    coefficients = np.array([params[k] for k in ("a", "b", "c", "d", "e", "f", "g")])
    return _features(X) @ coefficients