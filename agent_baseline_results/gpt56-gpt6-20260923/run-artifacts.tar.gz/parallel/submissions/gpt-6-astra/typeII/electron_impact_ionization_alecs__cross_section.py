"""A sum of two binary-encounter–Bethe ionization channels, each zero below its binding-energy threshold."""
import numpy as np
from scipy.optimize import least_squares

USED_INPUTS = ["electron_energy_eV"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {
    "S1": {"init": None},
    "B1": {"init": None},
    "u1": {"init": None},
    "S2": {"init": None},
    "B2": {"init": None},
    "u2": {"init": None},
}

def _channel(E, S, B, u):
    t = np.maximum(np.asarray(E, dtype=float) / max(B, 1e-12), 1.0)
    logt = np.log(t)
    return S / (t + u + 1.0) * (
        0.5 * logt * (1.0 - t**-2)
        + 1.0 - 1.0 / t
        - logt / (t + 1.0)
    )

def predict(X, S1, B1, u1, S2, B2, u2):
    E = np.asarray(X, dtype=float)[:, 0]
    return _channel(E, S1, B1, u1) + _channel(E, S2, B2, u2)

def fit(X_fit, y_fit):
    E = np.asarray(X_fit, dtype=float)[:, 0]
    y = np.asarray(y_fit, dtype=float).reshape(-1)
    valid = np.isfinite(E) & np.isfinite(y) & (E > 0)
    E, y = E[valid], y[valid]
    names = tuple(LOCAL_FITTABLE)
    if not len(E):
        return dict(zip(names, [1.0, 1.0, 1.0, 0.0, 2.0, 1.0]))

    energies = np.unique(E)
    values = np.array([np.median(y[E == e]) for e in energies])
    E, y = energies, values
    ymax = max(float(np.max(y)), 1e-8)
    emin, emax = float(np.min(E)), float(np.max(E))
    epeak = float(E[np.argmax(y)])
    scale = np.maximum(np.abs(y), 0.15 * ymax)
    lower = [0.0, emin * 1e-4, 0.0, 0.0, emin * 1e-4, 0.0]
    upper = [ymax * 1e4, emin, 300.0, ymax * 1e4, emax * 2.0, 300.0]

    def residual(p):
        pred = _channel(E, *p[:3]) + _channel(E, *p[3:])
        return (pred - y) / scale

    best = None
    for factor in (1.2, 2.0, 4.0):
        b1 = min(0.9 * emin, 0.25 * epeak)
        b2 = min(factor * max(b1, emin), emax)
        initial = [4.0 * ymax, b1, 2.0, 2.0 * ymax, b2, 2.0]
        try:
            result = least_squares(
                residual, initial, bounds=(lower, upper),
                loss="soft_l1", f_scale=0.04,
                x_scale="jac", max_nfev=650,
                ftol=1e-7, xtol=1e-7, gtol=1e-7
            )
            if np.all(np.isfinite(result.x)):
                if best is None or result.cost < best.cost:
                    best = result
        except (ValueError, FloatingPointError):
            pass

    if best is None:
        params = [5.0 * ymax, min(0.8 * emin, epeak / 4.0),
                  2.0, 0.0, emin, 2.0]
    else:
        params = best.x
    return {name: float(value) for name, value in zip(names, params)}