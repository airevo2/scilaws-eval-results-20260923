"""Incompressible anisotropic hyperelasticity: a neo-Hookean matrix plus dispersed exponential collagen fibers."""
import numpy as np
from scipy.optimize import least_squares

USED_INPUTS = ["lambda11", "lambda22"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {
    "mu": {"init": None},
    "k1": {"init": None},
    "k2": {"init": None},
    "kappa": {"init": None},
    "theta": {"init": None},
}

def predict(X, mu, k1, k2, kappa, theta):
    X = np.asarray(X, dtype=float)
    a = X[:, 0] ** 2
    b = X[:, 1] ** 2
    c = 1.0 / np.maximum(a * b, np.finfo(float).tiny)
    w = np.cos(theta) ** 2
    I1 = a + b + c
    I4 = w * a + (1.0 - w) * b
    E = np.maximum(kappa * (I1 - 3.0) +
                   (1.0 - 3.0 * kappa) * (I4 - 1.0), 0.0)
    direction = kappa * (a - c) + (1.0 - 3.0 * kappa) * w * a
    return (mu * (a - c) +
            4.0 * k1 * E * np.exp(np.minimum(k2 * E ** 2, 80.0)) * direction)

def fit(X_fit, y_fit):
    X = np.asarray(X_fit, dtype=float)
    y = np.asarray(y_fit, dtype=float).ravel()
    good = np.isfinite(y) & np.all(np.isfinite(X), axis=1)
    X, y = X[good], y[good]
    names = tuple(LOCAL_FITTABLE)
    fallback = dict(mu=0.001, k1=0.001, k2=3.0,
                    kappa=0.05, theta=np.pi / 4.0)
    if len(y) == 0:
        return fallback
    amplitude = max(float(np.quantile(np.abs(y), 0.7)), 1e-6)
    scale = 0.04 * np.abs(y) + 0.03 * amplitude
    best = None
    lower = [0.0, 0.0, 0.0, 0.0, 0.0]
    upper = [np.inf, np.inf, 200.0, 1.0 / 3.0, np.pi / 2.0]
    for dispersion, angle in [(0.01, 0.55), (0.15, 0.8), (0.25, 1.0)]:
        p0 = [amplitude * 0.1, amplitude * 0.03, 3.0, dispersion, angle]
        try:
            result = least_squares(
                lambda p: (predict(X, **dict(zip(names, p))) - y) / scale,
                p0, bounds=(lower, upper), loss="soft_l1",
                x_scale="jac", max_nfev=650
            )
            if np.all(np.isfinite(result.x)) and (
                    best is None or result.cost < best.cost):
                best = result
        except (ValueError, FloatingPointError, OverflowError):
            pass
    if best is None:
        return fallback
    return dict(zip(names, map(float, best.x)))