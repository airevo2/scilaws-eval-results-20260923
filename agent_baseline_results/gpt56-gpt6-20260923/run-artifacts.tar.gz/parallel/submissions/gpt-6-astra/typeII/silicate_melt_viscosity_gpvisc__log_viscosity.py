"""MYEGA viscosity law: log10(eta) = A + (B/T) exp(C/T)."""
import numpy as np
from scipy.optimize import least_squares

USED_INPUTS = ["T"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {
    "A": {"init": None},
    "B": {"init": None},
    "C": {"init": None},
}

def fit(X_fit, y_fit):
    T = np.asarray(X_fit, dtype=float)[:, 0]
    y = np.asarray(y_fit, dtype=float).ravel()
    valid = np.isfinite(T) & np.isfinite(y) & (T > 0)
    T, y = T[valid], y[valid]
    if len(y) == 0:
        return {"A": 0.0, "B": 0.0, "C": 0.0}

    scale = float(np.median(T))
    u = scale / T
    lower = -0.99 * float(np.min(T)) / scale
    upper = 20.0 * float(np.min(T)) / scale

    # Center the exponential to improve numerical conditioning.
    def residual(p):
        A, D, c = p
        return A + D * u * np.exp(c * (u - 1.0)) - y

    def jacobian(p):
        A, D, c = p
        z = u * np.exp(c * (u - 1.0))
        return np.column_stack((np.ones_like(u), z, D * z * (u - 1.0)))

    best = None
    for c0 in (0.0, 1.0, 4.0):
        c0 = float(np.clip(c0, lower + 1e-8, upper - 1e-8))
        z = u * np.exp(c0 * (u - 1.0))
        A0, D0 = np.linalg.lstsq(
            np.column_stack((np.ones_like(z), z)), y, rcond=None
        )[0]
        D0 = max(float(D0), 1e-8)
        p0 = [float(np.mean(y - D0 * z)), D0, c0]
        try:
            result = least_squares(
                residual, p0, jac=jacobian,
                bounds=([-np.inf, 0.0, lower], [np.inf, np.inf, upper]),
                x_scale="jac", max_nfev=600,
                ftol=1e-10, xtol=1e-10, gtol=1e-10,
            )
            score = float(np.dot(result.fun, result.fun))
            if np.isfinite(score) and (best is None or score < best[0]):
                best = (score, result.x)
        except (ValueError, FloatingPointError, np.linalg.LinAlgError):
            pass

    if best is None:
        return {"A": float(np.mean(y)), "B": 0.0, "C": 0.0}

    A, D, c = best[1]
    return {
        "A": float(A),
        "B": float(D * scale * np.exp(-c)),
        "C": float(c * scale),
    }

def predict(X, A, B, C):
    T = np.asarray(X, dtype=float)[:, 0]
    return A + (B / T) * np.exp(np.clip(C / T, -700.0, 600.0))