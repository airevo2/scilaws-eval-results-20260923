"""Incompressible matrix reinforced by two symmetric dispersed fiber families."""
import numpy as np
from scipy.optimize import least_squares

USED_INPUTS = ["lambda11", "lambda22"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {
    "mu": {"init": None},
    "k1": {"init": None},
    "k2": {"init": None},
    "kappa": {"init": None},
    "theta": {"init": None},
}

def predict(X, mu, k1, k2, kappa, theta):
    X = np.asarray(X, dtype=float)
    l1sq = X[:, 0] ** 2
    l2sq = X[:, 1] ** 2
    l3sq = 1.0 / np.maximum(l1sq * l2sq, 1e-24)
    ct = np.cos(theta) ** 2
    st = np.sin(theta) ** 2
    I1 = l1sq + l2sq + l3sq
    I4 = l1sq * ct + l2sq * st
    E = np.maximum(
        kappa * (I1 - 3.0) + (1.0 - 3.0 * kappa) * (I4 - 1.0),
        0.0,
    )
    projection = (
        kappa * (l2sq - l3sq)
        + (1.0 - 3.0 * kappa) * l2sq * st
    )
    return (
        mu * (l2sq - l3sq)
        + 4.0 * k1 * E
        * np.exp(np.clip(k2 * E ** 2, -100.0, 100.0))
        * projection
    )

def fit(X_fit, y_fit):
    X = np.asarray(X_fit, dtype=float)
    y = np.asarray(y_fit, dtype=float).reshape(-1)
    valid = np.isfinite(y) & np.all(np.isfinite(X), axis=1)
    X, y = X[valid], y[valid]
    fallback = dict(mu=0.001, k1=0.001, k2=3.0,
                    kappa=0.05, theta=1.0)
    if len(y) == 0:
        return fallback

    magnitude = max(float(np.quantile(np.abs(y), 0.9)), 1e-6)
    scale = 0.01 * magnitude + 0.04 * np.abs(y)

    def unpack(p):
        return dict(mu=float(np.exp(p[0])),
                    k1=float(np.exp(p[1])),
                    k2=float(np.exp(p[2])),
                    kappa=float(p[3]),
                    theta=float(p[4]))

    def residual(p):
        return (predict(X, **unpack(p)) - y) / scale

    best = None
    for theta0 in (0.65, 1.0, 1.3):
        p0 = [
            np.log(max(magnitude * 0.05, 1e-7)),
            np.log(max(magnitude * 0.01, 1e-8)),
            np.log(3.0), 0.05, theta0
        ]
        try:
            result = least_squares(
                residual, p0,
                bounds=([-25, -25, -10, 0, 0],
                        [5, 5, 8, 1.0 / 3.0, np.pi / 2.0]),
                loss="soft_l1", max_nfev=500,
            )
            if np.isfinite(result.cost):
                if best is None or result.cost < best.cost:
                    best = result
        except (ValueError, FloatingPointError, OverflowError):
            pass
    return fallback if best is None else unpack(best.x)