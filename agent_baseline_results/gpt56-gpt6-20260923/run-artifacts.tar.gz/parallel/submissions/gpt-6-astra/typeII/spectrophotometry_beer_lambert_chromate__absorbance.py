"""Concentration-dependent absorptivity: A = l * (a*c + b*c**n)."""
import numpy as np
from scipy.optimize import minimize_scalar

USED_INPUTS = ["concentration", "path_length"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {
    "a": {"init": None},
    "b": {"init": None},
    "n": {"init": None}
}

def fit(X_fit, y_fit):
    X_fit = np.asarray(X_fit, dtype=float)
    y = np.asarray(y_fit, dtype=float).reshape(-1)
    c = np.maximum(X_fit[:, 0], 1e-15)
    l = X_fit[:, 1]
    valid = np.isfinite(c) & np.isfinite(l) & np.isfinite(y)
    c, l, y = c[valid], l[valid], y[valid]
    if y.size == 0:
        return {"a": 1.0, "b": 0.0, "n": 2.0}

    def calibrate(n):
        M = np.column_stack((l*c, l*np.power(c, n)))
        coef = np.linalg.lstsq(M, y, rcond=None)[0]
        residual = M @ coef - y
        return float(residual @ residual), coef

    try:
        result = minimize_scalar(
            lambda n: calibrate(n)[0],
            bounds=(1.05, 4.0),
            method="bounded",
            options={"xatol": 1e-7, "maxiter": 100}
        )
        n = float(result.x)
        _, coef = calibrate(n)
        if np.all(np.isfinite(coef)):
            return {"a": float(coef[0]), "b": float(coef[1]), "n": n}
    except Exception:
        pass

    x = l*c
    a = float(np.dot(x, y) / max(float(np.dot(x, x)), 1e-30))
    return {"a": a, "b": 0.0, "n": 2.0}

def predict(X, **params):
    X = np.asarray(X, dtype=float)
    c = np.maximum(X[:, 0], 0.0)
    l = X[:, 1]
    return l * (params["a"] * c + params["b"] * np.power(c, params["n"]))