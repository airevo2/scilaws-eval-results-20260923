"""Yeoh-type simple-shear response: an odd polynomial through fifth order."""
import numpy as np

USED_INPUTS = ["gamma"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {
    "a": {"init": None},
    "b": {"init": None},
    "c": {"init": None},
}

def fit(X_fit, y_fit):
    gamma = np.asarray(X_fit, dtype=float)[:, 0]
    y = np.asarray(y_fit, dtype=float).reshape(-1)
    valid = np.isfinite(gamma) & np.isfinite(y)
    gamma, y = gamma[valid], y[valid]
    if gamma.size == 0:
        return {"a": 0.0, "b": 0.0, "c": 0.0}

    scale = float(np.max(np.abs(gamma)))
    if scale == 0.0:
        return {"a": 0.0, "b": 0.0, "c": 0.0}

    z = gamma / scale
    design = np.column_stack((z, z**3, z**5))
    coef = np.linalg.lstsq(design, y, rcond=None)[0]
    return {
        "a": float(coef[0] / scale),
        "b": float(coef[1] / scale**3),
        "c": float(coef[2] / scale**5),
    }

def predict(X, a, b, c):
    gamma = np.asarray(X, dtype=float)[:, 0]
    return gamma * (a + gamma**2 * (b + c * gamma**2))