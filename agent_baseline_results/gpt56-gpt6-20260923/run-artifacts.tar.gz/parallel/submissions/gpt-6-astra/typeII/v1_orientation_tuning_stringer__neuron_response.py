"""Orientation-periodic von Mises tuning with baseline, gain, preferred orientation, and concentration."""
import numpy as np
from scipy.optimize import least_squares

USED_INPUTS = ["orientation_deg"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {
    "baseline": {"init": None},
    "amplitude": {"init": None},
    "preferred_orientation": {"init": None},
    "concentration": {"init": None},
}

def predict(X, baseline, amplitude, preferred_orientation, concentration):
    theta = np.asarray(X, dtype=float)[:, 0]
    phase = np.deg2rad(2.0 * (theta - preferred_orientation))
    return baseline + amplitude * np.exp(
        np.maximum(concentration, 0.0) * (np.cos(phase) - 1.0)
    )

def fit(X_fit, y_fit):
    X = np.asarray(X_fit, dtype=float)
    y = np.asarray(y_fit, dtype=float).reshape(-1)
    valid = np.isfinite(X[:, 0]) & np.isfinite(y)
    X, y = X[valid], y[valid]
    if y.size == 0:
        return dict(baseline=0.0, amplitude=0.0,
                    preferred_orientation=0.0, concentration=1.0)

    scale = max(float(np.ptp(y)), float(np.std(y)), 1e-8)
    baseline = float(np.percentile(y, 20))
    amplitude = max(float(np.max(y)) - baseline, scale * 0.01)
    preferred = float(X[np.argmax(y), 0] % 180.0)

    def residual(p):
        return (predict(X, *p) - y) / scale

    best = None
    for concentration in (1.0, 5.0, 15.0):
        p0 = [baseline, amplitude, preferred, concentration]
        try:
            result = least_squares(
                residual, p0,
                bounds=([-np.inf, 0.0, preferred - 180.0, 1e-5],
                        [np.inf, np.inf, preferred + 180.0, 1000.0]),
                x_scale=[scale, scale, 30.0, concentration],
                max_nfev=500,
            )
            cost = float(np.dot(result.fun, result.fun))
            if np.all(np.isfinite(result.x)) and (best is None or cost < best[0]):
                best = (cost, result.x)
        except (ValueError, FloatingPointError, RuntimeError):
            pass

    p = best[1] if best is not None else [baseline, amplitude, preferred, 5.0]
    return {
        "baseline": float(p[0]),
        "amplitude": float(p[1]),
        "preferred_orientation": float(p[2] % 180.0),
        "concentration": float(p[3]),
    }