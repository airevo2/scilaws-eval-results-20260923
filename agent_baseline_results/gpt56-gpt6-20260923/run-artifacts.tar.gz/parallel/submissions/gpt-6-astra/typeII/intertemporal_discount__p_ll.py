"""Logistic choice from the difference of power-exponentially discounted rewards."""
import numpy as np
from scipy.optimize import least_squares
from scipy.special import expit

USED_INPUTS = ["ss_time_days", "ll_time_days", "ss_value", "ll_value"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {
    "k": {"init": None},
    "beta": {"init": None},
    "h": {"init": None}
}

def _discount(t, k, h):
    t = np.maximum(np.asarray(t, dtype=float), 0.0)
    with np.errstate(divide="ignore", over="ignore", invalid="ignore"):
        power = np.exp(np.minimum(h * (np.log(k) + np.log(t)), 7.0))
    return np.exp(-power)

def predict(X, k, beta, h):
    X = np.asarray(X, dtype=float)
    ss = X[:, 2] * _discount(X[:, 0], k, h)
    ll = X[:, 3] * _discount(X[:, 1], k, h)
    return expit(beta * (ll - ss))

def fit(X_fit, y_fit):
    X = np.asarray(X_fit, dtype=float)
    y = np.asarray(y_fit, dtype=float).reshape(-1)
    valid = np.isfinite(X).all(axis=1) & np.isfinite(y)
    X, y = X[valid], y[valid]
    if len(y) == 0:
        return {"k": 0.01, "beta": 1.0, "h": 1.0}

    time_scale = max(float(np.max(X[:, :2])), 1e-12)
    value_scale = max(float(np.max(np.abs(X[:, 2:]))), 1e-12)
    Z = X.copy()
    Z[:, :2] /= time_scale
    Z[:, 2:] /= value_scale

    def residual(theta):
        k, beta, h = np.exp(theta)
        return predict(Z, k, beta, h) - y

    best = None
    for initial_h in (0.7, 1.5, 4.0):
        try:
            result = least_squares(
                residual,
                np.log([1.0, 4.0, initial_h]),
                bounds=(
                    np.array([-20.0, -15.0, np.log(0.02)]),
                    np.array([20.0, 15.0, np.log(20.0)])
                ),
                max_nfev=350
            )
            if np.isfinite(result.fun).all():
                if best is None or np.sum(result.fun**2) < np.sum(best.fun**2):
                    best = result
        except (ValueError, FloatingPointError):
            pass

    k, beta, h = np.exp(best.x) if best is not None else (1.0, 4.0, 1.0)
    return {
        "k": float(k / time_scale),
        "beta": float(beta / value_scale),
        "h": float(h)
    }