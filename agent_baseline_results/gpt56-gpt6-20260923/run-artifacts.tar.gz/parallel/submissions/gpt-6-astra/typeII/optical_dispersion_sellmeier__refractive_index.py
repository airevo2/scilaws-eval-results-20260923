"""Modified Sellmeier dispersion: n² = A + B/(λ² - C) - D λ²."""
import numpy as np
from scipy.optimize import minimize_scalar, least_squares

USED_INPUTS = ["wavelength_um"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {
    "A": {"init": None},
    "B": {"init": None},
    "C": {"init": None},
    "D": {"init": None},
}

def fit(X_fit, y_fit):
    wavelength = np.asarray(X_fit, dtype=float)[:, 0]
    y = np.asarray(y_fit, dtype=float).reshape(-1)
    valid = np.isfinite(wavelength) & np.isfinite(y) & (wavelength > 0)
    t = wavelength[valid] ** 2
    y = y[valid]
    if len(y) == 0:
        return {"A": 1.0, "B": 0.0, "C": 0.0, "D": 0.0}

    upper = 0.98 * float(np.min(t))

    def conditional(C):
        matrix = np.column_stack((np.ones_like(t), 1.0 / (t - C), -t))
        # Weight the squared-index regression to approximate index residuals.
        weight = 1.0 / np.maximum(np.abs(y), 1e-8)
        coefficients = np.linalg.lstsq(
            matrix * weight[:, None], y**2 * weight, rcond=None
        )[0]
        residual = (matrix @ coefficients - y**2) * weight
        return float(residual @ residual), coefficients

    fallback = {"A": float(np.median(y)**2), "B": 0.0, "C": 0.0, "D": 0.0}
    try:
        result = minimize_scalar(
            lambda C: conditional(C)[0],
            bounds=(0.0, upper),
            method="bounded",
            options={"xatol": max(upper * 1e-9, 1e-14)},
        )
        candidates = [0.0, float(result.x)]
        C = min(candidates, key=lambda c: conditional(c)[0])
        _, coefficients = conditional(C)
        A, B, D = coefficients
        initial = np.array([A, B, C, D], dtype=float)

        def residual(parameters):
            a, b, c, d = parameters
            squared_index = a + b / (t - c) - d * t
            return np.sqrt(np.maximum(squared_index, 1e-12)) - y

        optimized = least_squares(
            residual,
            initial,
            bounds=(
                [-np.inf, -np.inf, 0.0, -np.inf],
                [np.inf, np.inf, upper, np.inf],
            ),
            x_scale="jac",
            max_nfev=1000,
        )
        parameters = optimized.x if np.all(np.isfinite(optimized.x)) else initial
        return dict(zip(("A", "B", "C", "D"), map(float, parameters)))
    except Exception:
        return fallback

def predict(X, A, B, C, D):
    t = np.asarray(X, dtype=float)[:, 0] ** 2
    denominator = t - C
    denominator = np.where(
        np.abs(denominator) < 1e-12,
        np.where(denominator < 0.0, -1e-12, 1e-12),
        denominator,
    )
    squared_index = A + B / denominator - D * t
    return np.sqrt(np.maximum(squared_index, 1e-12))