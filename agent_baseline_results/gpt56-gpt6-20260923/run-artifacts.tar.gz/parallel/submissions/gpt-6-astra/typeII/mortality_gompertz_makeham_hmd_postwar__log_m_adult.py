"""Gompertz–Makeham mortality: ln m(x) = ln(A + B exp(c x))."""
import numpy as np
from scipy.optimize import least_squares

USED_INPUTS = ["age"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {
    "log_A": {"init": None},
    "log_B": {"init": None},
    "c": {"init": None},
}

def fit(X_fit, y_fit):
    x = np.asarray(X_fit, dtype=float)[:, 0]
    y = np.asarray(y_fit, dtype=float).reshape(-1)
    valid = np.isfinite(x) & np.isfinite(y)
    x, y = x[valid], y[valid]
    if len(y) == 0:
        return {"log_A": -10.0, "log_B": -10.0, "c": 0.1}

    center = float(np.mean(x))
    z = x - center
    slope = float(np.linalg.lstsq(
        np.column_stack([np.ones(len(x)), z]), y, rcond=None
    )[0][1])
    slope = np.clip(slope, 1e-6, 1.0)
    level = float(np.mean(y))

    def residual(p):
        return np.logaddexp(p[0], p[1] + p[2] * z) - y

    best = None
    for offset in (1.0, 3.0, 8.0):
        initial = [float(np.min(y)) - offset, level, slope]
        try:
            result = least_squares(
                residual, initial,
                bounds=([-1000.0, -1000.0, 0.0],
                        [100.0, 100.0, 2.0]),
                x_scale="jac", max_nfev=600,
            )
            if np.all(np.isfinite(result.x)):
                loss = float(np.sum(result.fun ** 2))
                if best is None or loss < best[0]:
                    best = (loss, result.x)
        except (ValueError, RuntimeError, FloatingPointError):
            pass

    if best is None:
        p = np.array([float(np.min(y)) - 8.0, level, slope])
    else:
        p = best[1]
    return {
        "log_A": float(p[0]),
        "log_B": float(p[1] - p[2] * center),
        "c": float(p[2]),
    }

def predict(X, **params):
    x = np.asarray(X, dtype=float)[:, 0]
    return np.logaddexp(
        params["log_A"], params["log_B"] + params["c"] * x
    )