"""Non-rectangular hyperbolic light response, minus dark respiration."""
import numpy as np
from scipy.optimize import least_squares

USED_INPUTS = ["Qin"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {
    "alpha": {"init": None},
    "Pmax": {"init": None},
    "theta": {"init": None},
    "Rd": {"init": None},
}

def predict(X, alpha, Pmax, theta, Rd):
    Q = np.asarray(X, dtype=float)[:, 0]
    light = alpha * Q
    total = light + Pmax
    discriminant = np.maximum(total**2 - 4.0 * theta * light * Pmax, 0.0)
    # Rationalized smaller root of the photosynthetic response quadratic.
    gross = 2.0 * light * Pmax / np.maximum(
        total + np.sqrt(discriminant), np.finfo(float).tiny
    )
    return gross - Rd

def fit(X_fit, y_fit):
    X = np.asarray(X_fit, dtype=float)
    y = np.asarray(y_fit, dtype=float).reshape(-1)
    valid = np.isfinite(X[:, 0]) & np.isfinite(y)
    X, y = X[valid], y[valid]

    if len(y) == 0:
        return {"alpha": 0.05, "Pmax": 5.0, "theta": 0.7, "Rd": 0.5}

    order = np.argsort(X[:, 0])
    q = X[order, 0]
    yy = y[order]
    rd0 = max(0.01, -float(np.mean(yy[q == q[0]])))
    p0 = max(0.1, 1.15 * (float(np.max(y)) + rd0))

    unique_q, inverse = np.unique(q, return_inverse=True)
    means = np.bincount(inverse, weights=yy) / np.bincount(inverse)
    if len(unique_q) > 1:
        k = min(4, len(unique_q))
        slope = np.polyfit(unique_q[:k], means[:k], 1)[0]
        alpha0 = float(np.clip(slope, 0.001, 0.5))
    else:
        alpha0 = 0.05

    lower = [1e-8, 1e-6, 0.0, 0.0]
    upper = [10.0, 10000.0, 1.0, 100.0]
    best = np.array([alpha0, p0, 0.7, rd0])
    best = np.clip(best, np.array(lower) + 1e-9, np.array(upper) - 1e-9)
    best_cost = np.inf

    def residual(p):
        return predict(X, p[0], p[1], p[2], p[3]) - y

    for curvature in (0.3, 0.7, 0.95):
        initial = best.copy()
        initial[2] = curvature
        try:
            result = least_squares(
                residual, initial, bounds=(lower, upper),
                x_scale="jac", max_nfev=500,
                ftol=1e-9, xtol=1e-9, gtol=1e-9,
            )
            cost = float(np.dot(result.fun, result.fun))
            if np.isfinite(cost) and cost < best_cost:
                best, best_cost = result.x, cost
        except Exception:
            pass

    return {
        "alpha": float(best[0]),
        "Pmax": float(best[1]),
        "theta": float(best[2]),
        "Rd": float(best[3]),
    }