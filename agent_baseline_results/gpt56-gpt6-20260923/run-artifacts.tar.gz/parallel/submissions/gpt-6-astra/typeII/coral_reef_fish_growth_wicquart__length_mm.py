"""Shared stretched-exponential growth: L(age) = L_inf * (1 - exp(-k * age**p))."""
import numpy as np
from scipy.optimize import least_squares

USED_INPUTS = ["Agei"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {
    "L_inf": {"init": None},
    "k": {"init": None},
    "p": {"init": None},
}

def fit(X_fit, y_fit):
    age = np.asarray(X_fit, dtype=float)[:, 0]
    y = np.asarray(y_fit, dtype=float).reshape(-1)
    valid = np.isfinite(age) & np.isfinite(y) & (age >= 0)
    age, y = age[valid], y[valid]
    if len(y) == 0:
        return {"L_inf": 1.0, "k": 1.0, "p": 1.0}

    positive_age = age[age > 0]
    time_scale = float(np.max(positive_age)) if len(positive_age) else 1.0
    length_scale = max(float(np.max(np.abs(y))), 1.0)
    t = age / time_scale
    z = y / length_scale

    def residual(theta):
        amplitude, rate, exponent = np.exp(theta)
        return amplitude * (-np.expm1(-rate * t**exponent)) - z

    best = None
    lower = np.log([0.01, 1e-9, 0.01])
    upper = np.log([1e5, 1e5, 10.0])
    for exponent in (0.2, 0.5, 1.0):
        initial = np.log([1.5, 1.0, exponent])
        try:
            result = least_squares(
                residual, initial, bounds=(lower, upper),
                max_nfev=800, ftol=1e-10, xtol=1e-10, gtol=1e-10
            )
            if np.all(np.isfinite(result.x)):
                if best is None or result.cost < best.cost:
                    best = result
        except (ValueError, FloatingPointError):
            pass

    if best is None:
        return {
            "L_inf": length_scale,
            "k": 1.0 / time_scale,
            "p": 1.0,
        }
    amplitude, rate, exponent = np.exp(best.x)
    return {
        "L_inf": float(amplitude * length_scale),
        "k": float(rate / time_scale**exponent),
        "p": float(exponent),
    }

def predict(X, **params):
    age = np.maximum(np.asarray(X, dtype=float)[:, 0], 0.0)
    with np.errstate(over="ignore"):
        growth = params["k"] * age**params["p"]
    return params["L_inf"] * (-np.expm1(-growth))