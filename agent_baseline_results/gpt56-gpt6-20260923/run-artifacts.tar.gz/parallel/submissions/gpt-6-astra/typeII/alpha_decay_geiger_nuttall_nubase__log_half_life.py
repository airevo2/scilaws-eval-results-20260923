"""Shared two-term decay law: log10(T12/s) = a/sqrt(Q_alpha_MeV) + b*sqrt(Q_alpha_MeV)."""
import numpy as np

USED_INPUTS = ["Q_alpha_MeV"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {"a": {"init": None}, "b": {"init": None}}

def fit(X_fit, y_fit):
    Q = np.asarray(X_fit, dtype=float)[:, 0]
    y = np.asarray(y_fit, dtype=float).reshape(-1)
    valid = np.isfinite(Q) & (Q > 0) & np.isfinite(y)
    if not np.any(valid):
        return {"a": 0.0, "b": 0.0}
    root = np.sqrt(Q[valid])
    design = np.column_stack((1.0 / root, root))
    coefficients = np.linalg.lstsq(design, y[valid], rcond=None)[0]
    return {"a": float(coefficients[0]), "b": float(coefficients[1])}

def predict(X, **params):
    Q = np.asarray(X, dtype=float)[:, 0]
    root = np.sqrt(np.maximum(Q, np.finfo(float).tiny))
    return params["a"] / root + params["b"] * root