"""Height follows a diameter power law with a logarithmically declining exponent and a plot-specific amplitude."""
import numpy as np

USED_INPUTS = ["DBH_cm"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {"a": {"init": None}}

def _shape(D):
    log_D = np.log(np.maximum(np.asarray(D, dtype=float), 1.0))
    return np.exp(0.6 * log_D / (1.0 + 0.04 * log_D))

def fit(X_fit, y_fit):
    D = np.asarray(X_fit, dtype=float)[:, 0]
    y = np.asarray(y_fit, dtype=float).reshape(-1)
    valid = np.isfinite(D) & np.isfinite(y) & (D > 0)
    if not np.any(valid):
        return {"a": 1.0}
    z = _shape(D[valid])
    a = np.dot(z, y[valid]) / np.dot(z, z)
    return {"a": float(max(a, 0.0))}

def predict(X, **params):
    return params["a"] * _shape(np.asarray(X, dtype=float)[:, 0])