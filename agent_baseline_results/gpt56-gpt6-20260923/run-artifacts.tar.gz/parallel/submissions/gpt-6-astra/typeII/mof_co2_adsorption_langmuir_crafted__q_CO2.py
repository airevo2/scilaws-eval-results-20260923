"""Toth adsorption isotherm with local saturation capacity, affinity, and heterogeneity."""
import numpy as np
from scipy.optimize import least_squares

USED_INPUTS = ["P_bar"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {
    "q_s": {"init": None},
    "b": {"init": None},
    "t": {"init": None},
}

def predict(X, q_s, b, t):
    P = np.maximum(np.asarray(X, dtype=float)[:, 0], 0.0)
    return q_s * b * P / (1.0 + (b * P)**t)**(1.0 / t)

def fit(X_fit, y_fit):
    X = np.asarray(X_fit, dtype=float)
    y = np.asarray(y_fit, dtype=float).reshape(-1)
    valid = np.isfinite(X[:, 0]) & np.isfinite(y) & (X[:, 0] >= 0)
    X, y = X[valid], y[valid]
    if y.size == 0:
        return {"q_s": 1.0, "b": 1.0, "t": 1.0}

    scale = max(float(np.max(y)), 1e-6)
    positive = X[:, 0] > 0
    P = X[:, 0]
    if np.any(positive):
        half_index = np.argmin(np.abs(y[positive] - 0.5 * scale))
        b0 = 1.0 / max(float(P[positive][half_index]), 1e-10)
    else:
        b0 = 1.0

    lower = np.log([1e-10, 1e-10, 0.05])
    upper = np.log([max(scale * 1e6, 1.0), 1e10, 10.0])
    best = None
    for t0 in (0.6, 1.0, 1.7):
        initial = np.log([1.2 * scale, b0, t0])
        initial = np.clip(initial, lower + 1e-8, upper - 1e-8)
        try:
            result = least_squares(
                lambda z: (predict(X, *np.exp(z)) - y) / scale,
                initial,
                bounds=(lower, upper),
                max_nfev=1200,
            )
            if np.all(np.isfinite(result.x)):
                if best is None or result.cost < best.cost:
                    best = result
        except (ValueError, FloatingPointError):
            pass

    params = np.exp(best.x) if best is not None else np.array([scale, b0, 1.0])
    return {"q_s": float(params[0]), "b": float(params[1]), "t": float(params[2])}