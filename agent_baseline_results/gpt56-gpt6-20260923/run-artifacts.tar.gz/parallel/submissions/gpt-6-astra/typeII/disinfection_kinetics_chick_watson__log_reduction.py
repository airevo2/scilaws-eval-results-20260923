"""Log-reduction follows a power law in log-transformed dose: a * log(1 + CT)**b."""
import numpy as np
from scipy.optimize import least_squares

USED_INPUTS = ["CT"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {"a": {"init": None}, "b": {"init": None}}

def fit(X_fit, y_fit):
    x = np.asarray(X_fit, dtype=float)[:, 0]
    y = np.asarray(y_fit, dtype=float).reshape(-1)
    keep = np.isfinite(x) & np.isfinite(y) & (x > 0)
    x, y = x[keep], y[keep]
    if not len(y):
        return {"a": 0.0, "b": 1.0}

    t = np.log1p(x)
    scale = float(np.median(t))
    z = np.log(t / scale)
    positive = y > 0
    b0 = 1.0
    if positive.sum() >= 2 and np.ptp(z[positive]) > 1e-10:
        b0 = float(np.clip(
            np.polyfit(z[positive], np.log(y[positive]), 1)[0],
            0.0, 50.0
        ))
    c0 = max(float(np.median(
        y / np.exp(np.clip(b0 * z, -700, 700))
    )), 1e-12)
    initial = np.array([np.log(c0), b0])

    def residual(p):
        return np.exp(np.clip(p[0] + p[1] * z, -700, 700)) - y

    r0 = residual(initial)
    noise_scale = max(
        1.4826 * float(np.median(np.abs(r0 - np.median(r0)))),
        1e-6 * max(float(np.max(np.abs(y))), 1.0)
    )
    try:
        result = least_squares(
            residual, initial,
            bounds=([-700.0, 0.0], [700.0, 100.0]),
            loss="soft_l1", f_scale=noise_scale,
            max_nfev=1000
        )
        c, b = result.x
        a = float(np.exp(np.clip(c - b * np.log(scale), -700, 700)))
        return {"a": a, "b": float(b)}
    except Exception:
        a = float(np.exp(np.clip(
            initial[0] - b0 * np.log(scale), -700, 700
        )))
        return {"a": a, "b": b0}

def predict(X, a, b):
    ct = np.maximum(np.asarray(X, dtype=float)[:, 0], 0.0)
    with np.errstate(over="ignore", invalid="ignore"):
        result = a * np.power(np.log1p(ct), b)
    return np.nan_to_num(result, nan=0.0, posinf=np.finfo(float).max,
                         neginf=0.0)