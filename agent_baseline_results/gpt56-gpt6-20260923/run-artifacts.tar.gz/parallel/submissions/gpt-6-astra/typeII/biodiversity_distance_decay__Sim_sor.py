"""Regularized power-law distance decay: S = A (d + 0.2)^(-b)."""
import numpy as np
from scipy.optimize import least_squares

USED_INPUTS = ["env_dist"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {"A": {"init": None}, "b": {"init": None}}

def fit(X_fit, y_fit):
    d = np.asarray(X_fit, dtype=float)[:, 0]
    y = np.asarray(y_fit, dtype=float).reshape(-1)
    valid = np.isfinite(d) & np.isfinite(y)
    d, y = d[valid], y[valid]
    if len(y) == 0:
        return {"A": 0.5, "b": 0.5}

    z = np.log(np.maximum(d + 0.2, np.finfo(float).tiny))
    positive = y > 0
    b0 = 0.5
    if positive.sum() >= 2 and np.ptp(z[positive]) > 0:
        slope, intercept = np.polyfit(z[positive], np.log(y[positive]), 1)
        b0 = float(np.clip(-slope, 0.0, 20.0))
    logA0 = float(np.median(np.log(np.maximum(y, 1e-10)) + b0 * z))
    p0 = np.array([np.clip(logA0, -30.0, 30.0), b0])

    def residual(p):
        return np.exp(np.clip(p[0] - p[1] * z, -700.0, 700.0)) - y

    initial_residual = residual(p0)
    scale = max(float(np.median(np.abs(initial_residual -
                                           np.median(initial_residual)))), 1e-4)
    try:
        result = least_squares(
            residual, p0, bounds=([-30.0, 0.0], [30.0, 20.0]),
            loss="soft_l1", f_scale=scale, max_nfev=1000
        )
        p = result.x if np.all(np.isfinite(result.x)) else p0
    except Exception:
        p = p0
    return {"A": float(np.exp(p[0])), "b": float(p[1])}

def predict(X, **params):
    d = np.asarray(X, dtype=float)[:, 0]
    return params["A"] * np.maximum(d + 0.2, np.finfo(float).tiny) ** (-params["b"])