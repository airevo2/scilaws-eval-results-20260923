"""Life expectancy is affine in squared elapsed calendar time from the reference epoch."""
import numpy as np

USED_INPUTS = ["year"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {"a": {"init": None}, "b": {"init": None}}

def fit(X_fit, y_fit):
    t = np.asarray(X_fit, dtype=float)[:, 0]
    y = np.asarray(y_fit, dtype=float).reshape(-1)
    valid = np.isfinite(t) & np.isfinite(y)
    t, y = t[valid], y[valid]
    if y.size == 0:
        return {"a": 0.0, "b": 0.0}
    z = (t - 1700.0) ** 2
    center = float(np.mean(z))
    yc = float(np.mean(y))
    dz = z - center
    denom = float(np.dot(dz, dz))
    b = float(np.dot(dz, y - yc) / denom) if denom > 0 else 0.0
    return {"a": yc - b * center, "b": b}

def predict(X, **params):
    t = np.asarray(X, dtype=float)[:, 0]
    return params["a"] + params["b"] * (t - 1700.0) ** 2