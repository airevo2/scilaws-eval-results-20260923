"""Canopy conductance follows G_c = G_ref - m * ln(D), with reference conductance and VPD sensitivity calibrated per cluster."""
import numpy as np

USED_INPUTS = ["vpd"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {
    "G_ref": {"init": None},
    "m": {"init": None}
}

def fit(X_fit, y_fit):
    D = np.asarray(X_fit, dtype=float)[:, 0]
    y = np.asarray(y_fit, dtype=float).reshape(-1)
    valid = np.isfinite(D) & (D > 0) & np.isfinite(y)
    if not np.any(valid):
        return {"G_ref": 0.0, "m": 0.0}
    z = np.log(D[valid])
    y = y[valid]
    if len(y) < 2 or np.ptp(z) == 0:
        return {"G_ref": float(np.mean(y)), "m": 0.0}
    A = np.column_stack((np.ones_like(z), -z))
    coef = np.linalg.lstsq(A, y, rcond=None)[0]
    return {"G_ref": float(coef[0]), "m": float(coef[1])}

def predict(X, **params):
    D = np.asarray(X, dtype=float)[:, 0]
    D = np.maximum(D, np.finfo(float).tiny)
    return params["G_ref"] - params["m"] * np.log(D)