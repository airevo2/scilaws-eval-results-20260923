"""Penman–Monteith evaporation with a light-saturating, humidity-dependent canopy conductance and exponential VPD suppression."""
import numpy as np
from scipy.optimize import least_squares

USED_INPUTS = ["SWdown", "VPD", "RH", "Rnet", "Qg", "Ga", "delta", "theta_FC"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {
    "gmax": {"init": None},
    "light_scale": {"init": None},
    "vpd_sensitivity": {"init": None},
    "humidity_power": {"init": None},
    "rho_cp": {"init": None}
}

def predict(X, **params):
    X = np.asarray(X, dtype=float)
    S, D, H, R, G, ga, slope, theta = X.T
    S = np.maximum(S, 1e-12)
    H = np.maximum(H, 1e-12)
    ga = np.maximum(ga, 0.0)
    gc = (
        params["gmax"] * theta
        * S / (S + params["light_scale"])
        * np.exp(np.clip(-params["vpd_sensitivity"] * D, -700, 50))
        * H ** params["humidity_power"]
    )
    gc = np.maximum(gc, 1e-15)
    # Psychrometric constant in kPa K^-1.
    gamma = 0.066
    return (
        slope * (R - G) + params["rho_cp"] * ga * D
    ) / np.maximum(slope + gamma * (1.0 + ga / gc), 1e-15)

def fit(X_fit, y_fit):
    X = np.asarray(X_fit, dtype=float)
    y = np.asarray(y_fit, dtype=float).reshape(-1)
    valid = np.isfinite(X).all(axis=1) & np.isfinite(y)
    X, y = X[valid], y[valid]
    names = tuple(LOCAL_FITTABLE)
    fallback = np.array([0.05, 100.0, 1.0, 1.0, 1200.0])
    if not len(y):
        return dict(zip(names, fallback))
    scale = max(float(np.std(y)), 1.0)
    lower = [1e-8, 0.0, 0.0, 0.0, 100.0]
    upper = [10.0, 1e5, 100.0, 8.0, 5000.0]

    def residual(p):
        return (predict(X, **dict(zip(names, p))) - y) / scale

    best = None
    for light in (1.0, 300.0):
        initial = fallback.copy()
        initial[1] = light
        try:
            result = least_squares(
                residual, initial, bounds=(lower, upper),
                x_scale="jac", max_nfev=350
            )
            if np.all(np.isfinite(result.x)):
                if best is None or result.cost < best.cost:
                    best = result
        except (ValueError, FloatingPointError):
            pass
    p = fallback if best is None else best.x
    return {name: float(value) for name, value in zip(names, p)}