"""Surface tension scales as (T_c - T)^(11/9) divided by molar volume^(2/3), with one substance-specific amplitude."""
import numpy as np

USED_INPUTS = ["T_K", "rho_liq", "T_c", "M_mol"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {"a": {"init": None}}

def _basis(X):
    X = np.asarray(X, dtype=float)
    delta_T = np.maximum(X[:, 2] - X[:, 0], 0.0)
    molar_density = np.maximum(
        X[:, 1] / np.maximum(X[:, 3], np.finfo(float).tiny), 0.0
    )
    return delta_T ** (11.0 / 9.0) * molar_density ** (2.0 / 3.0)

def fit(X_fit, y_fit):
    basis = _basis(X_fit)
    y = np.asarray(y_fit, dtype=float).reshape(-1)
    valid = np.isfinite(basis) & np.isfinite(y) & (basis > 0)
    if not np.any(valid):
        return {"a": 0.0}
    a = np.median(y[valid] / basis[valid])
    return {"a": float(max(a, 0.0))}

def predict(X, **params):
    return params["a"] * _basis(X)