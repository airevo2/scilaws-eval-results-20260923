"""Generalized saturating adsorption: n = n_s [1 - (1 + K P)^(-m)]."""
import numpy as np
from scipy.optimize import least_squares

USED_INPUTS = ["P_bar"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {
    "n_s": {"init": None},
    "K": {"init": None},
    "m": {"init": None},
}

def predict(X, n_s, K, m):
    P = np.maximum(np.asarray(X, dtype=float)[:, 0], 0.0)
    return n_s * (-np.expm1(-m * np.log1p(K * P)))

def fit(X_fit, y_fit):
    X = np.asarray(X_fit, dtype=float)
    y = np.asarray(y_fit, dtype=float).reshape(-1)
    valid = np.isfinite(X[:, 0]) & np.isfinite(y) & (X[:, 0] >= 0)
    X, y = X[valid], y[valid]
    if len(y) == 0:
        return {"n_s": 1.0, "K": 1.0, "m": 1.0}

    scale = max(float(np.max(np.abs(y))), 1e-8)
    positive = X[:, 0][X[:, 0] > 0]
    pscale = float(np.median(positive)) if len(positive) else 1.0
    Z = X.copy()
    Z[:, 0] /= pscale
    yn = y / scale

    def residual(z):
        a, b, m = np.exp(z)
        return predict(Z, a, b, m) - yn

    best = None
    for m0 in (0.05, 0.3, 1.0):
        b0 = 1.0
        a0 = max(float(np.max(yn)), 0.1) / (-np.expm1(-m0 * np.log(2.0)))
        z0 = np.log([a0, b0, m0])
        try:
            sol = least_squares(
                residual, z0,
                bounds=([-16.0, -25.0, -12.0], [16.0, 25.0, 6.0]),
                loss="soft_l1", f_scale=0.005,
                max_nfev=1200,
            )
            if np.all(np.isfinite(sol.x)) and (best is None or sol.cost < best.cost):
                best = sol
        except (ValueError, FloatingPointError):
            pass

    if best is None:
        return {"n_s": 2.0 * scale, "K": 1.0 / pscale, "m": 1.0}

    a, b, m = np.exp(best.x)
    return {"n_s": float(a * scale), "K": float(b / pscale), "m": float(m)}