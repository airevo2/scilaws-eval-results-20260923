"""Log mortality sex ratio is quadratic in adult age and linear in calendar year."""
import numpy as np

USED_INPUTS = ["age", "year"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {
    "a": {"init": None},
    "b": {"init": None},
    "c": {"init": None},
}

def fit(X_fit, y_fit):
    X = np.asarray(X_fit, dtype=float)
    y = np.asarray(y_fit, dtype=float).reshape(-1)
    valid = np.isfinite(y) & np.all(np.isfinite(X[:, :2]), axis=1)
    X, y = X[valid], y[valid]
    if len(y) == 0:
        return {"a": 0.0, "b": 0.0, "c": 0.0}

    age_term = (X[:, 0] - 30.0) ** 2
    year = X[:, 1]
    features = np.column_stack((age_term, year))
    center = features.mean(axis=0)
    scale = features.std(axis=0)
    scale = np.where(scale > 0.0, scale, 1.0)
    design = np.column_stack((np.ones(len(y)), (features - center) / scale))

    try:
        coef = np.linalg.lstsq(design, y, rcond=None)[0]
        slopes = coef[1:] / scale
        intercept = coef[0] - np.dot(slopes, center)
        return {"a": float(intercept), "b": float(slopes[0]), "c": float(slopes[1])}
    except np.linalg.LinAlgError:
        return {"a": float(np.mean(y)), "b": 0.0, "c": 0.0}

def predict(X, **params):
    X = np.asarray(X, dtype=float)
    return (
        params["a"]
        + params["b"] * (X[:, 0] - 30.0) ** 2
        + params["c"] * X[:, 1]
    )