"""Quadratic log-tail law: ln S(p) = a + b ln p + c (ln p)^2."""
import numpy as np

USED_INPUTS = ["log_p_above"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {
    "a": {"init": None},
    "b": {"init": None},
    "c": {"init": None},
}

def fit(X_fit, y_fit):
    x = np.asarray(X_fit, dtype=float)[:, 0]
    y = np.asarray(y_fit, dtype=float).reshape(-1)
    valid = np.isfinite(x) & np.isfinite(y)
    x, y = x[valid], y[valid]
    if x.size == 0:
        return {"a": 0.0, "b": 0.0, "c": 0.0}

    center = float(np.mean(x))
    scale = float(np.std(x))
    if scale == 0.0:
        return {"a": float(np.mean(y)), "b": 0.0, "c": 0.0}

    z = (x - center) / scale
    degree = min(2, np.unique(x).size - 1)
    design = np.column_stack([z ** k for k in range(degree + 1)])
    coefficients = np.linalg.lstsq(design, y, rcond=None)[0]
    q = np.zeros(3)
    q[:degree + 1] = coefficients
    c = q[2] / scale**2
    b = q[1] / scale - 2.0 * c * center
    a = q[0] - q[1] * center / scale + c * center**2
    return {"a": float(a), "b": float(b), "c": float(c)}

def predict(X, **params):
    x = np.asarray(X, dtype=float)[:, 0]
    return params["a"] + x * (params["b"] + params["c"] * x)