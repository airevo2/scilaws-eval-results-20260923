"""Weir discharge with a coefficient affine in the square root of relative head:
Q = b h^(3/2) [a + c sqrt(h/p)].
The two coefficient parameters are calibrated separately for each cluster."""
import numpy as np

USED_INPUTS = ["h_m", "p_m", "b_m"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {"a": {"init": None}, "c": {"init": None}}

def _basis(X):
    X = np.asarray(X, dtype=float)
    h = np.maximum(X[:, 0], 0.0)
    p = np.maximum(X[:, 1], np.finfo(float).tiny)
    b = X[:, 2]
    base = b * h ** 1.5
    return np.column_stack((base, base * np.sqrt(h / p)))

def fit(X_fit, y_fit):
    A = _basis(X_fit)
    y = np.asarray(y_fit, dtype=float).reshape(-1)
    valid = np.isfinite(y) & np.all(np.isfinite(A), axis=1)
    A, y = A[valid], y[valid]
    if len(y) == 0:
        return {"a": 0.0, "c": 0.0}
    try:
        theta = np.linalg.lstsq(A, y, rcond=None)[0]
        return {"a": float(theta[0]), "c": float(theta[1])}
    except np.linalg.LinAlgError:
        denom = float(A[:, 0] @ A[:, 0])
        a = float(A[:, 0] @ y) / denom if denom > 0 else 0.0
        return {"a": a, "c": 0.0}

def predict(X, **params):
    return _basis(X) @ np.array([params["a"], params["c"]], dtype=float)