"""Capacity approaches a residual capacity by stretched-exponential cycling decay."""
import numpy as np
from scipy.optimize import least_squares

USED_INPUTS = ["cycle_index"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {
    "Q0": {"init": None},
    "Q_inf": {"init": None},
    "tau": {"init": None},
    "beta": {"init": None},
}

def _decay(k, tau, beta):
    z = beta * np.log(np.maximum(k, 1e-300) / max(tau, 1e-300))
    return np.exp(-np.exp(np.clip(z, -700.0, 700.0)))

def fit(X_fit, y_fit):
    k = np.asarray(X_fit, dtype=float)[:, 0]
    y = np.asarray(y_fit, dtype=float).reshape(-1)
    valid = np.isfinite(k) & np.isfinite(y)
    k, y = k[valid], y[valid]
    if len(y) == 0:
        return {"Q0": 0.0, "Q_inf": 0.0, "tau": 1.0, "beta": 1.0}
    ks = max(float(np.max(k)), 1.0)
    ys = max(float(np.max(np.abs(y))), 1e-12)
    x, v = k / ks, y / ys
    order = np.argsort(x)
    initial = float(np.median(v[order[:max(1, len(v)//5)]]))
    terminal = float(np.median(v[order[-max(1, len(v)//5):]]))
    amplitude = max(initial - terminal, 0.001)
    best = None

    def residual(p):
        q0, delta, log_tau, beta = p
        survival = _decay(x, np.exp(log_tau), beta)
        return q0 - delta * (1.0 - survival) - v

    for beta0 in (1.0, 2.0, 4.0):
        p0 = [initial, min(2.0 * amplitude, 50.0), 0.0, beta0]
        try:
            result = least_squares(
                residual, p0,
                bounds=([-10.0, -100.0, -9.0, 0.05],
                        [10.0, 100.0, 12.0, 15.0]),
                loss="soft_l1", f_scale=0.01,
                max_nfev=700, x_scale="jac"
            )
            if np.all(np.isfinite(result.x)):
                if best is None or result.cost < best.cost:
                    best = result
        except Exception:
            pass
    if best is None:
        return {"Q0": initial * ys, "Q_inf": terminal * ys,
                "tau": ks, "beta": 1.0}
    q0, delta, log_tau, beta = best.x
    return {"Q0": float(q0 * ys),
            "Q_inf": float((q0 - delta) * ys),
            "tau": float(np.exp(log_tau) * ks),
            "beta": float(beta)}

def predict(X, **params):
    k = np.asarray(X, dtype=float)[:, 0]
    return params["Q_inf"] + (params["Q0"] - params["Q_inf"]) * _decay(
        k, params["tau"], params["beta"]
    )