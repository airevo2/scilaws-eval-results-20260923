"""Hertz spherical-contact law: force scales with sqrt(radius) times indentation^(3/2), with one effective elastic modulus per cluster."""
import numpy as np

USED_INPUTS = ["indentation_m", "R_m"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {"E_eff": {"init": None}}

def fit(X_fit, y_fit):
    X_fit = np.asarray(X_fit, dtype=float)
    y = np.asarray(y_fit, dtype=float).reshape(-1)
    basis = (4.0 / 3.0) * np.sqrt(np.maximum(X_fit[:, 1], 0.0)) * np.maximum(X_fit[:, 0], 0.0)**1.5
    valid = np.isfinite(basis) & np.isfinite(y)
    b = basis[valid]
    y = y[valid]
    scale = float(np.max(b)) if b.size else 0.0
    if scale <= 0.0:
        return {"E_eff": 0.0}
    z = b / scale
    E_eff = np.dot(z, y) / (scale * np.dot(z, z))
    return {"E_eff": float(max(E_eff, 0.0))}

def predict(X, **params):
    X = np.asarray(X, dtype=float)
    delta = np.maximum(X[:, 0], 0.0)
    R = np.maximum(X[:, 1], 0.0)
    return (4.0 / 3.0) * params["E_eff"] * np.sqrt(R) * delta**1.5