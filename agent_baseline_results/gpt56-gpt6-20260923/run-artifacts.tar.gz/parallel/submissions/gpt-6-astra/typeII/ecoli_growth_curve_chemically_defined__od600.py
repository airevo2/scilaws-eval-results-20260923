"""Four-parameter logistic growth: baseline plus a saturating biomass increase."""
import numpy as np
from scipy.optimize import least_squares
from scipy.special import expit

USED_INPUTS = ["time_h"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {
    "baseline": {"init": None},
    "amplitude": {"init": None},
    "rate": {"init": None},
    "midpoint": {"init": None},
}

def fit(X_fit, y_fit):
    t = np.asarray(X_fit, dtype=float)[:, 0]
    y = np.asarray(y_fit, dtype=float).ravel()
    valid = np.isfinite(t) & np.isfinite(y)
    t, y = t[valid], y[valid]
    if y.size == 0:
        return dict(baseline=0.0, amplitude=0.0, rate=1.0, midpoint=0.0)

    origin = float(np.min(t))
    span = max(float(np.ptp(t)), 1.0)
    low = float(np.min(y))
    scale = float(np.ptp(y))
    if scale <= 1e-12:
        return dict(baseline=float(np.mean(y)), amplitude=0.0,
                    rate=1.0 / span, midpoint=float(np.median(t)))

    u = (t - origin) / span
    v = (y - low) / scale
    center = float(u[np.argmin(np.abs(v - 0.5))])

    def residual(p):
        b, a, r, c = p
        return b + a * expit(r * (u - c)) - v

    best = None
    for initial_rate in (2.0, 10.0, 30.0):
        try:
            result = least_squares(
                residual, [0.0, 1.0, initial_rate, center],
                bounds=([-2.0, 0.0, 1e-6, -3.0],
                        [1.0, 10.0, 500.0, 4.0]),
                max_nfev=600,
                ftol=1e-9, xtol=1e-9, gtol=1e-9,
            )
            if np.all(np.isfinite(result.x)):
                if best is None or result.cost < best.cost:
                    best = result
        except (ValueError, FloatingPointError):
            pass

    if best is None:
        return dict(baseline=low, amplitude=scale, rate=10.0 / span,
                    midpoint=origin + span * center)

    b, a, r, c = best.x
    return dict(
        baseline=float(low + scale * b),
        amplitude=float(scale * a),
        rate=float(r / span),
        midpoint=float(origin + span * c),
    )

def predict(X, **params):
    t = np.asarray(X, dtype=float)[:, 0]
    return params["baseline"] + params["amplitude"] * expit(
        params["rate"] * (t - params["midpoint"])
    )