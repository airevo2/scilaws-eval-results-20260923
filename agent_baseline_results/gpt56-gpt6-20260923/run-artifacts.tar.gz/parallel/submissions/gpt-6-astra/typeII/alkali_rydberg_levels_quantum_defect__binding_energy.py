"""Rydberg binding energy with an inverse-even-power quantum defect:
delta(n) = delta0 + delta2/n^2 + delta4/n^4.
The Rydberg constant is a fixed physical constant, expressed in cm^-1.
"""
import numpy as np
from scipy.constants import Rydberg
from scipy.optimize import least_squares

USED_INPUTS = ["n_qm"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {
    "delta0": {"init": None},
    "delta2": {"init": None},
    "delta4": {"init": None},
}

def fit(X_fit, y_fit):
    n = np.asarray(X_fit, dtype=float)[:, 0]
    y = np.asarray(y_fit, dtype=float).reshape(-1)
    good = np.isfinite(n) & np.isfinite(y) & (n > 0) & (y > 0)
    n, y = n[good], y[good]
    if n.size == 0:
        return {"delta0": 0.0, "delta2": 0.0, "delta4": 0.0}

    R = Rydberg / 100.0
    defect = n - np.sqrt(R / y)
    design = np.column_stack((np.ones_like(n), n**-2, n**-4))
    scale = np.maximum(np.linalg.norm(design, axis=0), 1e-12)
    initial = np.linalg.lstsq(design / scale, defect, rcond=None)[0] / scale

    def residual(p):
        effective_n = n - design @ p
        safe_n = np.maximum(effective_n, 1e-10)
        return np.log(R / y) - 2.0 * np.log(safe_n)

    try:
        result = least_squares(
            residual, initial, x_scale="jac",
            loss="soft_l1", f_scale=0.002, max_nfev=1000
        )
        p = result.x if np.all(np.isfinite(result.x)) else initial
    except Exception:
        p = initial
    return dict(zip(("delta0", "delta2", "delta4"), map(float, p)))

def predict(X, **params):
    n = np.maximum(np.asarray(X, dtype=float)[:, 0], 1e-12)
    delta = (
        params["delta0"]
        + params["delta2"] / n**2
        + params["delta4"] / n**4
    )
    denominator = np.maximum((n - delta)**2, 1e-24)
    return (Rydberg / 100.0) / denominator