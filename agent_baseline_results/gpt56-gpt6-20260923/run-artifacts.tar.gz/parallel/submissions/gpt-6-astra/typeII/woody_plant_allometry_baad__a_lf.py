"""Pipe-model allometry: leaf area is proportional to sapwood cross-sectional area."""
import numpy as np

USED_INPUTS = ["a_ssbh"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {"k": {"init": None}}

def fit(X_fit, y_fit):
    A = np.asarray(X_fit, dtype=float)[:, 0]
    y = np.asarray(y_fit, dtype=float).reshape(-1)
    valid = np.isfinite(A) & np.isfinite(y) & (A > 0) & (y > 0)
    if not np.any(valid):
        return {"k": 1.0}
    k = np.exp(np.mean(np.log(y[valid]) - np.log(A[valid])))
    return {"k": float(k)}

def predict(X, **params):
    A = np.asarray(X, dtype=float)[:, 0]
    return params["k"] * A