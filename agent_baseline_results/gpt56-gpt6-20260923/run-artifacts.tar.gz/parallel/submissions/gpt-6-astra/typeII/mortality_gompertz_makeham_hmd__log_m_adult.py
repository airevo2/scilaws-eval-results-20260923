"""Gompertz–Makeham mortality: m(age) = C + A exp(b*age), expressed in log space."""
import numpy as np
from scipy.optimize import least_squares

USED_INPUTS = ["age"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {
    "log_C": {"init": None},
    "log_A": {"init": None},
    "b": {"init": None},
}

def fit(X_fit, y_fit):
    x = np.asarray(X_fit, dtype=float)[:, 0]
    y = np.asarray(y_fit, dtype=float).reshape(-1)
    valid = np.isfinite(x) & np.isfinite(y)
    x, y = x[valid], y[valid]
    if x.size == 0:
        return {"log_C": -10.0, "log_A": -10.0, "b": 0.1}

    center = float(np.mean(x))
    z = x - center
    design = np.column_stack([np.ones_like(z), z])
    intercept, slope = np.linalg.lstsq(design, y, rcond=None)[0]
    slope = float(np.clip(slope, 1e-8, 1.0))
    best = None
    best_cost = np.inf

    for gap in (0.5, 2.0, 6.0):
        initial = [
            float(np.clip(np.min(y) - gap, -100, 20)),
            float(np.clip(intercept, -100, 20)),
            slope,
        ]
        try:
            result = least_squares(
                lambda p: np.logaddexp(p[0], p[1] + p[2] * z) - y,
                initial,
                bounds=([-100, -100, 0], [20, 20, 1]),
                max_nfev=1000,
            )
            if np.isfinite(result.cost) and result.cost < best_cost:
                best, best_cost = result.x, result.cost
        except (ValueError, FloatingPointError):
            pass

    if best is None:
        best = np.array([np.min(y) - 6.0, intercept, slope])

    return {
        "log_C": float(best[0]),
        "log_A": float(best[1] - best[2] * center),
        "b": float(best[2]),
    }

def predict(X, **params):
    age = np.asarray(X, dtype=float)[:, 0]
    return np.logaddexp(params["log_C"], params["log_A"] + params["b"] * age)