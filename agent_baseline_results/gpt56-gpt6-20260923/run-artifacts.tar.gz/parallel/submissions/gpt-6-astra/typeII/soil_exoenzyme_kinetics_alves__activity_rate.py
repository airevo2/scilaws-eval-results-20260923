"""Hill enzyme kinetics: v = Vmax*S**h / (K**h + S**h)."""
import numpy as np
from scipy.optimize import least_squares
from scipy.special import expit

USED_INPUTS = ["substrate_conc"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {
    "Vmax": {"init": None},
    "K": {"init": None},
    "h": {"init": None},
}

def fit(X_fit, y_fit):
    S = np.asarray(X_fit, dtype=float)[:, 0]
    y = np.asarray(y_fit, dtype=float).reshape(-1)
    keep = np.isfinite(S) & np.isfinite(y) & (S > 0)
    S, y = S[keep], y[keep]
    if S.size == 0:
        return {"Vmax": 1.0, "K": 1.0, "h": 1.0}

    scale = max(float(np.max(np.abs(y))), 1e-12)
    center = float(np.median(S))
    logS = np.log(S)
    lower = np.log([scale * 1e-6, float(S.min()) * 1e-6, 0.02])
    upper = np.log([scale * 1e4, float(S.max()) * 1e6, 20.0])

    def residual(theta):
        V, K, h = np.exp(theta)
        return (V * expit(h * (logS - np.log(K))) - y) / scale

    best = None
    best_cost = np.inf
    for exponent in (0.7, 1.0, 1.5):
        initial = np.log([scale * 1.2, center, exponent])
        try:
            result = least_squares(
                residual, initial, bounds=(lower, upper),
                max_nfev=700, ftol=1e-10, xtol=1e-10, gtol=1e-10
            )
            cost = float(np.sum(result.fun ** 2))
            if np.isfinite(cost) and cost < best_cost:
                best, best_cost = np.exp(result.x), cost
        except (ValueError, FloatingPointError):
            pass

    if best is None:
        best = (scale, center, 1.0)
    return {"Vmax": float(best[0]), "K": float(best[1]), "h": float(best[2])}

def predict(X, Vmax, K, h):
    S = np.maximum(np.asarray(X, dtype=float)[:, 0], 0.0)
    logS = np.log(np.maximum(S, np.finfo(float).tiny))
    result = Vmax * expit(h * (logS - np.log(max(K, np.finfo(float).tiny))))
    return np.where(S > 0, result, 0.0)