"""A Gaussian thermal-growth envelope multiplied by a Gompertz high-temperature inhibition factor."""
import numpy as np
from scipy.optimize import least_squares

USED_INPUTS = ["T"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {
    "A": {"init": None},
    "T_opt": {"init": None},
    "sigma": {"init": None},
    "T_inhibit": {"init": None},
    "width": {"init": None}
}

def predict(X, A, T_opt, sigma, T_inhibit, width):
    T = np.asarray(X, dtype=float)[:, 0]
    sigma = max(float(sigma), 1e-8)
    width = max(float(width), 1e-8)
    inhibition = np.exp(np.clip((T - T_inhibit) / width, -700, 50))
    exponent = -0.5 * ((T - T_opt) / sigma)**2 - inhibition
    return float(A) * np.exp(np.clip(exponent, -745, 0))

def fit(X_fit, y_fit):
    X = np.asarray(X_fit, dtype=float)
    y = np.asarray(y_fit, dtype=float).reshape(-1)
    valid = np.isfinite(X[:, 0]) & np.isfinite(y)
    X, y = X[valid], y[valid]
    names = ("A", "T_opt", "sigma", "T_inhibit", "width")
    if not len(y):
        return dict(zip(names, (0.0, 37.0, 6.0, 43.0, 2.0)))

    t, inverse = np.unique(X[:, 0], return_inverse=True)
    values = np.array([np.median(y[inverse == i]) for i in range(len(t))])
    scale = max(float(np.max(values)), 1e-5)
    peak = float(t[np.argmax(values)])
    span = max(float(np.ptp(t)), 5.0)
    xx = t[:, None]
    lower = [0.0, float(t.min()) - span, 0.1, float(t.min()) - span, 0.1]
    upper = [1000.0 * scale, float(t.max()) + 3 * span,
             3 * span, float(t.max()) + 2 * span, 2 * span]

    def residual(p):
        return (predict(xx, **dict(zip(names, p))) - values) / scale

    best = None
    for shift, sigma, width in [(0.0, span / 4, 1.0),
                                 (span / 6, span / 4, 2.0),
                                 (span / 3, span / 3, 4.0)]:
        p0 = [scale * 1.5, peak + shift, sigma,
              max(peak + 2, float(t.max()) - 3), width]
        try:
            result = least_squares(
                residual, p0, bounds=(lower, upper),
                x_scale="jac", max_nfev=650
            )
            score = float(np.dot(result.fun, result.fun))
            if np.all(np.isfinite(result.x)) and (best is None or score < best[0]):
                best = (score, result.x)
        except (ValueError, FloatingPointError):
            pass

    params = best[1] if best is not None else [
        scale, peak, span / 4, float(t.max()) - 2, 2.0
    ]
    return {name: float(value) for name, value in zip(names, params)}