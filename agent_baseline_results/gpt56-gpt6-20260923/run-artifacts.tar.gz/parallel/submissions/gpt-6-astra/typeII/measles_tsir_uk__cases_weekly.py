"""Seasonally forced log-growth: logarithmic epidemic-state feedback and a logarithmic susceptible-pool correction."""
import numpy as np
from scipy.optimize import least_squares

USED_INPUTS = ["cases_prev", "biweek", "z_t"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {
    "a": {"init": None},
    "b": {"init": None},
    "k": {"init": None},
    "s": {"init": None},
    "c": {"init": None},
}

def fit(X_fit, y_fit):
    X = np.asarray(X_fit, dtype=float)
    y = np.asarray(y_fit, dtype=float).reshape(-1)
    valid = np.isfinite(y) & np.all(np.isfinite(X), axis=1)
    X, y = X[valid], y[valid]
    if len(y) == 0:
        return dict(a=0.0, b=0.0, k=0.0, s=0.0, c=0.0)

    log_I = np.log1p(np.maximum(X[:, 0], 0.0))
    angle = 2.0 * np.pi * X[:, 1] / 26.0
    sn, cs = np.sin(angle), np.cos(angle)
    scale = max(float(np.max(np.abs(X[:, 2]))), 1.0)
    z = np.maximum(X[:, 2], 0.0) / scale
    A = np.column_stack((np.ones(len(y)), log_I, z, sn, cs))
    p = np.linalg.lstsq(A, y, rcond=None)[0]
    p[2] = max(float(p[2]), 0.0)

    def residual(q):
        return (
            q[0] + q[1] * log_I + np.log1p(q[2] * z)
            + q[3] * sn + q[4] * cs - y
        )

    r = residual(p)
    noise_scale = max(
        1.4826 * float(np.median(np.abs(r - np.median(r)))),
        1e-3,
    )
    try:
        result = least_squares(
            residual, p,
            bounds=([-np.inf, -np.inf, 0.0, -np.inf, -np.inf],
                    [np.inf, np.inf, np.inf, np.inf, np.inf]),
            loss="soft_l1",
            f_scale=noise_scale,
            max_nfev=500,
        )
        if np.all(np.isfinite(result.x)):
            p = result.x
    except (ValueError, RuntimeError, FloatingPointError):
        pass

    return dict(a=float(p[0]), b=float(p[1]), k=float(p[2] / scale),
                s=float(p[3]), c=float(p[4]))

def predict(X, **params):
    X = np.asarray(X, dtype=float)
    angle = 2.0 * np.pi * X[:, 1] / 26.0
    return (
        params["a"]
        + params["b"] * np.log1p(np.maximum(X[:, 0], 0.0))
        + np.log1p(params["k"] * np.maximum(X[:, 2], 0.0))
        + params["s"] * np.sin(angle)
        + params["c"] * np.cos(angle)
    )