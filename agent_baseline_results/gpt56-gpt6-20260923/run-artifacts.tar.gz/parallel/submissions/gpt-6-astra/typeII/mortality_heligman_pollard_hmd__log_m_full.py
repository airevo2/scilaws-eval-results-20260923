"""Eight-parameter Heligman–Pollard mortality law: childhood decline, a log-age accident hump, and Gompertz senescence."""
import numpy as np
from scipy.optimize import least_squares
from scipy.special import logsumexp

USED_INPUTS = ["age"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {
    "A": {"init": None},
    "B": {"init": None},
    "C": {"init": None},
    "D": {"init": None},
    "E": {"init": None},
    "F": {"init": None},
    "G": {"init": None},
    "H": {"init": None},
}

def predict(X, **params):
    x = np.maximum(np.asarray(X, dtype=float)[:, 0], 0.0)
    A, B, C = params["A"], params["B"], params["C"]
    D, E, F = params["D"], params["E"], params["F"]
    G, H = params["G"], params["H"]
    childhood = np.log(A) * (x + B) ** C
    hump = np.log(D) - E * (np.log(np.maximum(x, 1e-300)) - np.log(F)) ** 2
    senescence = np.log(G) + x * np.log(H)
    return logsumexp(np.vstack((childhood, hump, senescence)), axis=0)

def _decode(p):
    return {
        "A": float(np.exp(-np.exp(p[0]))),
        "B": float(np.exp(p[1])),
        "C": float(np.exp(p[2])),
        "D": float(np.exp(p[3])),
        "E": float(np.exp(p[4])),
        "F": float(np.exp(p[5])),
        "G": float(np.exp(p[6])),
        "H": float(np.exp(p[7])),
    }

def fit(X_fit, y_fit):
    X = np.asarray(X_fit, dtype=float)
    y = np.asarray(y_fit, dtype=float).reshape(-1)
    valid = np.isfinite(X[:, 0]) & np.isfinite(y)
    X, y = X[valid], y[valid]
    p0 = np.array([np.log(8.0), np.log(0.05), np.log(0.12),
                   -7.0, np.log(10.0), np.log(23.0), -10.0, 0.09])
    lower = np.array([0.0, -16.0, -5.0, -20.0, -5.0, np.log(5.0), -25.0, 0.001])
    upper = np.array([4.0, 4.0, 1.0, -2.0, 8.0, np.log(60.0), -2.0, 0.3])
    if not len(y):
        return _decode(p0)

    old = X[:, 0] >= np.quantile(X[:, 0], 0.65)
    if np.sum(old) >= 3 and np.ptp(X[old, 0]) > 0:
        slope, intercept = np.polyfit(X[old, 0], y[old], 1)
        p0[6] = np.clip(intercept, -24.0, -2.1)
        p0[7] = np.clip(slope, 0.002, 0.29)

    best = p0.copy()
    best_loss = np.inf
    for width in (5.0, 15.0):
        start = p0.copy()
        start[4] = np.log(width)
        try:
            result = least_squares(
                lambda p: predict(X, **_decode(p)) - y,
                start, bounds=(lower, upper),
                max_nfev=600, ftol=1e-8, xtol=1e-8, gtol=1e-8
            )
            loss = float(np.dot(result.fun, result.fun))
            if np.isfinite(loss) and loss < best_loss:
                best, best_loss = result.x, loss
        except (ValueError, FloatingPointError, RuntimeError):
            pass
    return _decode(best)