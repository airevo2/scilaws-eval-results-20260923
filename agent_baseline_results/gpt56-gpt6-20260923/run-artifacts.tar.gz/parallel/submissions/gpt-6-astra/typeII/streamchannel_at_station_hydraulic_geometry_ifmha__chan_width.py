"""Hydraulic geometry with a signed square-root correction in log discharge:
log(w) = a + b*log(Q) + c*sign(log(Q))*sqrt(abs(log(Q))).
"""
import numpy as np

USED_INPUTS = ["chan_discharge"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {
    "a": {"init": None},
    "b": {"init": None},
    "c": {"init": None},
}

def _features(X):
    Q = np.maximum(np.asarray(X, dtype=float)[:, 0], np.finfo(float).tiny)
    z = np.log(Q)
    return np.column_stack((
        np.ones_like(z),
        z,
        np.sign(z) * np.sqrt(np.abs(z)),
    ))

def fit(X_fit, y_fit):
    A = _features(X_fit)
    y = np.asarray(y_fit, dtype=float).reshape(-1)
    valid = np.isfinite(y) & (y > 0) & np.all(np.isfinite(A), axis=1)
    if not np.any(valid):
        return {"a": 0.0, "b": 0.0, "c": 0.0}
    try:
        p = np.linalg.lstsq(A[valid], np.log(y[valid]), rcond=None)[0]
        if not np.all(np.isfinite(p)):
            raise ValueError("Nonfinite fit")
    except Exception:
        p = np.array([np.mean(np.log(y[valid])), 0.0, 0.0])
    return {"a": float(p[0]), "b": float(p[1]), "c": float(p[2])}

def predict(X, **params):
    p = np.array([params["a"], params["b"], params["c"]], dtype=float)
    log_width = _features(X) @ p
    return np.exp(np.clip(log_width, -700.0, 700.0))