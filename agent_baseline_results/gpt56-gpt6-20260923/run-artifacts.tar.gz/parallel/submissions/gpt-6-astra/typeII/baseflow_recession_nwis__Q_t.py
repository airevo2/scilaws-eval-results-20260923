"""Power-law groundwater drainage: dQ/dt = -a Q**b, with Q(0)=Q_0."""
import numpy as np
from scipy.optimize import least_squares

USED_INPUTS = ["t", "Q_0"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {"a": {"init": None}, "b": {"init": None}}

def predict(X, a, b):
    X = np.asarray(X, dtype=float)
    t = np.maximum(X[:, 0], 0.0)
    q = np.maximum(X[:, 1], 1e-300)
    c = b - 1.0
    if abs(c) < 1e-8:
        return q * np.exp(-a * t)
    u = a * np.exp(np.clip(c * np.log(q), -700, 700)) * t
    z = 1.0 + c * u
    decay = np.log1p(np.maximum(c * u, -1.0 + 1e-15)) / c
    result = q * np.exp(np.clip(-decay, -745, 0))
    if c < 0:
        result = np.where(z <= 0, 0.0, result)
    return result

def fit(X_fit, y_fit):
    X = np.asarray(X_fit, dtype=float)
    y = np.asarray(y_fit, dtype=float).reshape(-1)
    good = np.isfinite(X).all(axis=1) & np.isfinite(y) & (X[:, 1] > 0)
    X, y = X[good], y[good]
    if len(y) == 0:
        return {"a": 0.01, "b": 1.0}

    q = X[:, 1]
    reference = float(np.exp(np.mean(np.log(q))))
    Z = X.copy()
    Z[:, 1] /= reference
    target = y / reference
    weights = np.maximum(Z[:, 1], 0.1 * np.quantile(Z[:, 1], 0.9))
    informative = (X[:, 0] > 0) & (y > 0) & (y < q)
    if np.any(informative):
        rate = float(np.median(
            -np.log(y[informative] / q[informative]) / X[informative, 0]
        ))
    else:
        rate = 0.01
    rate = np.clip(rate, 1e-8, 100.0)

    def residual(p):
        return (predict(Z, np.exp(p[0]), p[1]) - target) / weights

    best = None
    for exponent in (1.0, 1.5, 2.0):
        try:
            result = least_squares(
                residual, [np.log(rate), exponent],
                bounds=([-25.0, 0.1], [12.0, 4.0]),
                loss="soft_l1", f_scale=0.1, max_nfev=400
            )
            if np.isfinite(result.cost) and (best is None or result.cost < best.cost):
                best = result
        except (ValueError, FloatingPointError):
            pass

    if best is None:
        return {"a": rate, "b": 1.0}
    b = float(best.x[1])
    a = float(np.exp(best.x[0] - (b - 1.0) * np.log(reference)))
    return {"a": a, "b": b}