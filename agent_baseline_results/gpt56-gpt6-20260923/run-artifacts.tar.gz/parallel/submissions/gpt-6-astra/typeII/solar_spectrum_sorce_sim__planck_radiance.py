"""Planck spectral radiance per nanometre, with temperature fitted per cluster."""
import numpy as np
from scipy.constants import h, c, k
from scipy.optimize import minimize_scalar

USED_INPUTS = ["wavelength_nm"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {"T": {"init": None}}

def predict(X, T):
    wavelength_m = np.asarray(X, dtype=float)[:, 0] * 1e-9
    exponent = h * c / (wavelength_m * k * T)
    return (
        2.0 * h * c**2
        / (wavelength_m**5 * np.expm1(np.minimum(exponent, 700.0)))
        * 1e-9
    )

def fit(X_fit, y_fit):
    X = np.asarray(X_fit, dtype=float)
    y = np.asarray(y_fit, dtype=float).reshape(-1)
    valid = np.isfinite(X[:, 0]) & (X[:, 0] > 0) & np.isfinite(y) & (y > 0)
    X, y = X[valid], y[valid]
    if y.size == 0:
        return {"T": 5772.0}

    scale = np.max(y)
    result = minimize_scalar(
        lambda T: np.mean(((predict(X, T) - y) / scale)**2),
        bounds=(1000.0, 20000.0),
        method="bounded",
        options={"xatol": 1e-6},
    )
    return {"T": float(result.x)}