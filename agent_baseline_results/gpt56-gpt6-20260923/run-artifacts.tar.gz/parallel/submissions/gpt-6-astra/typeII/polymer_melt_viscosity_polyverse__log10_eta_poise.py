"""Arrhenius melt viscosity: log10(eta) = a + b/T, with two polymer-specific parameters."""
import numpy as np

USED_INPUTS = ["Temperature_K"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {"a": {"init": None}, "b": {"init": None}}

def fit(X_fit, y_fit):
    T = np.asarray(X_fit, dtype=float)[:, 0]
    y = np.asarray(y_fit, dtype=float).reshape(-1)
    valid = np.isfinite(T) & np.isfinite(y) & (T > 0)
    if not np.any(valid):
        return {"a": 0.0, "b": 0.0}
    u = 1.0 / T[valid]
    y = y[valid]
    u_mean = float(np.mean(u))
    y_mean = float(np.mean(y))
    du = u - u_mean
    denominator = float(np.dot(du, du))
    b = float(np.dot(du, y - y_mean) / denominator) if denominator > 0 else 0.0
    a = y_mean - b * u_mean
    return {"a": a, "b": b}

def predict(X, **params):
    T = np.asarray(X, dtype=float)[:, 0]
    return params["a"] + params["b"] / np.maximum(T, np.finfo(float).eps)