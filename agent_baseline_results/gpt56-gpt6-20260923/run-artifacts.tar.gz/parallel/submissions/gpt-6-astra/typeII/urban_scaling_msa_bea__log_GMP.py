"""Quadratic log-output scaling with universal curvature and cluster-specific intercept and slope."""
import numpy as np

USED_INPUTS = ["log_pop"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {"a": {"init": None}, "b": {"init": None}}

def fit(X_fit, y_fit):
    x = np.asarray(X_fit, dtype=float)[:, 0]
    y = np.asarray(y_fit, dtype=float).reshape(-1)
    valid = np.isfinite(x) & np.isfinite(y)
    x, y = x[valid], y[valid]
    if x.size == 0:
        return {"a": 0.0, "b": 1.0}
    adjusted = y - 0.0105 * x**2
    xm = float(np.mean(x))
    ym = float(np.mean(adjusted))
    dx = x - xm
    denominator = float(dx @ dx)
    b = float(dx @ (adjusted - ym) / denominator) if denominator > 0 else 0.0
    return {"a": ym - b * xm, "b": b}

def predict(X, **params):
    x = np.asarray(X, dtype=float)[:, 0]
    return params["a"] + params["b"] * x + 0.0105 * x**2