"""Regularized Chezy law: velocity scales with sqrt((R + 0.08) S), with a local resistance coefficient."""
import numpy as np

USED_INPUTS = ["R_m", "SLOPE"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {"C": {"init": None}}

def _basis(X):
    X = np.asarray(X, dtype=float)
    return np.sqrt(np.maximum(X[:, 0] + 0.08, 0.0) *
                   np.maximum(X[:, 1], 0.0))

def fit(X_fit, y_fit):
    h = _basis(X_fit)
    y = np.asarray(y_fit, dtype=float).reshape(-1)
    valid = np.isfinite(h) & np.isfinite(y) & (h > 0)
    h, y = h[valid], y[valid]
    denominator = float(np.dot(h, h))
    C = max(float(np.dot(h, y)) / denominator, 0.0) if denominator > 0 else 1.0
    return {"C": C}

def predict(X, **params):
    return float(params["C"]) * _basis(X)