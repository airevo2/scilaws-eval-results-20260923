"""Asymmetric probit dose response with a smooth square-root bend about the median log dose."""
import numpy as np
from scipy.special import ndtr
from scipy.optimize import least_squares

USED_INPUTS = ["log_conc_ppb"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {
    "mu": {"init": None},
    "slope": {"init": None},
    "asymmetry": {"init": None}
}

def predict(X, mu, slope, asymmetry):
    z = np.asarray(X, dtype=float)[:, 0] - mu
    bent_dose = z + asymmetry * (np.hypot(1.0, z) - 1.0)
    return ndtr(slope * bent_dose)

def fit(X_fit, y_fit):
    X = np.asarray(X_fit, dtype=float)
    y = np.asarray(y_fit, dtype=float).reshape(-1)
    valid = np.isfinite(X[:, 0]) & np.isfinite(y)
    X, y = X[valid], y[valid]
    if len(y) == 0:
        return {"mu": 0.0, "slope": 1.0, "asymmetry": 0.0}

    x = X[:, 0]
    span = max(float(np.ptp(x)), 1.0)
    ux, inv = np.unique(x, return_inverse=True)
    means = np.bincount(inv, weights=y) / np.bincount(inv)
    mu0 = float(ux[np.argmin(np.abs(means - 0.5))])
    slope0 = 4.0 / span
    bounds = (
        [float(x.min()) - 2.0 * span, 1e-5, -0.999],
        [float(x.max()) + 2.0 * span, 100.0, 0.999]
    )
    best = None
    for asym0 in (0.0, -0.5, 0.5):
        try:
            result = least_squares(
                lambda p: predict(X, *p) - y,
                [mu0, slope0, asym0],
                bounds=bounds,
                max_nfev=500
            )
            if np.all(np.isfinite(result.x)):
                score = float(np.dot(result.fun, result.fun))
                if best is None or score < best[0]:
                    best = (score, result.x)
        except Exception:
            pass
    p = best[1] if best is not None else [mu0, slope0, 0.0]
    return {
        "mu": float(p[0]),
        "slope": float(p[1]),
        "asymmetry": float(p[2])
    }