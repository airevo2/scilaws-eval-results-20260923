"""Human-capital-augmented Cobb–Douglas output per worker:
log(Y/L) = a + alpha*log(K/L) + beta*log(h).
"""
import numpy as np

USED_INPUTS = ["cn", "emp", "hc"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {
    "a": {"init": None},
    "alpha": {"init": None},
    "beta": {"init": None},
}

def fit(X_fit, y_fit):
    X = np.asarray(X_fit, dtype=float)
    y = np.asarray(y_fit, dtype=float).reshape(-1)
    logs = np.log(np.maximum(X, np.finfo(float).tiny))
    Z = np.column_stack((logs[:, 0] - logs[:, 1], logs[:, 2]))
    valid = np.isfinite(y) & np.all(np.isfinite(Z), axis=1)
    Z, y = Z[valid], y[valid]
    if not len(y):
        return {"a": 0.0, "alpha": 0.0, "beta": 0.0}
    center = np.mean(Z, axis=0)
    ym = float(np.mean(y))
    slopes = np.linalg.lstsq(Z - center, y - ym, rcond=None)[0]
    return {
        "a": float(ym - center @ slopes),
        "alpha": float(slopes[0]),
        "beta": float(slopes[1]),
    }

def predict(X, **params):
    X = np.asarray(X, dtype=float)
    logs = np.log(np.maximum(X, np.finfo(float).tiny))
    return (params["a"]
            + params["alpha"] * (logs[:, 0] - logs[:, 1])
            + params["beta"] * logs[:, 2])