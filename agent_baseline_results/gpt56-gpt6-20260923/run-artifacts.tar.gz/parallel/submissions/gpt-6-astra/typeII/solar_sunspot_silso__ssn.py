"""Hathaway solar-cycle profile: cubic onset with an exponential-quadratic decay."""
import numpy as np
from scipy.optimize import least_squares

USED_INPUTS = ["t_year"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {
    "A": {"init": None},
    "t0": {"init": None},
    "b": {"init": None}
}

def _profile(t, A, t0, b):
    z = np.clip((np.asarray(t, dtype=float) - t0) / max(float(b), 1e-8), 0.0, 40.0)
    e = np.exp(-z * z)
    return A * z**3 * e / (1.0 - 0.71 * e)

def fit(X_fit, y_fit):
    t = np.asarray(X_fit, dtype=float)[:, 0]
    y = np.asarray(y_fit, dtype=float).reshape(-1)
    valid = np.isfinite(t) & np.isfinite(y)
    t, y = t[valid], y[valid]
    if not len(t):
        return {"A": 0.0, "t0": 0.0, "b": 1.0}

    origin = float(np.min(t))
    x = t - origin
    span = max(float(np.ptp(t)), 1.0)
    amplitude = max(float(np.max(y)), 1.0)
    peak = float(x[np.argmax(y)])
    lower = [0.0, -3.0 * span, 0.05]
    upper = [100.0 * amplitude, span, 5.0 * span]
    best = None
    for width in [0.3 * span, 0.5 * span, span]:
        start = np.clip(peak - width, lower[1] + 1e-6, upper[1] - 1e-6)
        initial = [2.0 * amplitude, start, max(width, 0.1)]
        try:
            result = least_squares(
                lambda p: (_profile(x, *p) - y) / amplitude,
                initial, bounds=(lower, upper), x_scale="jac",
                max_nfev=1200
            )
            error = float(np.dot(result.fun, result.fun))
            if best is None or error < best[0]:
                best = (error, result.x)
        except Exception:
            pass
    p = best[1] if best is not None else [2.0 * amplitude, 0.0, span / 2.0]
    return {"A": float(p[0]), "t0": origin + float(p[1]), "b": float(p[2])}

def predict(X, **params):
    return _profile(np.asarray(X, dtype=float)[:, 0],
                    params["A"], params["t0"], params["b"])