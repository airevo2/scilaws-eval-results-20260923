"""Gompertz tumor growth: dV/dt = r V log(K/V), with an individual initial volume and growth parameters."""
import numpy as np
from scipy.optimize import least_squares

USED_INPUTS = ["time_day"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {
    "K": {"init": None},
    "B": {"init": None},
    "r": {"init": None},
}

def fit(X_fit, y_fit):
    t = np.asarray(X_fit, dtype=float)[:, 0]
    y = np.asarray(y_fit, dtype=float).reshape(-1)
    valid = np.isfinite(t) & np.isfinite(y)
    t, y = t[valid], y[valid]
    if len(y) == 0:
        return {"K": 1.0, "B": 1.0, "r": 0.1}

    scale = max(float(np.max(y)), 1.0)
    t0 = float(np.min(t))
    span = max(float(np.ptp(t)), 1.0)
    u = (t - t0) / span

    def model(p):
        logK, logC, logRate = p
        return np.exp(np.clip(
            logK - np.exp(logC) * np.exp(-np.exp(logRate) * u),
            -700.0, 700.0
        ))

    lower = [np.log(scale) - 3.0, -15.0, -12.0]
    upper = [np.log(scale) + 20.0, 12.0, 5.0]
    best = None
    initial_volume = max(float(np.mean(y[t == t0])), scale * 1e-4)
    for rate in (0.3, 1.0, 3.0):
        logK = np.log(scale * 2.0)
        C = max(logK - np.log(initial_volume), 0.01)
        p0 = [logK, np.log(C), np.log(rate)]
        try:
            result = least_squares(
                lambda p: (model(p) - y) / scale,
                p0, bounds=(lower, upper), max_nfev=1000
            )
            loss = float(np.dot(result.fun, result.fun))
            if np.isfinite(loss) and (best is None or loss < best[0]):
                best = (loss, result.x)
        except Exception:
            pass

    if best is None:
        return {"K": scale * 2.0, "B": 1.0, "r": 1.0 / span}
    logK, logC, logRate = best[1]
    r = float(np.exp(logRate) / span)
    B = float(np.exp(np.clip(logC + r * t0, -700.0, 700.0)))
    return {"K": float(np.exp(logK)), "B": B, "r": r}

def predict(X, K, B, r):
    t = np.asarray(X, dtype=float)[:, 0]
    attenuation = np.exp(np.clip(np.log(max(B, 1e-300)) - r * t, -700.0, 700.0))
    return np.exp(np.clip(np.log(max(K, 1e-300)) - attenuation, -700.0, 700.0))