"""Two-parameter rational functional response: a*N*(1+b*N)/(1+b*N+(b*N)**2)."""
import numpy as np
from scipy.optimize import least_squares

USED_INPUTS = ["prey_density"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {"a": {"init": None}, "b": {"init": None}}

def predict(X, a, b):
    N = np.asarray(X, dtype=float)[:, 0]
    z = b * N
    return a * N * (1.0 + z) / (1.0 + z + z * z)

def fit(X_fit, y_fit):
    X = np.asarray(X_fit, dtype=float)
    y = np.asarray(y_fit, dtype=float).reshape(-1)
    valid = np.isfinite(X[:, 0]) & np.isfinite(y)
    X, y = X[valid], y[valid]
    if len(y) == 0:
        return {"a": 1.0, "b": 1.0}

    N = X[:, 0]
    scale = max(float(np.max(np.abs(N))), 1e-8)
    u = N / scale
    yscale = max(float(np.max(np.abs(y))), 1e-8)

    def response(p):
        A, B = np.exp(p)
        z = B * u
        return A * u * (1.0 + z) / (1.0 + z + z*z)

    best = None
    for B0 in (0.1, 1.0, 10.0):
        basis = u * (1.0 + B0*u) / (1.0 + B0*u + (B0*u)**2)
        A0 = max(float(np.dot(basis, y) / max(np.dot(basis, basis), 1e-20)), 1e-8)
        p0 = np.clip(np.log([A0, B0]), -25.0, 25.0)
        try:
            result = least_squares(
                lambda p: (response(p) - y) / yscale,
                p0, bounds=(-30.0, 30.0), max_nfev=500
            )
            if np.all(np.isfinite(result.x)):
                score = float(np.dot(result.fun, result.fun))
                if best is None or score < best[0]:
                    best = (score, result.x)
        except Exception:
            pass

    if best is None:
        return {"a": yscale / scale, "b": 1.0 / scale}
    A, B = np.exp(best[1])
    return {"a": float(A / scale), "b": float(B / scale)}