"""Gaisser–Hillas shower profile, parameterized by peak deposit, peak depth, width, and asymmetry:
dE/dX = A * (1 + R*(X-Xmax)/L)**(1/R**2) * exp(-(X-Xmax)/(R*L)).
"""
import numpy as np
from scipy.optimize import least_squares

USED_INPUTS = ["X"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {
    "A": {"init": None},
    "Xmax": {"init": None},
    "L": {"init": None},
    "R": {"init": None},
}

def predict(X, A, Xmax, L, R):
    x = np.asarray(X, dtype=float)[:, 0]
    z = (x - Xmax) / max(float(L), 1e-12)
    r = max(float(R), 1e-6)
    t = r * z
    valid = t > -1.0
    safe_t = np.maximum(t, -1.0 + 1e-15)
    exponent = (np.log1p(safe_t) - safe_t) / (r * r)
    return np.where(valid, A * np.exp(np.clip(exponent, -745.0, 0.0)), 0.0)

def fit(X_fit, y_fit):
    X = np.asarray(X_fit, dtype=float)
    y = np.asarray(y_fit, dtype=float).reshape(-1)
    good = np.isfinite(X[:, 0]) & np.isfinite(y) & (y > 0)
    X, y = X[good], y[good]
    if len(y) == 0:
        return {"A": 1.0, "Xmax": 700.0, "L": 200.0, "R": 0.3}

    x = X[:, 0]
    scale = float(np.max(y))
    span = max(float(np.ptp(x)), 1.0)
    center = float(x[np.argmax(y)])
    width = max(span / 2.0, 1.0)
    lower = [1e-8, float(np.min(x) - 3.0 * span), span * 0.01, 1e-4]
    upper = [100.0, float(np.max(x) + 3.0 * span), span * 10.0, 3.0]

    def residual(p):
        return predict(X, p[0], p[1], p[2], p[3]) - y / scale

    best = None
    for initial_r in (0.15, 0.5, 1.0):
        initial = [1.0, center, width, initial_r]
        try:
            result = least_squares(
                residual, initial, bounds=(lower, upper),
                x_scale="jac", max_nfev=700,
                ftol=1e-9, xtol=1e-9, gtol=1e-9,
            )
            if np.all(np.isfinite(result.x)):
                if best is None or result.cost < best.cost:
                    best = result
        except (ValueError, FloatingPointError):
            pass

    p = best.x if best is not None else [1.0, center, width, 0.3]
    return {
        "A": float(p[0] * scale),
        "Xmax": float(p[1]),
        "L": float(p[2]),
        "R": float(p[3]),
    }