"""Residual-offset logarithmic retention law:
theta = theta_r + (theta_s - theta_r) / log(e + (alpha*h)**n).
"""
import numpy as np
from scipy.optimize import least_squares

USED_INPUTS = ["lab_head_m"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {
    "theta_r": {"init": None},
    "theta_s": {"init": None},
    "alpha": {"init": None},
    "n": {"init": None},
}

def fit(X_fit, y_fit):
    h = np.asarray(X_fit, dtype=float)[:, 0]
    y = np.asarray(y_fit, dtype=float).reshape(-1)
    valid = np.isfinite(h) & np.isfinite(y) & (h >= 0)
    h, y = h[valid], y[valid]
    if y.size == 0:
        return {"theta_r": 0.0, "theta_s": 0.4, "alpha": 1.0, "n": 1.0}

    logh = np.log(np.maximum(h, np.finfo(float).tiny))
    upper = float(np.clip(np.max(y), 0.001, 1.0))
    lower = float(np.clip(np.min(y), 0.0, upper))
    middle = (upper + lower) / 2.0
    log_midpoint = float(logh[np.argmin(np.abs(y - middle))])

    def residual(p):
        theta_r, amplitude, log_alpha, log_n = p
        denominator = np.logaddexp(1.0, np.exp(log_n) * (logh + log_alpha))
        return theta_r + amplitude / denominator - y

    bounds = ([0.0, 0.0, -25.0, -7.0],
              [1.0, 1.0, 25.0, 7.0])
    best = None
    fallback = np.array([0.5 * lower, upper - 0.5 * lower, 0.0, 0.0])
    for n0 in (0.6, 2.0, 8.0):
        for fraction in (0.0, 0.8):
            r0 = fraction * lower
            p0 = [
                r0,
                max(upper - r0, 0.001),
                float(np.clip(-log_midpoint + 1.5 / n0, -24.0, 24.0)),
                np.log(n0),
            ]
            try:
                result = least_squares(
                    residual, p0, bounds=bounds,
                    max_nfev=400, ftol=1e-9, xtol=1e-9, gtol=1e-9
                )
                if np.all(np.isfinite(result.x)):
                    if best is None or result.cost < best.cost:
                        best = result
            except (ValueError, FloatingPointError):
                pass

    p = fallback if best is None else best.x
    return {
        "theta_r": float(p[0]),
        "theta_s": float(p[0] + p[1]),
        "alpha": float(np.exp(p[2])),
        "n": float(np.exp(p[3])),
    }

def predict(X, theta_r, theta_s, alpha, n):
    h = np.maximum(np.asarray(X, dtype=float)[:, 0], np.finfo(float).tiny)
    denominator = np.logaddexp(1.0, n * (np.log(alpha) + np.log(h)))
    return theta_r + (theta_s - theta_r) / denominator