"""Continuous broken power law for rocky/Neptune-like, giant-planet, and degenerate high-mass regimes."""
import numpy as np

USED_INPUTS = ["M"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    M = np.maximum(X[:, 0], 0.02)
    x = np.log(M)
    return np.exp(
        0.453
        + 0.450 * x
        + 0.080 * np.maximum(0.0, x - np.log(2.0))
        - 0.602 * np.maximum(0.0, x - np.log(132.0))
    )