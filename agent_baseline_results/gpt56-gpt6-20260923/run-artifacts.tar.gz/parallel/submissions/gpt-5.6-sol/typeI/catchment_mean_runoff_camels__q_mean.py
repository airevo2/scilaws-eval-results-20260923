"""Schreiber precipitation partition: runoff is the precipitation remaining after exponential PET losses."""
import numpy as np

USED_INPUTS = ["p_mean", "pet_mean"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    p = X[:, 0]
    pet = X[:, 1]
    return p * np.exp(-pet / p)