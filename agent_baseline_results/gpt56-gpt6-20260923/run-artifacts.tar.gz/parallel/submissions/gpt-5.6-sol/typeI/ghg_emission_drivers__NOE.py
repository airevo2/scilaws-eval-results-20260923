"""Multiplicative power-law emissions model with demographic, economic, density, urbanization, and temperature effects."""
import numpy as np

USED_INPUTS = ["GDP", "TP", "AP", "DP", "UR", "AT"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    GDP = X[:, 0]
    TP = X[:, 1]
    AP = X[:, 2]
    DP = X[:, 3]
    UR = X[:, 4]
    AT = X[:, 5]
    return (0.0105 * GDP**0.25 * TP**0.5 * AP**0.13 *
            DP**(-0.25) * UR**(-0.25) * np.exp(-0.02 * AT))