"""Flux is the base-10 logarithm of the sum of a mass-independent floor and a stellar-mass power-law component."""
import numpy as np

USED_INPUTS = ["log10_M_star_SDF00"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    x = X[:, 0]
    return np.logaddexp(-2.5196651 * np.log(10.0), (1.3553754 * x - 1.6448057) * np.log(10.0)) / np.log(10.0)