"""Per-module PV maximum power: logarithmically corrected irradiance response with a linear temperature coefficient."""
import numpy as np

USED_INPUTS = ["G_W_m2", "T_module_C"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    G = X[:, 0]
    T = X[:, 1]
    irradiance_response = (203.150338 - 15.0640594 * np.log(G / 1000.0)) * (G / 1000.0)
    temperature_factor = 1.0 - 0.00252993617 * (T - 25.0)
    return irradiance_response * temperature_factor