"""Additive human-capital wage equation: schooling raises log wages linearly, while experience has a saturating logarithmic return with a linear depreciation term."""
import numpy as np

USED_INPUTS = ["SCHL_years", "exp"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    s = X[:, 0]
    x = X[:, 1]
    return 8.456 + 0.112 * s + 0.323 * np.log1p(x) - 0.00635 * x