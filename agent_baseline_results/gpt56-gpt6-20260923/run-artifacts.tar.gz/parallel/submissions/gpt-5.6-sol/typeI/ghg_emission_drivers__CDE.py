"""Multiplicative socioeconomic emissions law: emissions scale linearly with population,
sublinearly with GDP per capita, strongly with working-age share, and moderately with
urbanization, with a weak inverse density dependence."""
import numpy as np

USED_INPUTS = ["GDP", "TP", "AP", "DP", "UR"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    GDP = X[:, 0]
    TP = X[:, 1]
    AP = X[:, 2]
    DP = X[:, 3]
    UR = X[:, 4]
    return 0.000102 * GDP**0.48314 * TP**0.99910 * AP**2.83781 * DP**(-0.08689) * UR**0.49480