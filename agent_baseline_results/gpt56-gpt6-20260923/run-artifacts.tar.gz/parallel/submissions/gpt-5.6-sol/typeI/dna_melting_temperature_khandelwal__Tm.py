"""Additive empirical melting-temperature law: strength, logarithmic length, salt, and strand concentration."""
import numpy as np

USED_INPUTS = ["E", "N", "salt_M", "dna_conc_M"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    E = X[:, 0]
    N = X[:, 1]
    salt = X[:, 2]
    conc = X[:, 3]
    return (-30.105177
            + 7.524905 * E
            + 52.367217 * np.log10(N)
            + 12.718867 * np.log10(salt)
            + 4.338888 * np.log10(conc))