"""Photometric stellar-mass relation: i-band absolute luminosity plus a nonlinear g-r mass-to-light correction."""
import numpy as np

USED_INPUTS = ["g", "r", "i", "DM"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    g = X[:, 0]
    r = X[:, 1]
    i = X[:, 2]
    DM = X[:, 3]
    color = g - r
    return 0.95 - 0.426 * (i - DM) + 0.667 * color - 0.103 * color * color