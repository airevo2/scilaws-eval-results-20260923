"""Mammalian basal metabolic rate allometry: B scales as body mass to the three-quarter power."""
import numpy as np

USED_INPUTS = ["body_mass_g"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    M = X[:, 0]
    return 0.75 * np.log10(M) - 1.75