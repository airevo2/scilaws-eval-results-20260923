"""Semi-empirical liquid-drop binding-energy-per-nucleon mechanism."""
import numpy as np

USED_INPUTS = ["Z", "N", "A", "NZ_diff", "pair"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    Z = X[:, 0]
    A = X[:, 2]
    excess = X[:, 3]
    pair = X[:, 4]
    return (
        15.3739
        - 16.936628 * A ** (-1.0 / 3.0)
        - 0.6840322 * Z * (Z - 1.0) * A ** (-4.0 / 3.0)
        - 21.873752 * excess ** 2 / A ** 2
        + 11.330228 * pair * A ** (-7.0 / 4.0)
    )