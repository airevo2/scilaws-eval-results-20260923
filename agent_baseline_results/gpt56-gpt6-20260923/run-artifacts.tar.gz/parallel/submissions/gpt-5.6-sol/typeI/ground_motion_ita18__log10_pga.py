"""Compact nonlinear magnitude-distance attenuation model with additive EC8 and faulting terms."""
import numpy as np

USED_INPUTS = ["Mw", "R_km", "ec8_B", "ec8_C", "ec8_D", "ec8_E", "sof_NF", "sof_TF"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    mw = X[:, 0]
    r = X[:, 1]
    ec8_b = X[:, 2]
    ec8_c = X[:, 3]
    ec8_d = X[:, 4]
    ec8_e = X[:, 5]
    sof_nf = X[:, 6]
    sof_tf = X[:, 7]

    dm = mw - 5.5
    distance = np.log10(np.sqrt(r * r + 8.27054 * 8.27054))

    return (
        3.646286
        + 0.207087 * dm
        + 0.007359 * dm * dm
        - 1.630454 * distance
        + 0.270532 * dm * distance
        + 0.222493 * ec8_b
        + 0.303899 * ec8_c
        + 0.145524 * ec8_d
        + 0.439973 * ec8_e
        - 0.014051 * sof_nf
        - 0.130189 * sof_tf
    )