"""Log-linear gravity equation with GDP, distance, and bilateral trade-cost indicators."""
import numpy as np

USED_INPUTS = ["log_gdp_o", "log_gdp_d", "log_dist", "contig", "comlang_off", "col_dep_ever", "fta_wto"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    return (
        -18.1520
        + 1.1321 * X[:, 0]
        + 0.8823 * X[:, 1]
        - 1.1562 * X[:, 2]
        + 1.0085 * X[:, 3]
        + 0.9896 * X[:, 4]
        + 1.4185 * X[:, 5]
        + 0.5516 * X[:, 6]
    )