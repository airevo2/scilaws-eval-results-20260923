"""Quadratic logarithmic energy dependence with a shallow low-energy minimum."""
import numpy as np

USED_INPUTS = ["s"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    s = X[:, 0]
    z = np.log(s)
    return 45.63 - 3.09 * z + 0.338 * z * z