"""Multiplicative power law for national methane emissions."""
import numpy as np

USED_INPUTS = ["GDP", "TP", "UR"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    GDP = X[:, 0]
    TP = X[:, 1]
    UR = X[:, 2]
    return 0.5 * GDP**0.2 * TP**1.05 * UR**0.5