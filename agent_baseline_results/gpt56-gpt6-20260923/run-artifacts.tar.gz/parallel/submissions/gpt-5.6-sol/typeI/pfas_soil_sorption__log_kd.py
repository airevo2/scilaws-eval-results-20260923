"""Power-law sorption relationship in log space using the combined hydrophobicity and organic-carbon term."""
import numpy as np

USED_INPUTS = ["log_Kow", "foc"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    log_kow = X[:, 0]
    foc = X[:, 1]
    return 0.51983337 * (log_kow + np.log10(foc)) - 0.61742316