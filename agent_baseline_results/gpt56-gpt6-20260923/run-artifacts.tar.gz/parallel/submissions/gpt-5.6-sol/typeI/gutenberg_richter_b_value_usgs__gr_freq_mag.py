"""Gutenberg-Richter magnitude-frequency law: the base-10 cumulative event rate decreases linearly with magnitude threshold."""
import numpy as np

USED_INPUTS = ["M_threshold"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    M = X[:, 0]
    return 8.2 - 1.03 * M