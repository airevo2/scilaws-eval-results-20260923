"""Flat-LCDM luminosity-distance distance modulus."""
import numpy as np

USED_INPUTS = ["z_hd"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    z = X[:, 0]
    grid = np.linspace(0.0, 2.261, 8193)
    ez = 1.0 / np.sqrt(0.35 * (1.0 + grid)**3 + 0.65)
    dz = grid[1] - grid[0]
    integ = np.empty_like(grid)
    integ[0] = 0.0
    integ[1:] = np.cumsum(0.5 * (ez[:-1] + ez[1:]) * dz)
    dimensionless_dl = (1.0 + z) * np.interp(z, grid, integ)
    dl_mpc = 299792.458 * dimensionless_dl / 72.8
    return 5.0 * np.log10(dl_mpc) + 25.0