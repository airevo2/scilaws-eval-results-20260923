"""Power-law isolation-by-distance relationship."""
import numpy as np

USED_INPUTS = ["distance_km"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    d = X[:, 0]
    return 0.00084167 * d ** 0.55775843