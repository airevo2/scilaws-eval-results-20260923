"""Power-law race velocity with a multiplicative male-performance factor."""
import numpy as np

USED_INPUTS = ["distance_m", "sex_M"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    d = X[:, 0]
    s = X[:, 1]
    return 14.13609085 * d**(-0.09780145) * (1.092342 * s + (1.0 - s))