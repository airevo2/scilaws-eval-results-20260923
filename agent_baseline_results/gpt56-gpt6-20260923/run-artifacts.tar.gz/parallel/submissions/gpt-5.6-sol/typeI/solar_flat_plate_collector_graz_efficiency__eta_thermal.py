"""Quadratic thermal-loss efficiency law using the inlet-to-ambient temperature difference."""
import numpy as np

USED_INPUTS = ["G_W_m2", "T_in_C", "T_amb_C"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    G = X[:, 0]
    Tin = X[:, 1]
    Tamb = X[:, 2]
    return 0.74391524 - 1.24607696 * (Tin - Tamb) / G - 0.03432541 * (Tin * Tin - Tamb * Tamb) / G