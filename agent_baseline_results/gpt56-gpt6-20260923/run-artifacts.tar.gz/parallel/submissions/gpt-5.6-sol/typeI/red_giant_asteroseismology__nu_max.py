"""Power-law asteroseismic scaling relation between frequency of maximum power and large frequency separation."""
import numpy as np

USED_INPUTS = ["delta_nu"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    delta_nu = X[:, 0]
    return 5.02246 * delta_nu ** 1.35839