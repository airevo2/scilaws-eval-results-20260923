"""Continuous piecewise mass-luminosity relation represented by three hinge terms."""
import numpy as np

USED_INPUTS = ["log_M_Msun"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    x = X[:, 0]
    return (-1.22735392
            + 1.71801082 * x
            + 2.11570617 * np.maximum(x + 0.55994048, 0.0)
            + 0.82162703 * np.maximum(x + 0.09999997, 0.0)
            - 2.47592477 * np.maximum(x - 0.72947396, 0.0))