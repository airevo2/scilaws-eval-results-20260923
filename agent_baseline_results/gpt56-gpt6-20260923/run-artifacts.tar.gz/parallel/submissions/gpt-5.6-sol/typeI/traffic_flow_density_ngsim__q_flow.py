"""Exponential saturation of per-lane flow with increasing traffic density."""
import numpy as np

USED_INPUTS = ["k_veh_km_lane"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    k = X[:, 0]
    return 2896.33 * (1.0 - np.exp(-k / 59.84)) + 60.77