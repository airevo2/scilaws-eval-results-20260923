"""Intervening-opportunity (radiation) commuting law with proportional origin outflow."""
import numpy as np

USED_INPUTS = ["m_i", "m_j", "s_ij"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    m_i = X[:, 0]
    m_j = X[:, 1]
    s_ij = X[:, 2]
    flow = 0.1 * m_i * m_i * m_j / ((m_i + s_ij) * (m_i + s_ij + m_j))
    return np.log10(1.0 + flow)