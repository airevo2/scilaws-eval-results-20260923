"""WGS84 Somigliana normal gravity as a function of geodetic latitude."""
import numpy as np

USED_INPUTS = ["latitude"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    phi = np.deg2rad(X[:, 0])
    s2 = np.sin(phi) ** 2
    return 9.7803253359 * (1.0 + 0.00193185265241 * s2) / np.sqrt(1.0 - 0.00669437999014 * s2)