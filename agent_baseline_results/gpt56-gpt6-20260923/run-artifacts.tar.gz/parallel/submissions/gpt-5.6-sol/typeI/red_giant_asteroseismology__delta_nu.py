"""Power-law scaling of the red-giant large frequency separation with nu_max."""
import numpy as np

USED_INPUTS = ["nu_max"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    nu_max = X[:, 0]
    return 0.26056615 * nu_max**0.76670684