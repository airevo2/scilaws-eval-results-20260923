"""Fu's Budyko curve for the long-term evaporative fraction."""
import numpy as np

USED_INPUTS = ["pet_over_p"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    phi = X[:, 0]
    omega = 2.3
    return 1.0 + phi - (1.0 + phi ** omega) ** (1.0 / omega)