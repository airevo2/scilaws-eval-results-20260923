"""Ring-current tendency: linear Dst relaxation, positive dawn-to-dusk electric-field driving, and dynamic-pressure correction."""
import numpy as np

USED_INPUTS = ["Dst", "Ey", "P_dyn"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    dst = X[:, 0]
    ey = X[:, 1]
    p_dyn = X[:, 2]
    return 0.6897 - 0.0467 * dst - 2.50411 * np.maximum(ey, 0.0) - 0.06896 * p_dyn