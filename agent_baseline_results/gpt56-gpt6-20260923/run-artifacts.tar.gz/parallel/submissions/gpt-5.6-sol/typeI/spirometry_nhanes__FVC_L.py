"""Cubic height with age interaction and logarithmic age terms."""
import numpy as np

USED_INPUTS = ["age", "height_cm"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    t = X[:, 0]
    h = X[:, 1]
    return (0.0909187575 * t
            + 0.000211256390 * h * t
            + 0.000000668824764 * h**3
            - 0.257973832 * np.log(t))