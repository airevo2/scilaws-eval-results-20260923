"""Inverse-velocity background with a single Breit-Wigner resonance."""
import numpy as np

USED_INPUTS = ["E_eV"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    E = X[:, 0]
    return np.log10(
        2.62002640 / np.sqrt(E)
        + 275.773760 / (
            np.sqrt(E) * ((E - 4.87521681) ** 2 + 0.0669526432 ** 2)
        )
    )