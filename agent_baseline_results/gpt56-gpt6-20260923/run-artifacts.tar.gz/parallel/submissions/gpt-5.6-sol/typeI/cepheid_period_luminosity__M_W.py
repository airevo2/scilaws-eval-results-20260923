"""Bilinear period–metallicity Wesenheit relation."""
import numpy as np

USED_INPUTS = ["log_P", "feh"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    log_P = X[:, 0]
    feh = X[:, 1]
    return -2.76 - 3.30 * log_P + (-0.77 + 0.54 * log_P) * feh