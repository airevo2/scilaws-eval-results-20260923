"""Three-parameter Preston-curve relation with a low-income reciprocal correction."""
import numpy as np

USED_INPUTS = ["gdppc"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    x = X[:, 0]
    return 42.240789 + 4.282047 * np.log(x) - 1156.017398 / x