"""Pythagorean win expectation from season runs scored and allowed."""
import numpy as np

USED_INPUTS = ["R", "RA"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    R = X[:, 0]
    RA = X[:, 1]
    p = 1.83
    rp = np.power(R, p)
    rap = np.power(RA, p)
    return rp / (rp + rap)