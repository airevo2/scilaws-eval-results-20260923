"""Log-quadratic interaction model for dynamical ejecta mass."""
import numpy as np

USED_INPUTS = ["q", "Lambda_tilde"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    q = X[:, 0]
    u = np.log(X[:, 1])
    return np.exp(-85.89883644 + 50.66150501*q - 10.54870804*q*q
                  + 18.49498774*u - 0.99996113*u*u
                  - 6.03386569*q*u)