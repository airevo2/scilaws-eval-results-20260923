"""Peters-Mathews gravitational-radiation orbital-period decay law."""
import numpy as np

USED_INPUTS = ["Pb", "e"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    Pb = X[:, 0]
    e = X[:, 1]
    eccentricity_factor = (1.0 + (73.0 / 24.0) * e**2 + (37.0 / 96.0) * e**4) / (1.0 - e**2)**3.5
    return -2.8e-14 * Pb**(-5.0 / 3.0) * eccentricity_factor