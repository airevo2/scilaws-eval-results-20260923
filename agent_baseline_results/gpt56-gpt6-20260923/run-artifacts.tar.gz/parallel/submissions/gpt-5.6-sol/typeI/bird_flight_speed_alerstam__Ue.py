"""Equivalent airspeed follows a square-root dependence on wing loading."""
import numpy as np

USED_INPUTS = ["mass_kg", "wing_area_m2"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    m = X[:, 0]
    S = X[:, 1]
    return np.sqrt(100.0 + 16.0 * m / S)