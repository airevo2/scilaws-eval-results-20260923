"""Exponential form-factor ratio with linear and quadratic Q² suppression."""
import numpy as np

USED_INPUTS = ["Q2_GeV2"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    Q2 = X[:, 0]
    return np.exp(-0.03 * Q2 - 0.03 * Q2 * Q2)