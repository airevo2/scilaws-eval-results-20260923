"""Tremonti mass-metallicity quadratic relation."""
import numpy as np

USED_INPUTS = ["log_Mstar"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    m = X[:, 0]
    return -1.492 + 1.847 * m - 0.08026 * m * m