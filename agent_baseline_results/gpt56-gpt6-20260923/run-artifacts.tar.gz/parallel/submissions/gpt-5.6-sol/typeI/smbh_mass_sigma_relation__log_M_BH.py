"""Quadratic spheroid-mass scaling for the logarithmic black-hole mass."""
import numpy as np

USED_INPUTS = ["log_M_sph"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    z = X[:, 0] - 11.0
    return 8.5 + 1.2 * z + 0.08 * z * z