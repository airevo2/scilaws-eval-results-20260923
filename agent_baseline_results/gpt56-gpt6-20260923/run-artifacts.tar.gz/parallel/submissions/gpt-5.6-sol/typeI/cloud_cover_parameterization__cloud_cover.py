"""Additive empirical cloud-cover law with linear condensate, humidity, temperature, and quartic vertical-humidity-gradient dependence."""
import numpy as np

USED_INPUTS = ["q_c", "q_i", "RH", "T", "dz_RH"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    q_c = X[:, 0] / 1.0e-4
    q_i = X[:, 1] / 1.0e-5
    RH = X[:, 2]
    T = (X[:, 3] - 260.0) / 20.0
    g = X[:, 4] / 1.0e-3
    return (
        -0.21389051
        + 0.03984709 * q_c
        + 0.01573745 * q_i
        + 0.70554649 * RH
        - 0.11882973 * T
        + 0.00152219 * T * T
        - 0.08052458 * g
        + 0.94642347 * g * g
        + 0.72362855 * g * g * g
        + 0.12640203 * g * g * g * g
    )