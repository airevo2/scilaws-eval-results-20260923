"""Multiplicative melt-pool depth law: power-law dependence on laser power, scan velocity, and inverse beam diameter."""
import numpy as np

USED_INPUTS = ["laser_power_W", "scan_velocity_mm_per_s", "beam_diameter_um"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    P = X[:, 0]
    V = X[:, 1]
    D = X[:, 2]
    return 75.45 * (P / 200.0) ** 0.895 * (800.0 / V) ** 0.451 * (100.0 / D) ** 1.132