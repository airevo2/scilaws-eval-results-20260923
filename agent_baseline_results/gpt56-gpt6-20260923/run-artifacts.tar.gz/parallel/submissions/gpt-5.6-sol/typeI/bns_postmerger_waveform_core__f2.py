"""Compact empirical mechanism with quadratic mass and inverse-cube-root tidal scaling."""
import numpy as np

USED_INPUTS = ["mass", "kap2t", "m1", "m2"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    M = X[:, 0]
    K = X[:, 1]
    m1 = X[:, 2]
    m2 = X[:, 3]
    eta = m1 * m2 / (M * M)
    t = K ** (-1.0 / 3.0)
    return (5.91833 - 4.21811 * M + 0.72659 * M * M
            + 16.40857 * t + 5.77898 * M * t
            - 1.71384 * M * M * t - 18.2125 * eta * t)