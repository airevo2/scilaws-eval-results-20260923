"""Compact additive ejecta-velocity law: a linear mass-ratio suppression plus an inverse-square-root tidal-deformability contribution."""
import numpy as np

USED_INPUTS = ["q", "Lambda_tilde"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    q = X[:, 0]
    Lambda_tilde = X[:, 1]
    return 0.27 - 0.08 * q + 1.0 / np.sqrt(Lambda_tilde)