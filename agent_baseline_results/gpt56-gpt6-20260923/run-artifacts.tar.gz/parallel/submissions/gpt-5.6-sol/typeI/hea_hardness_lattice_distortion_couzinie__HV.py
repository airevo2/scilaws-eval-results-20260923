"""Compact quadratic VEC–mixing-enthalpy mechanism: baseline plus VEC-squared strengthening and a VEC-scaled enthalpy contribution."""
import numpy as np

USED_INPUTS = ["VEC", "dHmix"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    vec = X[:, 0]
    dhmix = X[:, 1]
    return 249.97976305 + 6.43401863 * vec**2 - 1.57081733 * vec * dhmix