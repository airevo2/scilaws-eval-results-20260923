"""Chave tropical-tree allometric biomass equation."""
import numpy as np

USED_INPUTS = ["wood_density", "diameter_cm", "height_m"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    rho = X[:, 0]
    D = X[:, 1]
    H = X[:, 2]
    return 0.0673 * (rho * D**2 * H)**0.976