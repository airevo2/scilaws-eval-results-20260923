"""Robust multiplicative energy-consumption law with power-law socioeconomic and demographic effects and exponential temperature dependence."""
import numpy as np

USED_INPUTS = ["GDP", "TP", "AP", "DP", "UR", "AT"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    GDP = X[:, 0]
    TP = X[:, 1]
    AP = X[:, 2]
    DP = X[:, 3]
    UR = X[:, 4]
    AT = X[:, 5]
    return 8.6e-13 * GDP**0.43 * TP**1.05 * AP**4.19 * DP**(-0.066) * UR**0.89 * np.exp(-0.0217 * AT)