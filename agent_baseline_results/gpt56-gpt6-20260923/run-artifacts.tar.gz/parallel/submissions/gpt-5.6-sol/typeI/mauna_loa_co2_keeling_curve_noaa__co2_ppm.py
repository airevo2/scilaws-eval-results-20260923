"""Exponential long-term growth with an annual seasonal harmonic."""
import numpy as np

USED_INPUTS = ["year_decimal"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    t = X[:, 0]
    u = t - 1958.0
    return (313.983461
            + 54.445801 * (np.exp(0.016702 * u) - 1.0)
            - 0.24907 * np.sin(2.0 * np.pi * u)
            - 0.095667 * np.cos(2.0 * np.pi * u))