"""Bilinear spirometric prediction: FEV1 varies with age, height, and their interaction."""
import numpy as np

USED_INPUTS = ["age", "height_cm"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    age = X[:, 0]
    height_cm = X[:, 1]
    return (-3.43020974
            + 0.02297219 * age
            + 0.04580343 * height_cm
            - 0.00030573 * age * height_cm)