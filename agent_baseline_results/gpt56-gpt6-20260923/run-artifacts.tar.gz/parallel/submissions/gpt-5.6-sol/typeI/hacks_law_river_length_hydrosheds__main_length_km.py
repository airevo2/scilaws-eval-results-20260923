"""Hack's law: main-stem length scales as a power of upstream drainage area."""
import numpy as np

USED_INPUTS = ["upland_area_skm"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    A = X[:, 0]
    return 1.65 * np.power(A, 0.551)