"""Power-law bulk modulus in density and atomic volume."""
import numpy as np

USED_INPUTS = ["V_atomic_A3", "density_g_cm3"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    V = X[:, 0]
    rho = X[:, 1]
    return 2600.0 * np.power(rho, 0.7) * np.power(V, -1.6)