"""Gompertz-shaped wind-turbine power curve with low-speed shutdown."""
import numpy as np

USED_INPUTS = ["wind_speed_mps"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    v = X[:, 0]
    z = np.maximum(v - 3.5, 0.0)
    p = 2057.8 * np.exp(-np.exp(-0.42329 * (v - 7.61986)))
    p = np.where(v < 3.5, 0.0, p)
    return p