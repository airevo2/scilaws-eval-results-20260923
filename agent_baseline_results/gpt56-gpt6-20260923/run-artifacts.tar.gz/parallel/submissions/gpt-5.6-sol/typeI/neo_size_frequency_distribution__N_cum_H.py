"""Cumulative near-Earth-object count with a half-decade-per-magnitude power law."""
import numpy as np

USED_INPUTS = ["H_upper"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    H = X[:, 0]
    return np.power(10.0, 0.5 * H - 5.8165)