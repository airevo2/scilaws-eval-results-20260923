"""Parker-spiral azimuthal field: the tangential component is radial field
carried into a spiral by solar-wind outflow, with inverse-speed and
heliocentric-distance scaling."""
import numpy as np

USED_INPUTS = ["B_r_nT", "v_sw_km_s", "r_AU"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    B_r = X[:, 0]
    v_sw = X[:, 1]
    r = X[:, 2]
    return -400.0 * r * B_r / v_sw