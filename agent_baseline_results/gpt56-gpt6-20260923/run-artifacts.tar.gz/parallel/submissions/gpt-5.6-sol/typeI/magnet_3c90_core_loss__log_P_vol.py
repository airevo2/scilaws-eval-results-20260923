"""Two-term core-loss law: hysteresis-like f B^a contribution plus eddy-current-like f^2 B^b contribution."""
import numpy as np

USED_INPUTS = ["f_Hz", "B_peak_T"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    f = X[:, 0]
    B = X[:, 1]
    z1 = -2.5760288 + np.log10(f) + 1.35070848 * np.log10(B)
    z2 = -5.40944738 + 2.0 * np.log10(f) + 2.84960482 * np.log10(B)
    m = np.maximum(z1, z2)
    return m + np.log10(10.0 ** (z1 - m) + 10.0 ** (z2 - m))