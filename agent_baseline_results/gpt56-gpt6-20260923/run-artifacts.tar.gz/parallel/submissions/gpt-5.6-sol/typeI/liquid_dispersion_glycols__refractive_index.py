"""Cauchy dispersion with temperature-dependent coefficients."""
import numpy as np

USED_INPUTS = ["lambda_um", "temperature_C"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    lam = X[:, 0]
    T = X[:, 1]
    u = 1.0 / (lam * lam)
    return (1.42501375 + 0.00472666017 * u - 0.000117470919 * u * u
            + T * (-0.000267382674 - 0.000008675146 * u
                   + 0.000000950760 * u * u))