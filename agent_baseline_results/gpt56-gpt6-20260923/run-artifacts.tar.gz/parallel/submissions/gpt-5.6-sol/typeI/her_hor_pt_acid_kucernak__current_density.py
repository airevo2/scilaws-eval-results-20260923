"""Mechanistic two-branch hydrogen electrocatalysis law: pressure-scaled anodic and cathodic exponential terms, with cathodic acid-activity dependence and a common Arrhenius temperature factor."""
import numpy as np

USED_INPUTS = ["eta", "T", "P_H2", "c_acid"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    eta = X[:, 0]
    T = X[:, 1]
    P_H2 = X[:, 2]
    c_acid = X[:, 3]
    R = 8.314462618
    temperature_factor = np.exp(10154.2 / R * (1.0 / 298.0 - 1.0 / T))
    anodic = 36.798 * (np.exp(34.044 * eta) - 1.0)
    cathodic = 136.677 * c_acid ** (-0.5) * (1.0 - np.exp(-45.205 * eta))
    return P_H2 * temperature_factor * (anodic + cathodic)