"""Exponential decline in richness with disturbance plus a residual richness floor."""
import numpy as np

USED_INPUTS = ["d"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    d = X[:, 0]
    return 1.0 + 8.0 * np.exp(-0.1 * (d - 15.0))