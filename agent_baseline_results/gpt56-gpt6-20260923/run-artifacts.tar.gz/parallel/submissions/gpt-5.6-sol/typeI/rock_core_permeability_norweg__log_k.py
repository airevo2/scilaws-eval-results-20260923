"""Power-law permeability relation in porosity odds."""
import numpy as np

USED_INPUTS = ["phi"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    phi = np.clip(X[:, 0], 0.0001, 0.69)
    return 3.35 + 3.70 * np.log10(phi / (1.0 - phi))