"""Smooth double-break cumulative crater size-frequency distribution."""
import numpy as np

USED_INPUTS = ["D_lower_km"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    d = X[:, 0]
    return (
        0.0016976077466697443
        * d**(-1.0133481347751685)
        * (1.0 + (2.430047043138523 / d)**6.014121750511386)**(0.4028917245683149 / 6.014121750511386)
        / (1.0 + (d / 30.477656626753795)**4.031465400949878)**(1.634113627365644 / 4.031465400949878)
    )