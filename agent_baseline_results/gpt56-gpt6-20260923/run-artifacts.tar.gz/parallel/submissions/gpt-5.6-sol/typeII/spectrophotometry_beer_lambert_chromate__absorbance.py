"""Quadratic concentration-dependent Beer–Lambert absorbance with a cluster-specific linear and quadratic response coefficient."""
import numpy as np

USED_INPUTS = ["concentration", "path_length"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {
    "epsilon": {"init": [1.5]},
    "nonlinearity": {"init": [0.1]},
}

def fit(X_fit, y_fit):
    c = np.asarray(X_fit[:, 0], dtype=float)
    l = np.asarray(X_fit[:, 1], dtype=float)
    y = np.asarray(y_fit, dtype=float)
    z = l * c
    design = np.column_stack((z, z * c))
    try:
        p, _, _, _ = np.linalg.lstsq(design, y, rcond=None)
        if not np.all(np.isfinite(p)):
            raise ValueError
        return {
            "epsilon": float(p[0]),
            "nonlinearity": float(p[1]),
        }
    except Exception:
        return {"epsilon": 1.5, "nonlinearity": 0.1}

def predict(X, **params):
    c = np.asarray(X[:, 0], dtype=float)
    l = np.asarray(X[:, 1], dtype=float)
    epsilon = float(params["epsilon"])
    nonlinearity = float(params["nonlinearity"])
    return l * (epsilon * c + nonlinearity * c * c)