"""Rydberg–Ritz binding-energy law with a cluster-specific quantum-defect expansion."""
import numpy as np
from scipy.optimize import least_squares

USED_INPUTS = ["n_qm"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {
    "R": {"init": None},
    "delta0": {"init": None},
    "delta2": {"init": None},
}

def _binding(n, R, delta0, delta2):
    n = np.asarray(n, dtype=float)
    x = np.maximum(n - delta0, 1e-6)
    nu = x - delta2 / (x * x)
    return R / np.maximum(nu, 1e-6) ** 2

def fit(X_fit, y_fit):
    n = np.asarray(X_fit[:, 0], dtype=float)
    y = np.maximum(np.asarray(y_fit, dtype=float), 1e-12)

    # The large-n points provide a stable initial estimate of the Rydberg scale.
    R0 = max(float(np.median(y * n * n)), 1.0)
    d0 = float(np.clip(np.median(n - np.sqrt(R0 / y)), -5.0, np.min(n) - 1e-3))
    p0 = np.array([np.log(R0), d0, 0.0], dtype=float)

    def residual(p):
        R = np.exp(np.clip(p[0], -30.0, 35.0))
        return _binding(n, R, p[1], p[2]) - y

    try:
        lo = [np.log(1e2), -20.0, -1e4]
        hi = [np.log(1e8), float(np.min(n) - 1e-5), 1e4]
        result = least_squares(
            residual, p0, bounds=(lo, hi),
            loss="linear", max_nfev=3000
        )
        return {
            "R": float(np.exp(result.x[0])),
            "delta0": float(result.x[1]),
            "delta2": float(result.x[2]),
        }
    except Exception:
        return {"R": float(R0), "delta0": float(d0), "delta2": 0.0}

def predict(X, R, delta0, delta2):
    return _binding(np.asarray(X[:, 0], dtype=float), R, delta0, delta2)