"""Three-parameter Hill saturation law for fluorometric enzyme activity."""
import numpy as np
from scipy.optimize import least_squares

USED_INPUTS = ["substrate_conc"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {
    "Vmax": {"init": None},
    "K half": {"init": None},
    "n": {"init": None},
}

def _hill(S, Vmax, K_half, n):
    S = np.maximum(np.asarray(S, dtype=float), 0.0)
    Sn = np.power(S, n)
    Kn = np.power(K_half, n)
    return Vmax * Sn / (Kn + Sn)

def fit(X_fit, y_fit):
    S = np.maximum(np.asarray(X_fit[:, 0], dtype=float), 1e-12)
    y = np.maximum(np.asarray(y_fit, dtype=float), 0.0)
    ymax = max(float(np.percentile(y, 95)), 1.0)
    starts = [
        [1.3 * ymax, max(float(np.median(S)), 1.0), 1.0],
        [2.0 * ymax, max(float(np.median(S)), 1.0), 0.5],
        [1.3 * ymax, max(float(np.median(S)), 1.0), 1.5],
    ]
    lo = np.log([1e-8, 1e-8, 0.05])
    hi = np.log([1e9, 1e9, 5.0])
    best = None
    for p0 in starts:
        try:
            r = least_squares(
                lambda z: _hill(S, *np.exp(z)) - y,
                np.log(np.maximum(p0, 1e-8)),
                bounds=(lo, hi),
                loss="soft_l1",
                max_nfev=1000,
            )
            score = float(np.sum(r.fun * r.fun))
            if best is None or score < best[0]:
                best = (score, np.exp(r.x))
        except Exception:
            pass
    if best is None:
        return {"Vmax": float(ymax), "K half": float(np.median(S)), "n": 1.0}
    p = best[1]
    return {"Vmax": float(p[0]), "K half": float(p[1]), "n": float(p[2])}

def predict(X, **params):
    return _hill(
        X[:, 0],
        params["Vmax"],
        params["K half"],
        params["n"],
    )