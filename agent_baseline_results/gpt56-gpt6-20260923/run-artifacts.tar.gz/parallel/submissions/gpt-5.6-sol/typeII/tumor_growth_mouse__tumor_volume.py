"""Cluster-specific logistic tumor-growth curve with carrying capacity, growth rate, and inflection time."""
import numpy as np
from scipy.optimize import least_squares

USED_INPUTS = ["time_day"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {
    "K": {"init": None},
    "r": {"init": None},
    "t0": {"init": None},
}

def _logistic(t, K, r, t0):
    z = np.clip(r * (t - t0), -60.0, 60.0)
    return K / (1.0 + np.exp(-z))

def fit(X_fit, y_fit):
    t = np.asarray(X_fit[:, 0], dtype=float)
    y = np.asarray(y_fit, dtype=float)
    finite = np.isfinite(t) & np.isfinite(y)
    t = t[finite]
    y = y[finite]
    if len(t) == 0:
        return {"K": 1000.0, "r": 0.25, "t0": 15.0}

    ymax = max(float(np.max(y)), 1.0)
    tmed = float(np.median(t))
    p0 = np.array([max(1.5 * ymax, 100.0), 0.25, tmed], dtype=float)
    lo = np.array([max(1.0, ymax * 0.5), 1e-4, float(np.min(t)) - 100.0])
    hi = np.array([max(1e4, 20.0 * ymax), 5.0, float(np.max(t)) + 100.0])

    def residual(p):
        return _logistic(t, p[0], p[1], p[2]) - y

    try:
        result = least_squares(residual, p0, bounds=(lo, hi), max_nfev=3000)
        p = result.x
    except Exception:
        p = p0
    return {"K": float(p[0]), "r": float(p[1]), "t0": float(p[2])}

def predict(X, K, r, t0):
    t = np.asarray(X[:, 0], dtype=float)
    return np.asarray(_logistic(t, K, r, t0), dtype=float)