"""Shifted inverse-density competition law: mean individual mass is total biomass per effective plant density."""
import numpy as np
from scipy.optimize import least_squares

USED_INPUTS = ["density"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {
    "a": {"init": None},
    "b": {"init": None},
}

def fit(X_fit, y_fit):
    N = np.asarray(X_fit[:, 0], dtype=float)
    y = np.asarray(y_fit, dtype=float)
    N = np.maximum(N, 1e-8)

    # Initial total-biomass scale from the upper-density observations.
    order = np.argsort(N)
    k = max(1, len(N) // 3)
    a0 = float(np.median(y[order[-k:]] * N[order[-k:]]))
    if not np.isfinite(a0) or a0 <= 0:
        a0 = max(float(np.nanmedian(np.abs(y) * N)), 1e-3)

    def residual(p):
        a, b = p
        return a / (N + b) - y

    try:
        result = least_squares(
            residual,
            x0=np.array([a0, 0.1]),
            bounds=([1e-10, -0.95], [np.inf, np.inf]),
            loss="soft_l1",
            f_scale=max(0.02, 0.1 * float(np.nanmedian(np.abs(y))) + 1e-6),
            max_nfev=2000,
        )
        a, b = result.x
        if not np.all(np.isfinite([a, b])):
            raise ValueError
    except Exception:
        a, b = a0, 0.1
    return {"a": float(a), "b": float(b)}

def predict(X, **params):
    N = np.maximum(np.asarray(X[:, 0], dtype=float), 1e-8)
    a = float(params["a"])
    b = float(params["b"])
    denom = np.maximum(N + b, 1e-8)
    return np.asarray(a / denom, dtype=float)