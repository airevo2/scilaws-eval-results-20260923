"""Cluster-specific log-quadratic thermal performance curve for 24-hour optical density."""
import numpy as np
from scipy.optimize import least_squares

USED_INPUTS = ["T"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {
    "logA": {"init": None},
    "slope": {"init": None},
    "curvature": {"init": None},
}

def _form(T, logA, slope, curvature):
    z = logA + slope * (T - 37.0) + curvature * (T - 37.0) ** 2
    return np.exp(np.clip(z, -40.0, 20.0))

def fit(X_fit, y_fit):
    T = np.asarray(X_fit[:, 0], dtype=float)
    y = np.asarray(y_fit, dtype=float)
    # Small positive floor suppresses measurement/noise negatives while retaining
    # the thermal shape over the observed temperature grid.
    pos = y[y > 1e-5]
    floor = max(1e-5, 0.02 * (float(np.max(pos)) if len(pos) else 1.0))
    yy = np.maximum(y, floor)
    x = T - 37.0
    target = np.log(yy)

    def resid(p):
        return p[0] + p[1] * x + p[2] * x * x - target

    try:
        p0 = np.linalg.lstsq(
            np.column_stack([np.ones_like(x), x, x * x]), target, rcond=None
        )[0]
        p0[0] = np.clip(p0[0], -20.0, 5.0)
        p0[2] = min(float(p0[2]), -1e-5)
        result = least_squares(
            resid, p0,
            bounds=([-30.0, -3.0, -1.0], [5.0, 3.0, 0.0]),
            max_nfev=300
        )
        p = result.x
    except Exception:
        p = np.array([np.log(max(float(np.max(yy)), 1e-5)), 0.0, -0.01])
    return {"logA": float(p[0]), "slope": float(p[1]), "curvature": float(p[2])}

def predict(X, **params):
    T = np.asarray(X[:, 0], dtype=float)
    return _form(T, params["logA"], params["slope"], params["curvature"])