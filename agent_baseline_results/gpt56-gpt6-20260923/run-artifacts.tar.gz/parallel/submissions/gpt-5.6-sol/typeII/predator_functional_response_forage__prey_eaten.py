"""Holling type-II functional response with cluster-specific attack rate and handling time."""
import numpy as np
from scipy.optimize import least_squares

USED_INPUTS = ["prey_density"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {
    "attack_rate": {"init": None},
    "handling_time": {"init": None},
}

def _response(N, attack_rate, handling_time):
    N = np.asarray(N, dtype=float)
    return attack_rate * N / (1.0 + attack_rate * handling_time * N)

def fit(X_fit, y_fit):
    N = np.maximum(np.asarray(X_fit[:, 0], dtype=float), 0.0)
    y = np.asarray(y_fit, dtype=float)
    positive = y[np.isfinite(y) & (y > 0)]
    ymax = float(np.max(positive)) if positive.size else 1.0
    nscale = float(np.median(N[N > 0])) if np.any(N > 0) else 1.0
    p0 = np.array([max(ymax / nscale, 1e-3), max(1.0 / ymax, 1e-3)])
    
    def residual(logp):
        a, h = np.exp(logp)
        return _response(N, a, h) - y
    
    try:
        result = least_squares(
            residual, np.log(p0), max_nfev=2000,
            loss="soft_l1", f_scale=max(0.25, 0.05 * ymax)
        )
        a, h = np.exp(result.x)
        if not (np.isfinite(a) and np.isfinite(h)):
            raise ValueError
        return {"attack_rate": float(a), "handling_time": float(h)}
    except Exception:
        return {"attack_rate": float(p0[0]), "handling_time": float(p0[1])}

def predict(X, **params):
    N = np.maximum(np.asarray(X[:, 0], dtype=float), 0.0)
    return _response(N, params["attack_rate"], params["handling_time"])