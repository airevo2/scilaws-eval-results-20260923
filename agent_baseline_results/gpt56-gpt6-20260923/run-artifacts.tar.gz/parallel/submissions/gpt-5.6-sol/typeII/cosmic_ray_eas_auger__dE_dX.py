"""Gaisser–Hillas longitudinal shower profile with cluster-specific normalization,
first-interaction depth, shower maximum, and attenuation length."""
import numpy as np
from scipy.optimize import least_squares

USED_INPUTS = ["X"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {
    "A": {"init": None},
    "X0": {"init": None},
    "Xmax": {"init": None},
    "lambda_": {"init": None},
}

def _log_profile(x, A, X0, Xmax, lambda_):
    dx = max(Xmax - X0, 1e-8)
    lam = max(lambda_, 1e-8)
    z = np.maximum((x - X0) / dx, 1e-300)
    return np.log(max(A, 1e-300)) + (dx / lam) * np.log(z) + (Xmax - x) / lam

def fit(X_fit, y_fit):
    x = np.asarray(X_fit[:, 0], dtype=float)
    y = np.maximum(np.asarray(y_fit, dtype=float), 1e-300)
    xmin = float(np.min(x))
    xmax = float(np.max(x))
    imax = int(np.argmax(y))
    peak = float(x[imax])
    ymax = float(np.max(y))

    # Fit in log space, which preserves the positive-definite profile shape.
    def residual(p):
        return _log_profile(x, np.exp(np.clip(p[0], -700.0, 700.0)),
                            p[1], p[2], p[3]) - np.log(y)

    p0 = np.array([
        np.log(ymax),
        xmin - max(100.0, 0.25 * (xmax - xmin)),
        peak,
        max(50.0, 0.35 * (xmax - xmin)),
    ])
    lower = np.array([np.log(1e-300), xmin - 5000.0, xmin, 1e-3])
    upper = np.array([np.log(1e300), xmin - 1e-6, xmax + 500.0, 5000.0])
    p0 = np.minimum(np.maximum(p0, lower + 1e-10), upper - 1e-10)

    try:
        result = least_squares(
            residual, p0, bounds=(lower, upper),
            loss="soft_l1", f_scale=0.05, max_nfev=3000
        )
        p = result.x
    except Exception:
        p = p0

    return {
        "A": float(np.exp(np.clip(p[0], -700.0, 700.0))),
        "X0": float(p[1]),
        "Xmax": float(p[2]),
        "lambda_": float(max(p[3], 1e-8)),
    }

def predict(X, **params):
    x = np.asarray(X[:, 0], dtype=float)
    A = float(params["A"])
    X0 = float(params["X0"])
    Xmax = float(params["Xmax"])
    lambda_ = float(params["lambda_"])
    logy = _log_profile(x, A, X0, Xmax, lambda_)
    return np.exp(np.clip(logy, -700.0, 700.0))