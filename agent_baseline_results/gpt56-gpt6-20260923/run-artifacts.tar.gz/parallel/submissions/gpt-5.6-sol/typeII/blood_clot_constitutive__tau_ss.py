"""Cluster-specific odd cubic shear stress law."""
import numpy as np

USED_INPUTS = ["gamma"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {
    "linear": {"init": None},
    "cubic": {"init": None},
}

def fit(X_fit, y_fit):
    gamma = np.asarray(X_fit[:, 0], dtype=float)
    y = np.asarray(y_fit, dtype=float)
    A = np.column_stack((gamma, gamma ** 3))
    try:
        coef, _, _, _ = np.linalg.lstsq(A, y, rcond=None)
        if not np.all(np.isfinite(coef)):
            raise ValueError
        return {"linear": float(coef[0]), "cubic": float(coef[1])}
    except Exception:
        scale = max(float(np.nanmax(np.abs(y))), 1.0)
        return {"linear": scale, "cubic": 0.0}

def predict(X, linear, cubic):
    gamma = np.asarray(X[:, 0], dtype=float)
    return linear * gamma + cubic * gamma ** 3