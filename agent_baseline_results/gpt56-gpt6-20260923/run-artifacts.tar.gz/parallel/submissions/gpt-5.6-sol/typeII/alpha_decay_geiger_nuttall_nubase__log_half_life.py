"""Geiger-Nuttall alpha-decay law: log10 half-life is affine in the inverse square root of the alpha-decay Q-value, with cluster-specific slope and intercept."""
import numpy as np

USED_INPUTS = ["Q_alpha_MeV"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {
    "slope": {"init": None},
    "intercept": {"init": None},
}

def fit(X_fit, y_fit):
    Q = np.asarray(X_fit[:, 0], dtype=float)
    y = np.asarray(y_fit, dtype=float)
    z = 1.0 / np.sqrt(np.maximum(Q, 1e-12))
    A = np.column_stack((z, np.ones_like(z)))
    try:
        beta, _, _, _ = np.linalg.lstsq(A, y, rcond=None)
        slope = float(beta[0])
        intercept = float(beta[1])
        if np.isfinite(slope) and np.isfinite(intercept):
            return {"slope": slope, "intercept": intercept}
    except Exception:
        pass
    return {
        "slope": 0.0,
        "intercept": float(np.mean(y)) if y.size else 0.0,
    }

def predict(X, slope, intercept):
    Q = np.asarray(X[:, 0], dtype=float)
    return slope / np.sqrt(np.maximum(Q, 1e-12)) + intercept