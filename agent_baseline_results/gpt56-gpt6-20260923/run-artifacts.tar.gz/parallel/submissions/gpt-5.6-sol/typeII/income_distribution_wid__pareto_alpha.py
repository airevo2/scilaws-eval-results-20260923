"""Lognormal upper-tail income model: if log income is normal with cluster-specific
dispersion sigma, the share held by the top p fraction is
Phi(sigma + Phi^{-1}(p)); the location parameter cancels from the share."""
import numpy as np
from scipy.optimize import least_squares
from scipy.special import ndtr, ndtri

USED_INPUTS = ["log_p_above"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {"sigma": {"init": None}}

def fit(X_fit, y_fit):
    x = np.asarray(X_fit[:, 0], dtype=float)
    y = np.asarray(y_fit, dtype=float)
    p = np.clip(np.exp(x), 1e-12, 1.0 - 1e-12)
    z = ndtri(p)
    def residual(q):
        sigma = np.exp(q[0])
        return np.log(np.maximum(ndtr(sigma + z), 1e-300)) - y
    try:
        r = least_squares(residual, [np.log(1.5)], bounds=([-5.0], [5.0]),
                          max_nfev=1000)
        sigma = float(np.exp(r.x[0]))
    except Exception:
        sigma = 1.5
    return {"sigma": sigma}

def predict(X, sigma):
    x = np.asarray(X[:, 0], dtype=float)
    p = np.clip(np.exp(x), 1e-12, 1.0 - 1e-12)
    return np.log(np.maximum(ndtr(float(sigma) + ndtri(p)), 1e-300))