"""Generalized von Bertalanffy growth curve with cluster-specific asymptotic length, rate, and early-growth exponent."""
import numpy as np
from scipy.optimize import least_squares

USED_INPUTS = ["Agei"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {
    "L_inf": {"init": None},
    "k": {"init": None},
    "p": {"init": None},
}

def _form(age, L_inf, k, p):
    age = np.maximum(np.asarray(age, dtype=float), 0.0)
    z = -np.expm1(-k * age)
    return L_inf * np.power(np.maximum(z, 0.0), p)

def fit(X_fit, y_fit):
    age = np.maximum(np.asarray(X_fit[:, 0], dtype=float), 0.0)
    y = np.asarray(y_fit, dtype=float)
    ymax = max(float(np.nanmax(y)), 1.0)
    starts = [
        [1.15 * ymax, 0.5, 0.4],
        [1.5 * ymax, 0.2, 0.3],
        [2.0 * ymax, 1.0, 0.5],
    ]
    best = None
    for p0 in starts:
        try:
            res = least_squares(
                lambda q: _form(age, q[0], q[1], q[2]) - y,
                p0,
                bounds=([1e-6, 1e-5, 0.03], [1e5, 50.0, 3.0]),
                max_nfev=3000,
            )
            loss = float(np.mean(res.fun * res.fun))
            if best is None or loss < best[0]:
                best = (loss, res.x)
        except Exception:
            pass
    if best is None:
        return {"L_inf": float(1.5 * ymax), "k": 0.5, "p": 0.4}
    q = best[1]
    return {"L_inf": float(q[0]), "k": float(q[1]), "p": float(q[2])}

def predict(X, **params):
    return _form(
        X[:, 0],
        float(params["L_inf"]),
        float(params["k"]),
        float(params["p"]),
    )