"""Quadratic age profile for log central adult mortality, with cluster-specific level, slope, and curvature."""
import numpy as np

USED_INPUTS = ["age"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {
    "level": {"init": None},
    "slope": {"init": None},
    "curvature": {"init": None},
}

def fit(X_fit, y_fit):
    age = np.asarray(X_fit[:, 0], dtype=float)
    y = np.asarray(y_fit, dtype=float)
    z = age - 60.0
    A = np.column_stack((np.ones_like(z), z, z * z))
    try:
        coef, _, _, _ = np.linalg.lstsq(A, y, rcond=None)
        if not np.all(np.isfinite(coef)):
            raise ValueError
        return {
            "level": float(coef[0]),
            "slope": float(coef[1]),
            "curvature": float(coef[2]),
        }
    except Exception:
        return {
            "level": float(np.mean(y)) if y.size else 0.0,
            "slope": 0.0,
            "curvature": 0.0,
        }

def predict(X, level, slope, curvature):
    age = np.asarray(X[:, 0], dtype=float)
    z = age - 60.0
    return level + slope * z + curvature * z * z