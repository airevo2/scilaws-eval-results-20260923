"""Per-cluster Gaussian solar-cycle profile with fitted amplitude, peak time, and width."""
import numpy as np
from scipy.optimize import least_squares

USED_INPUTS = ["t_year"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {
    "amplitude": {"init": [100.0]},
    "peak_year": {"init": [0.0]},
    "width_years": {"init": [2.2]},
}

def _profile(t, amplitude, peak_year, width_years):
    w = np.maximum(np.abs(width_years), 1e-6)
    q = (t - peak_year) / w
    return amplitude * np.exp(-0.5 * q * q)

def fit(X_fit, y_fit):
    t = np.asarray(X_fit[:, 0], dtype=float)
    y = np.asarray(y_fit, dtype=float)
    finite = np.isfinite(t) & np.isfinite(y)
    t = t[finite]
    y = y[finite]
    if len(t) == 0:
        return {"amplitude": 100.0, "peak_year": 0.0, "width_years": 2.2}

    i = int(np.argmax(y))
    amp0 = max(float(y[i]), 1.0)
    mu0 = float(t[i])
    w0 = 2.2
    lo = [0.0, float(np.min(t)) - 5.0, 0.2]
    hi = [5000.0, float(np.max(t)) + 5.0, 10.0]

    def residual(p):
        return _profile(t, p[0], p[1], p[2]) - y

    try:
        result = least_squares(
            residual, [amp0, mu0, w0], bounds=(lo, hi),
            loss="soft_l1", f_scale=15.0, max_nfev=1500
        )
        p = np.asarray(result.x, dtype=float)
        if not np.all(np.isfinite(p)):
            raise ValueError
        return {
            "amplitude": float(p[0]),
            "peak_year": float(p[1]),
            "width_years": float(p[2]),
        }
    except Exception:
        return {"amplitude": amp0, "peak_year": mu0, "width_years": w0}

def predict(X, amplitude, peak_year, width_years):
    t = np.asarray(X[:, 0], dtype=float)
    y = _profile(t, amplitude, peak_year, width_years)
    return np.asarray(y, dtype=float)