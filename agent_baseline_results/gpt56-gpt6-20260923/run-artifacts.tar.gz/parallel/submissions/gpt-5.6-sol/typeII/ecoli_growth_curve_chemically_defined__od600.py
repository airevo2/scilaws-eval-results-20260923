"""Four-parameter logistic growth curve with cluster-specific baseline, amplitude, rate, and midpoint."""
import numpy as np
from scipy.optimize import curve_fit

USED_INPUTS = ["time_h"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {
    "y0": {"init": None},
    "A": {"init": None},
    "k": {"init": None},
    "t_mid": {"init": None},
}

def _logistic(t, y0, A, k, t_mid):
    z = np.clip(-k * (t - t_mid), -700.0, 700.0)
    return y0 + A / (1.0 + np.exp(z))

def fit(X_fit, y_fit):
    t = np.asarray(X_fit[:, 0], dtype=float)
    y = np.asarray(y_fit, dtype=float)
    finite = np.isfinite(t) & np.isfinite(y)
    t, y = t[finite], y[finite]
    if len(y) == 0:
        return {"y0": 0.08, "A": 0.24, "k": 0.5, "t_mid": 12.0}

    lo = float(np.min(y))
    hi = float(np.max(y))
    span = max(hi - lo, 1e-4)
    y0_init = float(np.percentile(y, 10))
    A_init = max(float(np.percentile(y, 95)) - y0_init, 1e-4)
    tmid_init = float(np.median(t))
    if A_init > 0:
        half = y0_init + 0.5 * A_init
        j = int(np.argmin(np.abs(y - half)))
        tmid_init = float(t[j])

    p0 = [np.clip(y0_init, 0.0, 1.0), np.clip(A_init, 1e-4, 1.5), 0.5,
          np.clip(tmid_init, -100.0, 200.0)]
    try:
        popt, _ = curve_fit(
            _logistic, t, y, p0=p0,
            bounds=([0.0, 1e-5, 1e-5, -100.0],
                    [1.0, 2.0, 10.0, 200.0]),
            maxfev=10000
        )
        return {k: float(v) for k, v in zip(("y0", "A", "k", "t_mid"), popt)}
    except Exception:
        return {"y0": float(p0[0]), "A": float(p0[1]),
                "k": float(p0[2]), "t_mid": float(p0[3])}

def predict(X, **params):
    t = np.asarray(X[:, 0], dtype=float)
    out = _logistic(t, params["y0"], params["A"],
                    params["k"], params["t_mid"])
    return np.asarray(out, dtype=float)