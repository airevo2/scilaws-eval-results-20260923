"""Thresholded generalized electron-impact ionization law: a logarithmic rise above threshold, followed by a power-law high-energy decay."""
import numpy as np
from scipy.optimize import least_squares

USED_INPUTS = ["electron_energy_eV"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {
    "A": {"init": None},
    "I": {"init": None},
    "p": {"init": None},
    "q": {"init": None},
}

def _law(E, A, I, p, q):
    E = np.asarray(E, dtype=float)
    r = np.maximum(E / np.maximum(I, 1e-12), 1.0 + 1e-12)
    z = np.maximum(1.0 - I / np.maximum(E, 1e-12), 0.0)
    return A * np.log(r) * np.power(z, p) / np.power(np.maximum(E, 1e-12), q)

def fit(X_fit, y_fit):
    E = np.asarray(X_fit[:, 0], dtype=float)
    y = np.maximum(np.asarray(y_fit, dtype=float), 0.0)
    emin = max(float(np.min(E)), 1e-6)
    emax = max(float(np.max(E)), emin * 1.01)
    ymax = max(float(np.max(y)), 1e-6)
    starts = [
        [ymax * emax**0.8, 0.8 * emin, 1.0, 0.8],
        [ymax * emax, 0.6 * emin, 2.0, 1.0],
    ]
    lo = [1e-12, 1e-8, 0.0, 0.05]
    hi = [1e12, emin * (1.0 - 1e-8), 20.0, 3.0]
    best = None
    for s in starts:
        try:
            r = least_squares(
                lambda z: _law(E, z[0], z[1], z[2], z[3]) - y,
                s, bounds=(lo, hi), max_nfev=4000, x_scale="jac"
            )
            err = float(np.mean(r.fun * r.fun))
            if best is None or err < best[0]:
                best = (err, r.x)
        except Exception:
            pass
    if best is None:
        return {"A": float(ymax * emax), "I": float(0.8 * emin),
                "p": 1.0, "q": 0.8}
    z = best[1]
    return {"A": float(z[0]), "I": float(z[1]),
            "p": float(z[2]), "q": float(z[3])}

def predict(X, **params):
    E = np.asarray(X[:, 0], dtype=float)
    out = _law(E, params["A"], params["I"], params["p"], params["q"])
    return np.nan_to_num(out, nan=0.0, posinf=1e300, neginf=0.0)