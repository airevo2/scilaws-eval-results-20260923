"""Corresponding-states surface-tension form: molecular number-density scale
times a universal reduced-temperature critical-law factor, with one
substance-specific amplitude."""
import numpy as np

USED_INPUTS = ["T_K", "rho_liq", "T_c", "M_mol"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {"a": {"init": None}}

def _basis(X):
    T = np.asarray(X[:, 0], dtype=float)
    rho = np.asarray(X[:, 1], dtype=float)
    Tc = np.asarray(X[:, 2], dtype=float)
    M = np.asarray(X[:, 3], dtype=float)
    reduced = np.maximum(1.0 - T / Tc, np.finfo(float).tiny)
    number_density = np.maximum(rho / M, np.finfo(float).tiny)
    return number_density ** (2.0 / 3.0) * reduced ** 1.26

def fit(X_fit, y_fit):
    z = _basis(X_fit)
    y = np.asarray(y_fit, dtype=float)
    den = float(np.dot(z, z))
    if not np.isfinite(den) or den <= 0.0:
        return {"a": 1.0}
    a = float(np.dot(z, y) / den)
    if not np.isfinite(a):
        a = 1.0
    return {"a": a}

def predict(X, **params):
    z = _basis(X)
    a = float(params.get("a", 1.0))
    if not np.isfinite(a):
        a = 1.0
    return np.asarray(a * z, dtype=float)