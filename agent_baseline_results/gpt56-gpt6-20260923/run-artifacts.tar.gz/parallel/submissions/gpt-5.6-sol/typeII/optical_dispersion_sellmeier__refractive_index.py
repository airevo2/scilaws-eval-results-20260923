"""Two-resonance Sellmeier dispersion law with cluster-specific coefficients."""
import numpy as np
from scipy.optimize import least_squares

USED_INPUTS = ["wavelength_um"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {
    "B1": {"init": None},
    "C1": {"init": None},
    "B2": {"init": None},
    "C2": {"init": None},
}

def _form(w, B1, C1, B2, C2):
    w2 = np.maximum(np.asarray(w, dtype=float) ** 2, 1e-12)
    den1 = w2 - C1
    den2 = w2 - C2
    q = 1.0 + B1 * w2 / den1 + B2 * w2 / den2
    return np.sqrt(np.maximum(q, 1e-12))

def fit(X_fit, y_fit):
    w = np.asarray(X_fit[:, 0], dtype=float)
    y = np.asarray(y_fit, dtype=float)
    scale = max(float(np.median(y) ** 2 - 1.0), 0.05)
    wmin2 = max(float(np.min(w) ** 2), 1e-5)
    starts = [
        [0.8 * scale, 0.02 * wmin2, 0.2 * scale, 4.0 * max(float(np.max(w) ** 2), 1.0)],
        [scale, 0.01 * wmin2, 0.1 * scale, 10.0 * max(float(np.max(w) ** 2), 1.0)],
    ]
    lo = [-100.0, -100.0 * max(float(np.max(w) ** 2), 1.0),
          -100.0, -100.0 * max(float(np.max(w) ** 2), 1.0)]
    hi = [100.0, 0.99 * wmin2, 100.0, 1000.0 * max(float(np.max(w) ** 2), 1.0)]
    best = None
    for p0 in starts:
        try:
            r = least_squares(lambda p: _form(w, *p) - y, p0,
                              bounds=(lo, hi), max_nfev=3000)
            err = float(np.mean((r.fun) ** 2))
            if best is None or err < best[0]:
                best = (err, r.x)
        except Exception:
            pass
    if best is None:
        return {"B1": starts[0][0], "C1": starts[0][1],
                "B2": starts[0][2], "C2": starts[0][3]}
    p = best[1]
    return {"B1": float(p[0]), "C1": float(p[1]),
            "B2": float(p[2]), "C2": float(p[3])}

def predict(X, B1, C1, B2, C2):
    return _form(X[:, 0], B1, C1, B2, C2)