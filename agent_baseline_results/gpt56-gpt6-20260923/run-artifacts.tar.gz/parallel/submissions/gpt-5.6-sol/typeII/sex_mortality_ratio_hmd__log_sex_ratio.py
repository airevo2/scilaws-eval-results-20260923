"""Three-parameter additive quadratic-age and linear-year mechanism."""
import numpy as np

USED_INPUTS = ["age", "year"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {
    "level": {"init": None},
    "year_slope": {"init": None},
    "age_curvature": {"init": None},
}

def fit(X_fit, y_fit):
    X_fit = np.asarray(X_fit, dtype=float)
    y_fit = np.asarray(y_fit, dtype=float)
    age = X_fit[:, 0]
    year = X_fit[:, 1]
    Z = np.column_stack([
        np.ones(len(age)),
        year - 1980.0,
        ((age - 60.0) / 10.0) ** 2,
    ])
    try:
        beta, _, _, _ = np.linalg.lstsq(Z, y_fit, rcond=None)
        if not np.all(np.isfinite(beta)):
            raise ValueError
    except Exception:
        beta = np.array([
            float(np.nanmean(y_fit)) if y_fit.size else 0.0,
            0.0,
            0.0,
        ])
    return {
        "level": float(beta[0]),
        "year_slope": float(beta[1]),
        "age_curvature": float(beta[2]),
    }

def predict(X, level, year_slope, age_curvature):
    X = np.asarray(X, dtype=float)
    age = X[:, 0]
    year = X[:, 1]
    y = (
        float(level)
        + float(year_slope) * (year - 1980.0)
        + float(age_curvature) * ((age - 60.0) / 10.0) ** 2
    )
    return np.asarray(y, dtype=float)