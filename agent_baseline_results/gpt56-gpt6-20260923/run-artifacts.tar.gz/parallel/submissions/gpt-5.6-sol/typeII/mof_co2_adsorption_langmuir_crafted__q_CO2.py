"""Three-parameter Sips (Langmuir–Freundlich) adsorption isotherm."""
import numpy as np
from scipy.optimize import least_squares

USED_INPUTS = ["P_bar"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {
    "q_max": {"init": None},
    "K": {"init": None},
    "n": {"init": None},
}

def _sips(P, q_max, K, n):
    P = np.maximum(np.asarray(P, dtype=float), 0.0)
    z = np.power(np.maximum(K * P, 1e-300), n)
    return q_max * z / (1.0 + z)

def fit(X_fit, y_fit):
    P = np.maximum(np.asarray(X_fit[:, 0], dtype=float), 0.0)
    y = np.asarray(y_fit, dtype=float)
    finite = np.isfinite(P) & np.isfinite(y)
    P, y = P[finite], y[finite]
    if len(P) == 0:
        return {"q_max": 1.0, "K": 1.0, "n": 1.0}

    ymax = max(float(np.nanpercentile(y, 95)), 1e-3)
    q0 = max(1.1 * ymax, 1e-3)
    order = np.argsort(P)
    ps, ys = P[order], y[order]
    target = 0.5 * ymax
    kidx = int(np.argmin(np.abs(ys - target)))
    p50 = max(float(ps[kidx]), 1e-6)
    x0 = np.array([q0, 1.0 / p50, 0.8], dtype=float)

    def residual(z):
        return _sips(P, z[0], z[1], z[2]) - y

    try:
        res = least_squares(
            residual, x0,
            bounds=([1e-8, 1e-10, 0.05], [1e5, 1e8, 3.0]),
            loss="soft_l1", f_scale=max(0.02 * ymax, 1e-3),
            max_nfev=3000
        )
        qhat, khat, nhat = res.x
        return {"q_max": float(qhat), "K": float(khat), "n": float(nhat)}
    except Exception:
        return {"q_max": float(q0), "K": float(1.0 / p50), "n": 0.8}

def predict(X, **params):
    return _sips(
        X[:, 0],
        float(params["q_max"]),
        float(params["K"]),
        float(params["n"])
    )