"""Shared ecological distance-decay power law for Sørensen similarity: S(d) = c d^(-z)."""
import numpy as np
from scipy.optimize import curve_fit

USED_INPUTS = ["env_dist"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {
    "c": {"init": None},
    "z": {"init": None},
}

def _form(d, c, z):
    d = np.maximum(np.asarray(d, dtype=float), 1e-12)
    return c * np.power(d, -z)

def fit(X_fit, y_fit):
    d = np.maximum(np.asarray(X_fit[:, 0], dtype=float), 1e-12)
    y = np.asarray(y_fit, dtype=float)
    good = np.isfinite(d) & np.isfinite(y) & (y > 0)
    d0 = d[good]
    y0 = y[good]
    if d0.size < 2:
        return {"c": 0.5, "z": 0.3}
    try:
        slope, intercept = np.polyfit(np.log(d0), np.log(y0), 1)
        z0 = float(np.clip(-slope, 1e-6, 10.0))
        c0 = float(np.clip(np.exp(intercept), 1e-8, 100.0))
        popt, _ = curve_fit(
            _form, d0, y0, p0=[c0, z0],
            bounds=([1e-10, 0.0], [1e3, 20.0]),
            maxfev=5000,
        )
        c_hat, z_hat = popt
        if not (np.isfinite(c_hat) and np.isfinite(z_hat)):
            raise ValueError
        return {"c": float(c_hat), "z": float(z_hat)}
    except Exception:
        return {"c": c0, "z": z0}

def predict(X, **params):
    return _form(X[:, 0], params["c"], params["z"])