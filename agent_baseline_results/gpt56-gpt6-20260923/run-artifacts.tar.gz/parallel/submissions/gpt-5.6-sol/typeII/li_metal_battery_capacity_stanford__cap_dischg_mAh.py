"""Shared square-root transient plus linear cycle-aging law."""
import numpy as np

USED_INPUTS = ["cycle_index"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {
    "q0": {"init": 1.0},
    "sqrt_term": {"init": 1.0},
    "linear_fade": {"init": 1.0},
}

def _form(k, q0, sqrt_term, linear_fade):
    k = np.maximum(np.asarray(k, dtype=float), 1.0)
    return q0 + sqrt_term * np.sqrt(k) - linear_fade * k

def fit(X_fit, y_fit):
    k = np.maximum(np.asarray(X_fit[:, 0], dtype=float), 1.0)
    y = np.asarray(y_fit, dtype=float)
    A = np.column_stack((np.ones_like(k), np.sqrt(k), k))
    try:
        p, _, _, _ = np.linalg.lstsq(A, y, rcond=None)
        p = np.nan_to_num(p, nan=0.0, posinf=0.0, neginf=0.0)
        return {
            "q0": float(p[0]),
            "sqrt_term": float(p[1]),
            "linear_fade": float(p[2]),
        }
    except Exception:
        return {
            "q0": float(np.mean(y)) if len(y) else 0.0,
            "sqrt_term": 0.0,
            "linear_fade": 0.0,
        }

def predict(X, q0, sqrt_term, linear_fade):
    k = np.maximum(np.asarray(X[:, 0], dtype=float), 1.0)
    return np.nan_to_num(
        _form(k, q0, sqrt_term, linear_fade),
        nan=0.0,
        posinf=0.0,
        neginf=0.0,
    )