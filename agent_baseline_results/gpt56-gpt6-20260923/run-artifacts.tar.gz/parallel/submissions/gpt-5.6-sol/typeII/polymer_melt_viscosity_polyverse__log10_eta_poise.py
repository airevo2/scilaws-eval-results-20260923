"""Williams-Landel-Ferry temperature-shift form with cluster-specific level and strength."""
import numpy as np

USED_INPUTS = ["Temperature_K", "Tg_K"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {"C_wlf_K": 51.6}
LOCAL_FITTABLE = {
    "A": {"init": None},
    "B": {"init": None},
}

def fit(X_fit, y_fit):
    T = np.asarray(X_fit[:, 0], dtype=float)
    Tg = np.asarray(X_fit[:, 1], dtype=float)
    y = np.asarray(y_fit, dtype=float)
    C = OTHER_CONSTANTS["C_wlf_K"]
    dT = T - Tg
    z = dT / (C + dT)
    M = np.column_stack((np.ones_like(z), z))
    try:
        p, _, _, _ = np.linalg.lstsq(M, y, rcond=None)
        if not np.all(np.isfinite(p)):
            raise ValueError
        return {"A": float(p[0]), "B": float(p[1])}
    except Exception:
        return {"A": float(np.mean(y)), "B": 0.0}

def predict(X, A, B):
    T = np.asarray(X[:, 0], dtype=float)
    Tg = np.asarray(X[:, 1], dtype=float)
    C = OTHER_CONSTANTS["C_wlf_K"]
    dT = T - Tg
    z = dT / (C + dT)
    out = A + B * z
    return np.nan_to_num(out, nan=0.0, posinf=1e6, neginf=-1e6)