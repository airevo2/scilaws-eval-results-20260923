"""Cluster-specific quadratic law in the logarithm of the top fraction."""
import numpy as np

USED_INPUTS = ["log_p_above"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {
    "intercept": {"init": None},
    "slope": {"init": None},
    "curvature": {"init": None},
}

def fit(X_fit, y_fit):
    x = np.asarray(X_fit[:, 0], dtype=float)
    y = np.asarray(y_fit, dtype=float)
    A = np.column_stack((np.ones_like(x), x, x * x))
    try:
        beta = np.linalg.lstsq(A, y, rcond=None)[0]
        if beta.shape != (3,) or not np.all(np.isfinite(beta)):
            raise ValueError
    except Exception:
        beta = np.zeros(3, dtype=float)
    return {
        "intercept": float(beta[0]),
        "slope": float(beta[1]),
        "curvature": float(beta[2]),
    }

def predict(X, intercept, slope, curvature):
    x = np.asarray(X[:, 0], dtype=float)
    return np.asarray(intercept + slope * x + curvature * x * x, dtype=float)