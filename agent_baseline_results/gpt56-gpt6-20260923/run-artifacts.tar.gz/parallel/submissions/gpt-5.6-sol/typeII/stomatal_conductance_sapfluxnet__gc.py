"""Cluster-specific exponential VPD response: canopy conductance scales as a positive amplitude times an exponential function of VPD."""
import numpy as np
from scipy.optimize import least_squares

USED_INPUTS = ["vpd"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {
    "amplitude": {"init": None},
    "vpd_decay": {"init": None},
}

def _model(vpd, amplitude, vpd_decay):
    vpd = np.asarray(vpd, dtype=float)
    return amplitude * np.exp(np.clip(-vpd_decay * vpd, -700.0, 700.0))

def fit(X_fit, y_fit):
    vpd = np.asarray(X_fit[:, 0], dtype=float)
    y = np.asarray(y_fit, dtype=float)
    finite = np.isfinite(vpd) & np.isfinite(y)
    vpd = vpd[finite]
    y = y[finite]
    if len(y) == 0:
        return {"amplitude": 1.0, "vpd_decay": 1.0}

    amplitude0 = max(float(np.max(y)), 1e-6)
    positive = y > max(1e-8, 0.01 * amplitude0)
    if np.sum(positive) >= 2:
        slope, intercept = np.polyfit(vpd[positive], np.log(y[positive]), 1)
        amplitude0 = max(float(np.exp(intercept)), 1e-6)
        decay0 = float(-slope)
    else:
        decay0 = 1.0

    try:
        result = least_squares(
            lambda p: _model(vpd, p[0], p[1]) - y,
            x0=np.array([amplitude0, decay0], dtype=float),
            bounds=([1e-9, -100.0], [1e6, 100.0]),
            loss="soft_l1",
            max_nfev=1000,
        )
        amplitude, vpd_decay = result.x
    except Exception:
        amplitude, vpd_decay = amplitude0, decay0

    if not np.isfinite(amplitude) or amplitude <= 0:
        amplitude = amplitude0
    if not np.isfinite(vpd_decay):
        vpd_decay = decay0
    return {"amplitude": float(amplitude), "vpd_decay": float(vpd_decay)}

def predict(X, amplitude, vpd_decay):
    return np.asarray(_model(X[:, 0], amplitude, vpd_decay), dtype=float)