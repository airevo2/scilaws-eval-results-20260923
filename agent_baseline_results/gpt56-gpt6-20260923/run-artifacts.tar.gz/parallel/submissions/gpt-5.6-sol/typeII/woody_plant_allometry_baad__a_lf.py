"""Shared sapwood-area power law with inverse height scaling and a cluster-specific allometric amplitude."""
import numpy as np

USED_INPUTS = ["a_ssbh", "h_t"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {"a": {"init": None}}

def fit(X_fit, y_fit):
    A = np.asarray(X_fit[:, 0], dtype=float)
    H = np.asarray(X_fit[:, 1], dtype=float)
    y = np.asarray(y_fit, dtype=float)
    z = y * H / np.maximum(A, 1e-300)**1.5
    z = z[np.isfinite(z) & (z > 0)]
    if z.size == 0:
        return {"a": 1.0}
    return {"a": float(np.median(z))}

def predict(X, **params):
    A = np.maximum(np.asarray(X[:, 0], dtype=float), 0.0)
    H = np.maximum(np.asarray(X[:, 1], dtype=float), 1e-12)
    a = float(params.get("a", 1.0))
    return a * A**1.5 / H