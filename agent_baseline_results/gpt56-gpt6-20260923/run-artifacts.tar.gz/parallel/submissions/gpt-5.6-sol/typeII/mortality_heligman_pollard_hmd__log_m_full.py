"""Heligman–Pollard three-component age-mortality law: infant decline, a
lognormal young-adult accident hump, and an exponential senescent term."""
import numpy as np
from scipy.optimize import least_squares
from scipy.special import logsumexp

USED_INPUTS = ["age"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {
    "a": {"init": None},
    "b": {"init": None},
    "c": {"init": None},
    "d": {"init": None},
    "e": {"init": None},
    "f": {"init": None},
    "g": {"init": None},
    "h": {"init": None},
}

def _log_model(x, p):
    aa, b, c, d, e, f, g, h = np.exp(np.asarray(p, dtype=float))
    x = np.asarray(x, dtype=float)
    # A^(x+B)^C, with A=exp(-aa)
    z_infant = -aa * np.power(x + b, c)
    # The accident component is negligible at exact age zero.
    lx = np.log(np.maximum(x, 1.0e-12) / f)
    z_accident = np.log(d) - e * lx * lx
    z_old = np.log(g) + h * x
    return logsumexp(
        np.stack((z_infant, z_accident, z_old), axis=0), axis=0
    )

def fit(X_fit, y_fit):
    x = np.asarray(X_fit[:, 0], dtype=float)
    y = np.asarray(y_fit, dtype=float)
    ok = np.isfinite(x) & np.isfinite(y)
    x, y = x[ok], y[ok]
    if len(y) == 0:
        return {
            "a": 8.0, "b": 0.1, "c": 0.2, "d": 1.0e-3,
            "e": 10.0, "f": 22.0, "g": 1.0e-5, "h": 0.1
        }

    order = np.argsort(x)
    x, y = x[order], y[order]
    p0s = [
        np.log([8.0, 0.10, 0.20, 1.0e-3, 10.0, 22.0, 1.0e-5, 0.10]),
        np.log([7.0, 0.01, 0.15, 5.0e-4, 6.0, 23.0, 2.0e-5, 0.10]),
    ]
    lower = np.log([1.0e-4, 1.0e-6, 0.03, 1.0e-8,
                    1.0e-3, 1.0, 1.0e-10, 1.0e-3])
    upper = np.log([50.0, 10.0, 3.0, 10.0,
                    100.0, 100.0, 1.0, 0.5])
    best = None
    best_sse = np.inf
    for p0 in p0s:
        try:
            r = least_squares(
                lambda p: _log_model(x, p) - y,
                p0, bounds=(lower, upper),
                max_nfev=1800, ftol=1e-9, xtol=1e-9
            )
            sse = float(np.sum(r.fun * r.fun))
            if np.isfinite(sse) and sse < best_sse:
                best_sse, best = sse, r.x
        except Exception:
            pass
    if best is None:
        best = p0s[0]
    q = np.exp(best)
    return {
        "a": float(q[0]), "b": float(q[1]), "c": float(q[2]),
        "d": float(q[3]), "e": float(q[4]), "f": float(q[5]),
        "g": float(q[6]), "h": float(q[7])
    }

def predict(X, a, b, c, d, e, f, g, h):
    q = np.array([a, b, c, d, e, f, g, h], dtype=float)
    q = np.maximum(q, 1.0e-12)
    out = _log_model(np.asarray(X[:, 0], dtype=float), np.log(q))
    return np.asarray(out, dtype=float)