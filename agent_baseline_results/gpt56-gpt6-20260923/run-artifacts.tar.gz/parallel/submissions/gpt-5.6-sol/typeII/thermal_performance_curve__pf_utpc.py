"""Sharpe-Schoolfield thermal performance curve with cluster-specific scale,
activation energy, high-temperature deactivation energy, and deactivation
temperature."""
import numpy as np
from scipy.optimize import least_squares

USED_INPUTS = ["temperature"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {
    "P25": {"init": None},
    "Ea": {"init": None},
    "Eh": {"init": None},
    "Th": {"init": None},
}

_k = 8.617333262145e-5
_TREF = 25.0 + 273.15

def _curve(T, P25, Ea, Eh, Th):
    Tk = np.asarray(T, dtype=float) + 273.15
    ThK = Th + 273.15
    a = Ea / _k * (1.0 / _TREF - 1.0 / Tk)
    h_ref = Eh / _k * (1.0 / ThK - 1.0 / _TREF)
    h = Eh / _k * (1.0 / ThK - 1.0 / Tk)
    a = np.clip(a, -700.0, 700.0)
    h_ref = np.clip(h_ref, -700.0, 700.0)
    h = np.clip(h, -700.0, 700.0)
    return P25 * np.exp(a) * (1.0 + np.exp(h_ref)) / (1.0 + np.exp(h))

def fit(X_fit, y_fit):
    T = np.asarray(X_fit[:, 0], dtype=float)
    y = np.maximum(np.asarray(y_fit, dtype=float), np.finfo(float).tiny)
    scale = float(np.median(y))
    tmin = float(np.min(T))
    tmax = float(np.max(T))
    trange = max(tmax - tmin, 1.0)
    imax = int(np.argmax(y))
    th0 = float(T[imax] + 3.0)
    starts = [
        [scale, 0.6, 2.0, th0],
        [scale, 0.4, 5.0, tmax + 5.0],
        [scale, 1.0, 1.0, max(tmin + 2.0, th0)],
    ]
    lo = [np.finfo(float).tiny, 0.001, 0.01, tmin - 50.0]
    hi = [max(float(np.max(y)) * 1e8, scale * 1e8),
          10.0, 40.0, tmax + max(80.0, 5.0 * trange)]
    best = None
    best_cost = np.inf

    def residual(q):
        pred = np.maximum(_curve(T, *q), np.finfo(float).tiny)
        return np.clip(np.log(pred) - np.log(y), -100.0, 100.0)

    for p0 in starts:
        p0 = np.minimum(np.maximum(np.asarray(p0, dtype=float), np.asarray(lo) * 1.001), np.asarray(hi) * 0.999)
        try:
            z = least_squares(residual, p0, bounds=(lo, hi), max_nfev=2500)
            cost = float(np.mean(z.fun * z.fun))
            if np.isfinite(cost) and cost < best_cost:
                best_cost = cost
                best = z.x
        except Exception:
            pass

    if best is None:
        best = np.asarray(starts[0], dtype=float)
    return {
        "P25": float(max(best[0], np.finfo(float).tiny)),
        "Ea": float(max(best[1], 0.001)),
        "Eh": float(max(best[2], 0.01)),
        "Th": float(best[3]),
    }

def predict(X, P25, Ea, Eh, Th):
    return np.asarray(_curve(X[:, 0], P25, Ea, Eh, Th), dtype=float)