"""Planck blackbody spectral radiance with one cluster-specific effective temperature."""
import numpy as np
from scipy.optimize import least_squares

USED_INPUTS = ["wavelength_nm"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {"T": {"init": [5778.0]}}

def _planck(wavelength_nm, T):
    h = 6.62607015e-34
    c = 299792458.0
    k = 1.380649e-23
    lam = np.maximum(np.asarray(wavelength_nm, dtype=float), 1e-12) * 1e-9
    z = h * c / (lam * k * np.maximum(T, 1.0))
    z = np.minimum(z, 700.0)
    return 2.0 * h * c**2 / (lam**5 * np.expm1(z)) * 1e-9

def fit(X_fit, y_fit):
    wavelength = np.asarray(X_fit[:, 0], dtype=float)
    y = np.maximum(np.asarray(y_fit, dtype=float), 1e-12)
    try:
        def residual(q):
            T = float(q[0])
            return np.log(np.maximum(_planck(wavelength, T), 1e-12)) - np.log(y)
        result = least_squares(
            residual, np.array([5778.0]), bounds=(3000.0, 9000.0),
            loss="soft_l1", f_scale=0.08, max_nfev=100
        )
        T = float(np.clip(result.x[0], 3000.0, 9000.0))
    except Exception:
        T = 5778.0
    return {"T": T}

def predict(X, T):
    return np.asarray(_planck(X[:, 0], T), dtype=float)