"""Cluster-specific affine trend in calendar year."""
import numpy as np

USED_INPUTS = ["year"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {
    "level": {"init": None},
    "slope": {"init": None},
}

def fit(X_fit, y_fit):
    t = np.asarray(X_fit[:, 0], dtype=float)
    y = np.asarray(y_fit, dtype=float)
    tc = t - 2000.0
    A = np.column_stack((np.ones_like(tc), tc))
    try:
        coef, _, _, _ = np.linalg.lstsq(A, y, rcond=None)
        level = float(coef[0])
        slope = float(coef[1])
        if not np.isfinite(level) or not np.isfinite(slope):
            raise ValueError
    except Exception:
        level = float(np.nanmean(y)) if y.size else 0.0
        slope = 0.0
    return {"level": level, "slope": slope}

def predict(X, **params):
    t = np.asarray(X[:, 0], dtype=float)
    level = float(params["level"])
    slope = float(params["slope"])
    out = level + slope * (t - 2000.0)
    return np.asarray(np.nan_to_num(out, nan=0.0, posinf=1e6, neginf=-1e6), dtype=float)