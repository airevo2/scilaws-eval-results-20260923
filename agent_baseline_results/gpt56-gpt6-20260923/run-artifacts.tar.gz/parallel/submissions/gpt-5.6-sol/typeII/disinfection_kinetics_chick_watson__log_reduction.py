"""Two-parameter logarithmic dose-response: LRV rises as log10(1 + CT / K)."""
import numpy as np
from scipy.optimize import least_squares

USED_INPUTS = ["CT"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {
    "a": {"init": [1.0]},
    "K": {"init": [1.0]},
}

def _response(CT, a, K):
    CT = np.maximum(np.asarray(CT, dtype=float), 0.0)
    a = max(float(a), 1e-12)
    K = max(float(K), 1e-12)
    return a * np.log10(1.0 + CT / K)

def fit(X_fit, y_fit):
    CT = np.maximum(np.asarray(X_fit[:, 0], dtype=float), 0.0)
    y = np.maximum(np.asarray(y_fit, dtype=float), 0.0)
    scale = max(float(np.nanpercentile(y, 80)), 1e-3)
    k0 = max(float(np.nanmedian(CT)), 1e-6)
    q0 = np.log([scale, k0])

    def residual(q):
        return _response(CT, np.exp(q[0]), np.exp(q[1])) - y

    try:
        result = least_squares(
            residual,
            q0,
            bounds=(np.log([1e-8, 1e-10]), np.log([1e4, 1e8])),
            max_nfev=2000,
        )
        a, K = np.exp(result.x)
    except Exception:
        a, K = scale, k0

    return {"a": float(a), "K": float(K)}

def predict(X, a, K):
    return np.asarray(_response(X[:, 0], a, K), dtype=float)