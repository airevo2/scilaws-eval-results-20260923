"""Four-parameter van Genuchten-Mualem soil-water retention curve."""
import numpy as np
from scipy.optimize import least_squares

USED_INPUTS = ["lab_head_m"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {
    "theta_r": {"init": None},
    "theta_s": {"init": None},
    "alpha": {"init": None},
    "n": {"init": None},
}

def _curve(h, theta_r, theta_s, alpha, n):
    h = np.maximum(np.asarray(h, dtype=float), 1e-12)
    alpha = max(float(alpha), 1e-12)
    n = max(float(n), 1.000001)
    z = n * (np.log(alpha) + np.log(h))
    log_term = np.logaddexp(0.0, z)
    effective = np.exp(-(1.0 - 1.0 / n) * log_term)
    return theta_r + (theta_s - theta_r) * effective

def fit(X_fit, y_fit):
    h = np.maximum(np.asarray(X_fit[:, 0], dtype=float), 1e-12)
    y = np.asarray(y_fit, dtype=float)
    keep = np.isfinite(h) & np.isfinite(y)
    h, y = h[keep], y[keep]

    if len(y) == 0:
        return {"theta_r": 0.05, "theta_s": 0.5, "alpha": 1.0, "n": 1.5}

    lo_y = float(np.min(y))
    hi_y = float(np.max(y))
    theta_r0 = float(np.clip(0.5 * lo_y, 0.0, 0.95))
    theta_s0 = float(np.clip(max(hi_y * 1.05, theta_r0 + 0.01), 0.01, 1.0))
    alpha0 = float(np.clip(1.0 / np.sqrt(np.min(h) * np.max(h)), 1e-6, 1e4))
    p0 = np.array([theta_r0, theta_s0, alpha0, 1.5])

    def residual(p):
        pred = _curve(h, p[0], p[1], p[2], p[3])
        ordering = max(0.0, p[0] - p[1])
        return np.r_[pred - y, 10.0 * ordering]

    try:
        result = least_squares(
            residual,
            p0,
            bounds=([0.0, 0.0, 1e-8, 1.000001], [1.0, 1.0, 1e5, 20.0]),
            max_nfev=2000,
            x_scale="jac",
        )
        p = result.x
        if not np.all(np.isfinite(p)):
            raise ValueError
        return {
            "theta_r": float(p[0]),
            "theta_s": float(max(p[1], p[0])),
            "alpha": float(p[2]),
            "n": float(p[3]),
        }
    except Exception:
        return {
            "theta_r": theta_r0,
            "theta_s": theta_s0,
            "alpha": alpha0,
            "n": 1.5,
        }

def predict(X, theta_r, theta_s, alpha, n):
    return np.asarray(
        _curve(X[:, 0], theta_r, theta_s, alpha, n),
        dtype=float,
    )