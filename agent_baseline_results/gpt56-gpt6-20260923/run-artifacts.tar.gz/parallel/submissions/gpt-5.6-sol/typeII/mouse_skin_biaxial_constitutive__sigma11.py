"""Separable biaxial exponential stiffening law with cluster-specific baseline, directional amplitudes, and directional curvature parameters."""
import numpy as np
from scipy.optimize import least_squares

USED_INPUTS = ["lambda11", "lambda22"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {
    "c": {"init": 0.0},
    "A": {"init": 0.01},
    "k": {"init": 5.0},
    "B": {"init": 0.005},
    "h": {"init": 5.0},
}

def _value(X, p):
    e1 = X[:, 0] - 1.0
    e2 = X[:, 1] - 1.0
    c, A, k, B, h = p
    q1 = np.clip(k * e1 * e1, -40.0, 40.0)
    q2 = np.clip(h * e2 * e2, -40.0, 40.0)
    return c + A * e1 * np.exp(q1) + B * e2 * np.exp(q2)

def fit(X_fit, y_fit):
    y = np.asarray(y_fit, dtype=float)
    scale = max(float(np.percentile(np.abs(y), 80)), 1e-4)
    p0 = np.array([float(np.median(y)), scale, 5.0, scale, 5.0])
    lo = np.array([-0.2, -2.0, -100.0, -2.0, -100.0])
    hi = np.array([0.2, 2.0, 100.0, 2.0, 100.0])
    try:
        r = least_squares(
            lambda p: _value(X_fit, p) - y,
            p0, bounds=(lo, hi), max_nfev=2500
        )
        p = r.x
    except Exception:
        p = p0
    return {"c": float(p[0]), "A": float(p[1]), "k": float(p[2]),
            "B": float(p[3]), "h": float(p[4])}

def predict(X, **params):
    p = [params["c"], params["A"], params["k"], params["B"], params["h"]]
    return np.asarray(_value(X, p), dtype=float)