"""Stochastic intertemporal choice from the difference between hyperbolically discounted rewards."""
import numpy as np
from scipy.optimize import least_squares

USED_INPUTS = ["ss_time_days", "ll_time_days", "ss_value", "ll_value"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {
    "discount_rate": {"init": [0.01]},
    "choice_sensitivity": {"init": [1.0]},
}

def _utility_difference(X, discount_rate):
    t_ss = np.maximum(np.asarray(X[:, 0], dtype=float), 0.0)
    t_ll = np.maximum(np.asarray(X[:, 1], dtype=float), 0.0)
    v_ss = np.maximum(np.asarray(X[:, 2], dtype=float), 0.0)
    v_ll = np.maximum(np.asarray(X[:, 3], dtype=float), 0.0)
    u_ss = v_ss / (1.0 + discount_rate * t_ss)
    u_ll = v_ll / (1.0 + discount_rate * t_ll)
    return u_ll - u_ss

def _sigmoid(z):
    z = np.clip(z, -50.0, 50.0)
    return 1.0 / (1.0 + np.exp(-z))

def fit(X_fit, y_fit):
    y = np.asarray(y_fit, dtype=float)
    y = np.clip(y, 1e-5, 1.0 - 1e-5)
    d0, s0 = 0.01, 1.0

    def residual(q):
        discount_rate = np.exp(q[0])
        choice_sensitivity = np.exp(q[1])
        z = choice_sensitivity * _utility_difference(X_fit, discount_rate)
        return _sigmoid(z) - y

    try:
        sol = least_squares(
            residual,
            np.log([d0, s0]),
            bounds=(np.log([1e-9, 1e-6]), np.log([1e3, 1e3])),
            max_nfev=400
        )
        discount_rate, choice_sensitivity = np.exp(sol.x)
        return {
            "discount_rate": float(discount_rate),
            "choice_sensitivity": float(choice_sensitivity),
        }
    except Exception:
        return {
            "discount_rate": float(d0),
            "choice_sensitivity": float(s0),
        }

def predict(X, discount_rate, choice_sensitivity):
    return _sigmoid(
        choice_sensitivity * _utility_difference(X, discount_rate)
    )