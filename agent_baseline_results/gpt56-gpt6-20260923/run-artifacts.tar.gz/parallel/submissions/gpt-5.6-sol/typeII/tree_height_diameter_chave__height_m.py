"""Pantropical tree height follows a cluster-scaled square-root diameter allometry."""
import numpy as np

USED_INPUTS = ["DBH_cm"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {"a": {"init": None}}

_EXPONENT = 0.5

def fit(X_fit, y_fit):
    D = np.maximum(np.asarray(X_fit[:, 0], dtype=float), 1e-12)
    y = np.asarray(y_fit, dtype=float)
    basis = D ** _EXPONENT
    denom = float(np.dot(basis, basis))
    if not np.isfinite(denom) or denom <= 0.0:
        return {"a": 1.0}
    a = float(np.dot(basis, y) / denom)
    if not np.isfinite(a):
        a = 1.0
    return {"a": max(a, 0.0)}

def predict(X, **params):
    D = np.maximum(np.asarray(X[:, 0], dtype=float), 1e-12)
    a = float(params.get("a", 1.0))
    return a * D ** _EXPONENT