"""Three-parameter Sips (Langmuir-Freundlich) adsorption isotherm."""
import numpy as np
from scipy.optimize import least_squares

USED_INPUTS = ["P_bar"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {
    "n_s": {"init": None},
    "K": {"init": None},
    "m": {"init": None},
}

def _sips(P, n_s, K, m):
    P = np.maximum(np.asarray(P, dtype=float), 0.0)
    z = np.maximum(K * P, 0.0)
    zm = np.power(z, m)
    return n_s * zm / (1.0 + zm)

def fit(X_fit, y_fit):
    P = np.maximum(np.asarray(X_fit[:, 0], dtype=float), 0.0)
    y = np.maximum(np.asarray(y_fit, dtype=float), 0.0)
    ymax = max(float(np.max(y)), 1e-8)
    scale = max(float(np.std(y)), 1e-3)

    n0 = max(1.2 * ymax, 1e-6)
    m0 = 0.7
    positive = P > 0
    if np.any(positive):
        K0 = np.median(
            np.maximum(P[positive], 1e-12) ** (-m0)
            * np.maximum(y[positive], 1e-12) / np.maximum(n0 - y[positive], 1e-12)
        )
    else:
        K0 = 1.0
    K0 = float(np.clip(K0, 1e-8, 1e8))

    q0 = np.log([n0, K0, m0])

    def residual(q):
        n_s, K, m = np.exp(q)
        return (_sips(P, n_s, K, m) - y) / scale

    try:
        result = least_squares(
            residual,
            q0,
            bounds=(
                np.log([1e-10, 1e-10, 0.05]),
                np.log([1e8, 1e8, 10.0]),
            ),
            max_nfev=2000,
        )
        n_s, K, m = np.exp(result.x)
        return {"n_s": float(n_s), "K": float(K), "m": float(m)}
    except Exception:
        return {"n_s": float(n0), "K": float(K0), "m": float(m0)}

def predict(X, **params):
    return _sips(
        X[:, 0],
        float(params["n_s"]),
        float(params["K"]),
        float(params["m"]),
    )