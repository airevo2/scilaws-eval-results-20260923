"""Penman–Monteith latent heat flux with a light- and vapour-deficit-regulated canopy conductance."""
import numpy as np
from scipy.optimize import least_squares

USED_INPUTS = ["SWdown", "VPD", "RH", "Rnet", "Qg", "Ga", "delta", "theta_FC"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {
    "gmax": {"init": None},
    "k_light": {"init": None},
    "k_vpd": {"init": None},
    "rh_exp": {"init": None},
}

def _predict_core(X, gmax, k_light, k_vpd, rh_exp):
    sw = np.maximum(X[:, 0], 0.0)
    vpd = np.maximum(X[:, 1], 0.0)
    rh = np.clip(X[:, 2], 1.e-4, 1.0)
    rnet = X[:, 3]
    qg = X[:, 4]
    ga = np.maximum(X[:, 5], 1.e-7)
    delta = np.maximum(X[:, 6], 1.e-7)
    theta = np.maximum(X[:, 7], 1.e-5)

    gmax = max(float(gmax), 1.e-7)
    k_light = max(float(k_light), 1.e-5)
    k_vpd = max(float(k_vpd), 1.e-5)
    rh_exp = max(float(rh_exp), 0.0)

    gc = (gmax * sw / (sw + k_light) *
          np.exp(-vpd / k_vpd) *
          np.power(rh, rh_exp) *
          theta / (theta + 0.20))

    # gamma and the lumped rho*cp conversion are represented in the
    # conductance-scaled aerodynamic term.
    gamma = 0.066
    aero = 1200.0 * ga * vpd
    available = rnet - qg
    den = delta + gamma * (1.0 + ga / np.maximum(gc, 1.e-8))
    out = (delta * available + aero) / np.maximum(den, 1.e-8)
    return np.nan_to_num(out, nan=0.0, posinf=1.e6, neginf=-1.e6)

def fit(X_fit, y_fit):
    y = np.asarray(y_fit, dtype=float)
    sw = np.maximum(X_fit[:, 0], 0.0)
    scale = max(float(np.nanpercentile(np.abs(y), 90)), 50.0)
    p0 = np.array([0.01, max(np.nanmedian(sw), 100.0), 1.5, 0.5], dtype=float)
    lo = np.array([1.e-5, 1.e-3, 0.03, 0.0])
    hi = np.array([2.0, 2.e4, 100.0, 5.0])

    def resid(z):
        return (_predict_core(X_fit, *z) - y) / scale

    try:
        sol = least_squares(
            resid, p0, bounds=(lo, hi), max_nfev=350,
            loss="soft_l1", f_scale=1.0
        )
        z = np.clip(sol.x, lo, hi)
    except Exception:
        z = p0
    return {
        "gmax": float(z[0]),
        "k_light": float(z[1]),
        "k_vpd": float(z[2]),
        "rh_exp": float(z[3]),
    }

def predict(X, **params):
    return _predict_core(
        X,
        params["gmax"],
        params["k_light"],
        params["k_vpd"],
        params["rh_exp"],
    )