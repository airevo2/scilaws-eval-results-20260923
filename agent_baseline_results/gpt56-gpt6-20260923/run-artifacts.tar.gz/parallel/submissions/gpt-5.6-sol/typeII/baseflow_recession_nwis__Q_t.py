"""Nonlinear power-law reservoir recession: dQ/dt = -a Q^b."""
import numpy as np
from scipy.optimize import least_squares

USED_INPUTS = ["t", "Q_0"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {
    "a": {"init": None},
    "b": {"init": None},
}

def _form(t, q0, a, b):
    t = np.asarray(t, dtype=float)
    q0 = np.maximum(np.asarray(q0, dtype=float), 1e-12)
    if abs(b - 1.0) < 1e-7:
        return q0 * np.exp(-a * t)
    z = q0 ** (1.0 - b) - (1.0 - b) * a * t
    # A finite continuation prevents numerical failures after exhaustion.
    z = np.maximum(z, 1e-12)
    return z ** (1.0 / (1.0 - b))

def fit(X_fit, y_fit):
    t = np.asarray(X_fit[:, 0], dtype=float)
    q0 = np.maximum(np.asarray(X_fit[:, 1], dtype=float), 1e-12)
    y = np.maximum(np.asarray(y_fit, dtype=float), 1e-12)

    def residual(p):
        yp = _form(t, q0, p[0], p[1])
        return (yp - y) / np.maximum(q0, 1.0)

    # The scale of a is naturally small for discharge units of ft3/s.
    p0 = np.array([0.005, 1.3], dtype=float)
    try:
        r = least_squares(
            residual, p0, bounds=([1e-12, -2.0], [10.0, 3.0]),
            x_scale="jac", loss="soft_l1", max_nfev=1500
        )
        a, b = r.x
        if not (np.isfinite(a) and np.isfinite(b)):
            return {"a": 0.005, "b": 1.3}
        return {"a": float(a), "b": float(b)}
    except Exception:
        return {"a": 0.005, "b": 1.3}

def predict(X, **params):
    return _form(X[:, 0], X[:, 1], params["a"], params["b"])