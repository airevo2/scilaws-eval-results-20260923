"""Circular Gaussian orientation-tuning curve with cluster-specific baseline, amplitude, preferred orientation, and tuning width."""
import numpy as np
from scipy.optimize import least_squares

USED_INPUTS = ["orientation_deg"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {
    "baseline": {"init": None},
    "amplitude": {"init": None},
    "preferred_deg": {"init": None},
    "width_deg": {"init": None},
}

def _circular_distance(theta, preferred):
    return np.abs((theta - preferred + 90.0) % 180.0 - 90.0)

def _form(theta, baseline, amplitude, preferred_deg, width_deg):
    d = _circular_distance(theta, preferred_deg)
    width = np.maximum(np.abs(width_deg), 1e-6)
    return baseline + amplitude * np.exp(-0.5 * (d / width) ** 2)

def fit(X_fit, y_fit):
    theta = np.asarray(X_fit[:, 0], dtype=float)
    y = np.asarray(y_fit, dtype=float)
    finite = np.isfinite(theta) & np.isfinite(y)
    theta, y = theta[finite], y[finite]

    if len(y) == 0:
        return {
            "baseline": 0.0,
            "amplitude": 1.0,
            "preferred_deg": 0.0,
            "width_deg": 20.0,
        }

    ymin = float(np.min(y))
    ymax = float(np.max(y))
    spread = max(ymax - ymin, 1e-6)
    baseline0 = float(np.median(y))
    amplitude0 = spread
    preferred0 = float(theta[np.argmax(y)])
    starts = [
        [baseline0, amplitude0, preferred0, 10.0],
        [ymin, spread, preferred0, 15.0],
        [0.0, spread, preferred0, 30.0],
    ]

    def residual(p):
        return _form(theta, p[0], p[1], p[2], p[3]) - y

    best = None
    best_cost = np.inf
    for p0 in starts:
        try:
            result = least_squares(
                residual,
                p0,
                bounds=([-np.inf, 0.0, -360.0, 0.5],
                        [np.inf, np.inf, 360.0, 100.0]),
                max_nfev=2000,
            )
            if np.all(np.isfinite(result.x)) and result.cost < best_cost:
                best = result.x
                best_cost = result.cost
        except Exception:
            pass

    if best is None:
        best = np.asarray(starts[0], dtype=float)

    return {
        "baseline": float(best[0]),
        "amplitude": float(best[1]),
        "preferred_deg": float(best[2] % 180.0),
        "width_deg": float(max(best[3], 0.5)),
    }

def predict(X, **params):
    theta = np.asarray(X[:, 0], dtype=float)
    result = _form(
        theta,
        params["baseline"],
        params["amplitude"],
        params["preferred_deg"],
        params["width_deg"],
    )
    return np.asarray(result, dtype=float)