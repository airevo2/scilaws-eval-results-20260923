"""Cluster-specific log-linear production law in capital intensity and human capital:
log(Y/L) = a + alpha*log(cn/emp) + beta*log(hc)."""
import numpy as np

USED_INPUTS = ["cn", "emp", "hc"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {
    "a": {"init": None},
    "alpha": {"init": None},
    "beta": {"init": None},
}

def fit(X_fit, y_fit):
    X_fit = np.asarray(X_fit, dtype=float)
    y_fit = np.asarray(y_fit, dtype=float).reshape(-1)

    cn = np.maximum(X_fit[:, 0], np.finfo(float).tiny)
    emp = np.maximum(X_fit[:, 1], np.finfo(float).tiny)
    hc = np.maximum(X_fit[:, 2], np.finfo(float).tiny)

    design = np.column_stack((
        np.ones(X_fit.shape[0]),
        np.log(cn / emp),
        np.log(hc),
    ))

    try:
        coef, _, _, _ = np.linalg.lstsq(design, y_fit, rcond=None)
        coef = np.nan_to_num(coef, nan=0.0, posinf=0.0, neginf=0.0)
        return {
            "a": float(coef[0]),
            "alpha": float(coef[1]),
            "beta": float(coef[2]),
        }
    except Exception:
        return {"a": 0.0, "alpha": 0.5, "beta": 0.0}

def predict(X, **params):
    X = np.asarray(X, dtype=float)
    cn = np.maximum(X[:, 0], np.finfo(float).tiny)
    emp = np.maximum(X[:, 1], np.finfo(float).tiny)
    hc = np.maximum(X[:, 2], np.finfo(float).tiny)

    a = float(params.get("a", 0.0))
    alpha = float(params.get("alpha", 0.5))
    beta = float(params.get("beta", 0.0))

    pred = a + alpha * np.log(cn / emp) + beta * np.log(hc)
    return np.nan_to_num(pred, nan=0.0, posinf=1e100, neginf=-1e100)