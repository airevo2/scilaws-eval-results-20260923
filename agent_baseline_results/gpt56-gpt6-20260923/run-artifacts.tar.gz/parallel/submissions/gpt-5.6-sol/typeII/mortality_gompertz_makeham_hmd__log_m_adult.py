"""Cluster-specific quadratic age law for log central adult mortality."""
import numpy as np

USED_INPUTS = ["age"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {
    "a": {"init": None},
    "b": {"init": None},
    "c": {"init": None},
}

def fit(X_fit, y_fit):
    x = np.asarray(X_fit[:, 0], dtype=float)
    y = np.asarray(y_fit, dtype=float)
    A = np.column_stack((np.ones_like(x), x, x * x))
    try:
        coef, _, _, _ = np.linalg.lstsq(A, y, rcond=None)
        if not np.all(np.isfinite(coef)):
            raise ValueError("non-finite fit")
        return {"a": float(coef[0]), "b": float(coef[1]), "c": float(coef[2])}
    except Exception:
        return {"a": float(np.mean(y)) if y.size else 0.0, "b": 0.0, "c": 0.0}

def predict(X, a, b, c):
    x = np.asarray(X[:, 0], dtype=float)
    out = a + b * x + c * x * x
    return np.asarray(out, dtype=float)