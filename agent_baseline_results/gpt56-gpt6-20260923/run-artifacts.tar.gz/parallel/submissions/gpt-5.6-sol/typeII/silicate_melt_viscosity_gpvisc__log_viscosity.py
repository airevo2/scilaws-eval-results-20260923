"""Vogel–Fulcher–Tammann temperature dependence of silicate-melt viscosity."""
import numpy as np
from scipy.optimize import least_squares

USED_INPUTS = ["T"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {
    "A": {"init": None},
    "B": {"init": None},
    "T0": {"init": None},
}

def _vft(T, A, B, T0):
    return A + B / (T - T0)

def fit(X_fit, y_fit):
    T = np.asarray(X_fit[:, 0], dtype=float)
    y = np.asarray(y_fit, dtype=float)
    good = np.isfinite(T) & np.isfinite(y)
    T, y = T[good], y[good]
    if len(T) == 0:
        return {"A": 0.0, "B": 10000.0, "T0": 500.0}

    Tmin = float(np.min(T))
    Tmax = float(np.max(T))
    span = max(Tmax - Tmin, 1.0)
    # Select a stable starting T0 by variable projection over a modest grid.
    upper = Tmin - max(1e-3, 1e-5 * span)
    lower = Tmin - max(5000.0, 20.0 * span)
    grid = np.linspace(lower, upper, 80)
    best = None
    for t0 in grid:
        z = 1.0 / (T - t0)
        M = np.column_stack((np.ones_like(T), z))
        ab, _, _, _ = np.linalg.lstsq(M, y, rcond=None)
        err = np.mean((M @ ab - y) ** 2)
        if best is None or err < best[0]:
            best = (err, float(ab[0]), float(ab[1]), float(t0))

    p0 = np.array([best[1], best[2], best[3]], dtype=float)
    lo = np.array([-100.0, -1.0e7, lower], dtype=float)
    hi = np.array([100.0, 1.0e7, upper], dtype=float)
    try:
        r = least_squares(
            lambda p: _vft(T, p[0], p[1], p[2]) - y,
            np.clip(p0, lo + 1e-10, hi - 1e-10),
            bounds=(lo, hi),
            loss="soft_l1",
            f_scale=max(0.02, float(np.std(y)) * 0.5),
            max_nfev=2500,
        )
        p = r.x if np.all(np.isfinite(r.x)) else p0
    except Exception:
        p = p0
    return {"A": float(p[0]), "B": float(p[1]), "T0": float(p[2])}

def predict(X, A, B, T0):
    T = np.asarray(X[:, 0], dtype=float)
    den = T - float(T0)
    den = np.where(np.abs(den) < 1e-8, np.where(den >= 0, 1e-8, -1e-8), den)
    out = float(A) + float(B) / den
    return np.nan_to_num(out, nan=0.0, posinf=1e6, neginf=-1e6)