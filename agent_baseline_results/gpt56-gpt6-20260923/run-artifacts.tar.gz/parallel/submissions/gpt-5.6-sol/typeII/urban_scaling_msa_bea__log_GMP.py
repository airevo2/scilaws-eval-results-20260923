"""Cluster-specific urban scaling law: log GMP is affine in log population."""
import numpy as np

USED_INPUTS = ["log_pop"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {
    "intercept": {"init": None},
    "exponent": {"init": None},
}

def fit(X_fit, y_fit):
    x = np.asarray(X_fit[:, 0], dtype=float)
    y = np.asarray(y_fit, dtype=float)
    mask = np.isfinite(x) & np.isfinite(y)
    x = x[mask]
    y = y[mask]
    if len(x) < 2 or np.ptp(x) <= 1e-12:
        return {
            "intercept": float(np.mean(y)) if len(y) else 0.0,
            "exponent": 1.0,
        }
    A = np.column_stack((np.ones(len(x)), x))
    try:
        coef = np.linalg.lstsq(A, y, rcond=None)[0]
        if not np.all(np.isfinite(coef)):
            raise ValueError
        return {"intercept": float(coef[0]), "exponent": float(coef[1])}
    except Exception:
        return {
            "intercept": float(np.mean(y) - np.mean(x)),
            "exponent": 1.0,
        }

def predict(X, **params):
    x = np.asarray(X[:, 0], dtype=float)
    return params["intercept"] + params["exponent"] * x