"""Discrete epidemic growth: susceptible-scaled, seasonally modulated transmission with additive introductions, expressed as the offset-log case growth."""
import numpy as np
from scipy.optimize import least_squares

USED_INPUTS = ["cases_prev", "biweek", "z_t"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {
    "beta": {"init": None},
    "mu": {"init": None},
    "season_amp": {"init": None},
    "season_phase": {"init": None},
}

def _predict_core(X, beta, mu, season_amp, season_phase):
    I = np.maximum(np.asarray(X[:, 0], dtype=float), 0.0)
    s = np.asarray(X[:, 1], dtype=float)
    z = np.maximum(np.asarray(X[:, 2], dtype=float), 0.0)

    # Positive seasonal multiplier; phase is measured in 2-week intervals.
    seasonal = np.exp(
        season_amp * np.cos(2.0 * np.pi * (s - season_phase) / 26.0)
    )
    expected_next = mu + beta * z * seasonal * I
    expected_next = np.maximum(expected_next, 0.0)
    return np.log1p(expected_next) - np.log1p(I)

def fit(X_fit, y_fit):
    X = np.asarray(X_fit, dtype=float)
    y = np.asarray(y_fit, dtype=float)
    I = np.maximum(X[:, 0], 0.0)
    z = np.maximum(X[:, 2], 0.0)

    # Log-parameters enforce positive transmission and introduction rates.
    zscale = max(float(np.median(z[z > 0])) if np.any(z > 0) else 1.0, 1.0)
    iscale = max(float(np.median(I[I > 0])) if np.any(I > 0) else 1.0, 1.0)
    b0 = max(0.5 / zscale, 1e-10)
    m0 = max(float(np.expm1(np.clip(np.median(y[I < 1]) if np.any(I < 1)
                                   else np.median(y), -5, 3))), 1e-5)

    def residual(q):
        beta = np.exp(np.clip(q[0], -40, 20))
        mu = np.exp(np.clip(q[1], -20, 10))
        amp = q[2]
        phase = q[3]
        pred = _predict_core(X, beta, mu, amp, phase)
        return np.nan_to_num(pred - y, nan=0.0, posinf=20.0, neginf=-20.0)

    q0 = np.array([np.log(b0), np.log(m0), 0.3, 2.0], dtype=float)
    try:
        sol = least_squares(
            residual, q0,
            bounds=([-40.0, -20.0, -3.0, -26.0],
                    [20.0, 10.0, 3.0, 52.0]),
            max_nfev=1200
        )
        q = sol.x
        return {
            "beta": float(np.exp(np.clip(q[0], -40, 20))),
            "mu": float(np.exp(np.clip(q[1], -20, 10))),
            "season_amp": float(q[2]),
            "season_phase": float(q[3]),
        }
    except Exception:
        return {
            "beta": float(b0),
            "mu": float(m0),
            "season_amp": 0.0,
            "season_phase": 2.0,
        }

def predict(X, beta, mu, season_amp, season_phase):
    out = _predict_core(X, beta, mu, season_amp, season_phase)
    return np.nan_to_num(out, nan=0.0, posinf=50.0, neginf=-50.0)