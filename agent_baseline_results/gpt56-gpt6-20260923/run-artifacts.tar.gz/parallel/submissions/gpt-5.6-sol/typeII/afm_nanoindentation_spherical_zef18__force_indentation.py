"""Hertz spherical-contact law with one cluster-specific effective modulus."""
import numpy as np

USED_INPUTS = ["indentation_m", "R_m"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {"E_star": {"init": [1000.0]}}

def fit(X_fit, y_fit):
    delta = np.maximum(np.asarray(X_fit[:, 0], dtype=float), 0.0)
    radius = np.maximum(np.asarray(X_fit[:, 1], dtype=float), 0.0)
    y = np.asarray(y_fit, dtype=float)
    q = (4.0 / 3.0) * np.sqrt(radius) * delta ** 1.5
    valid = np.isfinite(q) & np.isfinite(y) & (q > 0.0)
    if not np.any(valid):
        return {"E_star": 1000.0}
    qv = q[valid]
    yv = y[valid]
    # Emphasize the high-force regime, where the additive measurement floor
    # is negligible, while retaining a one-parameter linear fit.
    cutoff = np.quantile(qv, 0.5)
    use = qv >= cutoff
    denom = float(np.dot(qv[use], qv[use]))
    if denom <= 0.0 or not np.isfinite(denom):
        return {"E_star": 1000.0}
    E_star = float(np.dot(qv[use], yv[use]) / denom)
    if not np.isfinite(E_star):
        E_star = 1000.0
    return {"E_star": max(E_star, 0.0)}

def predict(X, E_star):
    delta = np.maximum(np.asarray(X[:, 0], dtype=float), 0.0)
    radius = np.maximum(np.asarray(X[:, 1], dtype=float), 0.0)
    return E_star * (4.0 / 3.0) * np.sqrt(radius) * delta ** 1.5