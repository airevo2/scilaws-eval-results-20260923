"""Cluster-specific hydraulic-geometry power law: channel width scales as a fitted coefficient times discharge raised to a fitted exponent."""
import numpy as np

USED_INPUTS = ["chan_discharge"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {
    "a": {"init": 1.0},
    "b": {"init": 0.5},
}

def fit(X_fit, y_fit):
    Q = np.asarray(X_fit[:, 0], dtype=float)
    w = np.asarray(y_fit, dtype=float)
    mask = np.isfinite(Q) & np.isfinite(w) & (Q > 0.0) & (w > 0.0)
    if np.count_nonzero(mask) < 2:
        return {"a": 1.0, "b": 0.5}
    x = np.log(Q[mask])
    z = np.log(w[mask])
    A = np.column_stack((np.ones_like(x), x))
    try:
        beta = np.linalg.lstsq(A, z, rcond=None)[0]
        log_a = float(np.clip(beta[0], -700.0, 700.0))
        b = float(np.clip(beta[1], -10.0, 10.0))
        a = float(np.exp(log_a))
        if not np.isfinite(a) or not np.isfinite(b) or a <= 0.0:
            return {"a": 1.0, "b": 0.5}
        return {"a": a, "b": b}
    except Exception:
        return {"a": 1.0, "b": 0.5}

def predict(X, **params):
    Q = np.maximum(np.asarray(X[:, 0], dtype=float), np.finfo(float).tiny)
    a = float(params["a"])
    b = float(params["b"])
    y = a * np.power(Q, b)
    return np.nan_to_num(y, nan=0.0, posinf=np.finfo(float).max, neginf=0.0)