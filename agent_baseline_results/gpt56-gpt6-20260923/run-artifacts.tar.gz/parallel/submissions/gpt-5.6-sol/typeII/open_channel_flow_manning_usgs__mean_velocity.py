"""Manning open-channel resistance relation with a cluster-specific roughness."""
import numpy as np

USED_INPUTS = ["R_m", "SLOPE"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {"n": {"init": None}}

def fit(X_fit, y_fit):
    R = np.maximum(np.asarray(X_fit[:, 0], dtype=float), 1e-12)
    S = np.maximum(np.asarray(X_fit[:, 1], dtype=float), 0.0)
    y = np.asarray(y_fit, dtype=float)
    basis = np.sqrt(S) * np.power(R, 2.0 / 3.0)
    good = np.isfinite(basis) & np.isfinite(y) & (basis > 0)
    if not np.any(good):
        return {"n": 1.0}
    # Least-squares estimate for V = basis / n.
    b = basis[good]
    v = y[good]
    denom = float(np.dot(b, b))
    coeff = float(np.dot(b, v) / max(denom, 1e-30))
    if not np.isfinite(coeff) or coeff <= 0:
        coeff = float(np.median(v / np.maximum(b, 1e-30)))
    n = 1.0 / max(coeff, 1e-12)
    return {"n": float(n)}

def predict(X, **params):
    R = np.maximum(np.asarray(X[:, 0], dtype=float), 1e-12)
    S = np.maximum(np.asarray(X[:, 1], dtype=float), 0.0)
    n = max(float(params["n"]), 1e-12)
    return np.sqrt(S) * np.power(R, 2.0 / 3.0) / n