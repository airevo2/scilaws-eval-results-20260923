"""Four-parameter non-rectangular hyperbola light-response curve with dark respiration."""
import numpy as np
from scipy.optimize import least_squares

USED_INPUTS = ["Qin"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {
    "Amax": {"init": None},
    "alpha": {"init": None},
    "theta": {"init": None},
    "Rd": {"init": None},
}

def _model(Q, Amax, alpha, theta, Rd):
    Q = np.maximum(np.asarray(Q, dtype=float), 0.0)
    z = Amax + alpha * Q
    disc = np.maximum(
        z * z - 4.0 * theta * Amax * alpha * Q,
        0.0,
    )
    gross = (z - np.sqrt(disc)) / (2.0 * theta)
    return gross - Rd

def fit(X_fit, y_fit):
    Q = np.maximum(np.asarray(X_fit[:, 0], dtype=float), 0.0)
    y = np.asarray(y_fit, dtype=float)

    order = np.argsort(Q)
    qs = Q[order]
    ys = y[order]

    Rd0 = float(np.clip(max(0.0, -ys[0]), 0.01, 10.0))
    Amax0 = float(np.clip(max(0.5, np.max(y) + Rd0), 0.1, 100.0))

    if len(qs) > 1 and qs[1] > qs[0]:
        alpha0 = (ys[1] - ys[0]) / (qs[1] - qs[0])
    else:
        alpha0 = 0.03
    alpha0 = float(np.clip(alpha0, 1e-4, 2.0))

    p0 = np.array([Amax0, alpha0, 0.7, Rd0], dtype=float)
    lower = np.array([0.01, 1e-7, 1e-3, 0.0])
    upper = np.array([100.0, 5.0, 0.9999, 20.0])

    try:
        result = least_squares(
            lambda p: _model(Q, p[0], p[1], p[2], p[3]) - y,
            p0,
            bounds=(lower, upper),
            max_nfev=2000,
        )
        p = result.x if np.all(np.isfinite(result.x)) else p0
    except Exception:
        p = p0

    return {
        "Amax": float(p[0]),
        "alpha": float(p[1]),
        "theta": float(p[2]),
        "Rd": float(p[3]),
    }

def predict(X, **params):
    return _model(
        X[:, 0],
        params["Amax"],
        params["alpha"],
        params["theta"],
        params["Rd"],
    )