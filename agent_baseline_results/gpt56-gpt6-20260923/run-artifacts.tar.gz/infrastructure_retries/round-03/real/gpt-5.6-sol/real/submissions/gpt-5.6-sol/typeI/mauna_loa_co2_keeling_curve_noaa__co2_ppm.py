"""Exponential long-term growth with annual and semiannual seasonal harmonics."""
import numpy as np

USED_INPUTS = ["year_decimal", "month"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    t = X[:, 0]
    m = X[:, 1]
    z = t - 2000.0
    q = 2.0 * np.pi * (m - 1.0) / 12.0
    return (
        256.609959
        + 112.58658938 * np.exp(0.016276121328376487 * z)
        + 2.81542868 * np.sin(q)
        - 0.29160692 * np.cos(q)
        - 0.70919090 * np.sin(2.0 * q)
        + 0.35399499 * np.cos(2.0 * q)
    )