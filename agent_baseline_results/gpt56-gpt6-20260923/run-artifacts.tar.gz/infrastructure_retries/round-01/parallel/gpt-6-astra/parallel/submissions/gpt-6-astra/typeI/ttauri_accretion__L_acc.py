"""Accretion luminosity follows a power law in stellar luminosity, linear in base-10 logs."""
import numpy as np

USED_INPUTS = ["logL_star"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    return 1.5894927499070877 * X[:, 0] - 1.2360600184216528