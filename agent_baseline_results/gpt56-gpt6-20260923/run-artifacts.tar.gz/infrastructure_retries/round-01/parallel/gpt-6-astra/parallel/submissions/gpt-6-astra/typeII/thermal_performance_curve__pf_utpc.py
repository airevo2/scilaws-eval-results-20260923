"""A four-parameter O'Neill thermal curve: an exponential times a power of the distance to the upper thermal limit."""
import numpy as np
from scipy.optimize import least_squares

USED_INPUTS = ["temperature"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {
    "P_max": {"init": None},
    "T_opt": {"init": None},
    "T_max": {"init": None},
    "beta": {"init": None},
}

def _curve(T, amplitude, optimum, upper, beta):
    width = max(float(upper - optimum), np.finfo(float).tiny)
    z = np.maximum((upper - T) / width, np.finfo(float).tiny)
    exponent = beta * (np.log(z) + 1.0 - z)
    return np.where(T < upper, amplitude * np.exp(np.clip(exponent, -745.0, 0.0)), 0.0)

def fit(X_fit, y_fit):
    T = np.asarray(X_fit, dtype=float)[:, 0]
    y = np.asarray(y_fit, dtype=float).reshape(-1)
    valid = np.isfinite(T) & np.isfinite(y)
    T, y = T[valid], y[valid]
    if not len(T):
        return {"P_max": 0.0, "T_opt": 0.0, "T_max": 1.0, "beta": 1.0}

    origin = float(np.min(T))
    span = max(float(np.ptp(T)), 1.0)
    scale = max(float(np.max(np.abs(y))), np.finfo(float).tiny)
    t = (T - origin) / span
    v = y / scale
    mode = float(t[np.argmax(v)])

    def evaluate(q):
        amplitude = np.exp(q[0])
        optimum = q[1]
        width = np.exp(q[2])
        beta = np.exp(q[3])
        return _curve(t, amplitude, optimum, optimum + width, beta)

    lower = [-15.0, -4.0, -8.0, -8.0]
    upper = [12.0, 6.0, 7.0, 10.0]
    best = None
    best_cost = np.inf
    for width, shape in [(0.15, 0.4), (0.5, 1.0), (1.0, 2.0),
                         (2.0, 8.0), (4.0, 16.0), (8.0, 64.0)]:
        q0 = [np.log(max(float(np.max(v)), 0.01)), mode,
              np.log(width), np.log(shape)]
        try:
            result = least_squares(
                lambda q: evaluate(q) - v, q0,
                bounds=(lower, upper), max_nfev=600,
                ftol=1e-9, xtol=1e-9, gtol=1e-9
            )
            cost = float(np.dot(result.fun, result.fun))
            if np.isfinite(cost) and cost < best_cost:
                best, best_cost = result.x, cost
        except (ValueError, FloatingPointError, OverflowError):
            pass

    if best is None:
        best = np.array([np.log(max(float(np.max(v)), 0.01)),
                         mode, 0.0, 0.0])
    optimum = origin + span * best[1]
    return {
        "P_max": float(scale * np.exp(best[0])),
        "T_opt": float(optimum),
        "T_max": float(optimum + span * np.exp(best[2])),
        "beta": float(np.exp(best[3])),
    }

def predict(X, P_max, T_opt, T_max, beta):
    T = np.asarray(X, dtype=float)[:, 0]
    return _curve(T, P_max, T_opt, T_max, beta)