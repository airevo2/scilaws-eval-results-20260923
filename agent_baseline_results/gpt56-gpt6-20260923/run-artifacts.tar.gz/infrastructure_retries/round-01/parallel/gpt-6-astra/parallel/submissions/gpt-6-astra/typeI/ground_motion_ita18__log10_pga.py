"""Quadratic magnitude scaling, magnitude-dependent geometric attenuation, linear distance decay, and additive site and fault-style effects."""
import numpy as np

USED_INPUTS = ["Mw", "R_km", "ec8_B", "ec8_C", "ec8_D", "ec8_E", "sof_NF", "sof_TF"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    m = X[:, 0] - 5.5
    r = X[:, 1]
    effective_distance = np.sqrt(r**2 + 6.81626558**2)
    return (
        3.30088985
        + 0.197117613 * m
        + 0.0103485033 * m**2
        + (-1.30215079 + 0.251328332 * m) * np.log10(effective_distance)
        - 0.00306978319 * r
        + 0.01443930 * X[:, 2]
        + 0.23824316 * X[:, 3]
        + 0.21385867 * X[:, 4]
        + 0.24942365 * X[:, 5]
        + 0.02328098 * X[:, 6]
        - 0.10059303 * X[:, 7]
    )