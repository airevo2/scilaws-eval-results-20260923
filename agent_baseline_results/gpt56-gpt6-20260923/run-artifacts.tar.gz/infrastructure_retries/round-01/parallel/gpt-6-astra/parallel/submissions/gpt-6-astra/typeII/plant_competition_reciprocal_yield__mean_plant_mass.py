"""Smooth transition from individual size limitation to constant final yield:
w = w0 / (1 + (a*N)**b)**(1/b).
"""
import numpy as np
from scipy.optimize import least_squares

USED_INPUTS = ["density"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {
    "w0": {"init": None},
    "a": {"init": None},
    "b": {"init": None},
}

def predict(X, w0, a, b):
    N = np.maximum(np.asarray(X, dtype=float)[:, 0], 1e-300)
    log_w = np.log(max(w0, 1e-300)) - np.logaddexp(
        0.0, b * (np.log(max(a, 1e-300)) + np.log(N))
    ) / b
    return np.exp(np.clip(log_w, -700.0, 700.0))

def fit(X_fit, y_fit):
    N = np.asarray(X_fit, dtype=float)[:, 0]
    y = np.asarray(y_fit, dtype=float).ravel()
    valid = np.isfinite(N) & np.isfinite(y) & (N > 0)
    N, y = N[valid], y[valid]
    if len(y) == 0:
        return {"w0": 1.0, "a": 1.0, "b": 1.0}

    scale = max(float(np.max(np.abs(y))), 1e-12)
    logN = np.log(N)
    amplitude = max(float(np.max(y)), scale * 0.01)
    best = None

    def residual(p):
        b = np.exp(p[2])
        logw = p[0] - np.logaddexp(0.0, b * (p[1] + logN)) / b
        return (np.exp(np.clip(logw, -700.0, 300.0)) - y) / scale

    for b_start in (0.25, 1.0, 5.0):
        for a_start in (1.0 / np.median(N), 1.0):
            logw0 = np.log(amplitude) + np.logaddexp(
                0.0, b_start * np.log(a_start * np.min(N))
            ) / b_start
            p0 = np.array([logw0, np.log(a_start), np.log(b_start)])
            try:
                result = least_squares(
                    residual,
                    np.clip(p0, [-99.0, -99.0, -6.9], [299.0, 299.0, 4.6]),
                    bounds=([-100.0, -100.0, -7.0], [300.0, 300.0, 4.61]),
                    max_nfev=700,
                )
                score = float(np.dot(result.fun, result.fun))
                if np.isfinite(score) and (best is None or score < best[0]):
                    best = (score, result.x)
            except (ValueError, FloatingPointError, OverflowError):
                pass

    if best is None:
        return {"w0": amplitude * 2.0, "a": 1.0, "b": 1.0}
    p = best[1]
    return {"w0": float(np.exp(p[0])),
            "a": float(np.exp(p[1])),
            "b": float(np.exp(p[2]))}