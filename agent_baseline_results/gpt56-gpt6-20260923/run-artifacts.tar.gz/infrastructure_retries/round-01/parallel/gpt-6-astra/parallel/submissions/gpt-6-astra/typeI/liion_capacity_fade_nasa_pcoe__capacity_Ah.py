"""Capacity declines as a fractional power of cycle count."""
import numpy as np

USED_INPUTS = ["cycle_index"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    k = X[:, 0]
    return 1.948525300085094 - 0.011444187043288341 * k ** 0.7996393597311457