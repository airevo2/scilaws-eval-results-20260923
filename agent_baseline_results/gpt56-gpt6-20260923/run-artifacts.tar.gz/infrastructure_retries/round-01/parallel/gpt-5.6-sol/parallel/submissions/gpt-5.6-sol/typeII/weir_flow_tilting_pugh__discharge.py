"""Sharp-crested weir discharge with an effective head reduced by a crest-height correction."""
import numpy as np
from scipy.optimize import least_squares

USED_INPUTS = ["h_m", "p_m", "b_m"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {
    "C": {"init": [2.3]},
    "k": {"init": [0.03]}
}

def _predict_form(X, C, k):
    h = np.asarray(X[:, 0], dtype=float)
    p = np.asarray(X[:, 1], dtype=float)
    b = np.asarray(X[:, 2], dtype=float)
    H = np.maximum(h - k * p, 1e-10)
    return C * b * H ** 1.5

def fit(X_fit, y_fit):
    X_fit = np.asarray(X_fit, dtype=float)
    y_fit = np.asarray(y_fit, dtype=float)
    b = np.maximum(X_fit[:, 2], 1e-10)

    def residual(theta):
        C, k = theta
        pred = _predict_form(X_fit, C, k)
        scale = np.maximum(np.abs(y_fit), 1e-7)
        return (pred - y_fit) / scale

    try:
        result = least_squares(
            residual,
            x0=np.array([2.3, 0.03], dtype=float),
            bounds=([0.0, -2.0], [20.0, 2.0]),
            max_nfev=300
        )
        C, k = map(float, result.x)
        if not (np.isfinite(C) and np.isfinite(k) and C > 0):
            raise ValueError
        return {"C": C, "k": k}
    except Exception:
        z = b * np.maximum(X_fit[:, 0] - 0.03 * X_fit[:, 1], 1e-10) ** 1.5
        C = float(np.dot(z, y_fit) / max(np.dot(z, z), 1e-30))
        if not np.isfinite(C) or C <= 0:
            C = 2.3
        return {"C": C, "k": 0.03}

def predict(X, **params):
    C = float(params.get("C", 2.3))
    k = float(params.get("k", 0.03))
    if not np.isfinite(C) or C <= 0:
        C = 2.3
    if not np.isfinite(k):
        k = 0.03
    return np.asarray(_predict_form(X, C, k), dtype=float)