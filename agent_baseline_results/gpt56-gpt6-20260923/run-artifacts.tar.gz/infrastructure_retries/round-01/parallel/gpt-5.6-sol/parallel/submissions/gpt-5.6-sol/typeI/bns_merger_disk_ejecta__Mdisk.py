"""Compactness-dependent logistic transition from a low-compactness disk plateau to a small remnant floor."""
import numpy as np

USED_INPUTS = ["C1"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    C1 = X[:, 0]
    return 0.0007 + 0.199 * (1.0 / (1.0 + np.exp(158.0 * (C1 - 0.1564))))