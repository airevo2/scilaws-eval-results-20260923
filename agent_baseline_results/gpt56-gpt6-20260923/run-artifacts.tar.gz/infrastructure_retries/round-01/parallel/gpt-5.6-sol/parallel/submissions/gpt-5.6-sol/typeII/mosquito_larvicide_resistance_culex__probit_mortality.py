"""Four-parameter logistic dose-response curve on natural log concentration."""
import numpy as np
from scipy.optimize import curve_fit

USED_INPUTS = ["log_conc_ppb"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {
    "lower": {"init": None},
    "amplitude": {"init": None},
    "slope": {"init": None},
    "log_ec50": {"init": None},
}

def _logistic(x, lower, amplitude, slope, log_ec50):
    z = np.clip(slope * (x - log_ec50), -60.0, 60.0)
    return lower + amplitude / (1.0 + np.exp(-z))

def fit(X_fit, y_fit):
    x = np.asarray(X_fit[:, 0], dtype=float)
    y = np.asarray(y_fit, dtype=float)
    finite = np.isfinite(x) & np.isfinite(y)
    x, y = x[finite], y[finite]
    if x.size < 4:
        return {"lower": 0.0, "amplitude": 1.0, "slope": 2.0, "log_ec50": 3.5}
    lo0 = float(np.percentile(y, 5))
    hi0 = float(np.percentile(y, 95))
    amp0 = max(hi0 - lo0, 0.2)
    mid = lo0 + 0.5 * amp0
    j = int(np.argmin(np.abs(y - mid)))
    x500 = float(x[j])
    p0 = [lo0, amp0, 2.0, x500]
    try:
        popt, _ = curve_fit(
            _logistic, x, y, p0=p0,
            bounds=([-2.0, 0.05, 0.05, -10.0],
                    [2.0, 3.0, 20.0, 20.0]),
            maxfev=5000
        )
        return {
            "lower": float(popt[0]),
            "amplitude": float(popt[1]),
            "slope": float(popt[2]),
            "log_ec50": float(popt[3]),
        }
    except Exception:
        return {
            "lower": float(lo0),
            "amplitude": float(amp0),
            "slope": 2.0,
            "log_ec50": x500,
        }

def predict(X, **params):
    x = np.asarray(X[:, 0], dtype=float)
    return _logistic(
        x, params["lower"], params["amplitude"],
        params["slope"], params["log_ec50"]
    )