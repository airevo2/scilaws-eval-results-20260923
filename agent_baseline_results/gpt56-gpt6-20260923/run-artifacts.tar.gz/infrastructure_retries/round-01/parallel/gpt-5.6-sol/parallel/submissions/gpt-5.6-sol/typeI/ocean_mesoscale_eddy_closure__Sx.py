"""Linear eddy-momentum forcing from the zonal enstrophy and deformation-gradient combination."""
import numpy as np

USED_INPUTS = ["d_zeta2_dx", "d_zetaD_dx", "d_zetaDtilde_dy"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    d_zeta2_dx = X[:, 0]
    d_zetaD_dx = X[:, 1]
    d_zetaDtilde_dy = X[:, 2]
    return 1.0e9 * (-0.5 * d_zeta2_dx + d_zetaD_dx - d_zetaDtilde_dy)