"""Orthotropic exponential (Fung-type) biaxial constitutive stress law.

The stress is the lambda22 derivative of an exponential quadratic strain-energy
form, with a small cluster-specific stress offset to accommodate the measured
zero-load scatter.
"""
import numpy as np
from scipy.optimize import least_squares

USED_INPUTS = ["lambda11", "lambda22"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {
    "offset": {"init": None},
    "scale": {"init": None},
    "a11": {"init": None},
    "a22": {"init": None},
    "a12": {"init": None},
}

def _stress(X, offset, scale, a11, a22, a12):
    l1 = np.asarray(X[:, 0], dtype=float)
    l2 = np.asarray(X[:, 1], dtype=float)
    e1 = 0.5 * (l1 * l1 - 1.0)
    e2 = 0.5 * (l2 * l2 - 1.0)
    q = a11 * e1 * e1 + a22 * e2 * e2 + 2.0 * a12 * e1 * e2
    q = np.clip(q, -40.0, 40.0)
    return offset + scale * l2 * l2 * np.exp(q) * (a22 * e2 + a12 * e1)

def fit(X_fit, y_fit):
    X = np.asarray(X_fit, dtype=float)
    y = np.asarray(y_fit, dtype=float)
    if len(y) == 0:
        return {"offset": 0.0, "scale": 0.01, "a11": 1.0,
                "a22": 1.0, "a12": 0.1}

    # Robust scale estimates make fitting stable across the clusters.
    offset0 = float(np.median(y))
    spread = float(np.percentile(y, 90) - np.percentile(y, 10))
    ymax = max(float(np.max(np.abs(y - offset0))), spread, 1e-5)
    p0 = np.array([offset0, ymax, 1.0, 1.0, 0.1], dtype=float)

    def residual(p):
        z = _stress(X, p[0], p[1], p[2], p[3], p[4])
        return (z - y) / ymax

    try:
        sol = least_squares(
            residual, p0,
            bounds=([-0.2, 0.0, -30.0, -30.0, -30.0],
                    [0.2, 10.0, 30.0, 30.0, 30.0]),
            loss="soft_l1",
            f_scale=1.0,
            max_nfev=1800
        )
        p = sol.x
        if np.all(np.isfinite(p)):
            return {
                "offset": float(p[0]),
                "scale": float(p[1]),
                "a11": float(p[2]),
                "a22": float(p[3]),
                "a12": float(p[4]),
            }
    except Exception:
        pass
    return {
        "offset": offset0,
        "scale": ymax,
        "a11": 1.0,
        "a22": 1.0,
        "a12": 0.1,
    }

def predict(X, **params):
    return np.asarray(_stress(
        np.asarray(X, dtype=float),
        params["offset"],
        params["scale"],
        params["a11"],
        params["a22"],
        params["a12"],
    ), dtype=float)