"""Cluster-calibrated chiller performance surface: reciprocal COP is a temperature-lift surface with inverse-load and inverse-load-squared corrections."""
import numpy as np

USED_INPUTS = ["T_ei", "T_ci", "Q_e"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {
    "a": {"init": [0.0]},
    "b": {"init": [0.0]},
    "c": {"init": [0.0]},
    "d": {"init": [0.0]},
    "e": {"init": [0.0]},
    "f": {"init": [0.0]},
}

def _features(X):
    Te = np.maximum(np.asarray(X[:, 0], dtype=float), 1e-9)
    Tc = np.asarray(X[:, 1], dtype=float)
    Q = np.maximum(np.asarray(X[:, 2], dtype=float), 1e-9)
    lift = (Tc - Te) / Te
    return np.column_stack((
        np.ones_like(Te),
        lift,
        1.0 / Te,
        1.0 / Q,
        1.0 / (Q * Q),
        lift / Q,
    ))

def fit(X_fit, y_fit):
    A = _features(X_fit)
    target = np.asarray(y_fit, dtype=float) + 1.0
    try:
        p, _, _, _ = np.linalg.lstsq(A, target, rcond=None)
        if p.size != 6 or not np.all(np.isfinite(p)):
            raise ValueError
    except Exception:
        p = np.zeros(6, dtype=float)
        p[0] = float(np.nanmean(target)) if target.size else 0.0
    return {
        "a": float(p[0]),
        "b": float(p[1]),
        "c": float(p[2]),
        "d": float(p[3]),
        "e": float(p[4]),
        "f": float(p[5]),
    }

def predict(X, a, b, c, d, e, f):
    A = _features(X)
    p = np.array([a, b, c, d, e, f], dtype=float)
    out = A @ p - 1.0
    return np.nan_to_num(out, nan=0.0, posinf=1e12, neginf=-1e12)