"""Resonant capture with a higher-partial-wave background."""
import numpy as np

USED_INPUTS = ["E_eV"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    E = X[:, 0]
    sigma = (
        371.07843 / ((E - 4.90765053)**2 + 0.0752211935**2)
        + 0.00225511980 * E**2
    ) / np.sqrt(E)
    return np.log10(sigma)