"""SMAPE-optimized log-linear power-law model for national N2O emissions."""
import numpy as np

USED_INPUTS = ["GDP", "TP", "AP", "DP", "UR", "AT"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    GDP = np.maximum(X[:, 0], 1e-12)
    TP = np.maximum(X[:, 1], 1e-12)
    AP = np.maximum(X[:, 2], 1e-12)
    DP = np.maximum(X[:, 3], 1e-12)
    UR = np.maximum(X[:, 4], 1e-12)
    AT = X[:, 5]
    log_emissions = (
        2.6312795
        + 0.1772465 * np.log(GDP)
        + 1.0044458 * np.log(TP)
        - 0.4688901 * np.log(AP)
        - 0.3396542 * np.log(DP)
        - 0.2236863 * (UR / 100.0)
        - 0.2421694 * (AT / 10.0)
    )
    return np.exp(np.clip(log_emissions, -50.0, 50.0))