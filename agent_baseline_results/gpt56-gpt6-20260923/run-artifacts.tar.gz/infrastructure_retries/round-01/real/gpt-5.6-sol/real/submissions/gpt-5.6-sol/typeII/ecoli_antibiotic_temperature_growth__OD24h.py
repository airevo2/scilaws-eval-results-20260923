"""Cluster-calibrated Gaussian thermal growth curve with nonnegative baseline."""
import numpy as np
from scipy.optimize import least_squares

USED_INPUTS = ["T"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {
    "baseline": {"init": None},
    "amplitude": {"init": None},
    "optimum": {"init": None},
    "width": {"init": None},
}

def _form(T, baseline, amplitude, optimum, width):
    z = (T - optimum) / np.maximum(width, 1e-8)
    return baseline + amplitude * np.exp(-0.5 * z * z)

def fit(X_fit, y_fit):
    T = np.asarray(X_fit[:, 0], dtype=float)
    y = np.maximum(np.asarray(y_fit, dtype=float), 0.0)
    ymax = max(float(np.max(y)), 1e-6)
    ymin = float(np.min(y))
    imax = int(np.argmax(y))
    p0 = np.array([
        max(0.0, min(ymin, 0.8 * ymax)),
        max(ymax - max(0.0, ymin), 1e-6),
        float(np.clip(T[imax], 25.0, 45.0)),
        9.0,
    ])
    upper_amp = max(10.0 * ymax, 1.0)
    try:
        result = least_squares(
            lambda p: _form(T, *p) - y,
            p0,
            bounds=(
                [0.0, 0.0, 15.0, 2.0],
                [ymax, upper_amp, 55.0, 30.0],
            ),
            loss="soft_l1",
            f_scale=max(0.05 * ymax, 1e-4),
            max_nfev=600,
        )
        p = result.x
    except Exception:
        p = p0
    return {
        "baseline": float(p[0]),
        "amplitude": float(p[1]),
        "optimum": float(p[2]),
        "width": float(p[3]),
    }

def predict(X, baseline, amplitude, optimum, width):
    T = np.asarray(X[:, 0], dtype=float)
    y = _form(T, baseline, amplitude, optimum, width)
    return np.maximum(np.asarray(y, dtype=float), 0.0)