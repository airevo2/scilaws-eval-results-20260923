"""Cluster-calibrated signed power-law shear stress with shared strain-stiffening exponent."""
import numpy as np

USED_INPUTS = ["gamma"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {"exponent": 3.2361652868694573}
LOCAL_FITTABLE = {
    "amplitude": {"init": [8.0]},
    "offset": {"init": [0.0]},
}

def _shape(gamma):
    p = OTHER_CONSTANTS["exponent"]
    return np.sign(gamma) * np.abs(gamma) ** p

def fit(X_fit, y_fit):
    gamma = np.asarray(X_fit[:, 0], dtype=float)
    y_fit = np.asarray(y_fit, dtype=float)
    z = _shape(gamma)
    A = np.column_stack((z, np.ones_like(z)))
    try:
        params, _, _, _ = np.linalg.lstsq(A, y_fit, rcond=None)
        amplitude = float(params[0])
        offset = float(params[1])
        if not np.isfinite(amplitude) or not np.isfinite(offset):
            raise ValueError
    except Exception:
        amplitude = 8.0
        offset = float(np.mean(y_fit)) if y_fit.size else 0.0
    return {"amplitude": amplitude, "offset": offset}

def predict(X, amplitude, offset):
    gamma = np.asarray(X[:, 0], dtype=float)
    result = amplitude * _shape(gamma) + offset
    return np.asarray(result, dtype=float)