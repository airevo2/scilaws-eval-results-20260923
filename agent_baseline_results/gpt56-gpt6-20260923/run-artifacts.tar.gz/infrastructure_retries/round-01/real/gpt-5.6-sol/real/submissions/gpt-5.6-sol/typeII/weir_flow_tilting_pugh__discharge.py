"""Inclined sharp-crested weir discharge with a local scale and head-to-height correction."""
import numpy as np
from scipy.optimize import least_squares

USED_INPUTS = ["h_m", "p_m", "b_m"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {
    "a": {"init": None},
    "c": {"init": None},
}

def _form(h, p, b, a, c):
    ratio = np.divide(h, np.maximum(p, 1e-9))
    return a * b * np.maximum(h, 0.0) ** 1.5 * (1.0 + c * ratio)

def fit(X_fit, y_fit):
    h = np.maximum(np.asarray(X_fit[:, 0], dtype=float), 1e-8)
    p = np.maximum(np.asarray(X_fit[:, 1], dtype=float), 1e-8)
    b = np.maximum(np.asarray(X_fit[:, 2], dtype=float), 1e-8)
    y = np.asarray(y_fit, dtype=float)

    x0 = b * h ** 1.5
    x1 = x0 * h / p
    A = np.column_stack((x0, x1))
    try:
        coef, _, _, _ = np.linalg.lstsq(A, y, rcond=None)
        a0 = max(float(coef[0]), 1e-8)
        c0 = float(coef[1] / a0)
        c0 = float(np.clip(c0, -0.8, 5.0))

        scale = max(float(np.sqrt(np.mean(y * y))), 1e-8)
        def residual(z):
            return (_form(h, p, b, z[0], z[1]) - y) / scale

        result = least_squares(
            residual,
            x0=np.array([a0, c0]),
            bounds=([1e-10, -0.8], [np.inf, 5.0]),
            max_nfev=100,
        )
        if result.success and np.all(np.isfinite(result.x)):
            a_hat, c_hat = result.x
        else:
            a_hat, c_hat = a0, c0
    except Exception:
        denom = max(float(np.sum(x0 * x0)), 1e-20)
        a_hat = max(float(np.sum(x0 * y) / denom), 1e-8)
        c_hat = 0.0

    return {"a": float(a_hat), "c": float(c_hat)}

def predict(X, a, c):
    X = np.asarray(X, dtype=float)
    h = np.maximum(X[:, 0], 0.0)
    p = np.maximum(X[:, 1], 1e-9)
    b = np.maximum(X[:, 2], 0.0)
    y = _form(h, p, b, float(a), float(c))
    return np.nan_to_num(y, nan=0.0, posinf=1e100, neginf=0.0)