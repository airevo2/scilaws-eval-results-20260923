"""Smooth photovoltaic power law: irradiance-scaled efficiency with temperature, spectral air-mass, wind, and their low-order interactions."""
import numpy as np

USED_INPUTS = ["G_W_m2", "T_module_C", "WS_m_s", "air_mass"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    G = X[:, 0]
    T = X[:, 1]
    W = X[:, 2]
    A = X[:, 3]
    u = (T - 25.0) / 25.0
    v = np.log(G / 1000.0)
    a = np.log(A)
    w = np.log1p(W)
    e = (
        167.69785316
        + 25.32164247*u
        + 51.16573372*a
        + 29.48383676*w
        - 36.99871309*v
        - 17.63557508*u**3
        + 13.87809030*a**4
        - 25.20721816*a*a*w
        - 21.84857673*u*w*w
        + 20.92572687*u*u*w
        + 29.99036229*u*u*v
        - 39.85498216*u*u*v*a
        + 24.36054556*v*a
        + 32.20834776*v*a*w
        + 11.51491735*u*u*v*a
        - 18.85159763*u**3*v
        - 19.67702193*u*a*a*w
        - 19.12502193*u*v*a*a
        + 15.43096663*a**3*w
        - 15.23479411*u*u*w*w
        + 13.05397325*u*v*v*a
        - 12.76335757*v*v*w
        + 12.76104957*u*v*v*w
        + 12.64937676*a*w*w
        + 11.45050305*u**3*w
        - 11.41618195*v**3*a
        + 11.33173281*u*v*a*w
        + 11.14362853*a*a*w*w
    )
    return G * e / 1000.0