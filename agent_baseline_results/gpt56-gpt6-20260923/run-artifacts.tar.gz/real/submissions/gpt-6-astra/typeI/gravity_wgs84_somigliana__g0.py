"""Somigliana normal gravity with WGS84 shape factors and fitted equatorial gravity."""
import numpy as np

USED_INPUTS = ["latitude"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    s = np.sin(np.deg2rad(X[:, 0])) ** 2
    return 9.780951197349669 * (1 + 0.00193185265241 * s) / np.sqrt(1 - 0.00669437999013 * s)