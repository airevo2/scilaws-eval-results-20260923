"""Regularized cubic-porosity permeability law with a smooth low-porosity floor."""
import numpy as np

USED_INPUTS = ["phi"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    phi = X[:, 0]
    return np.arcsinh(895.8953356738666 * phi**3) - 1.2988861287356286