"""Positive ejecta model combining a mass–radius contribution and quadratic binary asymmetry."""
import numpy as np

USED_INPUTS = ["M1", "M2", "C1", "C2"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    m1, m2, c1, c2 = X.T
    mass = m1 + m2
    radius = (m1 / c1 + m2 / c2) / 2
    asymmetry = (m1 - m2) / mass

    log_symmetric = (
        6.03100795
        - 40.518225 * mass
        + 11.40443422 * radius
        - 1.43935436 * radius**2
        + 4.5188688 * mass * radius
    )
    return np.exp(log_symmetric) + 0.0887498222 * asymmetry**2