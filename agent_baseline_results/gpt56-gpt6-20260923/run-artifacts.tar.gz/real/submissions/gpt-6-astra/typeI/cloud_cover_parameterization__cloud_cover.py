"""Bounded cloud-fraction law combining humidity, temperature, condensate, and humidity gradient."""
import numpy as np

USED_INPUTS = ["q_c", "q_i", "RH", "T", "dz_RH"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    q_c = np.maximum(X[:, 0], 0.0)
    q_i = np.maximum(X[:, 1], 0.0)
    RH = np.maximum(X[:, 2], 0.0)
    t = (X[:, 3] - 273.15) / 50.0
    gradient = X[:, 4] * 1e4

    humidity = RH * np.exp(
        np.clip(1.25906946 * np.maximum(-t, 0.0), -50.0, 50.0)
    )
    condensate = 1e6 * (q_c + 0.00933654371 * q_i)
    score = (
        -10.38869422
        + 6.22346462 * humidity
        - 2.85959067 * t
        + 3.22062953 * humidity * t
        + 0.23080049 * np.log1p(
            152660.260 * condensate + 66.9580096 * condensate**3
        )
        - 0.1116703 * np.minimum(gradient, 0.0)
    )
    return 1.0 / (1.0 + np.exp(-np.clip(score, -700.0, 700.0)))