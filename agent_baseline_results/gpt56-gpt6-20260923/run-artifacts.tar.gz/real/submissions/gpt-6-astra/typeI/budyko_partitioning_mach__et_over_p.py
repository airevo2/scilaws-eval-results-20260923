"""Terrain- and soil-adjusted Fu water-balance curve."""
import numpy as np

USED_INPUTS = ["pet_over_p", "basin_slope", "clay_pct"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    phi = X[:, 0]
    slope = X[:, 1] / 100
    clay = X[:, 2] / 100
    omega = 1 + 1.689556908062381 / (1 + np.sqrt(slope / (1 - clay)))
    return 1 + phi - (1 + phi**omega)**(1 / omega)