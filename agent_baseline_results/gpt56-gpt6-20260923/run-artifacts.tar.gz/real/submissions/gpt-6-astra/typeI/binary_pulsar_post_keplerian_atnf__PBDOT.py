"""Quadrupole gravitational-wave orbital decay for canonical 1.4-solar-mass neutron stars."""
import numpy as np

USED_INPUTS = ["Pb", "e"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    period_seconds = X[:, 0] * 86400.0
    eccentricity = X[:, 1]
    eccentricity_factor = (
        1.0 + (73.0 / 24.0) * eccentricity**2
        + (37.0 / 96.0) * eccentricity**4
    ) / (1.0 - eccentricity**2)**3.5
    return (
        -(192.0 * np.pi / 5.0)
        * (2.0 * np.pi * 4.925490947e-6 / period_seconds)**(5.0 / 3.0)
        * (1.4 * 1.4 / (2.8**(1.0 / 3.0)))
        * eccentricity_factor
    )