"""Exponentially increasing CO2 baseline with slowly evolving annual and semiannual cycles."""
import numpy as np

USED_INPUTS = ["year_decimal", "month"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    t = X[:, 0] - 2020.0
    phase = 2.0 * np.pi * (X[:, 1] - 0.5) / 12.0
    baseline = (
        412.499009
        + 2.53582070 * np.expm1(0.0162566881 * t) / 0.0162566881
    )
    seasonal = (
        (2.92854084 + 0.00892164294 * t) * np.sin(phase)
        + (-0.830600296 + 0.00584355260 * t) * np.cos(phase)
        + (-0.584920437 - 0.00497835779 * t) * np.sin(2.0 * phase)
        + (0.718387900 + 0.00194957427 * t) * np.cos(2.0 * phase)
    )
    return baseline + seasonal