"""Luminosity scaling with a continuous broken power-law mass dependence."""
import numpy as np

USED_INPUTS = ["logL_star", "M_star_B98"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    log_luminosity = X[:, 0]
    log_mass = np.log10(X[:, 1])
    return (
        0.04745489
        + 1.21107582 * log_luminosity
        + 2.35225167 * log_mass
        - 3.55628850 * np.maximum(log_mass + 0.31875637, 0.0)
    )