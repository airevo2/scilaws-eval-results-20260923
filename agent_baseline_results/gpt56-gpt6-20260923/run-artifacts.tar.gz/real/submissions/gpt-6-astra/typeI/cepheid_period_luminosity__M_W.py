"""Robust period–Wesenheit–metallicity relation."""
import numpy as np

USED_INPUTS = ["log_P", "feh"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    log_P = X[:, 0]
    feh = X[:, 1]
    return -5.91386894 - 3.26710261 * (log_P - 1) - 0.30981728 * feh