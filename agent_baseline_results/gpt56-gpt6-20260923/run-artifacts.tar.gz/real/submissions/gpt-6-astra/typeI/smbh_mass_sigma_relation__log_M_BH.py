"""Empirical black-hole mass relation with velocity dispersion, spheroid mass, and pseudobulge offset."""
import numpy as np

USED_INPUTS = ["sigma0", "log_M_sph", "Pseudobulge"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    sigma0 = X[:, 0]
    log_M_sph = X[:, 1]
    pseudobulge = X[:, 2]
    return (
        8.43750111
        + 1.37543656 * (sigma0 / 200.0 - 1.0)
        + 0.38756769 * (log_M_sph - 11.0)
        - 0.60871059 * pseudobulge
    )