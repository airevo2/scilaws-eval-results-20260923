"""Population-scaled methane emissions with income saturation and density dependence."""
import numpy as np

USED_INPUTS = ["GDP", "TP", "AP", "DP"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    GDP = X[:, 0]
    TP = X[:, 1]
    AP = X[:, 2]
    DP = X[:, 3]
    return (
        108.582859215126
        * TP ** 1.04351409549743
        * GDP / (GDP + 460.539844441338)
        * (0.0378525255795076 + DP ** (-0.430535835053475))
        * np.exp(0.001354817069901 * (AP - 59.2776180933732) ** 2)
    )