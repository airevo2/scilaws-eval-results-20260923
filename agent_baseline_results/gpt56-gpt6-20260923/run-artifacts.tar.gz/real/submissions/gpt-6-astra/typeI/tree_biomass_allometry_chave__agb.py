"""Biomass allometry based on wood density and stem-volume scaling."""
import numpy as np

USED_INPUTS = ["wood_density", "diameter_cm", "height_m"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    rho = X[:, 0]
    diameter = X[:, 1]
    height = X[:, 2]
    return 0.0593303679920619 * (rho * diameter**2 * height)**0.9836803099048297