"""Flux proportional to stellar mass for detections; constant sensitivity level for upper limits."""
import numpy as np

USED_INPUTS = ["log10_M_star", "is_F_uplim"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    log_mass = X[:, 0]
    upper_limit = X[:, 1]
    return (1 - upper_limit) * (log_mass - 1.191541463414634) - upper_limit * 2.432846511627907