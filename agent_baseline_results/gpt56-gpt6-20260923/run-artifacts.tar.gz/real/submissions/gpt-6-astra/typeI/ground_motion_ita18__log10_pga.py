"""Magnitude-dependent geometric spreading, anelastic attenuation, and site/fault corrections."""
import numpy as np

USED_INPUTS = ["Mw", "R_km", "ec8_B", "ec8_C", "ec8_D", "ec8_E", "sof_TF", "sof_SS"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    m = X[:, 0] - 5.0
    r = np.sqrt(X[:, 1] ** 2 + 6.47997819 ** 2)
    return (
        3.22549
        + 0.23693 * m
        + (-1.41677 + 0.23907 * m) * np.log10(r)
        - 0.00304786 * r
        + 0.0510784 * X[:, 2]
        + 0.247128 * X[:, 3]
        + 0.113784 * X[:, 4]
        + 0.387220 * X[:, 5]
        - 0.132624 * X[:, 6]
        - 0.00560277 * X[:, 7]
    )