"""Allometric basal metabolic rate: log10(B) is linear in log10(body mass)."""
import numpy as np

USED_INPUTS = ["body_mass_g"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    return 0.68903391 * np.log10(X[:, 0]) - 1.66456997