"""Symmetric Butler–Volmer kinetics with hydrogen mass-transfer limitation."""
import numpy as np

USED_INPUTS = ["eta", "T", "P_H2", "c_acid"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    eta, T, P_H2, c_acid = X.T
    z = (96485.33212 / 8.314462618) * eta / T

    j0 = (
        1291.702792778358
        * np.tanh(np.maximum(T - 257.5513362321593, 0.0) / T)
        * np.sqrt(P_H2)
    )
    j_lim = (
        np.exp(6.210465708999424
               + 3014.2246252641407 * (1.0 / 298.0 - 1.0 / T))
        * P_H2
        * (c_acid / 4.0) ** 0.2998711762700257
    )

    anodic = j0 * np.exp(z / 2.0)
    cathodic = j0 * np.exp(-z / 2.0)
    difference = anodic**2 - cathodic**2
    coefficient = 2.0 * cathodic + anodic**2 / j_lim
    denominator = coefficient + np.sqrt(
        np.maximum(coefficient**2 + 4.0 * difference, 0.0)
    )
    return np.divide(
        2.0 * difference, denominator,
        out=np.zeros_like(eta), where=denominator > 0.0
    )