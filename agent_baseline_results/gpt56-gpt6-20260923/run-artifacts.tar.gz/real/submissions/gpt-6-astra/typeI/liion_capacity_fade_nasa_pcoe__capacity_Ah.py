"""Saturating capacity fade with a stretched-exponential cycling dependence."""
import numpy as np

USED_INPUTS = ["cycle_index"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    k = X[:, 0]
    return 1.37846072 + 0.50838420 * np.exp(-(k / 76.72135493)**2)