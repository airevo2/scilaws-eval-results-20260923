"""Saturating mass–metallicity relation with a bounded star-formation offset."""
import numpy as np

USED_INPUTS = ["log_Mstar", "log_SFR"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    m = X[:, 0] - 10.0
    s = X[:, 1]
    baseline = 8.145656164578643 + 1.0 - np.exp(
        -np.exp(0.9605254849080151 * (m + 0.579336249439891))
    )
    offset = s - 1.1102177137279747 * m - 0.1763397005989472
    return baseline - 0.20123061589846894 * np.tanh(np.abs(offset))