"""Positive power-law melt-pool scaling fitted robustly to replicate measurements."""
import numpy as np

USED_INPUTS = ["laser_power_W", "scan_velocity_mm_per_s", "beam_diameter_um"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    P = X[:, 0]
    V = X[:, 1]
    D = X[:, 2]
    return 248778.510945 * P**1.237350366 * V**(-1.176524047) * D**(-1.518733312)