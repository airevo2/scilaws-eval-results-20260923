"""Chemical-interaction hardening with a two-thirds scaling and electronic modulation."""
import numpy as np

USED_INPUTS = ["VEC", "dHmix"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    vec = X[:, 0]
    enthalpy = X[:, 1]
    chemical = -np.sign(enthalpy) * np.abs(enthalpy)**(2.0 / 3.0)
    return 390.32625474 + 0.7085473295 * chemical * np.exp(0.66249841 * vec)