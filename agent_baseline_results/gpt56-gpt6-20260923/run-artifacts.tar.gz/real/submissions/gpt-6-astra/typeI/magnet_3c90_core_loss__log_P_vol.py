"""Thermally activated hysteresis loss plus waveform-adjusted dynamic loss."""
import numpy as np
import math

USED_INPUTS = ["f_Hz", "B_peak_T", "T_C", "waveform_id"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    f = X[:, 0] / 1e5
    b = X[:, 1] / 0.1
    temperature = X[:, 2] + 273.15
    waveform = X[:, 3]

    triangular_factor = (
        (2 / np.pi)**2.5
        * np.sqrt(np.pi)
        * math.gamma(9 / 4)
        / math.gamma(7 / 4)
    )
    shape = np.where(
        waveform == 0,
        1.0,
        triangular_factor * np.where(waveform == 2, 2**1.5, 1.0)
    )

    hysteresis = (
        10**1.97492469
        * f
        * b**2.8518882
        * np.exp(1577.431 * (1 / temperature - 1 / 298.15))
    )
    dynamic = 10**1.09112844 * f**2.5 * b**2 * shape
    return np.log10(hysteresis + dynamic)