"""Quadratic disturbance–richness relationship."""
import numpy as np

USED_INPUTS = ["d"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    d = X[:, 0]
    return 13.1168164 - 0.413923286 * d + 0.00348902119 * d**2