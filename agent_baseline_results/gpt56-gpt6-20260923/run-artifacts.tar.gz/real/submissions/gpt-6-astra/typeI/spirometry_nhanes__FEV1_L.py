"""Height-scaled lung volume with smooth age-dependent decline."""
import numpy as np

USED_INPUTS = ["age", "height_cm"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    age = X[:, 0]
    height = X[:, 1]
    return (
        0.00018291605452743818
        * height ** 1.9422768513582227
        * np.exp(-0.0003019582876994357 * age ** 1.7645800958579445)
    )