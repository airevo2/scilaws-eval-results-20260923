"""Density-scaled bulk modulus with exponential atomic-volume softening."""
import numpy as np

USED_INPUTS = ["V_atomic_A3", "density_g_cm3"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    volume = X[:, 0]
    density = X[:, 1]
    return 149.25506785 * np.cbrt(density * density) * np.exp(-volume / 11.05119084)