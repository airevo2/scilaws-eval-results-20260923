"""Pressure-modulated solar-wind coupling with nonlinear ring-current recovery."""
import numpy as np

USED_INPUTS = ["Dst", "P_dyn", "V_sw", "Bz_GSM", "B_mag"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    Dst = X[:, 0]
    pressure = X[:, 1]
    speed = X[:, 2]
    bz = X[:, 3]
    field = X[:, 4]

    southward_fraction = np.clip((1.0 - bz / field) / 2.0, 0.0, 1.0)
    coupling = (
        (speed / 400.0) ** 0.89981149
        * field
        * southward_fraction ** 2.83551989
    )
    recovery = -0.01494955 * Dst * np.sqrt(
        1.0 + np.maximum(-Dst, 0.0) / 4.75067709
    )
    injection = -0.80945744 * coupling * pressure ** 0.38413252
    pressure_term = 0.84615640 * np.log1p(pressure)
    return recovery + injection + pressure_term