"""Smooth double-break cumulative crater distribution with a power-law large-diameter tail."""
import numpy as np

USED_INPUTS = ["D_lower_km"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    log_d = np.log(X[:, 0])
    log_n = (
        -5.97321
        - 1.81013 * log_d
        + (1.81013 - 0.83913)
        * np.logaddexp(0.0, 2.90641 * (log_d - 0.71259)) / 2.90641
        + (0.83913 - 3.62170)
        * np.logaddexp(0.0, 1.82217 * (log_d - 3.80670)) / 1.82217
    )
    return np.exp(log_n)