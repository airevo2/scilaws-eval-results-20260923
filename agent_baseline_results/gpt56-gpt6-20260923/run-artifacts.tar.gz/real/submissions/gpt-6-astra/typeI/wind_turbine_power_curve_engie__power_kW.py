"""Monotone cubic-logistic turbine power curve with rated-power saturation."""
import numpy as np

USED_INPUTS = ["wind_speed_mps"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    v = X[:, 0]
    logit = -13.517678664623176 + v * (
        3.5093460130318332 + v * (
            -0.32972406287204414 + 0.01219653055060343 * v
        )
    )
    return 1994.6363895259624 * np.exp(-np.logaddexp(0.0, -logit))