"""Phase-dependent high-frequency seismic scaling with RGB temperature correction."""
import numpy as np

USED_INPUTS = ["nu_max", "Teff", "phase"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    nu_max = X[:, 0]
    Teff = X[:, 1]
    helium_burning = X[:, 2] == 2
    amplitude = np.where(
        helium_burning,
        0.2531416487638997,
        0.29821171930351426 * (Teff / 5772.0) ** (3.0 / 8.0),
    )
    return amplitude * nu_max ** (3.0 / 4.0)