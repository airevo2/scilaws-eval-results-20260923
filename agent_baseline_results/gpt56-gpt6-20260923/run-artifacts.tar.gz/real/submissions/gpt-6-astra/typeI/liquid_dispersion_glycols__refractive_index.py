"""Thermo-optic Cauchy dispersion with a smooth temperature correction."""
import numpy as np

USED_INPUTS = ["lambda_um", "temperature_C"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    wavelength = X[:, 0]
    T = X[:, 1]
    thermal = T * (
        -0.0003346413264341075
        + T * (
            1.38040252072498e-05
            + T * (
                -1.023917222099639e-06
                + T * (
                    3.018166616985082e-08
                    - 3.023226084300952e-10 * T
                )
            )
        )
    )
    return (
        1.42678114448824
        + (0.003776697775611435 - 4.656341266697225e-06 * T)
        / wavelength**2
        + thermal
    )