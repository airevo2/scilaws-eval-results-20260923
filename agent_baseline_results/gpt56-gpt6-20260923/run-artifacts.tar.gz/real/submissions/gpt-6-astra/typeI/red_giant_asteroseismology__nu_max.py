"""Density-scaling relation with a saturating helium-burning mass correction."""
import numpy as np

USED_INPUTS = ["delta_nu", "phase"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    delta_nu = X[:, 0]
    phase = X[:, 1]
    mass_correction = np.where(
        phase == 2,
        2.0 * delta_nu**2 / (delta_nu**2 + 4.62381641**2),
        1.0,
    )
    return 5.50640724 * delta_nu**(4.0 / 3.0) * np.cbrt(mass_correction)