"""One-parameter Fu water balance with snow-adjusted evaporative demand and seasonality-dependent partitioning."""
import numpy as np

USED_INPUTS = ["p_mean", "pet_mean", "p_seasonality", "frac_snow"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    p = X[:, 0]
    pet = X[:, 1]
    seasonality = X[:, 2]
    snow = X[:, 3]

    aridity = pet / p
    effective_aridity = aridity * np.exp(-snow)
    omega = 1 + 4.5448694 * aridity / (1 + aridity) * np.exp(seasonality)

    runoff_fraction = effective_aridity * np.expm1(
        np.logaddexp(0, -omega * np.log(effective_aridity)) / omega
    )
    return p * np.clip(runoff_fraction, 0, 1)