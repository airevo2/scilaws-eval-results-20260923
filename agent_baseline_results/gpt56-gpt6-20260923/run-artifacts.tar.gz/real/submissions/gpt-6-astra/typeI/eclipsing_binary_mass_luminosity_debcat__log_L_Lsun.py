"""Smooth broken mass–luminosity law with a mass-dependent metallicity correction."""
import numpy as np

USED_INPUTS = ["log_M_Msun", "metallicity"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    x = X[:, 0]
    metallicity = X[:, 1]
    low_transition = 0.05 * np.logaddexp(0.0, (x + 0.3363884) / 0.05)
    high_transition = 0.05 * np.logaddexp(0.0, (x - 0.26526038) / 0.05)
    baseline = (
        -0.91278385
        + 2.3 * x
        + 2.56296349 * low_transition
        - 1.34829693 * high_transition
    )
    correction = np.minimum(metallicity + 0.11, 0.0) * (
        -0.12472343
        - 2.28428395 * np.exp(-((x - 0.33731467) / 0.35423694) ** 2)
    )
    return baseline + correction