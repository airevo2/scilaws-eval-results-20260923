"""Two-exponent gravity law with distance and intervening-opportunity attenuation."""
import numpy as np

USED_INPUTS = ["m_i", "m_j", "d_ij_km", "s_ij"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    m_i = X[:, 0]
    m_j = X[:, 1]
    d_ij_km = X[:, 2]
    s_ij = X[:, 3]
    log_flow = (
        0.8320618675994127 * np.log(m_i)
        + np.log(m_j)
        - 1.227344642909183
        * np.log(d_ij_km * np.sqrt(m_i + m_j + s_ij))
    )
    return np.logaddexp(np.log(2.0), log_flow) / np.log(10.0)