"""Collector efficiency with inlet-temperature-dependent losses and an irradiance correction."""
import numpy as np

USED_INPUTS = ["G_W_m2", "T_in_C", "T_amb_C"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    G = X[:, 0]
    T_in = X[:, 1]
    T_amb = X[:, 2]
    eta = (
        0.7582758937412928
        - 0.05951838453285195 * T_in * (T_in - T_amb) / G
        - 0.00003479967557698695 * G
    )
    return np.clip(eta, 0.0, 1.0)