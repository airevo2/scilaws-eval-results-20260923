"""Froissart log-squared growth with a decreasing Regge contribution."""
import numpy as np

USED_INPUTS = ["s"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    s = X[:, 0]
    return (
        36.30642906
        + 0.30 * np.log(s / 34.48063040)**2
        + 16.40082854 / np.sqrt(s)
    )