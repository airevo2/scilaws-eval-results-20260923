"""Charge-normalized rational Sachs form factor with regularized dipole-shape coefficients."""
import numpy as np

USED_INPUTS = ["Q2_GeV2"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    q2 = X[:, 0]
    tau = q2 / (4.0 * 0.9382720813**2)
    return (
        (1.0 - 0.22151505 * tau)
        * (1.0 + q2 / 0.71)**2
        / (1.0 + 11.08211852 * tau
           + 14.15167136 * tau**2
           + 20.49946480 * tau**3)
    )