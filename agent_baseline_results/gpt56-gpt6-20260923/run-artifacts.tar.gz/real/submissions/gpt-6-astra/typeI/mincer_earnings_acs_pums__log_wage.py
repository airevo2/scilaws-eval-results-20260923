"""Bounded schooling returns and saturating returns to work experience."""
import numpy as np

USED_INPUTS = ["SCHL_years", "exp"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    s = X[:, 0]
    x = X[:, 1]
    schooling = np.clip((s - 5.31488045) / 13.68511955, 0, 1)
    return (
        9.52887736
        + 1.46935950 * schooling**2
        + 0.81234780 * (-np.expm1(-x / 9.88675429))
    )