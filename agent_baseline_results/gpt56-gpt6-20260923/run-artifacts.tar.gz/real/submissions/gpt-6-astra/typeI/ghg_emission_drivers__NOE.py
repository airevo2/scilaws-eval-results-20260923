"""Population-scaled emissions with income, demographic, density, and climate effects."""
import numpy as np

USED_INPUTS = ["GDP", "TP", "AP", "DP", "UR", "AT"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    GDP, TP, AP, DP, UR, AT = X.T
    active = (AP - 60.0) / 10.0
    urban = (UR - 50.0) / 25.0
    temperature = (AT - 20.0) / 10.0

    log_per_capita = (
        0.2297382282
        + 0.1334056056 * np.log(GDP / 3000.0)
        - 0.3267140472 * 2.0 * np.log(DP / 50.0)
          / (1.0 + np.exp(1.2674398587 * active))
        - 0.2774987432 * temperature
        - 0.1715046090 * active
        - 0.1467714671 * temperature * urban
    )
    return TP * np.exp(log_per_capita)