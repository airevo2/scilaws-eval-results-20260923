"""Height-squared lung-volume scaling with a saturating adolescent maturation term."""
import numpy as np

USED_INPUTS = ["age", "height_cm"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    age = X[:, 0]
    height_cm = X[:, 1]
    return (
        -1.02120197
        + 0.000177011536 * height_cm**2
        + 0.92907062 / (1.0 + np.exp(15.14637461 - age))
    )