"""Cruising airspeed as an affine function of square-root wing loading."""
import numpy as np

USED_INPUTS = ["mass_kg", "wing_area_m2"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    mass = X[:, 0]
    area = X[:, 1]
    return 8.45031988 + 2.64344995 * np.sqrt(mass / area)