"""Endurance-regime velocity with distance-dependent fatigue and sex scaling."""
import numpy as np

USED_INPUTS = ["distance_m", "sex_M"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    d = X[:, 0]
    s = X[:, 1]
    return 6.03053116607362 * (1.0 + 0.11488028759157083 * s) * np.exp(-0.000004435795766069428 * d)