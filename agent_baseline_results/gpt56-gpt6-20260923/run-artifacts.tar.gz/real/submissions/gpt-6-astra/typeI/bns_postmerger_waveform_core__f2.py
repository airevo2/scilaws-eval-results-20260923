"""Mass-scaled tidal power law for the post-merger peak frequency."""
import numpy as np

USED_INPUTS = ["mass", "kap2t"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    mass = X[:, 0]
    kap2t = X[:, 1]
    return 41.49405521 * kap2t**(-0.34994082) / mass