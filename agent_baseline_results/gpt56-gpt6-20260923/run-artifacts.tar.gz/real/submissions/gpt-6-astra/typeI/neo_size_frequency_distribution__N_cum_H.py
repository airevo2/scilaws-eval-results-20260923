"""Tapered magnitude-count law with a fixed bright-end slope of one half."""
import numpy as np

USED_INPUTS = ["H_upper"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    H = X[:, 0]
    log_count = (
        np.log(10.0) * (0.5 * H - 5.78287614)
        - np.logaddexp(0.0, np.log(10.0) * 0.5 * (H - 18.57357992))
    )
    return np.exp(log_count)