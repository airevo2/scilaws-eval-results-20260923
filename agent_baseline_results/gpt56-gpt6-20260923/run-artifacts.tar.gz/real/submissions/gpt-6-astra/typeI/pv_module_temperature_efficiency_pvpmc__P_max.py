"""Irradiance-scaled PV power with thermal, irradiance-loss, and air-mass corrections."""
import numpy as np

USED_INPUTS = ["G_W_m2", "T_module_C", "air_mass"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    g = X[:, 0] / 1000.0
    temperature = X[:, 1] - 25.0
    inverse_air_mass = 1.0 / X[:, 2]
    effective_rating = (
        178.712751
        - 17.7434923 * g
        + 163.383748 * inverse_air_mass
        - 132.064780 * inverse_air_mass**2
    )
    thermal_factor = 1.0 - 0.00152187145 * temperature
    return np.maximum(0.0, g * effective_rating * thermal_factor)