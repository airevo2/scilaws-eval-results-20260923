"""Continuous broken power law for rocky planets, giants, and brown dwarfs."""
import numpy as np

USED_INPUTS = ["M"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    log_mass = np.log(np.maximum(X[:, 0], np.finfo(float).tiny))
    intercept = 0.00684250362
    rocky_slope = 0.284699539
    planet_slope = 0.588957006
    giant_slope = -0.0437297643
    dwarf_slope = -0.128452287
    rocky_break = 0.725083218
    giant_break = 4.88364938
    dwarf_break = 9.09662976

    log_radius = (
        intercept
        + rocky_slope * log_mass
        + (planet_slope - rocky_slope) * np.maximum(log_mass - rocky_break, 0)
        + (giant_slope - planet_slope) * np.maximum(log_mass - giant_break, 0)
        + (dwarf_slope - giant_slope) * np.maximum(log_mass - dwarf_break, 0)
    )
    return np.exp(log_radius)