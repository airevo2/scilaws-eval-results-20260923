"""Liquid-drop binding energy with surface symmetry, Coulomb diffuseness, pairing, and valence-shell corrections."""
import numpy as np

USED_INPUTS = ["Z", "N", "A", "NZ_diff", "pair"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    Z, N, A, NZ_diff, pair = X.T
    a13 = np.cbrt(A)
    # Conventional nuclear shell closures, not fitted parameters.
    magic = np.array([2, 8, 20, 28, 50, 82, 126, 184])
    vp = np.min(np.abs(Z[:, None] - magic), axis=1)
    vn = np.min(np.abs(N[:, None] - magic), axis=1)
    v = vp + vn
    symmetry = (NZ_diff**2 + 2 * np.abs(NZ_diff)) / A**2

    return (
        15.668764209779214
        - 18.019455012881433 / a13
        - 0.7180767988384326 * Z * (Z - 1) / (A * a13)
        - (28.55767514446237 - 38.30099844646253 / a13) * symmetry
        + 12.021755026335656 * pair / A**1.5
        + 0.9007000389492739 * (Z / A)**2
        + (-0.9190925369769245 * v + 0.018088038741614083 * v**2) / A
    )