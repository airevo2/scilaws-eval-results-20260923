"""Gravity law with distance-dependent GDP elasticities and a smooth low-flow floor."""
import numpy as np

USED_INPUTS = ["log_gdp_o", "log_gdp_d", "log_dist", "contig", "comlang_off", "col_dep_ever", "fta_wto"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    origin = X[:, 0]
    destination = X[:, 1]
    distance = X[:, 2]
    links = X[:, 3] + X[:, 4] + X[:, 5] + X[:, 6]
    gravity = (
        23.1513755
        + 0.00604739586 * origin
        - 0.307604903 * destination
        - 6.39638840 * distance
        + 0.876788357 * links
        + 0.147406544 * (origin + destination) * distance
    )
    return np.logaddexp(gravity, 1.80296163)