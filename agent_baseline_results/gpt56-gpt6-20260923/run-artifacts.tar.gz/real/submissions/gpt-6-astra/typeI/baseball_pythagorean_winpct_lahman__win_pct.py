"""Run-ratio win model with scoring-environment and season-length adjustment."""
import numpy as np

USED_INPUTS = ["R", "RA", "G"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    R = X[:, 0]
    RA = X[:, 1]
    G = X[:, 2]
    exponent = ((R + RA) / G) ** 0.34757086
    exponent = exponent * G / (G + 22.8367041)
    return 1.0 / (1.0 + np.exp(-exponent * np.log(R / RA)))