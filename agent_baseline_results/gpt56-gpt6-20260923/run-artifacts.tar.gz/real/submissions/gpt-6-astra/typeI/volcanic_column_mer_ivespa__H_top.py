"""Quarter-power buoyant-plume scaling with an additive height correction."""
import numpy as np

USED_INPUTS = ["MER_kg_per_s"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    mer = X[:, 0]
    return 1.05604979 + 0.21776127 * np.power(mer, 0.25)