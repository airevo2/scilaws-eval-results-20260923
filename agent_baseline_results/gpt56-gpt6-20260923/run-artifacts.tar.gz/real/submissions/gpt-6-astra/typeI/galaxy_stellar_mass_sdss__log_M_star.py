"""Colour-dependent stellar mass-to-light relation with a spectral-slope K correction."""
import numpy as np

USED_INPUTS = ["g", "i", "z_mag", "redshift", "DM"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    g, i, z_mag, redshift, DM = X.T
    colour = g - i
    # Non-fitted SDSS g and i effective wavelengths, in Angstroms.
    spectral_slope = colour / (2.5 * np.log10(7481.0 / 4686.0))
    luminosity = (
        0.4 * (DM - z_mag)
        + (1.0 - spectral_slope) * np.log10(1.0 + redshift)
    )
    return (
        luminosity
        + 1.128334279503685
        + 0.7156988011019715 * colour / (1.0 + redshift)
    )