"""Terminal ejecta speed proportional to the lighter star's escape-speed scale."""
import numpy as np

USED_INPUTS = ["C2"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    return 0.54724805 * np.sqrt(X[:, 0])