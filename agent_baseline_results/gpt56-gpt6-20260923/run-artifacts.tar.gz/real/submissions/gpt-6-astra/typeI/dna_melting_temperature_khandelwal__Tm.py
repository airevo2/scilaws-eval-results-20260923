"""Five-parameter melting law with concentration and saturating salt corrections."""
import numpy as np

USED_INPUTS = ["E", "N", "salt_M", "dna_conc_M"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    E = X[:, 0]
    N = X[:, 1]
    salt = X[:, 2]
    concentration = X[:, 3]

    reference_kelvin = (
        273.15
        + 29.6002922
        + 28.7100922 * np.sqrt(E)
        + 31.4715350 * np.log(concentration / 4.0) / (N - 1.0)
    )
    inverse_kelvin = (
        1.0 / reference_kelvin
        - 0.000628350624 / E
        * np.log(salt / (1.0 + np.exp(1.17646817) * salt))
    )
    return 1.0 / inverse_kelvin - 273.15