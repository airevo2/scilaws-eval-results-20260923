"""Area–length scaling with an explicit terminal-reach contribution."""
import numpy as np

USED_INPUTS = ["upland_area_skm", "catch_area_skm", "segment_length_km"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    A = X[:, 0]
    A_c = X[:, 1]
    L_s = X[:, 2]
    upstream_fraction = np.maximum(1.0 - A_c / A, 0.0)
    return L_s + 1.415043589911009 * A**0.5684052738851498 * upstream_fraction