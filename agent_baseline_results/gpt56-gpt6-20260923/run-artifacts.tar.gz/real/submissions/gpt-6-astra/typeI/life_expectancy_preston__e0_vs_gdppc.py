"""Saturating life expectancy as an exponential of inverse income."""
import numpy as np

USED_INPUTS = ["gdppc"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    income = X[:, 0]
    return 73.42562853 * np.exp(-39.02451400 / income)