"""Gutenberg–Richter cumulative earthquake frequency law."""
import numpy as np

USED_INPUTS = ["M_threshold"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    return 8.13524295 - 1.01912968 * X[:, 0]