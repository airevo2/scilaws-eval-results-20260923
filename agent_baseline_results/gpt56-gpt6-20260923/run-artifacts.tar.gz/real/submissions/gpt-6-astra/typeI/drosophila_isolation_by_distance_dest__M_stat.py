"""Nonnegative logarithmic isolation-by-distance relationship."""
import numpy as np

USED_INPUTS = ["log_distance_km"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    return np.maximum(0.0, 0.01892096 * X[:, 0] - 0.08523478)