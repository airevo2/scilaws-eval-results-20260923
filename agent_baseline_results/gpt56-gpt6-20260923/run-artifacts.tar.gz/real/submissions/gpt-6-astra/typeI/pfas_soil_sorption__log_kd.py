"""Hydrophobic sorption with a background sorption domain and a speciation correction."""
import numpy as np

USED_INPUTS = ["pKa1", "log_Kow", "pH", "foc"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    pKa1 = X[:, 0]
    log_Kow = X[:, 1]
    pH = X[:, 2]
    foc = X[:, 3]
    neutral_fraction = 1.0 / (1.0 + np.power(10.0, pH - pKa1))
    return (
        0.38933495 * log_Kow
        + np.log10(foc + 10.0 ** (-1.61555214))
        + np.sqrt(neutral_fraction)
    )