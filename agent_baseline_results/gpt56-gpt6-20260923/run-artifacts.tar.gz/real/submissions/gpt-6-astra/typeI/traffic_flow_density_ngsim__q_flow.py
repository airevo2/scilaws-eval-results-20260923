"""Saturating density–flow law with corridor- and time-dependent free-flow speed."""
import numpy as np

USED_INPUTS = ["k_veh_km_lane", "corridor", "t_bin_s"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    k = np.maximum(X[:, 0], 0.0)
    corridor = X[:, 1]
    t = X[:, 2]
    speed = np.maximum(
        76.99239 - 28.95858 * corridor - 0.00002943120 * t**2,
        0.0
    )
    return -3314.42914 * np.expm1(-k * speed / 3314.42914)