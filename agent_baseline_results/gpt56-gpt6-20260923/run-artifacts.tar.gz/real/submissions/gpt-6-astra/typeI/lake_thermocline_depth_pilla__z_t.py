"""Saturating depth dependence plus logarithmic wind-fetch deepening."""
import numpy as np

USED_INPUTS = ["A_s_km2", "Z_max_m"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    area = X[:, 0]
    depth = X[:, 1]
    thermocline = (
        9.83322118 * (-np.expm1(-depth / (2 * 9.83322118)))
        + 0.71003064 * np.log1p(area)
    )
    return np.minimum(depth / 2, thermocline)