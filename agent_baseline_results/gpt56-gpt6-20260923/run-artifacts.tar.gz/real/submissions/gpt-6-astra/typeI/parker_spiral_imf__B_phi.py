"""Saturating empirical relation between radial and azimuthal magnetic fields."""
import numpy as np

USED_INPUTS = ["B_r_nT"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    return -3.4550084991900216 * np.tanh(X[:, 0] / 3.4550084991900216)