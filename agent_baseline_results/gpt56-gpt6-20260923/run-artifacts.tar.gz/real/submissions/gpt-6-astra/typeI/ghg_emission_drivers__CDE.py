"""Population-scaled emissions with diminishing income response and quadratic temperature dependence."""
import numpy as np

USED_INPUTS = ["GDP", "TP", "AP", "DP", "UR", "AT"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    GDP = X[:, 0]
    TP = X[:, 1]
    AP = X[:, 2]
    DP = X[:, 3]
    UR = X[:, 4]
    AT = X[:, 5]
    return (
        8.445303148716582e-5
        * TP
        * np.log1p(GDP / 3355.450088616884)
        * AP ** 3.79994782
        * DP ** (-0.06775251)
        * UR ** 0.43806825
        * (1.0 + 0.0035268693424571358 * (AT - 20.0) ** 2)
    )