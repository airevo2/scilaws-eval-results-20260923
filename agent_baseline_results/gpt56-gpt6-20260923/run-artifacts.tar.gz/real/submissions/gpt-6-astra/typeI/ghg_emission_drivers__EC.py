"""Population-extensive energy demand with smoothly diminishing income elasticity."""
import numpy as np

USED_INPUTS = ["GDP", "TP", "AP", "DP", "UR"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    GDP, TP, AP, DP, UR = X.T
    return (
        3.9355120000152935e-14
        * TP
        * GDP**0.98035991
        * AP**4.44644590
        * DP**(-0.05008323)
        * UR**0.39549082
        / (1.0 + GDP / 2942.492865719392)**(0.98035991 - 0.5)
    )