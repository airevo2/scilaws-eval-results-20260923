"""Compactness-threshold disk law with a total-mass correction."""
import numpy as np

USED_INPUTS = ["M1", "M2", "C1"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    M1 = X[:, 0]
    M2 = X[:, 1]
    C1 = X[:, 2]
    margin = np.maximum(
        0.273295875 - C1 - 0.03171145 * (M1 + M2), 0.0
    )
    return M1 * np.maximum(
        0.00036363636, 16.36552471 * margin**1.57055332
    )