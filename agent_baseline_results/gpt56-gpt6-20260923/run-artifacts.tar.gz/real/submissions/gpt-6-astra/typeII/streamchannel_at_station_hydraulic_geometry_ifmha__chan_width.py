"""At-station hydraulic geometry: width follows a locally calibrated discharge power law."""
import numpy as np
from scipy.optimize import least_squares

USED_INPUTS = ["chan_discharge"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {"a": {"init": None}, "b": {"init": None}}

def fit(X_fit, y_fit):
    q = np.asarray(X_fit, dtype=float)[:, 0]
    w = np.asarray(y_fit, dtype=float).reshape(-1)
    valid = np.isfinite(q) & np.isfinite(w) & (q > 0) & (w > 0)
    q, w = q[valid], w[valid]
    if w.size == 0:
        return {"a": 1.0, "b": 0.0}

    x, y = np.log(q), np.log(w)
    center = float(np.mean(x))
    z = x - center
    if w.size < 3 or np.ptp(x) < 1e-10:
        return {"a": float(np.median(w)), "b": 0.0}

    A = np.column_stack((np.ones_like(z), z))
    p = np.linalg.lstsq(A, y, rcond=None)[0]
    p[1] = np.clip(p[1], 0.0, 1.0)
    p[0] = np.median(y - p[1] * z)
    residual = A @ p - y
    scale = max(float(np.median(np.abs(residual - np.median(residual)))), 1e-8)

    try:
        result = least_squares(
            lambda theta: A @ theta - y,
            p,
            bounds=([-np.inf, 0.0], [np.inf, 1.0]),
            loss="soft_l1",
            f_scale=scale,
            max_nfev=300,
        )
        if np.all(np.isfinite(result.x)):
            p = result.x
    except Exception:
        pass

    return {"a": float(np.exp(np.clip(p[0] - p[1] * center, -700, 700))),
            "b": float(p[1])}

def predict(X, a, b):
    q = np.maximum(np.asarray(X, dtype=float)[:, 0], np.finfo(float).tiny)
    return np.exp(np.clip(np.log(max(a, np.finfo(float).tiny)) + b * np.log(q), -700, 700))