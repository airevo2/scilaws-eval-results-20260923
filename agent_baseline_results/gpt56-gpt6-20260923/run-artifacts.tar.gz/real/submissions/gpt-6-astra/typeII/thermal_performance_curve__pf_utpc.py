"""An asymmetric Gaussian thermal-performance curve with separately fitted cold- and hot-side breadths."""
import numpy as np
from scipy.optimize import least_squares

USED_INPUTS = ["temperature"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {
    "amplitude": {"init": None},
    "optimum": {"init": None},
    "width_low": {"init": None},
    "width_high": {"init": None},
}

def _curve(t, amplitude, optimum, width_low, width_high):
    width = np.where(t < optimum, width_low, width_high)
    z = (t - optimum) / np.maximum(width, np.finfo(float).tiny)
    return amplitude * np.exp(-0.5 * np.minimum(np.abs(z), 40.0) ** 2)

def fit(X_fit, y_fit):
    t = np.asarray(X_fit, dtype=float)[:, 0]
    y = np.asarray(y_fit, dtype=float).reshape(-1)
    valid = np.isfinite(t) & np.isfinite(y)
    t, y = t[valid], y[valid]

    if len(y) == 0:
        return dict(amplitude=0.0, optimum=0.0, width_low=1.0, width_high=1.0)

    center = float((np.min(t) + np.max(t)) / 2.0)
    span = max(float(np.ptp(t)), 1.0e-6)
    scale = float(np.max(np.abs(y)))
    if scale == 0.0:
        return dict(amplitude=0.0, optimum=center, width_low=span, width_high=span)

    x = (t - center) / span
    v = y / scale

    if len(y) < 4 or np.ptp(t) == 0.0:
        return dict(
            amplitude=max(float(np.mean(y)), 0.0),
            optimum=center,
            width_low=span,
            width_high=span,
        )

    order = np.argsort(x)
    xx, vv = x[order], v[order]
    gaps = xx[2:] - xx[:-2]
    weights = np.divide(
        xx[1:-1] - xx[:-2],
        gaps,
        out=np.full_like(gaps, 0.5),
        where=gaps > 0.0,
    )
    differences = (
        vv[1:-1] - (1.0 - weights) * vv[:-2] - weights * vv[2:]
    ) / np.sqrt(1.0 + weights**2 + (1.0 - weights)**2)
    noise = float(np.sqrt(np.mean(differences**2)))
    breadth_penalty = noise / np.sqrt(max(len(y) / 2.0, 1.0))

    def residual(p):
        errors = _curve(x, *p) - v
        return np.concatenate((
            errors,
            [
                noise * np.log(p[2] / p[3]),
                breadth_penalty / p[2],
                breadth_penalty / p[3],
            ],
        ))

    peak = float(x[np.argmax(v)])
    starts = [
        [1.0, peak, 0.5, 0.4],
        [1.0, 0.0, 0.4, 0.4],
    ]
    lower = [0.0, -1.0, 0.03, 0.03]
    upper = [1.5, 1.0, 5.0, 5.0]
    best = np.array([max(float(np.mean(v)), 0.0), 0.0, 1.0, 1.0])
    best_cost = np.inf

    for start in starts:
        try:
            result = least_squares(
                residual, start, bounds=(lower, upper),
                max_nfev=250, ftol=1.0e-8, xtol=1.0e-8, gtol=1.0e-8,
            )
            if np.all(np.isfinite(result.x)) and result.cost < best_cost:
                best = result.x
                best_cost = result.cost
        except Exception:
            pass

    return {
        "amplitude": float(scale * best[0]),
        "optimum": float(center + span * best[1]),
        "width_low": float(span * best[2]),
        "width_high": float(span * best[3]),
    }

def predict(X, amplitude, optimum, width_low, width_high):
    t = np.asarray(X, dtype=float)[:, 0]
    return _curve(t, amplitude, optimum, width_low, width_high)