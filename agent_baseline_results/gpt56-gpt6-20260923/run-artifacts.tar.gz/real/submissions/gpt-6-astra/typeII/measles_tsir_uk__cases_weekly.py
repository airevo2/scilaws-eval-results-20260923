"""State-dependent mean reversion with a fitted periodic transmission trough."""
import numpy as np
from scipy.optimize import least_squares

USED_INPUTS = ["cases_prev", "biweek"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {
    "a": {"init": None},
    "b": {"init": None},
    "c": {"init": None},
    "phase": {"init": None},
    "width": {"init": None},
}

def _design(X, phase, width):
    I = np.maximum(np.asarray(X[:, 0], dtype=float), 0.0)
    s = np.asarray(X[:, 1], dtype=float)
    active = I / (1.0 + I)
    state = np.log1p(I) + (I > 0.0)
    distance = np.sin(np.pi * (s - phase) / 26.0)
    seasonal = active * np.exp(-(distance / max(width, 1e-8)) ** 2)
    return np.column_stack((np.ones(I.size), state, seasonal))

def fit(X_fit, y_fit):
    X = np.asarray(X_fit, dtype=float)
    y = np.asarray(y_fit, dtype=float).reshape(-1)
    valid = np.isfinite(y) & np.all(np.isfinite(X[:, :2]), axis=1)
    X, y = X[valid], y[valid]
    if y.size == 0:
        return {"a": 0.0, "b": 0.0, "c": 0.0,
                "phase": 17.0, "width": 0.25}

    def linear_fit(phase, width):
        F = _design(X, phase, width)
        A = np.vstack((F, np.diag([0.0, 1.0, 1.0])))
        coefficients = np.linalg.lstsq(
            A, np.concatenate((y, np.zeros(3))), rcond=None
        )[0]
        return coefficients, F

    def residual(p):
        coefficients, F = linear_fit(p[0], p[1])
        return np.concatenate((F @ coefficients - y, coefficients[1:]))

    phase, width = 17.0, 0.25
    try:
        result = least_squares(
            residual, [phase, width],
            bounds=([0.0, 0.05], [26.0, 2.0]),
            max_nfev=150,
        )
        if np.all(np.isfinite(result.x)):
            phase, width = map(float, result.x)
        coefficients, _ = linear_fit(phase, width)
        if not np.all(np.isfinite(coefficients)):
            raise ValueError("Nonfinite calibration")
    except Exception:
        coefficients = np.array([float(np.mean(y)), 0.0, 0.0])

    return {
        "a": float(coefficients[0]),
        "b": float(coefficients[1]),
        "c": float(coefficients[2]),
        "phase": float(phase),
        "width": float(width),
    }

def predict(X, a, b, c, phase, width):
    return _design(np.asarray(X, dtype=float), phase, width) @ np.array([a, b, c])