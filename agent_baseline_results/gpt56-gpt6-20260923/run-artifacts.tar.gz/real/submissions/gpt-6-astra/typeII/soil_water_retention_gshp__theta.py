"""Four-parameter, monotone retention curve with a smooth logarithmic dry-end tail."""
import numpy as np
from scipy.optimize import least_squares
from scipy.special import expit

USED_INPUTS = ["lab_head_m"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {
    "theta_s": {"init": None},
    "h0": {"init": None},
    "n": {"init": None},
    "m": {"init": None},
}

def _evaluate(t, p, jacobian=False):
    theta_s, log_h0, log_n, log_m = p
    n, m = np.exp(log_n), np.exp(log_m)
    q = t - log_h0
    u = np.arcsinh(np.exp(np.clip(q, -700.0, 700.0)))
    z = n * np.log(np.maximum(u, 1e-300))
    L = np.logaddexp(0.0, z)
    attenuation = np.exp(-m * L)
    prediction = theta_s * attenuation
    if not jacobian:
        return prediction
    w = m * expit(z)
    return np.column_stack((
        attenuation,
        prediction * w * n * np.sqrt(expit(2.0 * q)) / np.maximum(u, 1e-300),
        -prediction * w * z,
        -prediction * m * L,
    ))

def fit(X_fit, y_fit):
    h = np.asarray(X_fit, dtype=float)[:, 0]
    y = np.asarray(y_fit, dtype=float).reshape(-1)
    good = np.isfinite(h) & np.isfinite(y) & (h >= 0)
    h, y = h[good], y[good]
    if len(y) == 0:
        return {"theta_s": 0.0, "h0": 1.0, "n": 1.0, "m": 1.0}

    t = np.log(np.maximum(h, 1e-300))
    ymax = max(float(np.max(y)), 1e-8)
    upper_s = min(1.0, 1.5 * ymax)
    initial_s = min(ymax, upper_s * (1.0 - 1e-8))
    center = float(np.clip(np.median(t), -24.0, 24.0))
    lower = np.array([0.0, -25.0, -5.0, -8.0])
    upper = np.array([upper_s, 25.0, np.log(20.0), 4.0])

    best = np.array([initial_s, center, 0.0, -1.0])
    best_error = np.inf
    for log_n, log_m in ((0.0, -1.0), (1.0, -2.0)):
        initial = np.array([initial_s, center, log_n, log_m])
        try:
            result = least_squares(
                lambda p: _evaluate(t, p) - y,
                initial,
                jac=lambda p: _evaluate(t, p, True),
                bounds=(lower, upper),
                max_nfev=300,
                x_scale="jac",
            )
            error = float(np.sum(result.fun ** 2))
            if np.isfinite(error) and error < best_error:
                best, best_error = result.x, error
        except (ValueError, FloatingPointError, RuntimeError):
            pass

    return {
        "theta_s": float(best[0]),
        "h0": float(np.exp(best[1])),
        "n": float(np.exp(best[2])),
        "m": float(np.exp(best[3])),
    }

def predict(X, theta_s, h0, n, m):
    h = np.asarray(X, dtype=float)[:, 0]
    t = np.log(np.maximum(h, 1e-300))
    p = np.array([theta_s, np.log(h0), np.log(n), np.log(m)])
    return _evaluate(t, p)