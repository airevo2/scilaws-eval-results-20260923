"""Modified Sellmeier dispersion with a UV resonance and an infrared correction."""
import numpy as np
from scipy.optimize import least_squares, lsq_linear

USED_INPUTS = ["wavelength_um"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {
    "A": {"init": None},
    "B": {"init": None},
    "C": {"init": None},
    "D": {"init": None},
}

def predict(X, A, B, C, D):
    t = np.asarray(X, dtype=float)[:, 0] ** 2
    denominator = t - C
    eps = np.finfo(float).eps
    denominator = np.where(
        np.abs(denominator) < eps,
        np.where(denominator < 0, -eps, eps),
        denominator,
    )
    return np.sqrt(np.maximum(A + B / denominator - D * t, eps))

def fit(X_fit, y_fit):
    X = np.asarray(X_fit, dtype=float)
    y = np.asarray(y_fit, dtype=float).reshape(-1)
    valid = np.isfinite(X[:, 0]) & np.isfinite(y) & (X[:, 0] > 0)
    X, y = X[valid], y[valid]
    if len(y) == 0:
        return {"A": 1.0, "B": 0.0, "C": 0.0, "D": 0.0}

    t = X[:, 0] ** 2
    cmax = float(np.min(t)) * (1.0 - np.sqrt(np.finfo(float).eps))
    best = np.array([max(float(np.median(y ** 2)), 1.0), 0.0, 0.0, 0.0])
    best_error = np.inf

    def residual(p):
        return predict(X, p[0], p[1], p[2], p[3]) - y

    for fraction in (0.0, 0.25, 0.6):
        c0 = fraction * cmax
        H = np.column_stack((np.ones(len(t)), 1.0 / (t - c0), -t))
        try:
            linear = lsq_linear(
                H / np.maximum(y[:, None], np.finfo(float).eps),
                y,
                bounds=([1.0, 0.0, 0.0], [np.inf, np.inf, np.inf]),
            ).x
            p0 = np.array([linear[0], linear[1], c0, linear[2]])
            result = least_squares(
                residual, p0,
                bounds=([1.0, 0.0, 0.0, 0.0],
                        [np.inf, np.inf, cmax, np.inf]),
                x_scale="jac",
                max_nfev=500,
                ftol=1e-10,
                xtol=1e-10,
                gtol=1e-10,
            )
            error = float(np.sum(residual(result.x) ** 2))
            if np.isfinite(error) and error < best_error:
                best, best_error = result.x, error
        except Exception:
            continue

    return dict(zip(("A", "B", "C", "D"), map(float, best)))