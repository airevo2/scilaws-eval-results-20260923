"""Nonnegative baseline plus a periodic Gaussian orientation-tuning peak."""
import numpy as np
from scipy.optimize import least_squares

USED_INPUTS = ["orientation_deg"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {
    "baseline": {"init": None},
    "amplitude": {"init": None},
    "preferred_orientation": {"init": None},
    "width": {"init": None},
}

def _peak(theta, preferred_orientation, width):
    distance = (theta - preferred_orientation + 90.0) % 180.0 - 90.0
    return np.exp(-0.5 * (distance / max(float(width), 1e-8)) ** 2)

def fit(X_fit, y_fit):
    theta = np.asarray(X_fit, dtype=float)[:, 0]
    y = np.asarray(y_fit, dtype=float).reshape(-1)
    valid = np.isfinite(theta) & np.isfinite(y)
    theta, y = theta[valid] % 180.0, np.maximum(y[valid], 0.0)

    if len(y) == 0:
        return dict(baseline=0.0, amplitude=0.0,
                    preferred_orientation=0.0, width=30.0)

    scale = float(np.max(y))
    fallback = dict(baseline=float(np.mean(y)), amplitude=0.0,
                    preferred_orientation=float(theta[np.argmax(y)]),
                    width=30.0)
    if len(y) < 5 or scale <= 0.0:
        return fallback

    z = y / scale
    initial_baseline = float(np.quantile(z, 0.2))
    preferred = float(theta[np.argmax(z)])

    def residual(p):
        return p[0] + p[1] * _peak(theta, p[2], p[3]) - z

    best = None
    for initial_width in (18.0, 36.0):
        try:
            result = least_squares(
                residual,
                [initial_baseline, 1.0 - initial_baseline,
                 preferred, initial_width],
                bounds=([0.0, 0.0, -180.0, 10.0],
                        [2.0, 1.0, 360.0, 180.0]),
                max_nfev=160,
                x_scale=[1.0, 1.0, 30.0, 30.0],
            )
            if np.all(np.isfinite(result.x)):
                if best is None or result.cost < best.cost:
                    best = result
        except Exception:
            pass

    if best is None:
        return fallback

    baseline, amplitude, preferred, width = best.x
    residual_variance = float(np.sum(best.fun ** 2)) / max(len(z) - 4, 1)
    explained = float(np.sum((z - np.mean(z)) ** 2) - np.sum(best.fun ** 2))
    shrinkage = max(0.0, 1.0 - 2.0 * residual_variance / max(explained, 1e-12))
    baseline = shrinkage * baseline + (1.0 - shrinkage) * float(np.mean(z))
    amplitude *= shrinkage

    return {
        "baseline": float(scale * baseline),
        "amplitude": float(scale * amplitude),
        "preferred_orientation": float(preferred % 180.0),
        "width": float(width),
    }

def predict(X, baseline, amplitude, preferred_orientation, width):
    theta = np.asarray(X, dtype=float)[:, 0]
    return baseline + amplitude * _peak(theta, preferred_orientation, width)