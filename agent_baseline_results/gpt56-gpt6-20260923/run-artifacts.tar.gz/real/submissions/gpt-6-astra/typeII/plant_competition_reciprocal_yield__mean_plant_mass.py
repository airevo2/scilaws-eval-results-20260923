"""Generalized reciprocal competition law with positive, density-dependent mass."""
import numpy as np
from scipy.optimize import minimize, minimize_scalar

USED_INPUTS = ["density"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {
    "w1": {"init": None},
    "competition": {"init": None},
    "exponent": {"init": None},
}

def fit(X_fit, y_fit):
    N = np.asarray(X_fit, dtype=float)[:, 0]
    y = np.asarray(y_fit, dtype=float).reshape(-1)
    valid = np.isfinite(N) & np.isfinite(y) & (N > 0) & (y > 0)
    N, y = N[valid], y[valid]
    if len(y) == 0:
        return {"w1": 0.0, "competition": 0.0, "exponent": 1.0}

    def calibrate(c, b):
        log_shape = -b * np.log1p(c * (N - 1.0))
        w1 = np.mean(y * np.exp(-log_shape))
        objective = np.log(w1) + np.mean(log_shape)
        return float(objective), float(w1)

    if np.unique(N).size == 1:
        return {
            "w1": float(np.mean(y) * N[0]),
            "competition": 1.0,
            "exponent": 1.0,
        }

    reciprocal = minimize_scalar(
        lambda c: calibrate(c, 1.0)[0],
        bounds=(0.0, 1.0),
        method="bounded",
    )
    c = float(reciprocal.x)
    candidates = [(calibrate(c, 1.0)[0], c, 1.0)]
    candidates.extend([
        (calibrate(0.0, 1.0)[0], 0.0, 1.0),
        (calibrate(1.0, 1.0)[0], 1.0, 1.0),
    ])

    if np.unique(N).size >= 3:
        for start in [(c, 1.0), (1.0, 0.5)]:
            try:
                result = minimize(
                    lambda p: calibrate(p[0], p[1])[0],
                    start,
                    method="L-BFGS-B",
                    bounds=[(0.0, 1.0), (0.0, 1.0)],
                    options={"maxiter": 200, "ftol": 1e-12},
                )
                if np.isfinite(result.fun):
                    candidates.append((
                        float(result.fun),
                        float(result.x[0]),
                        float(result.x[1]),
                    ))
            except Exception:
                pass

    _, c, b = min(candidates, key=lambda item: item[0])
    return {
        "w1": calibrate(c, b)[1],
        "competition": c,
        "exponent": b,
    }

def predict(X, w1, competition, exponent):
    N = np.maximum(np.asarray(X, dtype=float)[:, 0], np.finfo(float).eps)
    return w1 * np.exp(
        -exponent * np.log1p(competition * (N - 1.0))
    )