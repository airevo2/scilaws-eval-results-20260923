"""Weibull choice law: log hazard is linear in log amount advantage and log delay."""
import numpy as np
from scipy.optimize import least_squares

USED_INPUTS = ["log_amount_ratio", "delay_diff_days"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {
    "intercept": {"init": None},
    "amount_exponent": {"init": None},
    "delay_exponent": {"init": None},
}

def _features(X):
    X = np.asarray(X, dtype=float)
    amount = np.log(np.maximum(X[:, 0], 1e-12))
    delay = np.log(np.maximum(X[:, 3], 1e-12))
    return np.column_stack((amount, -delay))

def _response(z):
    hazard = np.exp(np.clip(z, -700.0, 6.0))
    return -np.expm1(-hazard)

def fit(X_fit, y_fit):
    F = _features(X_fit)
    y = np.clip(np.asarray(y_fit, dtype=float).reshape(-1), 0.0, 1.0)
    valid = np.isfinite(F).all(axis=1) & np.isfinite(y)
    F, y = F[valid], y[valid]

    if len(y) == 0:
        return {"intercept": 0.0, "amount_exponent": 0.0,
                "delay_exponent": 0.0}

    center = F.mean(axis=0)
    scale = F.std(axis=0)
    scale = np.where(scale > 1e-10, scale, 1.0)
    Z = np.column_stack((np.ones(len(y)), (F - center) / scale))

    mean_y = np.clip(y.mean(), 1e-8, 1.0 - 1e-8)
    baseline = np.log(-np.log1p(-mean_y))
    fallback = np.array([baseline, 0.0, 0.0])
    best = fallback.copy()
    best_loss = np.sum((_response(Z @ best) - y) ** 2)

    transformed = np.log(-np.log1p(-np.clip(y, 0.01, 0.99)))
    initial = np.linalg.lstsq(Z, transformed, rcond=None)[0]
    initial[1:] = np.maximum(initial[1:], 0.0)

    def residual(p):
        return _response(Z @ p) - y

    def jacobian(p):
        z = Z @ p
        hazard = np.exp(np.clip(z, -700.0, 6.0))
        slope = hazard * np.exp(-hazard)
        slope[(z < -700.0) | (z > 6.0)] = 0.0
        return slope[:, None] * Z

    for start in (initial, fallback):
        try:
            result = least_squares(
                residual, start, jac=jacobian,
                bounds=([-np.inf, 0.0, 0.0], [np.inf, np.inf, np.inf]),
                max_nfev=300
            )
            loss = np.sum(residual(result.x) ** 2)
            if np.isfinite(loss) and loss < best_loss:
                best, best_loss = result.x, loss
        except Exception:
            pass

    slopes = best[1:] / scale
    intercept = best[0] - np.dot(center, slopes)
    return {
        "intercept": float(intercept),
        "amount_exponent": float(slopes[0]),
        "delay_exponent": float(slopes[1]),
    }

def predict(X, intercept, amount_exponent, delay_exponent):
    F = _features(X)
    z = intercept + amount_exponent * F[:, 0] + delay_exponent * F[:, 1]
    return _response(z)