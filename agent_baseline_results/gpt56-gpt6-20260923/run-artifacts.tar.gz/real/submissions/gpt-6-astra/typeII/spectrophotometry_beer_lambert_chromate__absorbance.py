"""Beer–Lambert scaling with a smooth concentration-dependent absorptivity."""
import numpy as np

USED_INPUTS = ["concentration", "path_length"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {"a": {"init": None}, "b": {"init": None}}

def fit(X_fit, y_fit):
    X_fit = np.asarray(X_fit, dtype=float)
    y = np.asarray(y_fit, dtype=float).reshape(-1)
    c = X_fit[:, 0]
    l = X_fit[:, 1]
    z = c * l
    h = np.log1p(np.maximum(c, 0.0))
    valid = np.isfinite(y) & np.isfinite(z) & np.isfinite(h)
    z, h, y = z[valid], h[valid], y[valid]
    if len(y) == 0 or np.dot(z, z) == 0:
        return {"a": 0.0, "b": 0.0}
    design = np.column_stack((z, z * h))
    try:
        if np.linalg.matrix_rank(design) < 2:
            a = np.dot(z, y) / np.dot(z, z)
            b = 0.0
        else:
            a, b = np.linalg.lstsq(design, y, rcond=None)[0]
        return {"a": float(a), "b": float(b)}
    except np.linalg.LinAlgError:
        return {"a": float(np.dot(z, y) / np.dot(z, z)), "b": 0.0}

def predict(X, a, b):
    X = np.asarray(X, dtype=float)
    c = np.maximum(X[:, 0], 0.0)
    l = np.maximum(X[:, 1], 0.0)
    return c * l * np.maximum(a + b * np.log1p(c), 0.0)