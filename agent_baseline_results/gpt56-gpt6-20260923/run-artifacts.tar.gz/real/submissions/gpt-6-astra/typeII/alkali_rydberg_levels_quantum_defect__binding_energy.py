"""Extended Ritz quantum-defect law with three locally fitted coefficients and the physical Rydberg constant."""
import numpy as np
from scipy.constants import Rydberg
from scipy.optimize import least_squares

USED_INPUTS = ["n_qm"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {
    "delta0": {"init": None},
    "delta2": {"init": None},
    "delta4": {"init": None},
}

def predict(X, delta0, delta2, delta4):
    n = np.asarray(X, dtype=float)[:, 0]
    s = np.maximum(n - delta0, 1e-6)
    defect = delta0 + delta2 / s**2 + delta4 / s**4
    effective_n = np.maximum(n - defect, 1e-6)
    return (Rydberg / 100.0) / effective_n**2

def fit(X_fit, y_fit):
    X = np.asarray(X_fit, dtype=float)
    y = np.asarray(y_fit, dtype=float).reshape(-1)
    valid = np.isfinite(X[:, 0]) & np.isfinite(y) & (y > 0)
    X, y = X[valid], y[valid]

    if len(y) == 0:
        return {"delta0": 0.0, "delta2": 0.0, "delta4": 0.0}

    n = X[:, 0]
    observed_defect = n - np.sqrt((Rydberg / 100.0) / y)
    upper = float(np.min(n) - 1e-3)
    initial = np.array([
        min(float(np.median(observed_defect)), upper - 1e-3),
        0.0,
        0.0,
    ])

    def residual(p):
        return predict(X, *p) - y

    best = initial
    try:
        result = least_squares(
            residual,
            initial,
            bounds=([-np.inf, -np.inf, -np.inf],
                    [upper, np.inf, np.inf]),
            x_scale="jac",
            max_nfev=1000,
            ftol=1e-11,
            xtol=1e-11,
            gtol=1e-10,
        )
        if np.all(np.isfinite(result.x)):
            if np.sum(residual(result.x)**2) <= np.sum(residual(best)**2):
                best = result.x
    except (ValueError, FloatingPointError, np.linalg.LinAlgError):
        pass

    return {
        "delta0": float(best[0]),
        "delta2": float(best[1]),
        "delta4": float(best[2]),
    }