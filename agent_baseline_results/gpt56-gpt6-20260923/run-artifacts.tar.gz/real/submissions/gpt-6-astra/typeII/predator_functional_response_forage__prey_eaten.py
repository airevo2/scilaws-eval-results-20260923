"""A saturating encounter rate with finite-prey depletion: N_a = N[1-exp(-a/(1+aN/C))]."""
import numpy as np
from scipy.optimize import least_squares

USED_INPUTS = ["prey_density"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {
    "a": {"init": None},
    "C": {"init": None},
}

def predict(X, a, C):
    N = np.maximum(np.asarray(X, dtype=float)[:, 0], 0.0)
    a = max(float(a), 0.0)
    C = max(float(C), np.finfo(float).tiny)
    return -N * np.expm1(-a / (1.0 + a * N / C))

def fit(X_fit, y_fit):
    N = np.asarray(X_fit, dtype=float)[:, 0]
    y = np.asarray(y_fit, dtype=float).reshape(-1)
    valid = np.isfinite(N) & np.isfinite(y) & (N > 0)
    N, y = N[valid], y[valid]
    if N.size == 0 or np.max(y) <= 0:
        return {"a": 0.0, "C": 1.0}

    scale = max(float(np.max(N)), np.finfo(float).tiny)
    x, z = N / scale, y / scale
    fraction = np.clip(
        np.dot(x, z) / max(np.dot(x, x), np.finfo(float).tiny),
        1e-6, 1.0 - 1e-6,
    )
    initial = np.log([
        -np.log1p(-fraction),
        max(float(np.max(z)), 1e-6),
    ])
    initial = np.clip(initial, -18.0, 18.0)

    def residual(theta):
        a, c = np.exp(theta)
        return -x * np.expm1(-a / (1.0 + a * x / c)) - z

    theta = initial
    try:
        result = least_squares(
            residual, initial, bounds=(-18.0, 18.0), max_nfev=250
        )
        if np.all(np.isfinite(result.x)):
            theta = result.x
    except (ValueError, FloatingPointError, RuntimeError):
        pass

    a, c = np.exp(theta)
    return {"a": float(a), "C": float(c * scale)}