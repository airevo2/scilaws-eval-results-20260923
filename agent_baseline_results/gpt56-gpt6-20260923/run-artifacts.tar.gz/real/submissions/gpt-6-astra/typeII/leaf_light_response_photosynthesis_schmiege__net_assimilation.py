"""Non-rectangular hyperbola with cluster-specific quantum yield, gross capacity, respiration, and curvature."""
import numpy as np
from scipy.optimize import least_squares

USED_INPUTS = ["Qin"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {
    "alpha": {"init": None},
    "capacity": {"init": None},
    "respiration": {"init": None},
    "theta": {"init": None},
}

def predict(X, alpha, capacity, respiration, theta):
    light = np.maximum(np.asarray(X, dtype=float)[:, 0], 0.0)
    excitation = alpha * light
    total = excitation + capacity
    discriminant = np.maximum(
        (excitation - capacity) ** 2
        + 4.0 * (1.0 - theta) * excitation * capacity,
        0.0,
    )
    gross = 2.0 * excitation * capacity / np.maximum(
        total + np.sqrt(discriminant), np.finfo(float).tiny
    )
    return gross - respiration

def fit(X_fit, y_fit):
    X = np.asarray(X_fit, dtype=float)
    y = np.asarray(y_fit, dtype=float).reshape(-1)
    valid = np.isfinite(X[:, 0]) & np.isfinite(y)
    X, y = X[valid], y[valid]
    if len(y) == 0:
        return dict(alpha=0.05, capacity=1.0, respiration=0.0, theta=0.5)

    order = np.argsort(X[:, 0])
    low = order[:max(3, len(y) // 2)]
    slope = 0.05
    if np.ptp(X[low, 0]) > 0:
        design = np.column_stack((X[low, 0], np.ones(len(low))))
        slope = float(np.linalg.lstsq(design, y[low], rcond=None)[0][0])

    alpha0 = float(np.clip(slope, 0.001, 0.5))
    respiration0 = float(np.clip(-np.min(y), 0.01, 4.0))
    capacity0 = max(float(np.max(y)) + respiration0, float(np.ptp(y)), 0.1)
    upper_capacity = max(100.0, 20.0 * capacity0)
    upper_respiration = max(5.0, 2.0 * respiration0)

    lower = [1e-7, 1e-5, 0.0, 0.0]
    upper = [1.0, upper_capacity, upper_respiration, 1.0]
    best = np.array([alpha0, capacity0, respiration0, 0.5])
    best_cost = np.inf

    def residual(p):
        return predict(X, *p) - y

    for curvature0 in (0.3, 0.8):
        initial = [alpha0, capacity0, respiration0, curvature0]
        try:
            result = least_squares(
                residual, initial, bounds=(lower, upper),
                x_scale="jac", max_nfev=500,
                ftol=1e-9, xtol=1e-9, gtol=1e-9,
            )
            cost = float(np.sum(result.fun ** 2))
            if np.all(np.isfinite(result.x)) and cost < best_cost:
                best, best_cost = result.x, cost
        except Exception:
            pass

    return dict(
        alpha=float(best[0]),
        capacity=float(best[1]),
        respiration=float(best[2]),
        theta=float(best[3]),
    )