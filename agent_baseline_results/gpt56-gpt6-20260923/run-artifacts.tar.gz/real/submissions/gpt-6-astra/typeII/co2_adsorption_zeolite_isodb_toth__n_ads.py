"""Toth adsorption isotherm with cluster-specific capacity, affinity, and heterogeneity."""
import numpy as np
from scipy.optimize import least_squares

USED_INPUTS = ["P_bar"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {
    "n_s": {"init": None},
    "b": {"init": None},
    "t": {"init": None},
}

def _normalized_form(P, theta):
    log_capacity, log_affinity, log_exponent = theta
    exponent = np.exp(log_exponent)
    log_z = np.log(np.maximum(P, 1e-300)) + log_affinity
    result = np.exp(
        log_capacity - np.logaddexp(0.0, -exponent * log_z) / exponent
    )
    return np.where(P > 0.0, result, 0.0)

def fit(X_fit, y_fit):
    P = np.asarray(X_fit, dtype=float)[:, 0]
    y = np.asarray(y_fit, dtype=float).reshape(-1)
    valid = np.isfinite(P) & np.isfinite(y) & (P > 0.0)
    P, y = P[valid], y[valid]
    if P.size == 0:
        return {"n_s": 0.0, "b": 1.0, "t": 1.0}

    pressure_scale = float(np.median(P))
    uptake_scale = max(float(np.max(y)), 1e-12)
    p = P / pressure_scale
    target = y / uptake_scale
    best_theta = np.log([1.5, 1.0, 1.0])
    best_error = np.inf

    for exponent_start in (0.25, 0.7, 1.5, 4.0):
        try:
            result = least_squares(
                lambda theta: _normalized_form(p, theta) - target,
                np.log([1.5, 1.0, exponent_start]),
                bounds=([-12.0, -30.0, -6.0], [22.0, 30.0, 4.0]),
                max_nfev=400,
                ftol=1e-9,
                xtol=1e-9,
                gtol=1e-9,
            )
            error = float(np.dot(result.fun, result.fun))
            if np.isfinite(error) and error < best_error:
                best_error = error
                best_theta = result.x
        except Exception:
            pass

    return {
        "n_s": float(uptake_scale * np.exp(best_theta[0])),
        "b": float(np.exp(best_theta[1]) / pressure_scale),
        "t": float(np.exp(best_theta[2])),
    }

def predict(X, n_s, b, t):
    P = np.asarray(X, dtype=float)[:, 0]
    log_z = np.log(np.maximum(P, 1e-300)) + np.log(max(b, 1e-300))
    uptake = n_s * np.exp(-np.logaddexp(0.0, -t * log_z) / t)
    return np.where(P > 0.0, uptake, 0.0)