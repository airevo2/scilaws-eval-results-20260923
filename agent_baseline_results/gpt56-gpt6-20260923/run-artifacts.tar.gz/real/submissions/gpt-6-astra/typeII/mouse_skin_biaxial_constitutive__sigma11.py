"""Anisotropic power-law response in principal logarithmic strains, with a coupled geometric-mean term."""
import numpy as np
from scipy.optimize import least_squares

USED_INPUTS = ["lambda11", "lambda22"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {
    "a": {"init": None},
    "b": {"init": None},
    "c": {"init": None},
    "d": {"init": None},
    "k": {"init": None},
}

def _strains(X):
    return np.maximum(np.log(np.maximum(np.asarray(X, dtype=float), 1e-12)), 0.0)

def _power(x, p):
    return np.where(
        x > 0.0,
        np.exp(np.clip(p * np.log(np.maximum(x, 1e-300)), -700.0, 100.0)),
        0.0,
    )

def fit(X_fit, y_fit):
    X = np.asarray(X_fit, dtype=float)
    y = np.asarray(y_fit, dtype=float).reshape(-1)
    valid = np.isfinite(X).all(axis=1) & np.isfinite(y)
    X, y = X[valid], y[valid]
    if len(y) == 0:
        return {"a": 0.0, "b": 2.0, "c": 0.0, "d": 2.0, "k": 0.0}

    E = _strains(X)
    s = np.maximum(np.max(E, axis=0), 1e-8)
    u, v = (E / s).T
    scale = max(float(np.max(np.abs(y))), 1e-8)

    def matrix(p):
        U = _power(u, p[0])
        V = _power(v, p[1])
        return np.column_stack((U, V, np.sqrt(U * V)))

    def coefficients(p):
        return np.linalg.lstsq(matrix(p), y, rcond=1e-10)[0]

    def residual(p):
        return (matrix(p) @ coefficients(p) - y) / scale

    best_p = np.array([2.0, 2.0])
    best_cost = float(np.sum(residual(best_p) ** 2))
    for start in ([3.0, 3.0], [8.0, 8.0]):
        try:
            result = least_squares(
                residual, start,
                bounds=([0.5, 0.5], [30.0, 30.0]),
                max_nfev=200,
                ftol=1e-9, xtol=1e-9, gtol=1e-9,
            )
            cost = float(np.sum(result.fun ** 2))
            if np.isfinite(cost) and cost < best_cost:
                best_p, best_cost = result.x, cost
        except (ValueError, FloatingPointError, np.linalg.LinAlgError):
            pass

    A, C, K = coefficients(best_p)
    b, d = map(float, best_p)
    a = A / s[0] ** b
    c = C / s[1] ** d
    k = K / (s[0] ** (b / 2.0) * s[1] ** (d / 2.0))
    return {"a": float(a), "b": b, "c": float(c), "d": d, "k": float(k)}

def predict(X, a, b, c, d, k):
    e, f = _strains(X).T
    U = _power(e, b)
    V = _power(f, d)
    stress = a * U + c * V + k * np.sqrt(U * V)
    return np.maximum(stress, 0.0)