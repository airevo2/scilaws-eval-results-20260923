"""Temperature-ratio efficiency law with inverse-load losses, cubic load correction, and condenser-temperature curvature."""
import numpy as np

USED_INPUTS = ["T_ei", "T_ci", "Q_e"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {
    "a": {"init": None},
    "b": {"init": None},
    "c": {"init": None},
    "d": {"init": None},
    "f": {"init": None},
    "g": {"init": None},
    "h": {"init": None},
}

def _basis(X):
    X = np.asarray(X, dtype=float)
    Te, Tc, Q = X[:, 0], X[:, 1], X[:, 2]
    return np.column_stack((
        np.ones_like(Te),
        Tc / Te,
        1.0 / Te,
        1.0 / Q,
        Q ** 3,
        Tc / Q,
        Tc ** 2 / Te,
    ))

def fit(X_fit, y_fit):
    A = _basis(X_fit)
    y = np.asarray(y_fit, dtype=float).reshape(-1)
    valid = np.isfinite(y) & np.all(np.isfinite(A), axis=1)
    A, y = A[valid], y[valid]
    names = ("a", "b", "c", "d", "f", "g", "h")
    coefficients = np.zeros(7)
    if len(y):
        coefficients[0] = np.mean(y)
        scale = np.linalg.norm(A, axis=0)
        scale = np.where(scale > 0.0, scale, 1.0)
        try:
            candidate = np.linalg.lstsq(A / scale, y, rcond=None)[0] / scale
            if np.all(np.isfinite(candidate)):
                coefficients = candidate
        except np.linalg.LinAlgError:
            pass
    return dict(zip(names, map(float, coefficients)))

def predict(X, a, b, c, d, f, g, h):
    return _basis(X) @ np.array([a, b, c, d, f, g, h], dtype=float)