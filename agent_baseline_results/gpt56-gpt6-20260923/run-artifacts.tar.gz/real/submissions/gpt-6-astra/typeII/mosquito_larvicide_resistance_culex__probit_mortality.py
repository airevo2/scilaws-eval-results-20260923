"""A bounded log-dose probit response with a locally fitted maximum mortality."""
import numpy as np
from scipy.optimize import least_squares
from scipy.special import ndtr

USED_INPUTS = ["log10_conc_ppb"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {
    "midpoint": {"init": None},
    "slope": {"init": None},
    "maximum": {"init": None},
}

def fit(X_fit, y_fit):
    x = np.asarray(X_fit, dtype=float)[:, 0]
    y = np.asarray(y_fit, dtype=float).reshape(-1)
    keep = np.isfinite(x) & np.isfinite(y)
    x, y = x[keep], np.clip(y[keep], 0.0, 1.0)

    if len(x) == 0:
        return {"midpoint": 0.0, "slope": 0.0, "maximum": 1.0}

    if np.ptp(x) == 0 or np.ptp(y) == 0:
        from scipy.special import ndtri
        level = np.clip(np.mean(y), np.finfo(float).eps,
                        1.0 - np.finfo(float).eps)
        return {
            "midpoint": float(np.mean(x) - ndtri(level)),
            "slope": 1.0,
            "maximum": 1.0,
        }

    doses, inverse = np.unique(x, return_inverse=True)
    means = np.bincount(inverse, weights=y) / np.bincount(inverse)
    midpoint = float(doses[np.argmin(np.abs(means - 0.5))])
    slope = 1.0 / max(float(np.std(x)), np.sqrt(np.finfo(float).eps))
    initial = np.array([midpoint, slope, 1.0])

    def residual(p):
        response = p[2] * ndtr((x - p[0]) * p[1])
        # One unit-weight asymptotic observation weakly stabilizes the
        # upper limit when the calibration window lacks high doses.
        return np.r_[response - y, p[2] - 1.0]

    try:
        result = least_squares(
            residual,
            initial,
            bounds=([-np.inf, 0.0, 0.0], [np.inf, np.inf, 1.0]),
            max_nfev=500,
            x_scale="jac",
        )
        p = result.x if np.all(np.isfinite(result.x)) else initial
    except Exception:
        p = initial

    return {
        "midpoint": float(p[0]),
        "slope": float(p[1]),
        "maximum": float(p[2]),
    }

def predict(X, midpoint, slope, maximum):
    x = np.asarray(X, dtype=float)[:, 0]
    return np.clip(maximum * ndtr((x - midpoint) * slope), 0.0, 1.0)