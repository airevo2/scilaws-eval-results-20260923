"""Childhood decline, a young-adult mortality shoulder, and Gompertz senescence, with age-dependent calendar improvement."""
import numpy as np
from scipy.optimize import least_squares
from scipy.special import expit

USED_INPUTS = ["age", "year"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {
    "a": {"init": None},
    "b": {"init": None},
    "h": {"init": None},
    "e": {"init": None},
    "c": {"init": None},
    "d": {"init": None},
    "u": {"init": None},
    "v": {"init": None},
}

def _model(X, p, jacobian=False):
    x = X[:, 0]
    t = (X[:, 1] - 2000.0) / 50.0
    a, b, h, e, c, d, u, v = p
    z = np.exp(b)
    r = e / (e + x)

    childhood = a - np.log(x + z)
    shoulder = h - np.logaddexp(0.0, e - x) - np.log((x + e) / (2.0 * e))
    senescence = c + d * x / 100.0
    baseline = np.logaddexp(np.logaddexp(childhood, shoulder), senescence)

    if not jacobian:
        return baseline + (u + v * r) * t

    wc = np.exp(childhood - baseline)
    wh = np.exp(shoulder - baseline)
    ws = np.exp(senescence - baseline)
    return np.column_stack((
        wc,
        -wc * z / (x + z),
        wh,
        wh * (-expit(e - x) - 1.0 / (x + e) + 1.0 / e)
        + v * x * t / (x + e)**2,
        ws,
        ws * x / 100.0,
        t,
        r * t,
    ))

def fit(X_fit, y_fit):
    X = np.asarray(X_fit, dtype=float)
    y = np.asarray(y_fit, dtype=float).reshape(-1)
    valid = np.isfinite(X).all(axis=1) & np.isfinite(y)
    X, y = X[valid], y[valid]

    names = ("a", "b", "h", "e", "c", "d", "u", "v")
    p0 = np.array([-7.0, -2.0, -7.0, 16.0, -11.0, 10.0, -0.5, -1.0])
    lower = np.array([-20.0, -12.0, -20.0, 5.0, -25.0, 1.0, -10.0, -10.0])
    upper = np.array([0.0, 4.0, 0.0, 40.0, 0.0, 25.0, 10.0, 10.0])
    if len(y) == 0:
        return dict(zip(names, map(float, p0)))

    try:
        x = X[:, 0]
        t = (X[:, 1] - 2000.0) / 50.0
        e = p0[3]
        adult = x >= 40.0
        if adult.sum() > 8:
            A = np.column_stack((
                np.ones(adult.sum()),
                x[adult] / 100.0,
                t[adult],
                t[adult] * e / (e + x[adult]),
            ))
            c, d, u, v = np.linalg.lstsq(A, y[adult], rcond=None)[0]
            p0[4:] = [c, d, u, v]

        adjusted = y - (p0[6] + p0[7] * e / (e + x)) * t
        child = (x >= 1.0) & (x <= 10.0)
        if child.any():
            p0[0] = np.median(adjusted[child] + np.log(x[child]))
        infant = x == 0.0
        if infant.any():
            p0[1] = p0[0] - np.median(adjusted[infant])
        young = (x >= 18.0) & (x <= 25.0)
        if young.any():
            p0[2] = np.median(adjusted[young])

        p0 = np.clip(p0, lower + 1e-6, upper - 1e-6)
        span = max(float(np.ptp(X[:, 1])), 1.0)
        weights = np.exp((X[:, 1] - np.max(X[:, 1])) / span)
        result = least_squares(
            lambda p: (_model(X, p) - y) * weights,
            p0,
            jac=lambda p: _model(X, p, True) * weights[:, None],
            bounds=(lower, upper),
            x_scale="jac",
            max_nfev=150,
        )
        if np.isfinite(result.x).all():
            p0 = result.x
    except Exception:
        p0 = np.clip(p0, lower + 1e-6, upper - 1e-6)

    return dict(zip(names, map(float, p0)))

def predict(X, a, b, h, e, c, d, u, v):
    return _model(np.asarray(X, dtype=float), (a, b, h, e, c, d, u, v))