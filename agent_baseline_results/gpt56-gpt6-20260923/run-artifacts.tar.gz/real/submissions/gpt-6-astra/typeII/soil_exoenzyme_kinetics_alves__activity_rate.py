"""Michaelis–Menten kinetics with optional substrate inhibition."""
import numpy as np
from scipy.optimize import least_squares

USED_INPUTS = ["substrate_conc"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {
    "Vmax": {"init": None},
    "Km": {"init": None},
    "inhibition": {"init": None},
}

def fit(X_fit, y_fit):
    s = np.asarray(X_fit[:, 0], dtype=float)
    y = np.asarray(y_fit, dtype=float)
    valid = np.isfinite(s) & np.isfinite(y) & (s > 0)
    s, y = s[valid], y[valid]
    if len(y) == 0:
        return {"Vmax": 0.0, "Km": 1.0, "inhibition": 0.0}

    sx = max(float(np.max(s)), np.finfo(float).tiny)
    sy = max(float(np.mean(np.abs(y))), np.finfo(float).tiny)
    x, z = s / sx, y / sy

    def form(p):
        return p[0] * x / (p[1] + x + p[2] * x * x)

    initial = np.array([max(float(np.max(z)), 0.0) * 1.3, 0.2])
    chosen = np.array([initial[0], initial[1], 0.0])

    try:
        basic = least_squares(
            lambda p: form([p[0], p[1], 0.0]) - z,
            initial,
            bounds=([0.0, 1e-8], [1e6, 1e6]),
            max_nfev=300,
        )
        chosen = np.array([basic.x[0], basic.x[1], 0.0])

        if len(y) > 4 and len(np.unique(s)) >= 4:
            extended = least_squares(
                lambda p: form(p) - z,
                [basic.x[0], basic.x[1], 0.01],
                bounds=([0.0, 1e-8, 0.0], [1e6, 1e6, 1e6]),
                max_nfev=400,
            )
            n = len(y)

            def criterion(p, k):
                rss = float(np.sum((form(p) - z) ** 2))
                return (
                    n * np.log(max(rss / n, np.finfo(float).tiny))
                    + 2 * k
                    + 2 * k * (k + 1) / max(n - k - 1, 1)
                )

            if np.all(np.isfinite(extended.x)):
                if criterion(extended.x, 3) < criterion(chosen, 2):
                    chosen = extended.x
    except Exception:
        pass

    return {
        "Vmax": float(chosen[0] * sy),
        "Km": float(chosen[1] * sx),
        "inhibition": float(chosen[2] / sx),
    }

def predict(X, Vmax, Km, inhibition):
    s = np.maximum(np.asarray(X[:, 0], dtype=float), 0.0)
    return Vmax * s / (Km + s + inhibition * s * s)