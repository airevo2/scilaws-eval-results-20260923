"""Vogel–Fulcher–Tammann temperature dependence with three locally calibrated parameters."""
import numpy as np
from scipy.optimize import minimize_scalar

USED_INPUTS = ["T"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {
    "A": {"init": None},
    "B": {"init": None},
    "C": {"init": None},
}

def fit(X_fit, y_fit):
    T = np.asarray(X_fit, dtype=float)[:, 0]
    y = np.asarray(y_fit, dtype=float).ravel()
    valid = np.isfinite(T) & np.isfinite(y) & (T > 0)
    T, y = T[valid], y[valid]

    if len(y) == 0:
        return {"A": -4.0, "B": 0.0, "C": 0.0}

    def calibrate(C):
        z = 1.0 / (T - C)
        dz = z - np.mean(z)
        variance = float(dz @ dz)
        if variance > 1e-24:
            B = float(dz @ (y - np.mean(y))) / variance
            A = float(np.clip(np.mean(y) - B * np.mean(z), -6.0, -2.0))
        else:
            A = -4.0
        B = max(0.0, float(z @ (y - A)) / float(z @ z))
        residual = A + B * z - y
        return float(residual @ residual), A, B, float(C)

    lower = -float(np.min(T))
    upper = 0.85 * float(np.min(T))
    candidates = [calibrate(0.0), calibrate(lower), calibrate(upper)]
    if len(y) >= 3 and np.ptp(T) > 1e-8:
        try:
            result = minimize_scalar(
                lambda C: calibrate(C)[0],
                bounds=(lower, upper),
                method="bounded",
                options={"xatol": 1e-7, "maxiter": 150},
            )
            if np.isfinite(result.fun):
                candidates.append(calibrate(float(result.x)))
        except (ValueError, FloatingPointError):
            pass

    _, A, B, C = min(candidates, key=lambda item: item[0])
    return {"A": A, "B": B, "C": C}

def predict(X, A, B, C):
    T = np.maximum(np.asarray(X, dtype=float)[:, 0], 1e-6)
    # Regularize only extrapolations approaching the formal VFT pole.
    denominator = np.maximum(T - C, 0.15 * T)
    return np.asarray(A + B / denominator, dtype=float)