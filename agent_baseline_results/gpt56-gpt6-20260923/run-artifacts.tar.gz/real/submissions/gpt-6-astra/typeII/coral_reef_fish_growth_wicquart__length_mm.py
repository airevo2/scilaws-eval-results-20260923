"""Concave allometric growth with a calibrated hatching length."""
import numpy as np
from scipy.optimize import minimize_scalar

USED_INPUTS = ["Agei"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {
    "a": {"init": None},
    "b": {"init": None},
    "L0": {"init": None},
}

def fit(X_fit, y_fit):
    t = np.maximum(np.asarray(X_fit, dtype=float)[:, 0], 0.0)
    y = np.asarray(y_fit, dtype=float).reshape(-1)
    valid = np.isfinite(t) & np.isfinite(y)
    t, y = t[valid], y[valid]
    if len(y) == 0:
        return {"a": 0.0, "b": 1.0, "L0": 0.0}

    at_birth = t == 0.0
    L0 = max(0.0, float(np.mean(y[at_birth]))) if np.any(at_birth) else 0.0
    positive = t > 0.0
    u, v = t[positive], y[positive] - L0
    if len(u) == 0:
        return {"a": 0.0, "b": 1.0, "L0": L0}

    def amplitude(b):
        z = np.power(u, b)
        return max(0.0, float(np.dot(z, v) / np.dot(z, z)))

    def objective(b):
        return float(np.sum((amplitude(b) * np.power(u, b) - v) ** 2))

    if np.unique(u).size < 2:
        b = 1.0
    else:
        result = minimize_scalar(
            objective, bounds=(1e-6, 1.0), method="bounded",
            options={"xatol": 1e-9, "maxiter": 150}
        )
        b = float(result.x)
        if objective(1.0) < objective(b):
            b = 1.0

    return {"a": amplitude(b), "b": b, "L0": L0}

def predict(X, a, b, L0):
    t = np.maximum(np.asarray(X, dtype=float)[:, 0], 0.0)
    return L0 + a * np.power(t, b)