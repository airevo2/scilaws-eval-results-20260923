"""Molecular-weight power law with a glass-temperature-scaled Vogel–Fulcher thermal term."""
import numpy as np
from scipy.optimize import lsq_linear, least_squares

USED_INPUTS = ["Temperature_K", "log10_Mw", "Tg_K"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {
    "n": {"init": None},
    "A": {"init": None},
}

def _design(X):
    X = np.asarray(X, dtype=float)
    T = X[:, 0]
    M = X[:, 1]
    Tg = X[:, 3]
    denominator = np.maximum(T - (2.0 / 3.0) * Tg, 1.0)
    return np.column_stack((M, Tg / denominator))

def fit(X_fit, y_fit):
    D = _design(X_fit)
    y = np.asarray(y_fit, dtype=float).reshape(-1)
    valid = np.isfinite(y) & np.all(np.isfinite(D), axis=1)
    D, y = D[valid], y[valid]

    if len(y) == 0:
        return {"n": 0.0, "A": 0.0}

    try:
        initial = lsq_linear(
            D, y + 10.0, bounds=(0.0, np.inf), max_iter=100
        ).x
        result = least_squares(
            lambda p: D @ p - 10.0 - y,
            np.maximum(initial, np.finfo(float).eps),
            bounds=(0.0, np.inf),
            loss="soft_l1",
            f_scale=1.0,
            x_scale="jac",
            max_nfev=200,
        )
        parameters = result.x if np.all(np.isfinite(result.x)) else initial
    except Exception:
        parameters = np.maximum(
            np.linalg.lstsq(D, y + 10.0, rcond=None)[0], 0.0
        )

    return {"n": float(parameters[0]), "A": float(parameters[1])}

def predict(X, n, A):
    return _design(X) @ np.array([n, A], dtype=float) - 10.0