"""Nonlinear reservoir recession: dQ/dt = -a Q^(1+b), anchored at observed Q_0."""
import numpy as np
from scipy.optimize import least_squares

USED_INPUTS = ["t", "Q_0"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {"a": {"init": None}, "b": {"init": None}}

def _recession(t, q, log_a, b):
    t = np.maximum(np.asarray(t, dtype=float), 0.0)
    q = np.maximum(np.asarray(q, dtype=float), 0.0)
    log_term = (
        log_a
        + np.log(b)
        + np.log(np.maximum(t, np.finfo(float).tiny))
        + b * np.log(np.maximum(q, np.finfo(float).tiny))
    )
    decay = np.logaddexp(0.0, log_term) / b
    result = q * np.exp(-decay)
    return np.where(t == 0.0, q, result)

def fit(X_fit, y_fit):
    X = np.asarray(X_fit, dtype=float)
    y = np.asarray(y_fit, dtype=float).reshape(-1)
    valid = (
        np.isfinite(X).all(axis=1)
        & np.isfinite(y)
        & (X[:, 0] > 0.0)
        & (X[:, 1] > 0.0)
        & (y >= 0.0)
    )
    t = X[valid, 0]
    q = X[valid, 1]
    y = y[valid]
    if len(y) == 0:
        return {"a": 0.0, "b": 1.0}

    scale = float(np.median(q))
    z = q / scale
    target = y / scale
    residual_scale = max(float(np.sqrt(np.mean(target**2))), 1e-12)
    rates = -np.log(np.clip(y / q, 1e-12, 1.0)) / t
    rate = max(float(np.median(rates)), 1e-8)

    def residual(p):
        return (
            _recession(t, z, p[0], p[1]) - target
        ) / residual_scale

    best = None
    for b0 in (0.1, 0.7, 1.5):
        p0 = [float(np.clip(np.log(rate), -24.0, 9.0)), b0]
        try:
            result = least_squares(
                residual,
                p0,
                bounds=([-30.0, 1e-6], [10.0, 4.0]),
                max_nfev=250,
            )
            loss = float(np.sum(result.fun**2))
            if np.isfinite(loss) and (best is None or loss < best[0]):
                best = (loss, result.x)
        except (ValueError, FloatingPointError, OverflowError):
            pass

    if best is None:
        b = 0.5
        return {"a": float(rate / scale**b), "b": b}

    log_rate, b = best[1]
    a = np.exp(log_rate - b * np.log(scale))
    return {"a": float(a), "b": float(b)}

def predict(X, a, b):
    X = np.asarray(X, dtype=float)
    if a <= 0.0:
        return np.maximum(X[:, 1], 0.0)
    return _recession(X[:, 0], X[:, 1], np.log(a), max(b, 1e-6))