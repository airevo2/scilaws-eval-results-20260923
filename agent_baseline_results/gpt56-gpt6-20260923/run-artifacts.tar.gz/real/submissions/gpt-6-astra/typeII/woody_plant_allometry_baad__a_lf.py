"""Sapwood-area allometry with a cube-root stem-slenderness correction."""
import numpy as np

USED_INPUTS = ["a_ssbh", "h_t"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {"scale": {"init": None}}

def _shape(X):
    area = np.maximum(np.asarray(X[:, 0], dtype=float), np.finfo(float).tiny)
    height = np.maximum(np.asarray(X[:, 1], dtype=float), np.finfo(float).tiny)
    return area * np.cbrt(np.sqrt(area) / height)

def fit(X_fit, y_fit):
    shape = _shape(X_fit)
    y = np.asarray(y_fit, dtype=float)
    valid = np.isfinite(y) & (y > 0) & np.isfinite(shape) & (shape > 0)
    if not np.any(valid):
        return {"scale": 1.0}
    scale = np.exp(np.median(np.log(y[valid]) - np.log(shape[valid])))
    return {"scale": float(scale)}

def predict(X, scale):
    return scale * _shape(X)