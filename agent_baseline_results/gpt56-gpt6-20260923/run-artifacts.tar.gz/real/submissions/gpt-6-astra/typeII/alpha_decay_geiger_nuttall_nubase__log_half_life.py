"""Geiger–Nuttall law: log10 half-life = a / sqrt(Q_alpha_MeV) + b."""
import numpy as np

USED_INPUTS = ["Q_alpha_MeV"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {"a": {"init": None}, "b": {"init": None}}

def fit(X_fit, y_fit):
    q = np.asarray(X_fit, dtype=float)[:, 0]
    y = np.asarray(y_fit, dtype=float).reshape(-1)
    valid = np.isfinite(q) & np.isfinite(y) & (q > 0)
    q, y = q[valid], y[valid]
    if y.size == 0:
        return {"a": 0.0, "b": 0.0}

    x = 1.0 / np.sqrt(q)
    x_mean = float(np.mean(x))
    y_mean = float(np.mean(y))
    dx = x - x_mean
    denominator = float(np.dot(dx, dx))
    if denominator > 0:
        a = max(0.0, float(np.dot(dx, y - y_mean) / denominator))
    else:
        a = 0.0
    b = y_mean - a * x_mean
    return {"a": a, "b": b}

def predict(X, a, b):
    q = np.asarray(X, dtype=float)[:, 0]
    q = np.maximum(q, np.finfo(float).tiny)
    return a / np.sqrt(q) + b