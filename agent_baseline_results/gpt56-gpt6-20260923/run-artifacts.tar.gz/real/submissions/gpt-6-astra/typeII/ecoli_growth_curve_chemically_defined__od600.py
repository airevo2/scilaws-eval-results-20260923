"""Saturating growth with a transient biomass overshoot and gradual relaxation."""
import numpy as np
from scipy.optimize import least_squares
from scipy.special import expit

USED_INPUTS = ["time_h"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {
    "baseline": {"init": None},
    "amplitude": {"init": None},
    "rate": {"init": None},
    "midpoint": {"init": None},
}

def predict(X, baseline, amplitude, rate, midpoint):
    t = np.asarray(X, dtype=float)[:, 0]
    z = rate * (t - midpoint)
    exposure = np.exp(np.clip(z, -50.0, 20.0))
    growth = -np.expm1(-exposure)
    relaxation = (expit(z) / (1.0 + np.logaddexp(0.0, z))) ** 2
    return baseline + amplitude * (growth + relaxation)

def fit(X_fit, y_fit):
    X = np.asarray(X_fit, dtype=float)
    y = np.asarray(y_fit, dtype=float).reshape(-1)
    valid = np.isfinite(X[:, 0]) & np.isfinite(y)
    X, y = X[valid], y[valid]

    if len(y) == 0:
        return dict(baseline=0.0, amplitude=0.0, rate=1.0, midpoint=0.0)

    t = X[:, 0]
    b = max(0.0, float(np.min(y)))
    spread = float(np.ptp(y))
    span = max(float(np.ptp(t)), 1.0)
    m = float(t[np.argmin(np.abs(y - (b + spread / 2.0)))])

    if spread <= np.finfo(float).eps:
        return dict(
            baseline=float(np.mean(y)),
            amplitude=0.0,
            rate=1.0 / span,
            midpoint=float(np.median(t)),
        )

    p0 = np.array([b, spread, 0.5, m])
    lower = [0.0, 0.0, 0.001, float(np.min(t)) - 4.0 * span]
    upper = [
        max(float(np.max(y)) + spread, np.finfo(float).eps),
        2.0 * spread,
        10.0,
        float(np.max(t)) + 4.0 * span,
    ]

    def residual(p):
        return predict(X, *p) - y

    try:
        result = least_squares(
            residual, p0, bounds=(lower, upper),
            max_nfev=300, ftol=1e-9, xtol=1e-9, gtol=1e-9
        )
        p = result.x if np.all(np.isfinite(result.x)) else p0
    except Exception:
        p = p0

    return dict(
        baseline=float(p[0]),
        amplitude=float(p[1]),
        rate=float(p[2]),
        midpoint=float(p[3]),
    )