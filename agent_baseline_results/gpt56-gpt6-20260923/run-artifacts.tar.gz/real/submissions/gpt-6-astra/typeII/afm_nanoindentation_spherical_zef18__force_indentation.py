"""Hertz spherical-contact law with one effective elastic modulus per cluster."""
import numpy as np

USED_INPUTS = ["indentation_m", "R_m"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {"E_eff": {"init": None}}

def _basis(X):
    delta = np.maximum(np.asarray(X[:, 0], dtype=float), 0.0)
    radius = np.maximum(np.asarray(X[:, 1], dtype=float), 0.0)
    return (4.0 / 3.0) * np.sqrt(radius) * delta**1.5

def fit(X_fit, y_fit):
    basis = _basis(X_fit)
    y = np.asarray(y_fit, dtype=float).reshape(-1)
    valid = np.isfinite(basis) & np.isfinite(y)
    basis, y = basis[valid], y[valid]
    denominator = np.dot(basis, basis)
    modulus = max(0.0, float(np.dot(basis, y) / denominator)) if denominator > 0.0 else 0.0
    return {"E_eff": modulus}

def predict(X, E_eff):
    return E_eff * _basis(X)