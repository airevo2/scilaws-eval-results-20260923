"""Two-parameter, saturating VPD response: Gc = a / (1 + b D²).
Calibration constrains mean-VPD elasticity to lie between zero and minus one.
"""
import numpy as np
from scipy.optimize import minimize_scalar

USED_INPUTS = ["vpd"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {"a": {"init": None}, "b": {"init": None}}

def fit(X_fit, y_fit):
    D = np.asarray(X_fit, dtype=float)[:, 0]
    y = np.asarray(y_fit, dtype=float).reshape(-1)
    valid = np.isfinite(D) & np.isfinite(y) & (D > 0)
    D, y = D[valid], y[valid]
    if len(y) == 0:
        return {"a": 0.0, "b": 0.0}

    scale = float(np.mean(D))
    z = (D / scale) ** 2

    def amplitude(q):
        f = 1.0 / (1.0 + q * z)
        return max(0.0, float(np.dot(f, y) / np.dot(f, f)))

    def objective(q):
        residual = y - amplitude(q) / (1.0 + q * z)
        return float(np.mean(residual ** 2))

    q = 0.0
    try:
        result = minimize_scalar(
            objective, bounds=(0.0, 1.0), method="bounded"
        )
        candidates = [0.0, 1.0]
        if result.success and np.isfinite(result.x):
            candidates.append(float(result.x))
        q = min(candidates, key=objective)
    except Exception:
        pass

    return {"a": amplitude(q), "b": float(q / scale ** 2)}

def predict(X, a, b):
    D = np.asarray(X, dtype=float)[:, 0]
    return a / (1.0 + b * D ** 2)