"""Bounded square-root exponential decay of Sørensen similarity."""
import numpy as np
from scipy.optimize import least_squares

USED_INPUTS = ["env_dist"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {"S0": {"init": None}, "k": {"init": None}}

def fit(X_fit, y_fit):
    d = np.asarray(X_fit, dtype=float)[:, 0]
    y = np.asarray(y_fit, dtype=float).ravel()
    valid = np.isfinite(d) & np.isfinite(y)
    d, y = d[valid], y[valid]
    if y.size == 0:
        return {"S0": 0.5, "k": 0.0}

    t = np.sqrt(np.maximum(d, 0.0))
    scale = float(np.max(t))
    fallback = {"S0": float(np.clip(np.mean(y), 0.0, 1.0)), "k": 0.0}
    if scale == 0.0 or np.ptp(t) == 0.0:
        return fallback
    t = t / scale

    try:
        design = np.column_stack([np.ones(y.size), -t])
        initial = np.linalg.lstsq(
            design, np.log(np.maximum(y, 1e-12)), rcond=None
        )[0]
        amplitude = float(np.exp(np.clip(initial[0], -25.0, 0.0)))
        rate = max(float(initial[1]), 0.0)
        result = least_squares(
            lambda p: p[0] * np.exp(-p[1] * t) - y,
            x0=[amplitude, rate],
            bounds=([0.0, 0.0], [1.0, np.inf]),
            max_nfev=1000,
        )
        if np.all(np.isfinite(result.x)):
            return {"S0": float(result.x[0]), "k": float(result.x[1] / scale)}
    except (ValueError, RuntimeError, np.linalg.LinAlgError):
        pass
    return fallback

def predict(X, S0, k):
    d = np.maximum(np.asarray(X, dtype=float)[:, 0], 0.0)
    return S0 * np.exp(-k * np.sqrt(d))