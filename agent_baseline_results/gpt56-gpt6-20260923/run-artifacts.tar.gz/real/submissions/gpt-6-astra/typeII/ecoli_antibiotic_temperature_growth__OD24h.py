"""A thermal growth window: logistic activation at low temperature and logistic growth arrest at high temperature."""
import numpy as np
from scipy.optimize import least_squares
from scipy.special import expit

USED_INPUTS = ["T"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {
    "A": {"init": None},
    "T_c": {"init": None},
    "w_c": {"init": None},
    "T_h": {"init": None},
    "w_h": {"init": None},
}

def predict(X, A, T_c, w_c, T_h, w_h):
    T = np.asarray(X, dtype=float)[:, 0]
    return (
        A
        * expit((T - T_c) / max(w_c, 1e-12))
        * expit((T_h - T) / max(w_h, 1e-12))
    )

def fit(X_fit, y_fit):
    T = np.asarray(X_fit, dtype=float)[:, 0]
    y = np.asarray(y_fit, dtype=float).reshape(-1)
    valid = np.isfinite(T) & np.isfinite(y)
    T, y = T[valid], np.maximum(y[valid], 0.0)
    names = ("A", "T_c", "w_c", "T_h", "w_h")

    if len(y) == 0:
        return dict(zip(names, (0.0, 0.0, 1.0, 0.0, 1.0)))

    u, inverse = np.unique(T, return_inverse=True)
    counts = np.bincount(inverse)
    means = np.bincount(inverse, weights=y) / counts
    amplitude = max(float(np.max(means)), 1e-10)
    span = max(float(np.ptp(u)), 1.0)

    active = np.flatnonzero(means >= amplitude / 2.0)
    left = float(u[active[0]]) if len(active) else float(u[0])
    right = float(u[active[-1]]) if len(active) else float(u[-1])

    lower = np.array([
        0.0, u[0] - span, span / 160.0, u[0], span / 160.0
    ])
    upper = np.array([
        amplitude, u[-1], span, u[-1] + span, span
    ])
    best = None
    best_cost = np.inf

    def residual(p):
        estimates = (
            p[0] * expit((u - p[1]) / p[2])
            * expit((p[3] - u) / p[4])
        )
        return (estimates - means) * np.sqrt(counts) / amplitude

    for width in (span / 24.0, span / 8.0):
        initial = np.array([
            amplitude * (1.0 - 1e-6),
            left,
            width,
            right + span / 24.0,
            span / 32.0,
        ])
        initial = np.minimum(np.maximum(initial, lower), upper)
        if best is None:
            best = initial.copy()
        try:
            result = least_squares(
                residual,
                initial,
                bounds=(lower, upper),
                max_nfev=200,
            )
            cost = float(np.dot(result.fun, result.fun))
            if np.all(np.isfinite(result.x)) and cost < best_cost:
                best, best_cost = result.x, cost
        except (ValueError, FloatingPointError, RuntimeError):
            pass

    return dict(zip(names, map(float, best)))