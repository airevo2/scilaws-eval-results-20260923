"""Two-parameter logistic life-expectancy trend, calibrated with recency-weighted least squares."""
import numpy as np
from scipy.optimize import least_squares
from scipy.special import expit

USED_INPUTS = ["year"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {
    "a": {"init": None},
    "b": {"init": None},
}

def fit(X_fit, y_fit):
    t = np.asarray(X_fit[:, 0], dtype=float)
    y = np.asarray(y_fit, dtype=float)
    valid = np.isfinite(t) & np.isfinite(y)
    t, y = t[valid], y[valid]

    center = float(np.mean(t))
    mean_y = max(float(np.mean(y)), 1e-6)
    spread = max(float(np.std(t)), 1.0)
    weights = np.exp((t - np.max(t)) / spread)

    # Optimize a logarithmic scale and a centered time displacement.
    initial = np.array([np.log(2.0 * mean_y), 0.0])

    def residual(c):
        scale = np.exp(c[0])
        estimate = scale * expit((t - center + c[1]) / scale)
        return weights * (estimate - y)

    best = initial
    try:
        result = least_squares(
            residual,
            initial,
            bounds=([np.log(1e-6), -1e9],
                    [np.log(1e6), 1e9]),
            max_nfev=500,
        )
        if np.all(np.isfinite(result.x)):
            best = result.x
    except (ValueError, RuntimeError, FloatingPointError):
        pass

    return {
        "a": float(np.exp(best[0])),
        "b": float(center - best[1]),
    }

def predict(X, a, b):
    t = np.asarray(X[:, 0], dtype=float)
    return a * expit((t - b) / a)