"""Three-parameter saturating isotherm with a linear low-pressure limit."""
import numpy as np
from scipy.optimize import least_squares

USED_INPUTS = ["P_bar"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {
    "a": {"init": None},
    "b": {"init": None},
    "c": {"init": None},
}

def fit(X_fit, y_fit):
    P = np.asarray(X_fit, dtype=float)[:, 0]
    y = np.asarray(y_fit, dtype=float).reshape(-1)
    valid = np.isfinite(P) & np.isfinite(y) & (P > 0)
    P, y = P[valid], y[valid]

    if P.size == 0 or np.max(y) <= 0:
        return {"a": 0.0, "b": 1.0, "c": 1.0}

    scale = float(np.max(y))
    yn = y / scale

    def profile(z):
        b, c = np.exp(z)
        h = np.arctan(c * np.arcsinh(b * P))
        amplitude = max(float(np.dot(h, yn) / max(np.dot(h, h), 1e-300)), 0.0)
        return h, amplitude

    def residual(z):
        h, amplitude = profile(z)
        return amplitude * h - yn

    starts = [
        [np.log(1.0 / np.median(P)), np.log(0.7)],
        [np.log(1.0 / np.max(P)), np.log(0.1)],
        [np.log(1.0 / np.min(P)), np.log(0.1)],
    ]
    lower = np.array([-25.0, -18.0])
    upper = np.array([25.0, 18.0])
    best_z = np.clip(starts[0], lower, upper)
    best_cost = float(np.dot(residual(best_z), residual(best_z)))

    for start in starts:
        try:
            result = least_squares(
                residual,
                np.clip(start, lower, upper),
                bounds=(lower, upper),
                max_nfev=300,
                ftol=1e-10,
                xtol=1e-10,
                gtol=1e-10,
            )
            cost = float(np.dot(result.fun, result.fun))
            if np.isfinite(cost) and cost < best_cost:
                best_cost = cost
                best_z = result.x
        except Exception:
            pass

    _, amplitude = profile(best_z)
    b, c = np.exp(best_z)
    return {
        "a": float(scale * amplitude),
        "b": float(b),
        "c": float(c),
    }

def predict(X, a, b, c):
    P = np.maximum(np.asarray(X, dtype=float)[:, 0], 0.0)
    return a * np.arctan(c * np.arcsinh(b * P))