"""Three-parameter asymmetric solar-cycle pulse: rapid rise and slower decay."""
import numpy as np
from scipy.optimize import least_squares

USED_INPUTS = ["t_year"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {
    "amplitude": {"init": None},
    "t_peak": {"init": None},
    "width": {"init": None},
}

def _pulse(z):
    z = np.clip(z, -100.0, 1e6)
    return np.exp(np.clip(1.0 - z - np.exp(-z), -700.0, 0.0))

def fit(X_fit, y_fit):
    t = np.asarray(X_fit[:, 0], dtype=float)
    y = np.asarray(y_fit, dtype=float)
    valid = np.isfinite(t) & np.isfinite(y)
    t, y = t[valid], np.maximum(y[valid], 0.0)

    if len(t) == 0:
        return {"amplitude": 0.0, "t_peak": 0.0, "width": 1.0}

    origin = float(np.min(t))
    span = float(np.ptp(t))
    amplitude = float(np.max(y))
    if span <= 0.0 or amplitude <= 0.0:
        return {
            "amplitude": float(np.mean(y)),
            "t_peak": origin,
            "width": 1.0,
        }

    u = (t - origin) / span
    v = y / amplitude
    best = None

    for peak in (float(u[np.argmax(y)]), 0.5, 0.0):
        try:
            result = least_squares(
                lambda p: p[0] * _pulse((u - p[1]) / p[2]) - v,
                x0=[0.9, peak, 0.25],
                bounds=([0.0, -1.0, 0.001], [1.0, 2.0, 0.5]),
                max_nfev=300,
            )
            if np.all(np.isfinite(result.x)):
                if best is None or result.cost < best.cost:
                    best = result
        except (ValueError, FloatingPointError):
            pass

    p = best.x if best is not None else np.array(
        [1.0, float(u[np.argmax(y)]), 0.25]
    )
    return {
        "amplitude": float(amplitude * p[0]),
        "t_peak": float(origin + span * p[1]),
        "width": float(span * p[2]),
    }

def predict(X, amplitude, t_peak, width):
    t = np.asarray(X[:, 0], dtype=float)
    z = (t - t_peak) / max(float(width), np.finfo(float).eps)
    return amplitude * _pulse(z)