"""Guggenheim corresponding-states law with one fitted surface-tension amplitude."""
import numpy as np

USED_INPUTS = ["T_K", "T_c"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {"sigma_0": {"init": None}}

def fit(X_fit, y_fit):
    X_fit = np.asarray(X_fit, dtype=float)
    y_fit = np.asarray(y_fit, dtype=float).reshape(-1)
    tau = np.maximum(1.0 - X_fit[:, 0] / X_fit[:, 1], 0.0)
    basis = tau ** (11.0 / 9.0)
    valid = np.isfinite(basis) & np.isfinite(y_fit)
    basis = basis[valid]
    values = y_fit[valid]
    denominator = np.dot(basis, basis)
    amplitude = np.dot(basis, values) / denominator if denominator > 0.0 else 0.0
    return {"sigma_0": float(max(amplitude, 0.0))}

def predict(X, sigma_0):
    X = np.asarray(X, dtype=float)
    tau = np.maximum(1.0 - X[:, 0] / X[:, 1], 0.0)
    return sigma_0 * tau ** (11.0 / 9.0)