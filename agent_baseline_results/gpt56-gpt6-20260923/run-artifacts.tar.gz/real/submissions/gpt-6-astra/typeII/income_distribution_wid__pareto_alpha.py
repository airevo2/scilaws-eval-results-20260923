"""Bounded tail-share exponent with smooth tail curvature and locally calibrated temporal drift."""
import numpy as np
from scipy.special import expit, logit
from scipy.optimize import least_squares

USED_INPUTS = ["log_p_above", "year"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {
    "a": {"init": None},
    "b": {"init": None},
    "c": {"init": None},
    "d": {"init": None},
}

def _spatial(X):
    q = np.maximum(-X[:, 0], 0.0)
    return np.column_stack((np.ones(len(X)), np.sqrt(q), q))

def _solve(fun, initial):
    try:
        result = least_squares(fun, initial, max_nfev=100)
        if np.all(np.isfinite(result.x)):
            return result.x
    except Exception:
        pass
    return initial

def _calibrate(X, y):
    H = _spatial(X)
    t0 = float(np.mean(X[:, 2]))
    A = np.column_stack((H, X[:, 2] - t0))
    x = X[:, 0]
    ratio = np.clip(y / np.minimum(x, -1e-12), 1e-6, 1.0 - 1e-6)
    initial = np.linalg.lstsq(A, logit(ratio), rcond=None)[0]
    coefficients = _solve(lambda v: x * expit(A @ v) - y, initial)
    return coefficients, t0

def fit(X_fit, y_fit):
    X = np.asarray(X_fit, dtype=float)
    y = np.asarray(y_fit, dtype=float).reshape(-1)
    valid = np.isfinite(y) & np.all(np.isfinite(X), axis=1)
    X, y = X[valid], y[valid]
    if not len(y):
        return {"a": 0.0, "b": 0.0, "c": 0.0, "d": 0.0}

    coefficients, t0 = _calibrate(X, y)
    H = _spatial(X)
    years = X[:, 2]
    unique_years = np.unique(years)
    numerator, denominator = 0.0, 0.0

    # Estimate how much temporal drift transfers to disjoint time windows.
    if len(unique_years) >= 4:
        for forward in (False, True):
            for fraction in (0.5, 0.75):
                cutoff = np.quantile(
                    unique_years, fraction if forward else 1.0 - fraction
                )
                train = years <= cutoff if forward else years >= cutoff
                test = ~train
                if np.sum(train) < 6 or np.sum(test) < 2:
                    continue
                local, center = _calibrate(X[train], y[train])
                static = _solve(
                    lambda v: X[train, 0] * expit(H[train] @ v) - y[train],
                    local[:3],
                )
                baseline = X[test, 0] * expit(H[test] @ static)
                drifting = X[test, 0] * expit(
                    H[test] @ local[:3] + (years[test] - center) * local[3]
                )
                delta = drifting - baseline
                numerator += float(delta @ (y[test] - baseline))
                denominator += float(delta @ delta)

        shrinkage = np.clip(numerator / max(denominator, 1e-15), 0.0, 1.0)
        coefficients[3] *= shrinkage
        offset = (years - t0) * coefficients[3]
        coefficients[:3] = _solve(
            lambda v: X[:, 0] * expit(H @ v + offset) - y,
            coefficients[:3],
        )

    a, b, c, d = coefficients
    return {
        "a": float(a - d * t0),
        "b": float(b),
        "c": float(c),
        "d": float(d),
    }

def predict(X, a, b, c, d):
    X = np.asarray(X, dtype=float)
    q = np.maximum(-X[:, 0], 0.0)
    exponent = expit(a + b * np.sqrt(q) + c * q + d * X[:, 2])
    return -q * exponent