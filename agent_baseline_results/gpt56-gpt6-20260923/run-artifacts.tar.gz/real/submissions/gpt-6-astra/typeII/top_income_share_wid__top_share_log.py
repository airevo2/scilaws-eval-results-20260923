"""Logarithmically corrected Pareto tail with exponential temporal evolution."""
import numpy as np
from scipy.optimize import least_squares

USED_INPUTS = ["log_p_above", "top_pct", "year"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {
    "a": {"init": None},
    "b": {"init": None},
    "c": {"init": None},
}

def fit(X_fit, y_fit):
    X = np.asarray(X_fit, dtype=float)
    y = np.asarray(y_fit, dtype=float)
    good = np.isfinite(y) & np.all(np.isfinite(X), axis=1)
    X, y = X[good], y[good]
    if len(y) == 0:
        return {"a": 0.5, "b": 0.0, "c": 0.0}

    x = X[:, 0]
    year = X[:, 2]
    A = np.column_stack((x, np.log1p(-x)))
    origin = float(np.mean(year))
    scale = max(float(np.ptp(year)), 1.0)
    v = (year - origin) / scale
    initial = np.linalg.lstsq(A, y, rcond=None)[0]
    coefficients = initial.copy()
    rate = 0.0

    if np.unique(year).size > 1:
        limit = 300.0 * scale / max(float(np.max(np.abs(year))), 1.0)

        def residual(p):
            return (A @ p[:2]) * np.exp(np.clip(p[2] * v, -300, 300)) - y

        try:
            result = least_squares(
                residual,
                np.r_[initial, 0.0],
                bounds=([-np.inf, -np.inf, -limit],
                        [np.inf, np.inf, limit]),
                max_nfev=150,
            )
            p = result.x
            if np.all(np.isfinite(p)):
                # Estimate trend uncertainty with years as dependent blocks.
                J = result.jac
                r = residual(p)
                scores = np.array([
                    np.sum(J[year == yr] * r[year == yr, None], axis=0)
                    for yr in np.unique(year)
                ])
                inverse = np.linalg.pinv(J.T @ J)
                covariance = inverse @ scores.T @ scores @ inverse
                variance = max(float(covariance[2, 2]), 0.0)
                trend = float(p[2])
                if trend * trend + variance > 0:
                    trend *= trend * trend / (trend * trend + variance)
                multiplier = np.exp(np.clip(trend * v, -300, 300))
                coefficients = np.linalg.lstsq(
                    A * multiplier[:, None], y, rcond=None
                )[0]
                rate = trend / scale
        except (ValueError, RuntimeError, np.linalg.LinAlgError):
            pass

    # Absorb the calibration time origin into the two amplitudes.
    amplitudes = coefficients * np.exp(np.clip(-rate * origin, -300, 300))
    return {
        "a": float(amplitudes[0]),
        "b": float(amplitudes[1]),
        "c": float(rate),
    }

def predict(X, a, b, c):
    X = np.asarray(X, dtype=float)
    x = X[:, 0]
    year = X[:, 2]
    value = (a * x + b * np.log1p(-x)) * np.exp(
        np.clip(c * year, -300, 300)
    )
    # A top-p income share lies between p and one.
    return np.clip(value, x, 0.0)