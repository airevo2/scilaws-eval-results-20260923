"""Equilibrium evaporation modulated by vegetation, atmospheric dryness and temperature."""
import numpy as np
from scipy.optimize import least_squares
from scipy.special import expit

USED_INPUTS = ["VPD", "Tair", "Rnet", "Qg", "LAI", "delta"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {
    "intercept": {"init": None},
    "vegetation": {"init": None},
    "dryness": {"init": None},
    "temperature": {"init": None},
    "background": {"init": None},
}

def _features(X):
    X = np.asarray(X, dtype=float)
    vpd, tair, rnet, qg, lai, delta = X.T
    available = np.maximum(rnet - qg, 0.0)
    delta = np.maximum(delta, 0.0)
    # Psychrometric constant, approximately 0.066 kPa/K.
    equilibrium = available * delta / (delta + 0.066)
    B = np.column_stack((
        np.ones(len(X)),
        np.log1p(np.maximum(lai, 0.0)),
        -np.sqrt(np.maximum(vpd, 0.0)),
        (tair - 273.15) / 10.0,
    ))
    return equilibrium, B

def fit(X_fit, y_fit):
    X = np.asarray(X_fit, dtype=float)
    y = np.asarray(y_fit, dtype=float).reshape(-1)
    valid = np.isfinite(y) & np.all(np.isfinite(X), axis=1)
    X, y = X[valid], y[valid]
    names = list(LOCAL_FITTABLE)
    if len(y) == 0:
        return dict(zip(names, [0.0, 0.0, 0.0, 0.0, 0.0]))
    if len(y) > 10000:
        ix = np.linspace(0, len(y) - 1, 10000).astype(int)
        X, y = X[ix], y[ix]

    e, B = _features(X)
    active = np.ptp(B[:, 1:], axis=0) > 1e-8
    B[:, 1:] *= active

    background = float(np.clip(np.percentile(y, 10), 0.0, 200.0))
    fraction = np.clip(
        np.sum(e * (y - background)) / max(np.sum(e * e), 1e-12),
        0.01, 0.99
    )
    p0 = np.array([
        np.log(fraction / (1.0 - fraction)), 0.0, 0.0, 0.0, background
    ])

    def residual(p):
        return p[4] + e * expit(B @ p[:4]) - y

    def jacobian(p):
        z = expit(B @ p[:4])
        return np.column_stack((
            (e * z * (1.0 - z))[:, None] * B,
            np.ones(len(y))
        ))

    try:
        result = least_squares(
            residual, p0, jac=jacobian,
            bounds=([-15.0, 0.0, 0.0, 0.0, 0.0],
                    [15.0, 5.0, 5.0, 5.0, 200.0]),
            max_nfev=150,
            x_scale="jac",
        )
        p = result.x if np.all(np.isfinite(result.x)) else p0
    except Exception:
        p = p0
    p[1:4] *= active
    return dict(zip(names, map(float, p)))

def predict(X, intercept, vegetation, dryness, temperature, background):
    e, B = _features(X)
    p = np.array([intercept, vegetation, dryness, temperature])
    return np.asarray(background + e * expit(B @ p), dtype=float)