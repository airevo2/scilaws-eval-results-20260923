"""A generalized Gompertz law with a shared age pivot and exponentially evolving mortality gradient."""
import numpy as np
from scipy.optimize import least_squares

USED_INPUTS = ["age", "year"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {
    "a": {"init": None},
    "b": {"init": None},
    "c": {"init": None},
}

def fit(X_fit, y_fit):
    X_fit = np.asarray(X_fit, dtype=float)
    y = np.asarray(y_fit, dtype=float).reshape(-1)
    z = X_fit[:, 0] ** (3.0 / 2.0)
    year = X_fit[:, 1]
    center = float(np.mean(year))
    t = year - center

    design = np.column_stack((z, t, np.ones_like(z)))
    coef = np.linalg.lstsq(design, y, rcond=None)[0]
    slope = max(float(coef[0]), np.finfo(float).eps)
    pivot = -float(coef[2]) / slope
    denominator = slope * (float(np.mean(z)) - pivot)
    rate = float(coef[1]) / denominator if abs(denominator) > np.finfo(float).eps else 0.0
    initial = np.array([np.log(slope), rate, pivot])

    def residual(p):
        gradient = np.exp(np.clip(p[0] + p[1] * t, -300.0, 300.0))
        return gradient * (z - p[2]) - y

    fitted = initial
    try:
        result = least_squares(
            residual, initial, x_scale="jac", max_nfev=300
        )
        if np.all(np.isfinite(result.x)):
            if np.linalg.norm(residual(result.x)) <= np.linalg.norm(residual(initial)):
                fitted = result.x
    except (ValueError, FloatingPointError, np.linalg.LinAlgError):
        pass

    return {
        "a": float(fitted[0] - fitted[1] * center),
        "b": float(fitted[1]),
        "c": float(fitted[2]),
    }

def predict(X, a, b, c):
    X = np.asarray(X, dtype=float)
    gradient = np.exp(np.clip(a + b * X[:, 1], -300.0, 300.0))
    return gradient * (X[:, 0] ** (3.0 / 2.0) - c)