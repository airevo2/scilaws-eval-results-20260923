"""Three-parameter Gaisser–Hillas profile with zero-depth onset."""
import numpy as np
from scipy.optimize import least_squares

USED_INPUTS = ["X"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {
    "amplitude": {"init": None},
    "xmax": {"init": None},
    "width": {"init": None},
}

def predict(X, amplitude, xmax, width):
    depth = np.maximum(np.asarray(X, dtype=float)[:, 0], np.finfo(float).tiny)
    xmax = max(float(xmax), np.finfo(float).tiny)
    width = max(float(width), np.finfo(float).tiny)
    u = depth / xmax - 1.0
    log_shape = (xmax / width) ** 2 * (
        np.log(depth / xmax) - u
    )
    return float(amplitude) * np.exp(np.clip(log_shape, -700.0, 0.0))

def fit(X_fit, y_fit):
    X = np.asarray(X_fit, dtype=float)
    y = np.asarray(y_fit, dtype=float).reshape(-1)
    valid = np.isfinite(X[:, 0]) & np.isfinite(y) & (X[:, 0] > 0)
    X, y = X[valid], y[valid]
    if len(y) == 0:
        return {"amplitude": 0.0, "xmax": 1.0, "width": 1.0}

    x = X[:, 0]
    span = max(float(np.ptp(x)), 1.0)
    scale = max(float(np.max(y)), np.finfo(float).eps)
    lower = np.array([
        0.0,
        max(1.0, float(np.min(x)) - span),
        max(1.0, span / 20.0),
    ])
    upper = np.array([
        10.0 * scale,
        float(np.max(x)) + span,
        10.0 * span,
    ])
    initial = np.array([
        max(float(np.quantile(y, 0.8)), scale / 10.0),
        float(np.median(x)),
        span / 2.0,
    ])
    initial = np.maximum(lower + 1e-8 * (upper - lower), initial)
    initial = np.minimum(upper - 1e-8 * (upper - lower), initial)

    def residual(p):
        return (predict(X, *p) - y) / scale

    parameters = initial
    try:
        result = least_squares(
            residual,
            initial,
            bounds=(lower, upper),
            x_scale="jac",
            max_nfev=300,
            ftol=1e-9,
            xtol=1e-9,
            gtol=1e-9,
        )
        if np.all(np.isfinite(result.x)):
            parameters = result.x
    except (ValueError, FloatingPointError, RuntimeError):
        pass

    return {
        "amplitude": float(parameters[0]),
        "xmax": float(parameters[1]),
        "width": float(parameters[2]),
    }