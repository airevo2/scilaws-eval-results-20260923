"""Human-capital-augmented Cobb–Douglas law with bounded elasticities."""
import numpy as np

USED_INPUTS = ["cn", "emp", "hc"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {
    "a": {"init": None},
    "alpha": {"init": None},
    "beta": {"init": None},
}

def _features(X):
    X = np.asarray(X, dtype=float)
    tiny = np.finfo(float).tiny
    k = np.log(np.maximum(X[:, 0], tiny)) - np.log(
        np.maximum(X[:, 1], tiny)
    )
    h = np.log(np.maximum(X[:, 2], tiny))
    return np.column_stack((k, h))

def fit(X_fit, y_fit):
    F = _features(X_fit)
    y = np.asarray(y_fit, dtype=float).reshape(-1)
    valid = np.isfinite(y) & np.all(np.isfinite(F), axis=1)
    F, y = F[valid], y[valid]
    if len(y) == 0:
        return {"a": 0.0, "alpha": 0.0, "beta": 0.0}

    center = F.mean(axis=0)
    level = float(y.mean())
    A = F - center
    b = y - level

    # Capital elasticity lies in [0, 1]; the human-capital effect
    # is bounded, with combined elasticity no greater than one.
    vertices = np.array([
        [0.0, -1.0],
        [1.0, -1.0],
        [1.0, 0.0],
        [0.0, 1.0],
    ])
    candidates = [np.zeros(2)]
    try:
        p = np.linalg.lstsq(A, b, rcond=None)[0]
        if (0.0 <= p[0] <= 1.0 and
                p[1] >= -1.0 and p.sum() <= 1.0):
            candidates.append(p)
    except np.linalg.LinAlgError:
        pass

    # Exact least-squares minimization along each feasible boundary.
    for j in range(len(vertices)):
        start = vertices[j]
        direction = vertices[(j + 1) % len(vertices)] - start
        v = A @ direction
        denominator = float(v @ v)
        t = float(v @ (b - A @ start)) / denominator if denominator > 0 else 0.0
        candidates.append(start + np.clip(t, 0.0, 1.0) * direction)

    p = min(candidates, key=lambda q: float(np.sum((A @ q - b) ** 2)))
    return {
        "a": float(level - center @ p),
        "alpha": float(p[0]),
        "beta": float(p[1]),
    }

def predict(X, a, alpha, beta):
    F = _features(X)
    return np.asarray(a + alpha * F[:, 0] + beta * F[:, 1])