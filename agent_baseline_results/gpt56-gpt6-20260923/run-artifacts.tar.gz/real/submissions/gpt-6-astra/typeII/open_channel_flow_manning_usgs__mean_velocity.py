"""Chezy-type resistance law with one locally calibrated velocity coefficient."""
import numpy as np

USED_INPUTS = ["R_m", "SLOPE"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {"C": {"init": None}}

def fit(X_fit, y_fit):
    X_fit = np.asarray(X_fit, dtype=float)
    y_fit = np.asarray(y_fit, dtype=float).reshape(-1)
    basis = np.sqrt(
        np.maximum(X_fit[:, 0], 0.0) *
        np.maximum(X_fit[:, 1], 0.0)
    )
    valid = np.isfinite(basis) & np.isfinite(y_fit) & (basis > 0.0)
    denominator = np.sum(basis[valid])
    if denominator > 0.0:
        C = max(float(np.sum(y_fit[valid]) / denominator), 0.0)
    else:
        C = 0.0
    return {"C": C}

def predict(X, C):
    X = np.asarray(X, dtype=float)
    return C * np.sqrt(
        np.maximum(X[:, 0], 0.0) *
        np.maximum(X[:, 1], 0.0)
    )