"""Urban output follows a power law in population: log_GMP = a + b * log_pop."""
import numpy as np

USED_INPUTS = ["log_pop"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {"a": {"init": None}, "b": {"init": None}}

def fit(X_fit, y_fit):
    x = np.asarray(X_fit, dtype=float)[:, 0]
    y = np.asarray(y_fit, dtype=float).reshape(-1)
    valid = np.isfinite(x) & np.isfinite(y)
    x, y = x[valid], y[valid]
    if x.size == 0:
        return {"a": 0.0, "b": 1.0}
    x_mean, y_mean = np.mean(x), np.mean(y)
    dx = x - x_mean
    denominator = np.dot(dx, dx)
    b = float(np.dot(dx, y - y_mean) / denominator) if denominator > 0 else 1.0
    a = float(y_mean - b * x_mean)
    return {"a": a, "b": b}

def predict(X, a, b):
    return a + b * np.asarray(X, dtype=float)[:, 0]