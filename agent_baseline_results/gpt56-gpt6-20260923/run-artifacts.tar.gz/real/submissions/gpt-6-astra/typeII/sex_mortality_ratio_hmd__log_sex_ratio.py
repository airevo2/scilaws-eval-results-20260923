"""A positive, log-concave quadratic in cubed adult age, calibrated per population."""
import numpy as np
from scipy.optimize import least_squares

USED_INPUTS = ["age"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {
    "a": {"init": None},
    "b": {"init": None},
    "c": {"init": None},
}

def fit(X_fit, y_fit):
    age = np.asarray(X_fit, dtype=float)[:, 0]
    y = np.asarray(y_fit, dtype=float).reshape(-1)
    valid = np.isfinite(age) & np.isfinite(y)
    age, y = age[valid], y[valid]

    if y.size == 0:
        return {"a": 0.0, "b": 0.0, "c": 0.0}

    ages, inverse, counts = np.unique(
        age, return_inverse=True, return_counts=True
    )
    means = np.bincount(inverse, weights=y) / counts
    weights = np.sqrt(counts / counts.sum())
    z = (ages / 100.0) ** 3
    design = np.column_stack((np.ones_like(z), z, z * z))

    initial = np.array([
        np.log(max(float(np.mean(y)), 1e-8)), 0.0, -1.0
    ])

    def residual(p):
        prediction = np.exp(np.clip(design @ p, -50.0, 20.0))
        return weights * (prediction - means)

    def jacobian(p):
        linear = design @ p
        prediction = np.exp(np.clip(linear, -50.0, 20.0))
        active = (linear > -50.0) & (linear < 20.0)
        return design * (weights * prediction * active)[:, None]

    best = initial
    try:
        result = least_squares(
            residual,
            initial,
            jac=jacobian,
            bounds=([-np.inf, -np.inf, -np.inf],
                    [np.inf, np.inf, 0.0]),
            max_nfev=300,
        )
        if np.all(np.isfinite(result.x)):
            best = result.x
    except (ValueError, FloatingPointError, np.linalg.LinAlgError):
        pass

    return {"a": float(best[0]), "b": float(best[1]), "c": float(best[2])}

def predict(X, a, b, c):
    age = np.asarray(X, dtype=float)[:, 0]
    z = (age / 100.0) ** 3
    return np.exp(np.clip(a + b * z + c * z * z, -50.0, 20.0))