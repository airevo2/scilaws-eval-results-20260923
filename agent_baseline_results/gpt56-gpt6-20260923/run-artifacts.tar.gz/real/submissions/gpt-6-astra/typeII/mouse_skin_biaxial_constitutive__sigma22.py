"""Two coupled tensile-strain power laws with nonnegative amplitudes."""
import numpy as np
from scipy.optimize import least_squares

USED_INPUTS = ["lambda11", "lambda22"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {
    "log_A": {"init": None},
    "n": {"init": None},
    "log_B": {"init": None},
    "m": {"init": None},
    "coupling": {"init": None},
}

def predict(X, log_A, n, log_B, m, coupling):
    X = np.asarray(X, dtype=float)
    u = X[:, 0] - 1.0
    v = X[:, 1] - 1.0
    z = np.maximum(v + coupling * u, 0.0)
    w = np.maximum(u + coupling * v, 0.0)
    first = np.exp(np.clip(log_A + n * np.log(np.maximum(z, 1e-100)), -700, 100))
    second = np.exp(np.clip(log_B + m * np.log(np.maximum(w, 1e-100)), -700, 100))
    return np.where(z > 0, first, 0.0) + np.where(w > 0, second, 0.0)

def fit(X_fit, y_fit):
    X = np.asarray(X_fit, dtype=float)
    y = np.asarray(y_fit, dtype=float).reshape(-1)
    valid = np.isfinite(y) & np.all(np.isfinite(X), axis=1)
    X, y = X[valid], y[valid]
    names = ("log_A", "n", "log_B", "m", "coupling")
    p = np.array([-3.0, 5.0, -3.0, 5.0, 0.0])
    if len(y) == 0:
        return dict(zip(names, [-40.0, 1.0, -40.0, 1.0, 0.0]))
    scale = max(float(np.std(y)), 0.001)
    def residual(q):
        return (predict(X, *q) - y) / scale
    try:
        result = least_squares(
            residual,
            p,
            bounds=(
                [-40.0, 1.0, -40.0, 1.0, -0.5],
                [30.0, 15.0, 30.0, 15.0, 0.5],
            ),
            max_nfev=500,
            ftol=1e-9,
            xtol=1e-9,
            gtol=1e-9,
        )
        if np.all(np.isfinite(result.x)):
            p = result.x
    except Exception:
        pass
    return {name: float(value) for name, value in zip(names, p)}