"""Nonnegative capacity law combining mean throughput, cycle fade, and a diffusion-scale throughput correction."""
import numpy as np
from scipy.optimize import lsq_linear

USED_INPUTS = ["cycle_index", "efc"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {
    "a": {"init": None},
    "b": {"init": None},
    "c": {"init": None},
    "d": {"init": None},
}

def _basis(X):
    X = np.asarray(X, dtype=float)
    k = np.maximum(X[:, 0], np.finfo(float).eps)
    e = np.maximum(X[:, 1], 0.0)
    return np.column_stack((
        np.ones_like(k),
        e / k,
        -k,
        e / np.sqrt(k),
    ))

def fit(X_fit, y_fit):
    A = _basis(X_fit)
    y = np.asarray(y_fit, dtype=float).reshape(-1)
    valid = np.isfinite(y) & np.all(np.isfinite(A), axis=1)
    A, y = A[valid], y[valid]
    fallback = float(max(0.0, np.median(y))) if y.size else 0.0
    params = np.array([fallback, 0.0, 0.0, 0.0])

    if y.size:
        try:
            scale = np.linalg.norm(A, axis=0)
            scale = np.where(scale > 0.0, scale, 1.0)
            result = lsq_linear(
                A / scale,
                y,
                bounds=(0.0, np.inf),
                tol=1e-10,
                max_iter=150,
            )
            candidate = result.x / scale
            if np.all(np.isfinite(candidate)):
                params = candidate
        except Exception:
            pass

    return dict(zip(("a", "b", "c", "d"), map(float, params)))

def predict(X, a, b, c, d):
    capacity = _basis(X) @ np.array([a, b, c, d], dtype=float)
    return np.maximum(capacity, 0.0)