"""Generalized logarithmic dose response: LRV = ln(1 + exp(a) CT**b)."""
import numpy as np
from scipy.optimize import least_squares

USED_INPUTS = ["CT"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {"a": {"init": None}, "b": {"init": None}}

def fit(X_fit, y_fit):
    x = np.asarray(X_fit, dtype=float)[:, 0]
    y = np.asarray(y_fit, dtype=float).reshape(-1)
    valid = np.isfinite(x) & np.isfinite(y) & (x >= 0)
    x, y = x[valid], np.maximum(y[valid], 0.0)
    if y.size == 0:
        return {"a": -30.0, "b": 0.0}

    logx = np.log(np.maximum(x, np.finfo(float).tiny))
    center = float(np.mean(logx))
    z = logx - center
    mean_y = max(float(np.mean(y)), np.finfo(float).eps)
    intercept = mean_y + np.log(-np.expm1(-mean_y))
    variance = float(np.dot(z, z))
    slope = max(0.0, float(np.dot(z, y) / variance)) if variance > 0 else 0.0
    initial = np.array([intercept, slope])

    def residual(p):
        return np.logaddexp(0.0, p[0] + p[1] * z) - y

    def jacobian(p):
        t = p[0] + p[1] * z
        sigmoid = np.exp(-np.logaddexp(0.0, -t))
        return np.column_stack((sigmoid, sigmoid * z))

    try:
        result = least_squares(
            residual, initial, jac=jacobian,
            bounds=([-np.inf, 0.0], [np.inf, np.inf]),
            max_nfev=300
        )
        p = result.x if np.all(np.isfinite(result.x)) else initial
    except Exception:
        p = initial
    return {"a": float(p[0] - p[1] * center), "b": float(p[1])}

def predict(X, a, b):
    ct = np.asarray(X, dtype=float)[:, 0]
    log_ct = np.log(np.maximum(ct, np.finfo(float).tiny))
    return np.logaddexp(0.0, a + b * log_ct)