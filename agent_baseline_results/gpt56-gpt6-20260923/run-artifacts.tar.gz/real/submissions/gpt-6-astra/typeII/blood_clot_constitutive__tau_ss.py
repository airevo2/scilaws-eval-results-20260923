"""Monotone strain-stiffening shear law with per-specimen strain and stress offsets."""
import numpy as np
from scipy.optimize import least_squares

USED_INPUTS = ["gamma"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {
    "A": {"init": None},
    "gamma0": {"init": None},
    "tau0": {"init": None},
}

def fit(X_fit, y_fit):
    x = np.asarray(X_fit[:, 0], dtype=float)
    y = np.asarray(y_fit, dtype=float)
    valid = np.isfinite(x) & np.isfinite(y)
    x, y = x[valid], y[valid]
    if len(y) == 0:
        return {"A": 0.0, "gamma0": 0.0, "tau0": 0.0}

    design = np.column_stack([
        x**3 * (1.0 + x*x),
        -(3.0*x*x + 5.0*x**4),
        np.ones_like(x),
    ])
    coefficients = np.linalg.lstsq(design, y, rcond=None)[0]
    amplitude = max(float(coefficients[0]), 1e-10)
    shift = float(np.clip(coefficients[1] / amplitude, -0.5, 0.5))
    initial = np.array([amplitude, shift, float(coefficients[2])])

    def residual(p):
        z = x - p[1]
        return p[0] * z**3 * (1.0 + z*z) + p[2] - y

    def jacobian(p):
        z = x - p[1]
        return np.column_stack([
            z**3 * (1.0 + z*z),
            -p[0] * (3.0*z*z + 5.0*z**4),
            np.ones_like(z),
        ])

    try:
        result = least_squares(
            residual, initial, jac=jacobian,
            bounds=([0.0, -1.0, -np.inf], [np.inf, 1.0, np.inf]),
            x_scale="jac", max_nfev=200,
        )
        parameters = result.x if np.all(np.isfinite(result.x)) else initial
    except Exception:
        parameters = initial

    return {
        "A": float(parameters[0]),
        "gamma0": float(parameters[1]),
        "tau0": float(parameters[2]),
    }

def predict(X, A, gamma0, tau0):
    z = np.asarray(X[:, 0], dtype=float) - gamma0
    return A * z**3 * (1.0 + z*z) + tau0