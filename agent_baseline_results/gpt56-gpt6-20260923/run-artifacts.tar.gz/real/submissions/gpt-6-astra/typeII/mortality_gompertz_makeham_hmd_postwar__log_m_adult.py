"""Age-corrected Gompertz mortality with a log-linear calendar-time trend."""
import numpy as np

USED_INPUTS = ["age", "year"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {
    "intercept": {"init": None},
    "age_slope": {"init": None},
    "year_slope": {"init": None},
}

def fit(X_fit, y_fit):
    X = np.asarray(X_fit, dtype=float)
    y = np.asarray(y_fit, dtype=float).reshape(-1)
    valid = np.isfinite(y) & np.all(np.isfinite(X), axis=1) & (X[:, 0] > 0)
    X, y = X[valid], y[valid]
    if len(y) == 0:
        return {"intercept": 0.0, "age_slope": 0.0, "year_slope": 0.0}

    age = X[:, 0]
    year = X[:, 1]
    age_center = float(np.mean(age))
    year_center = float(np.mean(year))
    design = np.column_stack((
        np.ones(len(y)),
        age - age_center,
        year - year_center,
    ))
    coefficients = np.linalg.lstsq(design, y + np.log(age), rcond=None)[0]
    intercept = coefficients[0] - coefficients[1] * age_center - coefficients[2] * year_center
    return {
        "intercept": float(intercept),
        "age_slope": float(coefficients[1]),
        "year_slope": float(coefficients[2]),
    }

def predict(X, intercept, age_slope, year_slope):
    X = np.asarray(X, dtype=float)
    age = np.maximum(X[:, 0], np.finfo(float).tiny)
    return intercept + age_slope * age + year_slope * X[:, 1] - np.log(age)