"""Bethe-like logarithmic high-energy decay with smooth low-energy suppression."""
import numpy as np
from scipy.optimize import least_squares

USED_INPUTS = ["electron_energy_eV"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {
    "amplitude": {"init": None},
    "energy_scale": {"init": None},
    "suppression_energy": {"init": None},
    "quadratic_scale": {"init": None},
    "energy_offset": {"init": None},
}

def _form(E, amplitude, energy_scale, suppression_energy,
          quadratic_scale, energy_offset):
    E = np.maximum(np.asarray(E, dtype=float), np.finfo(float).tiny)
    return (
        amplitude * np.log1p(E / energy_scale)
        * np.exp(-suppression_energy / E)
        / (E + energy_offset + quadratic_scale / E)
    )

def fit(X_fit, y_fit):
    E = np.asarray(X_fit, dtype=float)[:, 0]
    y = np.asarray(y_fit, dtype=float).reshape(-1)
    valid = np.isfinite(E) & np.isfinite(y) & (E > 0)
    E, y = E[valid], y[valid]

    names = tuple(LOCAL_FITTABLE)
    if len(E) == 0:
        return dict(zip(names, [0.0, 1.0, 1.0, 0.0, 0.0]))

    scale = max(float(np.max(np.abs(y))), 1e-12)
    yn = y / scale
    lower = [0.0, 0.001, 0.0, 0.0, 0.0]
    upper = [1e6, 1e4, 1e4, 1e7, 1e4]
    starts = [
        [150.0, 10.0, 60.0, 200.0, 10.0],
        [150.0, 0.1, 20.0, 5000.0, 50.0],
        [150.0, 30.0, 40.0, 1000.0, 0.0],
    ]

    best = np.asarray(starts[0], dtype=float)
    best_error = np.inf
    for initial in starts:
        try:
            result = least_squares(
                lambda p: _form(E, *p) - yn,
                initial,
                bounds=(lower, upper),
                x_scale="jac",
                max_nfev=600,
            )
            error = float(np.dot(result.fun, result.fun))
            if np.all(np.isfinite(result.x)) and error < best_error:
                best = result.x.copy()
                best_error = error
        except (ValueError, RuntimeError, FloatingPointError):
            continue

    best[0] *= scale
    return dict(zip(names, map(float, best)))

def predict(X, amplitude, energy_scale, suppression_energy,
            quadratic_scale, energy_offset):
    return _form(
        np.asarray(X, dtype=float)[:, 0],
        amplitude, energy_scale, suppression_energy,
        quadratic_scale, energy_offset,
    )