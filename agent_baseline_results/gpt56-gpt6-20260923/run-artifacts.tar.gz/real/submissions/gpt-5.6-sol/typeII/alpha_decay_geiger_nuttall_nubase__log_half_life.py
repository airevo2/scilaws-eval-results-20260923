"""Geiger-Nuttall alpha-decay relation: log half-life is affine in inverse square-root Q."""
import numpy as np

USED_INPUTS = ["Q_alpha_MeV"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {
    "a": {"init": [0.0]},
    "b": {"init": [150.0]},
}

def fit(X_fit, y_fit):
    q = np.asarray(X_fit[:, 0], dtype=float)
    y = np.asarray(y_fit, dtype=float)
    z = 1.0 / np.sqrt(np.maximum(q, 1e-12))
    A = np.column_stack((np.ones_like(z), z))
    if len(y) >= 2 and np.ptp(z) > 1e-12:
        try:
            p = np.linalg.lstsq(A, y, rcond=None)[0]
            if np.all(np.isfinite(p)):
                return {"a": float(p[0]), "b": float(p[1])}
        except Exception:
            pass
    b = 150.0
    a = float(np.mean(y - b * z)) if len(y) else 0.0
    return {"a": a, "b": b}

def predict(X, a, b):
    q = np.asarray(X[:, 0], dtype=float)
    return np.asarray(a + b / np.sqrt(np.maximum(q, 1e-12)), dtype=float)