"""Cluster-calibrated exponential biaxial skin-stress law."""
import numpy as np
from scipy.optimize import least_squares

USED_INPUTS = ["lambda11", "lambda22"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {
    "log_scale": {"init": None},
    "x2_coeff": {"init": None},
    "z2_coeff": {"init": None},
    "xz_coeff": {"init": None},
    "z_coeff": {"init": None},
}

def _form(X, log_scale, x2_coeff, z2_coeff, xz_coeff, z_coeff):
    x = np.asarray(X[:, 0], dtype=float) - 1.0
    z = np.asarray(X[:, 1], dtype=float) - 1.0
    exponent = (
        x2_coeff * x * x
        + z2_coeff * z * z
        + xz_coeff * x * z
        + z_coeff * z
    )
    exponent = np.clip(exponent, -30.0, 30.0)
    scale = np.exp(np.clip(log_scale, -20.0, 5.0))
    return scale * np.expm1(exponent)

def fit(X_fit, y_fit):
    y_fit = np.asarray(y_fit, dtype=float)
    scale0 = max(float(np.percentile(np.abs(y_fit), 85)), 1e-5)
    p0 = np.array([np.log(scale0), 1.0, 4.0, 1.0, 2.0], dtype=float)
    lower = np.array([-20.0, -50.0, -50.0, -50.0, -50.0])
    upper = np.array([5.0, 50.0, 50.0, 50.0, 50.0])
    try:
        result = least_squares(
            lambda p: _form(X_fit, *p) - y_fit,
            p0,
            bounds=(lower, upper),
            loss="soft_l1",
            f_scale=max(0.001, 0.1 * scale0),
            max_nfev=1200,
        )
        p = np.clip(result.x, lower, upper)
    except Exception:
        p = p0
    return {
        "log_scale": float(p[0]),
        "x2_coeff": float(p[1]),
        "z2_coeff": float(p[2]),
        "xz_coeff": float(p[3]),
        "z_coeff": float(p[4]),
    }

def predict(X, log_scale, x2_coeff, z2_coeff, xz_coeff, z_coeff):
    return np.asarray(
        _form(X, log_scale, x2_coeff, z2_coeff, xz_coeff, z_coeff),
        dtype=float,
    )