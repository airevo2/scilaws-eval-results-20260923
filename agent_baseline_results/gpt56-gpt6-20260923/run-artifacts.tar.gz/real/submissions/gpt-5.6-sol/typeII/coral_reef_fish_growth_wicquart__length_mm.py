"""Three-parameter von Bertalanffy growth curve with a directly fitted age-zero length."""
import numpy as np
from scipy.optimize import least_squares

USED_INPUTS = ["Agei"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {
    "L0": {"init": None},
    "A": {"init": None},
    "k": {"init": None},
}

def _form(age, L0, A, k):
    z = np.clip(-k * np.maximum(age, 0.0), -700.0, 0.0)
    return L0 + A * (-np.expm1(z))

def fit(X_fit, y_fit):
    age = np.asarray(X_fit[:, 0], dtype=float)
    y = np.asarray(y_fit, dtype=float)
    finite = np.isfinite(age) & np.isfinite(y)
    age = np.maximum(age[finite], 0.0)
    y = y[finite]

    if y.size == 0:
        return {"L0": 0.0, "A": 1.0, "k": 0.2}

    ymin = float(np.min(y))
    ymax = float(np.max(y))
    yrange = max(ymax - ymin, 1.0)
    yscale = max(abs(ymax), abs(ymin), yrange, 1.0)
    amin = -2.0 * yscale
    amax = 2.0 * yscale
    upper_A = 10.0 * yscale

    order = np.argsort(age)
    n0 = max(1, min(len(y), max(2, len(y) // 10)))
    L0_init = float(np.median(y[order[:n0]]))
    A_init = max(ymax - L0_init, 0.25 * yrange)
    k_init = 0.2
    p0 = np.array([
        np.clip(L0_init, amin, amax),
        np.clip(A_init, 1e-6, upper_A),
        k_init,
    ])

    try:
        res = least_squares(
            lambda p: _form(age, p[0], p[1], p[2]) - y,
            p0,
            bounds=([amin, 1e-8, 1e-4], [amax, upper_A, 5.0]),
            loss="soft_l1",
            f_scale=max(0.05 * yrange, 1e-3),
            max_nfev=600,
        )
        p = res.x
        if not np.all(np.isfinite(p)):
            raise ValueError
        return {"L0": float(p[0]), "A": float(p[1]), "k": float(p[2])}
    except Exception:
        return {"L0": float(np.clip(L0_init, amin, amax)),
                "A": float(np.clip(A_init, 1e-8, upper_A)),
                "k": k_init}

def predict(X, L0, A, k):
    age = np.asarray(X[:, 0], dtype=float)
    out = _form(age, float(L0), float(A), float(k))
    return np.asarray(out, dtype=float)