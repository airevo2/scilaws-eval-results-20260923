"""Cluster-calibrated power-law allometry for whole-plant leaf area."""
import numpy as np

USED_INPUTS = ["a_ssbh", "h_t"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {"log_c": {"init": None}}

def fit(X_fit, y_fit):
    A = np.maximum(np.asarray(X_fit[:, 0], dtype=float), 1e-300)
    H = np.maximum(np.asarray(X_fit[:, 1], dtype=float), 1e-300)
    Y = np.maximum(np.asarray(y_fit, dtype=float), 1e-300)
    residual = np.log(Y) - 1.2678 * np.log(A) + 0.8238 * np.log(H)
    return {"log_c": float(np.median(residual))}

def predict(X, log_c):
    A = np.maximum(np.asarray(X[:, 0], dtype=float), 1e-300)
    H = np.maximum(np.asarray(X[:, 1], dtype=float), 1e-300)
    log_prediction = log_c + 1.2678 * np.log(A) - 0.8238 * np.log(H)
    return np.exp(np.clip(log_prediction, -745.0, 709.0))