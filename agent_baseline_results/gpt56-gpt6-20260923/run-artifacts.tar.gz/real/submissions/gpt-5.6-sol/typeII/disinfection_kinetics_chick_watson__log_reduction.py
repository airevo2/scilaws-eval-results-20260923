"""Two-parameter affine dose-response in log10(CT), constrained to nonnegative LRV."""
import numpy as np

USED_INPUTS = ["CT"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {
    "intercept": {"init": None},
    "slope": {"init": None},
}

def fit(X_fit, y_fit):
    ct = np.maximum(np.asarray(X_fit[:, 0], dtype=float), 1e-12)
    y = np.maximum(np.asarray(y_fit, dtype=float), 0.0)
    z = np.log10(ct)
    A = np.column_stack((np.ones_like(z), z))
    try:
        beta, _, _, _ = np.linalg.lstsq(A, y, rcond=None)
        intercept = float(beta[0])
        slope = float(max(beta[1], 0.0))
        if not np.isfinite(intercept):
            raise ValueError
    except Exception:
        intercept = float(np.mean(y))
        slope = 0.0
    return {"intercept": intercept, "slope": slope}

def predict(X, intercept, slope):
    ct = np.maximum(np.asarray(X[:, 0], dtype=float), 1e-12)
    return np.maximum(
        0.0,
        float(intercept) + float(max(slope, 0.0)) * np.log10(ct),
    )