"""Cluster-calibrated quadratic load model with linear evaporator and condenser temperature effects."""
import numpy as np

USED_INPUTS = ["T_ei", "T_ci", "Q_e"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {
    "a": {"init": None},
    "b_e": {"init": None},
    "b_c": {"init": None},
    "b_q": {"init": None},
    "b_q2": {"init": None},
}

def _design(X):
    Te = (np.asarray(X[:, 0], dtype=float) - 285.0) / 5.0
    Tc = (np.asarray(X[:, 1], dtype=float) - 296.0) / 5.0
    Q = (np.asarray(X[:, 2], dtype=float) - 200.0) / 100.0
    return np.column_stack((np.ones(len(Te)), Te, Tc, Q, Q * Q))

def fit(X_fit, y_fit):
    A = _design(X_fit)
    y = np.asarray(y_fit, dtype=float)
    try:
        c, _, _, _ = np.linalg.lstsq(A, y, rcond=None)
        if not np.all(np.isfinite(c)):
            raise ValueError
    except Exception:
        c = np.array([float(np.mean(y)), 0.0, 0.0, 0.0, 0.0])
    return {
        "a": float(c[0]),
        "b_e": float(c[1]),
        "b_c": float(c[2]),
        "b_q": float(c[3]),
        "b_q2": float(c[4]),
    }

def predict(X, a, b_e, b_c, b_q, b_q2):
    A = _design(X)
    c = np.array([a, b_e, b_c, b_q, b_q2], dtype=float)
    out = A @ c
    return np.asarray(out, dtype=float)