"""Four-parameter logistic growth law for OD600 trajectories."""
import numpy as np
from scipy.optimize import least_squares

USED_INPUTS = ["time_h"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {
    "baseline": {"init": None},
    "amplitude": {"init": None},
    "rate": {"init": None},
    "midpoint": {"init": None},
}

def _logistic(t, baseline, amplitude, rate, midpoint):
    z = np.clip(-rate * (t - midpoint), -60.0, 60.0)
    return baseline + amplitude / (1.0 + np.exp(z))

def fit(X_fit, y_fit):
    t = np.asarray(X_fit[:, 0], dtype=float)
    y = np.asarray(y_fit, dtype=float)
    order = np.argsort(t)
    t = t[order]
    y = y[order]

    lo_t = float(np.min(t))
    hi_t = float(np.max(t))
    lo_y = float(np.min(y))
    hi_y = float(np.max(y))
    spread = max(hi_y - lo_y, 0.001)
    baseline0 = max(0.0, lo_y - 0.002)
    amplitude0 = max(0.02, 1.25 * spread)
    rate0 = 0.35
    midpoint0 = hi_t + 2.0

    # A nearly flat calibration window is common for non-growing wells.
    # Keep its extrapolation nearly flat unless a measurable slope supports growth.
    if spread < 0.004:
        return {
            "baseline": float(np.clip(np.median(y), 0.0, 1.0)),
            "amplitude": 0.30,
            "rate": 0.015,
            "midpoint": max(hi_t + 20.0, 35.0),
        }

    p0 = np.array([baseline0, amplitude0, rate0, midpoint0], dtype=float)
    lower = np.array([0.0, 0.005, 0.005, lo_t - 30.0])
    upper = np.array([max(0.20, hi_y), 0.80, 3.0, hi_t + 60.0])

    try:
        res = least_squares(
            lambda p: _logistic(t, p[0], p[1], p[2], p[3]) - y,
            np.clip(p0, lower + 1e-9, upper - 1e-9),
            bounds=(lower, upper),
            loss="soft_l1",
            f_scale=0.003,
            max_nfev=250,
        )
        p = res.x
        return {
            "baseline": float(p[0]),
            "amplitude": float(p[1]),
            "rate": float(p[2]),
            "midpoint": float(p[3]),
        }
    except Exception:
        return {
            "baseline": float(np.clip(baseline0, 0.0, 1.0)),
            "amplitude": float(amplitude0),
            "rate": float(rate0),
            "midpoint": float(midpoint0),
        }

def predict(X, baseline, amplitude, rate, midpoint):
    t = np.asarray(X[:, 0], dtype=float)
    return np.asarray(_logistic(t, baseline, amplitude, rate, midpoint), dtype=float)