"""Sharpe-Schoolfield thermal performance curve with per-cluster scale,
activation energy, high-temperature deactivation energy, and deactivation
temperature fitted in log-performance space."""
import numpy as np
from scipy.optimize import least_squares

USED_INPUTS = ["temperature"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {
    "log_scale": {"init": None},
    "log_activation": {"init": None},
    "log_deactivation": {"init": None},
    "deactivation_temperature": {"init": None},
}

_KELVIN = 273.15
_TREF_K = 298.15

def _log_model(T, log_scale, log_activation, log_deactivation,
               deactivation_temperature):
    T = np.asarray(T, dtype=float)
    tk = np.maximum(T + _KELVIN, 1e-6)
    th = max(float(deactivation_temperature) + _KELVIN, 1e-6)
    activation = np.exp(np.clip(log_activation, -20.0, 13.0))
    deactivation = np.exp(np.clip(log_deactivation, -20.0, 13.0))
    u = deactivation * (1.0 / th - 1.0 / tk)
    u = np.clip(u, -60.0, 60.0)
    out = (log_scale
           + activation * (1.0 / _TREF_K - 1.0 / tk)
           - np.log1p(np.exp(u)))
    return np.clip(out, -745.0, 700.0)

def fit(X_fit, y_fit):
    T = np.asarray(X_fit[:, 0], dtype=float)
    y = np.asarray(y_fit, dtype=float)
    finite = np.isfinite(T) & np.isfinite(y)
    T = T[finite]
    y = y[finite]
    if len(T) == 0:
        return {
            "log_scale": -10.0,
            "log_activation": np.log(5000.0),
            "log_deactivation": np.log(10000.0),
            "deactivation_temperature": 40.0,
        }

    ymax = max(float(np.max(y)), 1e-14)
    floor = max(1e-14, ymax * 1e-12)
    ly = np.log(np.maximum(y, floor))
    tmin = float(np.min(T))
    tmax = float(np.max(T))
    tpeak = float(T[int(np.argmax(y))])

    q0 = np.array([
        float(np.median(ly)),
        np.log(5000.0),
        np.log(10000.0),
        float(np.clip(tpeak + 8.0, tmin + 0.5, tmax + 80.0)),
    ])
    lo = np.array([
        -60.0, np.log(1.0), np.log(1.0), max(-200.0, tmin - 30.0)
    ])
    hi = np.array([
        40.0, np.log(2.0e5), np.log(2.0e5), max(100.0, tmax + 120.0)
    ])

    try:
        res = least_squares(
            lambda q: _log_model(T, q[0], q[1], q[2], q[3]) - ly,
            np.minimum(np.maximum(q0, lo + 1e-8), hi - 1e-8),
            bounds=(lo, hi),
            loss="soft_l1",
            f_scale=0.25,
            max_nfev=2500,
        )
        q = res.x
        if not np.all(np.isfinite(q)):
            q = q0
    except Exception:
        q = q0

    return {
        "log_scale": float(q[0]),
        "log_activation": float(q[1]),
        "log_deactivation": float(q[2]),
        "deactivation_temperature": float(q[3]),
    }

def predict(X, log_scale, log_activation, log_deactivation,
            deactivation_temperature):
    T = np.asarray(X[:, 0], dtype=float)
    lp = _log_model(
        T, log_scale, log_activation, log_deactivation,
        deactivation_temperature
    )
    return np.exp(np.clip(lp, -745.0, 700.0))