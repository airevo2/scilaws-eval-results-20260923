"""Time-varying quadratic log-tail curve for top income shares."""
import numpy as np

USED_INPUTS = ["log_p_above", "year"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {
    "slope": {"init": None},
    "curvature": {"init": None},
    "time_slope": {"init": None},
}

def _design(X):
    x = np.asarray(X[:, 0], dtype=float)
    t = (np.asarray(X[:, 1], dtype=float) - 2000.0) / 10.0
    return np.column_stack((x, x * x, x * t))

def fit(X_fit, y_fit):
    A = _design(X_fit)
    y = np.asarray(y_fit, dtype=float)
    try:
        coef, _, _, _ = np.linalg.lstsq(A, y, rcond=None)
        coef = np.nan_to_num(coef, nan=0.0, posinf=0.0, neginf=0.0)
    except Exception:
        coef = np.zeros(3, dtype=float)
    return {
        "slope": float(coef[0]),
        "curvature": float(coef[1]),
        "time_slope": float(coef[2]),
    }

def predict(X, slope, curvature, time_slope):
    A = _design(X)
    params = np.array([slope, curvature, time_slope], dtype=float)
    return np.nan_to_num(A @ params, nan=0.0, posinf=0.0, neginf=0.0)