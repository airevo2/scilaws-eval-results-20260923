"""Cluster-calibrated quadratic upper-tail curve with a time-varying slope."""
import numpy as np

USED_INPUTS = ["log_p_above", "year"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {
    "level": {"init": None},
    "slope": {"init": None},
    "curvature": {"init": None},
    "time_slope": {"init": None},
}

def _design(X):
    x = np.asarray(X[:, 0], dtype=float)
    u = (np.asarray(X[:, 2], dtype=float) - 2000.0) / 10.0
    return np.column_stack([
        np.ones(x.shape[0]),
        x,
        x * x,
        x * u,
    ])

def fit(X_fit, y_fit):
    B = _design(X_fit)
    y = np.asarray(y_fit, dtype=float)
    try:
        coef, _, _, _ = np.linalg.lstsq(B, y, rcond=None)
        coef = np.asarray(coef, dtype=float)
        if coef.size != 4 or not np.all(np.isfinite(coef)):
            raise ValueError
    except Exception:
        coef = np.array([float(np.mean(y)), 0.45, 0.0, 0.0], dtype=float)
    return {
        "level": float(coef[0]),
        "slope": float(coef[1]),
        "curvature": float(coef[2]),
        "time_slope": float(coef[3]),
    }

def predict(X, level, slope, curvature, time_slope):
    B = _design(X)
    coef = np.array([level, slope, curvature, time_slope], dtype=float)
    pred = B @ coef
    return np.asarray(pred, dtype=float)