"""Shared hydraulic-radius power law with one cluster-specific scale."""
import numpy as np

USED_INPUTS = ["R_m", "SLOPE"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {"k": {"init": None}}

_RADIUS_EXPONENT = 0.446

def fit(X_fit, y_fit):
    R = np.asarray(X_fit[:, 0], dtype=float)
    y = np.asarray(y_fit, dtype=float)
    z = np.power(np.maximum(R, 0.0), _RADIUS_EXPONENT)
    good = np.isfinite(z) & np.isfinite(y) & (z > 0.0)
    if not np.any(good):
        return {"k": 0.0}
    zg = z[good]
    yg = y[good]
    den = float(np.dot(zg, zg))
    if not np.isfinite(den) or den <= 0.0:
        return {"k": 0.0}
    k = float(np.dot(zg, yg) / den)
    if not np.isfinite(k):
        k = 0.0
    return {"k": max(k, 0.0)}

def predict(X, k):
    R = np.maximum(np.asarray(X[:, 0], dtype=float), 0.0)
    kk = float(k) if np.isfinite(k) else 0.0
    return kk * np.power(R, _RADIUS_EXPONENT)