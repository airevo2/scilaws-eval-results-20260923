"""Three-parameter Gompertz growth curve fitted in log-volume space."""
import numpy as np
from scipy.optimize import minimize_scalar

USED_INPUTS = ["time_day"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {
    "logK": {"init": None},
    "q": {"init": None},
    "r": {"init": None},
}

def _fit_for_r(t, logy, r):
    z = np.exp(np.clip(-r * t, -50.0, 50.0))
    M = np.column_stack((np.ones_like(t), z))
    coef, _, _, _ = np.linalg.lstsq(M, logy, rcond=None)
    resid = M @ coef - logy
    return float(np.mean(resid * resid)), coef

def fit(X_fit, y_fit):
    t = np.asarray(X_fit[:, 0], dtype=float)
    y = np.maximum(np.asarray(y_fit, dtype=float), 1e-8)
    logy = np.log(y)
    good = np.isfinite(t) & np.isfinite(logy)
    t, logy = t[good], logy[good]

    if len(t) < 2:
        v = float(np.mean(logy)) if len(logy) else 0.0
        return {"logK": v, "q": 0.0, "r": 0.05}

    def objective(log_r):
        r = float(np.exp(log_r))
        return _fit_for_r(t, logy, r)[0]

    try:
        if len(t) >= 4 and np.ptp(t) > 0:
            opt = minimize_scalar(objective, bounds=(-5.3, 0.4),
                                  method="bounded",
                                  options={"xatol": 1e-4, "maxiter": 80})
            r = float(np.exp(opt.x))
            _, coef = _fit_for_r(t, logy, r)
        else:
            r = 0.05
            _, coef = _fit_for_r(t, logy, r)

        logK = float(coef[0])
        q = float(coef[1])
        if not np.isfinite(logK) or not np.isfinite(q) or not np.isfinite(r):
            raise ValueError
        return {"logK": logK, "q": q, "r": r}
    except Exception:
        A = np.column_stack((np.ones_like(t), t))
        coef, _, _, _ = np.linalg.lstsq(A, logy, rcond=None)
        rate = float(np.clip(coef[1], -2.0, 2.0))
        level = float(coef[0] + rate * np.median(t))
        return {"logK": level, "q": -rate / 0.05, "r": 0.05}

def predict(X, logK, q, r):
    t = np.asarray(X[:, 0], dtype=float)
    r = float(np.clip(r, 1e-5, 3.0))
    exponent = float(logK) + float(q) * np.exp(np.clip(-r * t, -50.0, 50.0))
    return np.exp(np.clip(exponent, -30.0, 30.0))