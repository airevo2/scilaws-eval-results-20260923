"""Cluster-calibrated linearized energy-balance model using radiation, aerodynamic demand, and canopy scaling."""
import numpy as np

USED_INPUTS = ["SWdown", "VPD", "Ga", "Rnet", "Qg", "LAI"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {
    "a": {"init": 0.0},
    "b": {"init": 0.0},
    "c": {"init": 0.0},
    "d": {"init": 0.0},
    "e": {"init": 0.0},
}

def _design(X):
    sw = np.asarray(X[:, 0], dtype=float)
    vpd = np.asarray(X[:, 1], dtype=float)
    ga = np.maximum(np.asarray(X[:, 2], dtype=float), 0.0)
    rnet = np.asarray(X[:, 3], dtype=float)
    qg = np.asarray(X[:, 4], dtype=float)
    lai = np.maximum(np.asarray(X[:, 5], dtype=float), 0.0)
    available = rnet - qg
    aerodynamic = ga * np.maximum(vpd, 0.0)
    return np.column_stack((
        np.ones(len(X)),
        available,
        sw,
        aerodynamic,
        available * lai,
    ))

def fit(X_fit, y_fit):
    F = _design(X_fit)
    y = np.asarray(y_fit, dtype=float)
    scale = np.maximum(np.std(F, axis=0), 1.0)
    Fs = F / scale
    try:
        coef_scaled = np.linalg.lstsq(Fs, y, rcond=None)[0]
        coef = coef_scaled / scale
        coef = np.nan_to_num(coef, nan=0.0, posinf=0.0, neginf=0.0)
        return {
            "a": float(coef[0]),
            "b": float(coef[1]),
            "c": float(coef[2]),
            "d": float(coef[3]),
            "e": float(coef[4]),
        }
    except Exception:
        return {"a": 100.0, "b": 0.3, "c": 0.05, "d": 100.0, "e": 0.0}

def predict(X, a, b, c, d, e):
    F = _design(X)
    y = F @ np.array([a, b, c, d, e], dtype=float)
    return np.nan_to_num(y, nan=20.0, posinf=2000.0, neginf=0.0)