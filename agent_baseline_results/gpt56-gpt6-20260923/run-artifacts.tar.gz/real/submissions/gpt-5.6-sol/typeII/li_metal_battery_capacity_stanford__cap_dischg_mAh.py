"""Four-parameter saturating capacity-fade law versus equivalent full cycles."""
import numpy as np
from scipy.optimize import least_squares

USED_INPUTS = ["efc", "nominal_capacity_mAh"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {
    "A": {"init": None},
    "B": {"init": None},
    "rate": {"init": None},
    "power": {"init": None},
}

def _form(x, A, B, rate, power):
    x = np.maximum(np.asarray(x, dtype=float), 0.0)
    z = np.clip(rate * np.power(x, power), 0.0, 700.0)
    return A - B * (-np.expm1(-z))

def fit(X_fit, y_fit):
    x = np.maximum(np.asarray(X_fit[:, 0], dtype=float), 1e-8)
    y = np.asarray(y_fit, dtype=float)
    finite = np.isfinite(x) & np.isfinite(y)
    x, y = x[finite], y[finite]
    if len(y) == 0:
        return {"A": 1.0, "B": 0.1, "rate": 0.001, "power": 0.5}

    ymin = max(float(np.min(y)), 1e-8)
    ymax = max(float(np.max(y)), ymin)
    yrange = max(ymax - ymin, 0.02 * ymax, 1e-8)
    xmax = max(float(np.max(x)), 1e-8)

    p0 = np.array([
        ymax + 0.05 * yrange,
        min(0.95 * ymax, max(yrange, 1e-8)),
        1.0 / max(xmax ** 0.5, 1e-8),
        0.5,
    ])
    lo = np.array([0.0, 0.0, 1e-10, 0.10])
    hi = np.array([max(10.0 * ymax, 1.0), max(20.0 * ymax, 1.0),
                   1e3, 2.5])
    p0 = np.clip(p0, lo * 1.0001 + 1e-12, hi * 0.9999)

    def residual(p):
        return _form(x, p[0], p[1], p[2], p[3]) - y

    try:
        res = least_squares(
            residual, p0, bounds=(lo, hi), loss="soft_l1",
            f_scale=max(0.01 * ymax, 1e-8), max_nfev=1200
        )
        p = res.x
    except Exception:
        p = p0
    return {"A": float(p[0]), "B": float(p[1]),
            "rate": float(p[2]), "power": float(p[3])}

def predict(X, A, B, rate, power):
    x = np.maximum(np.asarray(X[:, 0], dtype=float), 0.0)
    y = _form(x, A, B, rate, power)
    return np.nan_to_num(y, nan=0.0, posinf=0.0, neginf=0.0)