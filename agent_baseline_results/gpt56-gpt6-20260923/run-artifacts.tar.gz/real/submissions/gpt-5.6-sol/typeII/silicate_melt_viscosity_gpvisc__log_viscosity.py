"""Three-parameter Vogel-Fulcher-Tammann temperature law per composition cluster."""
import numpy as np
from scipy.optimize import least_squares

USED_INPUTS = ["T"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {
    "a": {"init": None},
    "b": {"init": None},
    "T0": {"init": None},
}

def _predict_t(T, a, b, T0):
    T = np.asarray(T, dtype=float)
    den = np.maximum(T - T0, 5.0)
    return a + b * 10000.0 / den

def fit(X_fit, y_fit):
    T = np.asarray(X_fit[:, 0], dtype=float)
    y = np.asarray(y_fit, dtype=float)
    good = np.isfinite(T) & np.isfinite(y)
    T = T[good]
    y = y[good]

    if len(T) < 3:
        z = 10000.0 / max(float(np.mean(T)) if len(T) else 1400.0, 300.0)
        a = float(np.mean(y) - 2.0 * z) if len(y) else 0.0
        return {"a": a, "b": 2.0, "T0": 0.0}

    tmin = float(np.min(T))
    tmax = float(np.max(T))
    z = 10000.0 / T
    ab = np.linalg.lstsq(np.column_stack([np.ones(len(T)), z]), y, rcond=None)[0]

    # Keep the VFT pole safely below the calibration temperatures.
    hi = tmin - 5.0
    lo = min(-1000.0, hi - 2000.0)
    t0_init = float(np.clip(tmin - 300.0, lo, hi))
    p0 = np.array([ab[0], max(abs(float(ab[1])), 1e-3), t0_init])

    def residual(p):
        return _predict_t(T, p[0], p[1], p[2]) - y

    try:
        result = least_squares(
            residual,
            p0,
            bounds=([-100.0, 0.0, lo], [100.0, 100.0, hi]),
            loss="soft_l1",
            f_scale=0.15,
            max_nfev=300,
        )
        p = result.x
        if not np.all(np.isfinite(p)):
            raise ValueError
    except Exception:
        p = np.array([float(ab[0]), max(abs(float(ab[1])), 1e-3), 0.0])

    return {"a": float(p[0]), "b": float(p[1]), "T0": float(p[2])}

def predict(X, a, b, T0):
    return _predict_t(X[:, 0], a, b, T0)