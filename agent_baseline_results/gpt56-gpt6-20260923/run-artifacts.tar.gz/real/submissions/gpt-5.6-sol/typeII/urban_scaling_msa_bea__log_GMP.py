"""Cluster-calibrated log-linear urban scaling law with weak universal curvature."""
import numpy as np

USED_INPUTS = ["log_pop"]
LAW_CONSTANTS = {"curvature": 0.0065}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {
    "intercept": {"init": None},
    "slope": {"init": None},
}

def fit(X_fit, y_fit):
    x = np.asarray(X_fit[:, 0], dtype=float)
    y = np.asarray(y_fit, dtype=float)
    z = x - 12.5
    c = LAW_CONSTANTS["curvature"]
    response = y - c * z * z
    A = np.column_stack((np.ones_like(z), z))
    try:
        params = np.linalg.lstsq(A, response, rcond=None)[0]
        if not np.all(np.isfinite(params)):
            raise ValueError
        return {"intercept": float(params[0]), "slope": float(params[1])}
    except Exception:
        return {
            "intercept": float(np.mean(y) - c * np.mean(z * z)),
            "slope": 1.1,
        }

def predict(X, intercept, slope):
    z = np.asarray(X[:, 0], dtype=float) - 12.5
    return intercept + slope * z + LAW_CONSTANTS["curvature"] * z * z