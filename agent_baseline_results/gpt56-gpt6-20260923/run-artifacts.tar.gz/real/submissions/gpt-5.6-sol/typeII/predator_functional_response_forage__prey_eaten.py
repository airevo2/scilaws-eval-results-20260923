"""Holling Type II functional response with cluster-specific encounter and handling parameters."""
import numpy as np
from scipy.optimize import curve_fit

USED_INPUTS = ["prey_density"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {
    "attack_scale": {"init": None},
    "handling_scale": {"init": None},
}

def _form(N, attack_scale, handling_scale):
    N = np.maximum(np.asarray(N, dtype=float), 0.0)
    return attack_scale * N / (1.0 + handling_scale * N)

def fit(X_fit, y_fit):
    N = np.maximum(np.asarray(X_fit[:, 0], dtype=float), 0.0)
    y = np.maximum(np.asarray(y_fit, dtype=float), 0.0)
    positive = N > 0
    if not np.any(positive):
        return {"attack_scale": 1.0, "handling_scale": 1.0}
    Ns = N[positive]
    ys = y[positive]
    slope = float(np.max(ys / np.maximum(Ns, 1e-12)))
    ymax = float(np.max(ys))
    a0 = max(1e-6, slope, 2.0 * ymax / max(float(np.max(Ns)), 1e-12))
    b0 = max(1e-10, a0 / max(ymax, 1e-8) - 1.0 / max(float(np.max(Ns)), 1e-12))
    try:
        popt, _ = curve_fit(
            _form, Ns, ys,
            p0=[a0, b0],
            bounds=([1e-10, 0.0], [1e8, 1e8]),
            maxfev=3000
        )
        a, b = float(popt[0]), float(popt[1])
        if not np.isfinite(a) or not np.isfinite(b):
            raise ValueError
        return {"attack_scale": a, "handling_scale": b}
    except Exception:
        return {"attack_scale": a0, "handling_scale": b0}

def predict(X, attack_scale, handling_scale):
    N = np.maximum(np.asarray(X[:, 0], dtype=float), 0.0)
    pred = _form(N, attack_scale, handling_scale)
    return np.minimum(np.maximum(pred, 0.0), N)