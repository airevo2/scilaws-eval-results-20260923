"""Cluster-calibrated curved age and period trend for log central adult mortality."""
import numpy as np

USED_INPUTS = ["age", "year"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {
    "level": {"init": None},
    "age_slope": {"init": None},
    "period_slope": {"init": None},
}

def _basis(X):
    age = np.asarray(X[:, 0], dtype=float)
    year = np.asarray(X[:, 1], dtype=float)
    u = (age - 60.0) / 20.0
    v = (year - 1985.0) / 20.0
    age_shape = u + 0.05 * u * u
    period_shape = v + 0.03 * v * v
    return age_shape, period_shape

def fit(X_fit, y_fit):
    age_shape, period_shape = _basis(X_fit)
    y = np.asarray(y_fit, dtype=float)
    Z = np.column_stack((np.ones(y.size), age_shape, period_shape))
    try:
        coef, _, _, _ = np.linalg.lstsq(Z, y, rcond=None)
        if not np.all(np.isfinite(coef)):
            raise ValueError
        return {
            "level": float(coef[0]),
            "age_slope": float(coef[1]),
            "period_slope": float(coef[2]),
        }
    except Exception:
        return {
            "level": float(np.mean(y)) if y.size else -4.5,
            "age_slope": 1.85,
            "period_slope": -0.27,
        }

def predict(X, level, age_slope, period_slope):
    age_shape, period_shape = _basis(X)
    return np.asarray(level + age_slope * age_shape + period_slope * period_shape, dtype=float)