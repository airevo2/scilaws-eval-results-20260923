"""Three-parameter Gompertz-period approximation: a gently curved log-age profile plus a linear calendar-year trend."""
import numpy as np

USED_INPUTS = ["age", "year"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {
    "level": {"init": None},
    "age_slope": {"init": None},
    "period_slope": {"init": None},
}

def _design(X):
    age = np.asarray(X[:, 0], dtype=float)
    year = np.asarray(X[:, 1], dtype=float)
    z = age - 60.0
    u = (year - 2000.0) / 50.0
    # Fixed mild curvature captures the common adult-age Gompertz shape.
    age_profile = z + 0.003 * z * z
    return np.column_stack((np.ones_like(z), age_profile, u))

def fit(X_fit, y_fit):
    Z = _design(X_fit)
    y = np.asarray(y_fit, dtype=float)
    try:
        beta = np.linalg.lstsq(Z, y, rcond=None)[0]
        if not np.all(np.isfinite(beta)):
            raise ValueError
    except Exception:
        beta = np.array([float(np.mean(y)), 0.0, 0.0])
    return {
        "level": float(beta[0]),
        "age_slope": float(beta[1]),
        "period_slope": float(beta[2]),
    }

def predict(X, level, age_slope, period_slope):
    Z = _design(X)
    out = Z @ np.array([level, age_slope, period_slope], dtype=float)
    return np.nan_to_num(out, nan=0.0, posinf=20.0, neginf=-20.0)