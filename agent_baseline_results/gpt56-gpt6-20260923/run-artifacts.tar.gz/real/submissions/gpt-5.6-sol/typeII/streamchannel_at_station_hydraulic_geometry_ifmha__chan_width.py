"""At-a-station hydraulic geometry power law: channel width scales as discharge to a cluster-specific exponent."""
import numpy as np

USED_INPUTS = ["chan_discharge"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {
    "a": {"init": None},
    "b": {"init": None},
}

def fit(X_fit, y_fit):
    Q = np.asarray(X_fit[:, 0], dtype=float)
    w = np.asarray(y_fit, dtype=float)
    good = np.isfinite(Q) & np.isfinite(w) & (Q > 0.0) & (w > 0.0)
    if np.count_nonzero(good) < 2:
        return {"a": 1.0, "b": 0.5}
    x = np.log(Q[good])
    z = np.log(w[good])
    A = np.column_stack((np.ones_like(x), x))
    try:
        coef, _, _, _ = np.linalg.lstsq(A, z, rcond=None)
        intercept = float(np.clip(coef[0], -50.0, 50.0))
        b = float(np.clip(coef[1], -2.0, 2.0))
        a = float(np.exp(intercept))
        if not np.isfinite(a) or not np.isfinite(b) or a <= 0.0:
            return {"a": 1.0, "b": 0.5}
        return {"a": a, "b": b}
    except Exception:
        return {"a": 1.0, "b": 0.5}

def predict(X, a, b):
    Q = np.maximum(np.asarray(X[:, 0], dtype=float), np.finfo(float).tiny)
    out = float(a) * np.power(Q, float(b))
    return np.nan_to_num(out, nan=1.0, posinf=1e300, neginf=1e-300)