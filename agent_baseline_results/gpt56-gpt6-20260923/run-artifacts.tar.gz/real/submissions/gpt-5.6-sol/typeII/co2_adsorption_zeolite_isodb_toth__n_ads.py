"""Three-parameter Sips (Langmuir–Freundlich) adsorption isotherm."""
import numpy as np
from scipy.optimize import curve_fit

USED_INPUTS = ["P_bar"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {
    "n_sat": {"init": None},
    "K": {"init": None},
    "m": {"init": None},
}

def _sips(P, n_sat, K, m):
    P = np.maximum(np.asarray(P, dtype=float), 0.0)
    z = np.clip((K * P) ** m, 0.0, 1e300)
    return n_sat * z / (1.0 + z)

def fit(X_fit, y_fit):
    P = np.maximum(np.asarray(X_fit[:, 0], dtype=float), 1e-12)
    y = np.asarray(y_fit, dtype=float)
    ymax = max(float(np.max(y)), 1e-8)
    pmed = max(float(np.median(P)), 1e-8)
    p0 = [max(1.2 * ymax, 1e-6), 1.0 / pmed, 1.0]
    lower = [max(ymax, 1e-10), 1e-12, 0.15]
    upper = [max(100.0 * ymax, 1.0), 1e12, 4.0]
    try:
        popt, _ = curve_fit(
            _sips, P, y, p0=p0, bounds=(lower, upper),
            maxfev=4000, method="trf"
        )
        if np.all(np.isfinite(popt)):
            return {
                "n_sat": float(popt[0]),
                "K": float(popt[1]),
                "m": float(popt[2]),
            }
    except Exception:
        pass
    return {"n_sat": float(p0[0]), "K": float(p0[1]), "m": 1.0}

def predict(X, n_sat, K, m):
    return _sips(X[:, 0], n_sat, K, m)