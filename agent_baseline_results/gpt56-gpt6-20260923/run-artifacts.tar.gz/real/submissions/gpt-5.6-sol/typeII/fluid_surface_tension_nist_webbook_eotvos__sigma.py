"""One-parameter per-substance density/temperature scaling for liquid surface tension."""
import numpy as np

USED_INPUTS = ["T_K", "rho_liq", "T_c", "M_mol"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {"scale": {"init": None}}

_RHO_EXPONENT = 3.5956
_REDUCED_T_EXPONENT = 0.27895

def _shape(X):
    T = np.asarray(X[:, 0], dtype=float)
    rho = np.maximum(np.asarray(X[:, 1], dtype=float), 1e-12)
    Tc = np.maximum(np.asarray(X[:, 2], dtype=float), 1e-12)
    reduced_distance = np.maximum(1.0 - T / Tc, 1e-12)
    return rho ** _RHO_EXPONENT * reduced_distance ** _REDUCED_T_EXPONENT

def fit(X_fit, y_fit):
    z = _shape(X_fit)
    y = np.asarray(y_fit, dtype=float)
    den = float(np.dot(z, z))
    if not np.isfinite(den) or den <= 0.0:
        return {"scale": 0.0}
    a = float(np.dot(z, y) / den)
    if not np.isfinite(a):
        a = 0.0
    return {"scale": a}

def predict(X, scale):
    return np.asarray(scale * _shape(X), dtype=float)