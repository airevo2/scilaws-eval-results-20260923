"""Cluster-calibrated seasonal and low-count measles growth law.

The law combines a smooth annual seasonal component with two complementary
count effects: a logarithmic correction for epidemic size and an inverse
square-root correction that captures the distinct zero/low-count regime.
All five coefficients are calibrated from the individual cluster window.
"""
import numpy as np

USED_INPUTS = ["cases_prev", "biweek"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {
    "intercept": {"init": None},
    "season_sin": {"init": None},
    "season_cos": {"init": None},
    "count_log": {"init": None},
    "count_invroot": {"init": None},
}

def _design(X):
    X = np.asarray(X, dtype=float)
    cases = np.maximum(X[:, 0], 0.0)
    biweek = X[:, 1]
    theta = 2.0 * np.pi * (biweek - 1.0) / 26.0
    return np.column_stack((
        np.ones(len(cases)),
        np.sin(theta),
        np.cos(theta),
        np.log1p(cases),
        1.0 / np.sqrt(1.0 + cases),
    ))

def fit(X_fit, y_fit):
    A = _design(X_fit)
    y = np.asarray(y_fit, dtype=float)
    scale = np.sqrt(np.sum(A * A, axis=0))
    scale[scale < 1e-12] = 1.0
    try:
        # Column scaling makes the calibration stable for short windows.
        coef = np.linalg.lstsq(A / scale, y, rcond=None)[0] / scale
        if coef.shape != (5,) or not np.all(np.isfinite(coef)):
            raise ValueError
    except Exception:
        coef = np.zeros(5, dtype=float)
        coef[0] = float(np.mean(y)) if y.size else 0.0
    return {
        "intercept": float(coef[0]),
        "season_sin": float(coef[1]),
        "season_cos": float(coef[2]),
        "count_log": float(coef[3]),
        "count_invroot": float(coef[4]),
    }

def predict(X, intercept, season_sin, season_cos, count_log, count_invroot):
    A = _design(X)
    coef = np.array([
        intercept,
        season_sin,
        season_cos,
        count_log,
        count_invroot,
    ], dtype=float)
    result = A @ coef
    return np.nan_to_num(result, nan=0.0, posinf=10.0, neginf=-10.0)