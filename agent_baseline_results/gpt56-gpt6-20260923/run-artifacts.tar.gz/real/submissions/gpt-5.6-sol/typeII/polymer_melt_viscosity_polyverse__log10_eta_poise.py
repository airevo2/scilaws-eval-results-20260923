"""WLF-temperature, molecular-weight, and shear-rate viscosity law."""
import numpy as np

USED_INPUTS = ["Temperature_K", "log10_Mw", "Shear_Rate", "Tg_K"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {
    "log_eta_ref": {"init": None},
    "wlf_scale": {"init": None},
}

def _wlf_feature(T, Tg):
    # WLF-like temperature dependence, with a fixed broad denominator.
    d = T - Tg
    return (Tg - T) / (100.0 + d)

def fit(X_fit, y_fit):
    T = np.asarray(X_fit[:, 0], dtype=float)
    M = np.asarray(X_fit[:, 1], dtype=float)
    rate = np.asarray(X_fit[:, 2], dtype=float)
    Tg = np.asarray(X_fit[:, 3], dtype=float)
    y = np.asarray(y_fit, dtype=float)

    z = _wlf_feature(T, Tg)
    base = 2.5 * M - 0.30 * np.log10(1.0 + np.maximum(rate, 0.0))
    A = np.column_stack((np.ones_like(z), z))
    target = y - base

    try:
        p, _, _, _ = np.linalg.lstsq(A, target, rcond=None)
        if not np.all(np.isfinite(p)):
            raise ValueError
        return {"log_eta_ref": float(p[0]), "wlf_scale": float(p[1])}
    except Exception:
        return {"log_eta_ref": float(np.mean(target)), "wlf_scale": 1.0}

def predict(X, log_eta_ref, wlf_scale):
    X = np.asarray(X, dtype=float)
    T = X[:, 0]
    M = X[:, 1]
    rate = np.maximum(X[:, 2], 0.0)
    Tg = X[:, 3]
    z = _wlf_feature(T, Tg)
    out = (
        float(log_eta_ref)
        + float(wlf_scale) * z
        + 2.5 * M
        - 0.30 * np.log10(1.0 + rate)
    )
    return np.nan_to_num(out, nan=0.0, posinf=50.0, neginf=-50.0)