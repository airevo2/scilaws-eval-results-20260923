"""Two-parameter logistic dose-response model in log10 concentration."""
import numpy as np
from scipy.optimize import least_squares

USED_INPUTS = ["log10_conc_ppb"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {
    "logit_intercept": {"init": None},
    "logit_slope": {"init": None},
}

def _response(x, intercept, slope):
    z = np.clip(intercept + slope * x, -60.0, 60.0)
    return 1.0 / (1.0 + np.exp(-z))

def fit(X_fit, y_fit):
    x = np.asarray(X_fit[:, 0], dtype=float)
    y = np.asarray(y_fit, dtype=float)
    valid = np.isfinite(x) & np.isfinite(y)
    x = x[valid]
    y = np.clip(y[valid], 0.0, 1.0)

    if x.size == 0:
        return {"logit_intercept": -4.0, "logit_slope": 3.0}

    # A clipped-logit regression provides a stable start, including
    # fit windows containing mostly zero or one responses.
    q = np.clip(y, 1.0e-3, 1.0 - 1.0e-3)
    try:
        p0 = np.linalg.lstsq(
            np.column_stack((np.ones(x.size), x)),
            np.log(q / (1.0 - q)),
            rcond=None
        )[0]
    except Exception:
        p0 = np.array([-4.0, 3.0])

    if not np.all(np.isfinite(p0)):
        p0 = np.array([-4.0, 3.0])
    p0[0] = np.clip(p0[0], -30.0, 30.0)
    p0[1] = np.clip(p0[1], 0.05, 15.0)

    try:
        result = least_squares(
            lambda p: _response(x, p[0], p[1]) - y,
            p0,
            bounds=([-30.0, 0.05], [30.0, 15.0]),
            max_nfev=250
        )
        p = result.x if np.all(np.isfinite(result.x)) else p0
    except Exception:
        p = p0

    return {
        "logit_intercept": float(p[0]),
        "logit_slope": float(p[1]),
    }

def predict(X, logit_intercept, logit_slope):
    x = np.asarray(X[:, 0], dtype=float)
    return _response(x, float(logit_intercept), float(logit_slope))