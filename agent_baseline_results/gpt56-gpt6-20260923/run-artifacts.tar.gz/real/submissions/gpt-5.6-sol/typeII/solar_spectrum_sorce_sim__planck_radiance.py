"""Scaled blackbody solar spectral radiance."""
import numpy as np

USED_INPUTS = ["wavelength_nm"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {
    "h": 6.62607015e-34,
    "c": 299792458.0,
    "k": 1.380649e-23,
    "T_sun": 5778.0,
}
LOCAL_FITTABLE = {"scale": {"init": [1.0]}}

def _shape(wavelength_nm):
    lam = np.maximum(np.asarray(wavelength_nm, dtype=float), 1e-9) * 1e-9
    h = OTHER_CONSTANTS["h"]
    c = OTHER_CONSTANTS["c"]
    k = OTHER_CONSTANTS["k"]
    T = OTHER_CONSTANTS["T_sun"]
    z = h * c / (lam * k * T)
    z = np.minimum(z, 700.0)
    return (2.0 * h * c**2 / lam**5) / np.expm1(z) * 1e-9

def fit(X_fit, y_fit):
    shape = _shape(X_fit[:, 0])
    y = np.asarray(y_fit, dtype=float)
    den = float(np.dot(shape, shape))
    if not np.isfinite(den) or den <= 0.0:
        return {"scale": 1.0}
    scale = float(np.dot(shape, y) / den)
    if not np.isfinite(scale) or scale <= 0.0:
        scale = 1.0
    return {"scale": scale}

def predict(X, **params):
    scale = float(params.get("scale", 1.0))
    if not np.isfinite(scale):
        scale = 1.0
    return np.asarray(scale * _shape(X[:, 0]), dtype=float)