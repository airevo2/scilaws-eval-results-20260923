"""Cluster-calibrated logarithmic historical improvement model for period life expectancy."""
import numpy as np

USED_INPUTS = ["year"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {
    "level": {"init": None},
    "trend": {"init": None},
}

def _basis(year):
    year = np.asarray(year, dtype=float)
    return np.log(np.maximum(year - 1600.0, 1.0))

def fit(X_fit, y_fit):
    year = np.asarray(X_fit[:, 0], dtype=float)
    y = np.asarray(y_fit, dtype=float)
    z = _basis(year)
    A = np.column_stack((np.ones_like(z), z))
    
    try:
        p = np.linalg.lstsq(A, y, rcond=None)[0]
        # A few Huber IRLS steps reduce the influence of isolated war,
        # pandemic, or reporting anomalies while retaining a fast fit.
        for _ in range(6):
            residual = y - A @ p
            scale = 1.4826 * np.median(np.abs(residual - np.median(residual)))
            scale = max(float(scale), 0.15)
            u = np.abs(residual) / (1.5 * scale)
            weights = np.where(u <= 1.0, 1.0, 1.0 / np.maximum(u, 1e-12))
            Aw = A * weights[:, None]
            yw = y * weights
            p = np.linalg.lstsq(Aw, yw, rcond=None)[0]
        if not np.all(np.isfinite(p)):
            raise ValueError
        return {"level": float(p[0]), "trend": float(p[1])}
    except Exception:
        return {
            "level": float(np.mean(y)) if y.size else 65.0,
            "trend": 0.2,
        }

def predict(X, level, trend):
    z = _basis(X[:, 0])
    result = level + trend * z
    return np.asarray(result, dtype=float)