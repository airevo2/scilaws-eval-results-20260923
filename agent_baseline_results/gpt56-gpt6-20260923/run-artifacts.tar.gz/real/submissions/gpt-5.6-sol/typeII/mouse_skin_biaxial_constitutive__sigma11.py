"""Anisotropic exponential stress law with stretch-dependent lateral response."""
import numpy as np
from scipy.optimize import least_squares

USED_INPUTS = ["lambda11", "lambda22"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {
    "a": {"init": [0.01]},
    "b": {"init": [1.0]},
    "c": {"init": [1.0]},
    "d": {"init": [0.0]},
    "e": {"init": [1.0]},
}

def _form(X, a, b, c, d, e):
    u = np.asarray(X[:, 0], dtype=float) - 1.0
    v = np.asarray(X[:, 1], dtype=float) - 1.0
    exponent = np.clip(b*u + c*v + d*u*v + e*u*u, -40.0, 40.0)
    return a * u * np.exp(exponent)

def fit(X_fit, y_fit):
    X_fit = np.asarray(X_fit, dtype=float)
    y_fit = np.asarray(y_fit, dtype=float)
    u = np.maximum(X_fit[:, 0] - 1.0, 1e-8)

    valid = np.isfinite(u) & np.isfinite(y_fit)
    if not np.any(valid):
        return {"a": 0.01, "b": 1.0, "c": 1.0, "d": 0.0, "e": 1.0}

    u0 = u[valid]
    y0 = y_fit[valid]
    a0 = np.median(np.abs(y0) / u0)
    if not np.isfinite(a0) or a0 <= 1e-8:
        a0 = max(float(np.percentile(np.abs(y0), 75)), 0.002)

    p0 = np.array([a0, 1.0, 1.0, 0.0, 1.0], dtype=float)

    def residual(p):
        return _form(X_fit[valid], *p) - y0

    try:
        result = least_squares(
            residual,
            p0,
            bounds=([0.0, -100.0, -100.0, -100.0, -100.0],
                    [10.0, 100.0, 100.0, 100.0, 100.0]),
            loss="soft_l1",
            f_scale=max(0.001, 0.1 * float(np.std(y0))),
            max_nfev=2000,
        )
        p = result.x
        if not np.all(np.isfinite(p)):
            p = p0
    except Exception:
        p = p0

    return {"a": float(p[0]), "b": float(p[1]), "c": float(p[2]),
            "d": float(p[3]), "e": float(p[4])}

def predict(X, a, b, c, d, e):
    y = _form(X, float(a), float(b), float(c), float(d), float(e))
    return np.nan_to_num(y, nan=0.0, posinf=1e6, neginf=-1e6)