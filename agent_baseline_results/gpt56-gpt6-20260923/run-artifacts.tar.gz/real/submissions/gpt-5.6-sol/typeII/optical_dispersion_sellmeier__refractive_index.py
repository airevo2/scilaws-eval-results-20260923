"""Three-parameter single-resonance Sellmeier dispersion law."""
import numpy as np
from scipy.optimize import least_squares

USED_INPUTS = ["wavelength_um"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {
    "A": {"init": None},
    "B": {"init": None},
    "C": {"init": None},
}

def _model(w, A, B, C):
    w = np.maximum(np.asarray(w, dtype=float), 1e-8)
    den = np.maximum(w*w - C, 1e-8)
    q = A + B/den
    return np.sqrt(np.maximum(q, 1e-12))

def fit(X_fit, y_fit):
    w = np.asarray(X_fit[:, 0], dtype=float)
    y = np.asarray(y_fit, dtype=float)
    z = np.maximum(w*w, 1e-8)
    # Stable starting estimate from a weakly dispersive Cauchy approximation.
    try:
        cc = np.polyfit(1.0/z, y, 1)
        A0 = max(0.5, float(cc[1]*cc[1]))
        B0 = max(1e-5, float(2.0*cc[0]*max(cc[1], 0.5)))
    except Exception:
        A0, B0 = float(max(1.0, np.min(y)**2)), 0.1
    C0 = min(0.02, 0.25*float(np.min(z)))
    p0 = np.array([A0, B0, C0], dtype=float)

    def residual(p):
        return _model(w, p[0], p[1], p[2]) - y

    lo = np.array([0.01, 0.0, -10.0])
    hi = np.array([25.0, 100.0, max(1e-7, 0.90*float(np.min(z)))])
    try:
        sol = least_squares(residual, np.minimum(np.maximum(p0, lo), hi),
                            bounds=(lo, hi), max_nfev=1200)
        if np.all(np.isfinite(sol.x)):
            return {"A": float(sol.x[0]), "B": float(sol.x[1]), "C": float(sol.x[2])}
    except Exception:
        pass
    return {"A": float(max(A0, 0.01)), "B": float(max(B0, 0.0)), "C": float(C0)}

def predict(X, A, B, C):
    return _model(X[:, 0], A, B, C)