"""Non-rectangular hyperbolic leaf photosynthetic light-response curve."""
import numpy as np
from scipy.optimize import curve_fit

USED_INPUTS = ["Qin"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {
    "Amax": {"init": None},
    "alpha": {"init": None},
    "Rd": {"init": None},
    "theta": {"init": None},
}

def _form(Q, Amax, alpha, Rd, theta):
    Q = np.maximum(np.asarray(Q, dtype=float), 0.0)
    theta = np.clip(theta, 1e-5, 0.99999)
    z = alpha * Q + Amax
    disc = np.maximum(z * z - 4.0 * theta * alpha * Q * Amax, 0.0)
    gross = (z - np.sqrt(disc)) / (2.0 * theta)
    return gross - Rd

def fit(X_fit, y_fit):
    Q = np.maximum(np.asarray(X_fit[:, 0], dtype=float), 0.0)
    y = np.asarray(y_fit, dtype=float)
    finite = np.isfinite(Q) & np.isfinite(y)
    Q = Q[finite]
    y = y[finite]
    if y.size == 0:
        return {"Amax": 8.0, "alpha": 0.03, "Rd": 0.6, "theta": 0.7}

    qspan = max(float(np.max(Q) - np.min(Q)), 1.0)
    yspan = max(float(np.max(y) - np.min(y)), 0.5)
    low = y[Q <= np.quantile(Q, 0.2)]
    rd0 = max(0.01, min(5.0, -float(np.median(low)) if low.size else 0.5))
    amax0 = max(0.1, min(100.0, float(np.max(y)) + rd0))
    alpha0 = max(1e-4, min(2.0, yspan / qspan))
    p0 = [amax0, alpha0, rd0, 0.7]

    try:
        popt, _ = curve_fit(
            _form,
            Q,
            y,
            p0=p0,
            bounds=([0.01, 1e-7, 0.0, 0.01], [100.0, 2.0, 10.0, 0.9999]),
            maxfev=4000,
        )
        if np.all(np.isfinite(popt)):
            return {
                "Amax": float(popt[0]),
                "alpha": float(popt[1]),
                "Rd": float(popt[2]),
                "theta": float(popt[3]),
            }
    except Exception:
        pass
    return {"Amax": float(amax0), "alpha": float(alpha0), "Rd": float(rd0), "theta": 0.7}

def predict(X, Amax, alpha, Rd, theta):
    return np.asarray(_form(X[:, 0], Amax, alpha, Rd, theta), dtype=float)