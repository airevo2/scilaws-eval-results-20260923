"""Cluster-calibrated logistic intertemporal-choice model with log delay sensitivity."""
import numpy as np
from scipy.optimize import least_squares

USED_INPUTS = ["log_amount_ratio", "ss_time_days", "ll_time_days",
               "delay_diff_days", "ss_value", "ll_value"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {
    "intercept": {"init": None},
    "amount_sensitivity": {"init": None},
    "delay_sensitivity": {"init": None},
}

def _sigmoid(z):
    return 1.0 / (1.0 + np.exp(-np.clip(z, -35.0, 35.0)))

def _features(X):
    r = np.asarray(X[:, 0], dtype=float)
    delay = np.maximum(np.asarray(X[:, 3], dtype=float), 0.0)
    return np.column_stack((np.ones(len(r)), r, np.log1p(delay)))

def fit(X_fit, y_fit):
    F = _features(X_fit)
    y = np.asarray(y_fit, dtype=float)
    q = np.clip(y, 0.02, 0.98)
    try:
        p0 = np.linalg.lstsq(F, np.log(q / (1.0 - q)), rcond=None)[0]
        p0 = np.nan_to_num(p0, nan=0.0, posinf=10.0, neginf=-10.0)
        p0 = np.clip(p0, -20.0, 20.0)
        result = least_squares(
            lambda p: _sigmoid(F @ p) - y,
            p0,
            bounds=([-30.0, -30.0, -30.0], [30.0, 30.0, 30.0]),
            max_nfev=500,
        )
        p = result.x
        if not np.all(np.isfinite(p)):
            p = p0
    except Exception:
        p = np.array([0.0, 1.0, -1.0])
    return {
        "intercept": float(p[0]),
        "amount_sensitivity": float(p[1]),
        "delay_sensitivity": float(p[2]),
    }

def predict(X, intercept, amount_sensitivity, delay_sensitivity):
    F = _features(X)
    p = np.array([intercept, amount_sensitivity, delay_sensitivity], dtype=float)
    return _sigmoid(F @ p)