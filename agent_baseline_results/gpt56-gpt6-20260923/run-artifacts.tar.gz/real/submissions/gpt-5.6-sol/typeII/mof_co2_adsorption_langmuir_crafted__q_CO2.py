"""Three-parameter Sips adsorption isotherm with cluster-specific capacity,
affinity, and heterogeneity exponent."""
import numpy as np
from scipy.optimize import least_squares

USED_INPUTS = ["P_bar"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {
    "qmax": {"init": None},
    "K": {"init": None},
    "n": {"init": None},
}

def _model(P, qmax, K, n):
    u = np.power(np.maximum(K * P, 1e-300), n)
    return qmax * u / (1.0 + u)

def fit(X_fit, y_fit):
    P = np.maximum(np.asarray(X_fit[:, 0], dtype=float), 1e-12)
    y = np.maximum(np.asarray(y_fit, dtype=float), 0.0)
    ymax = max(float(np.max(y)), 1e-5)
    pmed = max(float(np.median(P)), 1e-5)

    starts = [
        [1.3 * ymax, 1.0 / pmed, 1.0],
        [2.5 * ymax, 1.0 / pmed, 0.8],
        [5.0 * ymax, 0.3 / pmed, 1.2],
        [10.0 * ymax, 3.0 / pmed, 1.0],
    ]
    best = None
    lo = np.log([1e-5, 1e-7, 0.15])
    hi = np.log([1e5, 1e7, 5.0])

    for s in starts:
        z0 = np.clip(np.log(np.maximum(s, 1e-12)), lo, hi)
        def residual(z):
            q, k, n = np.exp(z)
            return _model(P, q, k, n) - y
        try:
            sol = least_squares(
                residual, z0, bounds=(lo, hi),
                max_nfev=700, ftol=1e-9, xtol=1e-9, gtol=1e-9
            )
            loss = float(np.sum(sol.fun * sol.fun))
            if best is None or loss < best[0]:
                best = (loss, np.exp(sol.x))
        except Exception:
            pass

    if best is None:
        return {"qmax": float(2.0 * ymax), "K": float(1.0 / pmed), "n": 1.0}
    q, k, n = best[1]
    return {"qmax": float(q), "K": float(k), "n": float(n)}

def predict(X, qmax, K, n):
    P = np.maximum(np.asarray(X[:, 0], dtype=float), 0.0)
    out = _model(P, float(qmax), float(K), float(n))
    return np.nan_to_num(out, nan=0.0, posinf=1e12, neginf=0.0)