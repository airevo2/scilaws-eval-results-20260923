"""Pantropical saturating height-diameter allometry with one cluster-specific asymptotic height."""
import numpy as np

USED_INPUTS = ["DBH_cm"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {"H_asym": {"init": [30.0]}}

_SHAPE_EXPONENT = 0.72
_DIAMETER_SCALE_CM = 54.4

def _shape(D):
    D = np.maximum(np.asarray(D, dtype=float), 0.0)
    return -np.expm1(-np.power(D / _DIAMETER_SCALE_CM, _SHAPE_EXPONENT))

def fit(X_fit, y_fit):
    D = X_fit[:, 0]
    y = np.asarray(y_fit, dtype=float)
    z = _shape(D)
    denom = float(np.dot(z, z))
    if not np.isfinite(denom) or denom <= 1e-12:
        positive = y[np.isfinite(y) & (y > 0)]
        a = float(np.mean(positive)) if positive.size else 30.0
    else:
        a = float(np.dot(z, y) / denom)
    if not np.isfinite(a) or a <= 0.0:
        a = float(np.nanmedian(y)) if np.any(np.isfinite(y)) else 30.0
    return {"H_asym": max(a, 1e-6)}

def predict(X, H_asym):
    D = X[:, 0]
    pred = H_asym * _shape(D)
    return np.asarray(pred, dtype=float)