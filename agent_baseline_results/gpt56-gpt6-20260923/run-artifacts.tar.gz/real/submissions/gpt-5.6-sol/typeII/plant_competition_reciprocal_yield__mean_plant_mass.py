"""Species-specific allometric self-thinning law for mean plant mass."""
import numpy as np

USED_INPUTS = ["density"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {
    "a": {"init": None},
    "b": {"init": None},
}

def fit(X_fit, y_fit):
    N = np.asarray(X_fit[:, 0], dtype=float)
    y = np.asarray(y_fit, dtype=float)
    mask = np.isfinite(N) & np.isfinite(y) & (N > 0) & (y > 0)
    if np.sum(mask) < 2:
        return {
            "a": max(float(np.nanmedian(y)) if len(y) else 1.0, 1e-8),
            "b": 0.7,
        }

    x = np.log(N[mask])
    z = np.log(y[mask])
    A = np.column_stack((np.ones_like(x), x))
    try:
        coef = np.linalg.lstsq(A, z, rcond=None)[0]
        intercept = float(np.clip(coef[0], -50.0, 50.0))
        slope = float(np.clip(coef[1], -2.0, 0.2))
        a = float(np.exp(intercept))
        b = float(np.clip(-slope, -0.2, 2.0))
        if not np.isfinite(a) or not np.isfinite(b) or a <= 0:
            raise ValueError
        return {"a": a, "b": b}
    except Exception:
        return {
            "a": max(float(np.nanmedian(y[mask])), 1e-8),
            "b": 0.7,
        }

def predict(X, a, b):
    N = np.maximum(np.asarray(X[:, 0], dtype=float), 1e-12)
    return np.asarray(a * np.power(N, -b), dtype=float)