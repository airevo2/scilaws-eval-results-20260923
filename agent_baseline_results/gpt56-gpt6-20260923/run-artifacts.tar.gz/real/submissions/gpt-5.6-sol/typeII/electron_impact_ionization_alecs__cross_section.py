"""Thresholded saturating-power cross-section law with a decaying high-energy tail."""
import numpy as np
from scipy.optimize import least_squares

USED_INPUTS = ["electron_energy_eV"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {
    "A": {"init": None},
    "I": {"init": None},
    "S": {"init": None},
    "p": {"init": None},
    "q": {"init": None},
}

def _form(E, A, I, S, p, q):
    E = np.asarray(E, dtype=float)
    I = max(float(I), 1e-8)
    S = max(float(S), 1e-8)
    x = np.maximum(E - I, 0.0) / S
    rise = -np.expm1(-np.power(np.maximum(x, 0.0), max(float(p), 1e-6)))
    tail = np.power(1.0 + np.maximum(E, 0.0) / S, -max(float(q), 1e-6))
    out = float(A) * rise * tail
    return np.nan_to_num(out, nan=0.0, posinf=1e12, neginf=0.0)

def fit(X_fit, y_fit):
    E = np.asarray(X_fit[:, 0], dtype=float)
    y = np.asarray(y_fit, dtype=float)
    finite = np.isfinite(E) & np.isfinite(y)
    E, y = E[finite], y[finite]
    if len(E) == 0:
        return {"A": 1.0, "I": 10.0, "S": 100.0, "p": 1.5, "q": 1.0}

    emin = max(float(np.min(E)), 1e-3)
    emax = max(float(np.max(E)), emin * 1.01)
    ymax = max(float(np.max(y)), 1e-4)
    upper_I = max(emin * 0.999, 1e-3)
    starts = [
        [3.0 * ymax, 0.5 * emin, 100.0, 1.5, 1.0],
        [5.0 * ymax, 0.8 * emin, 0.5 * emax, 2.0, 1.0],
        [10.0 * ymax, 0.2 * emin, 2.0 * emax, 1.0, 0.7],
    ]
    lo = [1e-8, 1e-5, 1e-3, 0.15, 0.05]
    hi = [1e7, upper_I, 1e7, 8.0, 4.0]
    best = None
    for start in starts:
        start = np.minimum(np.maximum(np.asarray(start, dtype=float), lo), hi)
        try:
            res = least_squares(
                lambda z: _form(E, *z) - y,
                start,
                bounds=(lo, hi),
                loss="soft_l1",
                f_scale=max(0.02, 0.05 * ymax),
                max_nfev=2500,
            )
            score = float(np.sum(res.fun * res.fun))
            if best is None or score < best[0]:
                best = (score, res.x)
        except Exception:
            pass
    if best is None:
        return {"A": 3.0 * ymax, "I": 0.5 * emin, "S": 100.0, "p": 1.5, "q": 1.0}
    z = best[1]
    return {"A": float(z[0]), "I": float(z[1]), "S": float(z[2]),
            "p": float(z[3]), "q": float(z[4])}

def predict(X, A, I, S, p, q):
    return _form(X[:, 0], A, I, S, p, q)