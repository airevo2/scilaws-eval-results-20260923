"""Cluster-calibrated Michaelis-Menten substrate-response law."""
import numpy as np
from scipy.optimize import least_squares

USED_INPUTS = ["substrate_conc"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {
    "vmax": {"init": None},
    "km": {"init": None},
}

def _response(S, vmax, km):
    S = np.maximum(np.asarray(S, dtype=float), 0.0)
    return vmax * S / (km + S)

def fit(X_fit, y_fit):
    S = np.asarray(X_fit[:, 0], dtype=float)
    y = np.asarray(y_fit, dtype=float)
    ok = np.isfinite(S) & np.isfinite(y)
    S, y = S[ok], y[ok]

    if len(y) == 0:
        return {"vmax": 1.0, "km": 100.0}

    ymax = max(float(np.max(y)), 1e-8)
    smed = max(float(np.median(S)), 1.0)
    p0 = np.array([max(1.15 * ymax, 1e-8), smed])
    lo = np.array([0.0, 1e-8])
    hi = np.array([max(1e8, 1000.0 * ymax), 1e8])

    try:
        result = least_squares(
            lambda p: _response(S, p[0], p[1]) - y,
            np.minimum(np.maximum(p0, lo), hi),
            bounds=(lo, hi),
            max_nfev=500,
        )
        vmax, km = result.x
        if not np.all(np.isfinite(result.x)):
            raise ValueError
        return {"vmax": float(vmax), "km": float(km)}
    except Exception:
        return {"vmax": float(p0[0]), "km": float(p0[1])}

def predict(X, vmax, km):
    S = np.asarray(X[:, 0], dtype=float)
    pred = _response(S, float(vmax), max(float(km), 1e-8))
    return np.nan_to_num(pred, nan=0.0, posinf=1e300, neginf=0.0)