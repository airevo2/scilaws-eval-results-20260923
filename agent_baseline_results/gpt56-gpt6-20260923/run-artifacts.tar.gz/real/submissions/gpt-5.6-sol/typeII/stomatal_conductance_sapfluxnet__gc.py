"""Cluster-calibrated exponential decline of canopy conductance with vapour pressure deficit."""
import numpy as np
from scipy.optimize import curve_fit

USED_INPUTS = ["vpd"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {
    "gmax": {"init": None},
    "sensitivity": {"init": None},
}

def _form(vpd, gmax, sensitivity):
    return gmax * np.exp(-sensitivity * np.maximum(vpd, 0.0))

def fit(X_fit, y_fit):
    vpd = np.asarray(X_fit[:, 0], dtype=float)
    y = np.asarray(y_fit, dtype=float)
    good = np.isfinite(vpd) & np.isfinite(y)
    vpd = vpd[good]
    y = np.maximum(y[good], 0.0)
    if y.size == 0:
        return {"gmax": 1.0, "sensitivity": 0.5}
    g0 = max(float(np.max(y)), float(np.mean(y)), 1e-6)
    p0 = [g0, 0.7]
    try:
        p, _ = curve_fit(
            _form, vpd, y, p0=p0,
            bounds=([0.0, 0.0], [np.inf, 10.0]),
            maxfev=3000
        )
        gmax, sensitivity = float(p[0]), float(p[1])
    except Exception:
        gmax, sensitivity = p0
    if not np.isfinite(gmax) or gmax < 0:
        gmax = g0
    if not np.isfinite(sensitivity) or sensitivity < 0:
        sensitivity = 0.7
    return {"gmax": gmax, "sensitivity": sensitivity}

def predict(X, gmax, sensitivity):
    vpd = np.asarray(X[:, 0], dtype=float)
    out = _form(vpd, float(gmax), float(sensitivity))
    return np.nan_to_num(out, nan=0.0, posinf=1e300, neginf=0.0)