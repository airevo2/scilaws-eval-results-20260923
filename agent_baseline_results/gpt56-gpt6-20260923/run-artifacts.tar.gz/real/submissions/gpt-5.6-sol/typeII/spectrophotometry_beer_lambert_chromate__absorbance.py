"""Cluster-calibrated Beer-Lambert law with a fitted blank/background offset."""
import numpy as np

USED_INPUTS = ["concentration", "path_length"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {
    "baseline": {"init": [0.0]},
    "epsilon": {"init": [8.0]},
}

def fit(X_fit, y_fit):
    c = np.asarray(X_fit[:, 0], dtype=float)
    l = np.asarray(X_fit[:, 1], dtype=float)
    y = np.asarray(y_fit, dtype=float)
    z = c * l
    A = np.column_stack((np.ones_like(z), z))
    try:
        q, _, _, _ = np.linalg.lstsq(A, y, rcond=None)
        baseline = float(q[0])
        epsilon = float(q[1])
        if not np.isfinite(baseline) or not np.isfinite(epsilon):
            raise ValueError
        return {"baseline": baseline, "epsilon": epsilon}
    except Exception:
        return {
            "baseline": float(np.mean(y)) if y.size else 0.0,
            "epsilon": 0.0,
        }

def predict(X, baseline, epsilon):
    c = np.asarray(X[:, 0], dtype=float)
    l = np.asarray(X[:, 1], dtype=float)
    out = baseline + epsilon * c * l
    return np.asarray(out, dtype=float)