"""Cluster-calibrated plane in calendar year and a smooth adult-age profile."""
import numpy as np

USED_INPUTS = ["age", "year"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {
    "a": {"init": None},
    "b": {"init": None},
    "c": {"init": None},
}

def _design(age, year):
    q = (np.asarray(age, dtype=float) - 60.0) / 20.0
    r = (np.asarray(year, dtype=float) - 1950.0) / 50.0
    age_shape = np.exp(-((q + 0.0) / 1.5) ** 2) - 0.55 * q
    return np.column_stack((np.ones_like(q), age_shape, r))

def fit(X_fit, y_fit):
    X_fit = np.asarray(X_fit, dtype=float)
    y_fit = np.asarray(y_fit, dtype=float)
    A = _design(X_fit[:, 0], X_fit[:, 1])
    ok = np.isfinite(y_fit) & np.all(np.isfinite(A), axis=1)
    if np.sum(ok) < 3:
        return {"a": 0.4, "b": 0.0, "c": 0.0}
    try:
        coef, _, _, _ = np.linalg.lstsq(A[ok], y_fit[ok], rcond=None)
        coef = np.asarray(coef, dtype=float)
        if coef.shape != (3,) or not np.all(np.isfinite(coef)):
            raise ValueError
        return {"a": float(coef[0]), "b": float(coef[1]), "c": float(coef[2])}
    except Exception:
        return {"a": float(np.nanmean(y_fit[ok])), "b": 0.0, "c": 0.0}

def predict(X, a, b, c):
    X = np.asarray(X, dtype=float)
    A = _design(X[:, 0], X[:, 1])
    out = A @ np.array([a, b, c], dtype=float)
    return np.nan_to_num(out, nan=0.0, posinf=20.0, neginf=-20.0)