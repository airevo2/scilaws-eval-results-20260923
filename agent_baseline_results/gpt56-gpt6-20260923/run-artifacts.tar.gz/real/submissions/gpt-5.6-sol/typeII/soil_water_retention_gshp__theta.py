"""Four-parameter van Genuchten soil-water retention curve."""
import numpy as np
from scipy.optimize import least_squares

USED_INPUTS = ["lab_head_m"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {
    "theta_r": {"init": None},
    "theta_s": {"init": None},
    "alpha": {"init": None},
    "n": {"init": None},
}

def _vg(h, theta_r, theta_s, alpha, n):
    h = np.maximum(np.asarray(h, dtype=float), 1e-12)
    alpha = max(float(alpha), 1e-12)
    n = max(float(n), 1.001)
    m = 1.0 - 1.0 / n
    z = np.minimum((alpha * h) ** n, 1e100)
    return theta_r + (theta_s - theta_r) / np.maximum((1.0 + z) ** m, 1e-12)

def fit(X_fit, y_fit):
    h = np.maximum(np.asarray(X_fit[:, 0], dtype=float), 1e-12)
    y = np.asarray(y_fit, dtype=float)
    ymin = float(np.min(y))
    ymax = float(np.max(y))
    spread = max(ymax - ymin, 0.01)
    theta_r0 = max(-0.05, ymin - 0.1 * spread)
    theta_s0 = min(1.1, ymax + 0.1 * spread)
    alpha0 = 1.0 / max(float(np.median(h)), 1e-4)
    p0 = np.array([theta_r0, theta_s0, np.log(alpha0), np.log(0.5)])

    def form(p):
        alpha = np.exp(np.clip(p[2], -18.0, 18.0))
        n = 1.0 + np.exp(np.clip(p[3], -8.0, 4.0))
        return _vg(h, p[0], p[1], alpha, n)

    lo = np.array([-0.1, max(ymax, 0.01), -18.0, -8.0])
    hi = np.array([min(ymin, 0.9), 1.2, 18.0, 4.0])
    p0 = np.minimum(np.maximum(p0, lo + 1e-8), hi - 1e-8)
    try:
        result = least_squares(
            lambda p: form(p) - y,
            p0,
            bounds=(lo, hi),
            max_nfev=400,
            x_scale="jac",
        )
        p = result.x
    except Exception:
        p = p0
    return {
        "theta_r": float(p[0]),
        "theta_s": float(p[1]),
        "alpha": float(np.exp(np.clip(p[2], -18.0, 18.0))),
        "n": float(1.0 + np.exp(np.clip(p[3], -8.0, 4.0))),
    }

def predict(X, **params):
    h = X[:, 0]
    return np.asarray(_vg(
        h,
        params["theta_r"],
        params["theta_s"],
        params["alpha"],
        params["n"],
    ), dtype=float)