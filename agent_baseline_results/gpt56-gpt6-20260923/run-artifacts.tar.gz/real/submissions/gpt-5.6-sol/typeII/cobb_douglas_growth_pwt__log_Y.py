"""Cobb–Douglas output per engaged person with human-capital-augmented labor."""
import numpy as np

USED_INPUTS = ["cn", "emp", "hc"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {
    "a": {"init": None},
    "alpha": {"init": None},
}

def fit(X_fit, y_fit):
    cn = np.asarray(X_fit[:, 0], dtype=float)
    emp = np.asarray(X_fit[:, 1], dtype=float)
    hc = np.asarray(X_fit[:, 2], dtype=float)
    capital_intensity = np.log(np.maximum(cn / np.maximum(emp, 1e-12), 1e-300))
    human_capital = np.log(np.maximum(hc, 1e-300))
    design = np.column_stack((np.ones(len(y_fit)), capital_intensity - human_capital))
    response = np.asarray(y_fit, dtype=float) - human_capital
    try:
        coefficients = np.linalg.lstsq(design, response, rcond=None)[0]
        a_hat = float(coefficients[0])
        alpha_hat = float(np.clip(coefficients[1], 0.0, 1.0))
        if not np.isfinite(a_hat) or not np.isfinite(alpha_hat):
            raise ValueError
        return {"a": a_hat, "alpha": alpha_hat}
    except Exception:
        return {"a": float(np.mean(y_fit)), "alpha": 0.33}

def predict(X, a, alpha):
    cn = np.asarray(X[:, 0], dtype=float)
    emp = np.asarray(X[:, 1], dtype=float)
    hc = np.asarray(X[:, 2], dtype=float)
    capital_intensity = np.log(np.maximum(cn / np.maximum(emp, 1e-12), 1e-300))
    human_capital = np.log(np.maximum(hc, 1e-300))
    return a + alpha * capital_intensity + (1.0 - alpha) * human_capital