"""Eight-parameter smooth age-period model for log central mortality.

The age profile combines a quadratic broad-age trend with localized infant
and young-adult components.  Calendar change is represented by a linear
period effect whose age dependence has a broad slope and an old-age slope.
All coefficients are calibrated independently for each mortality series.
"""
import numpy as np

USED_INPUTS = ["age", "year"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {
    "c0": {"init": None},
    "c1": {"init": None},
    "c2": {"init": None},
    "c3": {"init": None},
    "c4": {"init": None},
    "t0": {"init": None},
    "t1": {"init": None},
    "t2": {"init": None},
}

def _design(X):
    age = np.asarray(X[:, 0], dtype=float)
    year = np.asarray(X[:, 1], dtype=float)

    z = (age - 50.0) / 50.0
    q = (year - 2000.0) / 25.0

    infant = np.exp(-age / 1.5)
    young = np.exp(-((age - 18.0) / 12.0) ** 2)
    old = np.maximum(age - 45.0, 0.0) / 50.0

    return np.column_stack((
        np.ones_like(age),
        z,
        z * z,
        infant,
        young,
        q,
        q * z,
        q * old,
    ))

def fit(X_fit, y_fit):
    A = _design(X_fit)
    y = np.asarray(y_fit, dtype=float)

    good = np.isfinite(y) & np.all(np.isfinite(A), axis=1)
    if np.count_nonzero(good) >= 8:
        try:
            beta = np.linalg.lstsq(A[good], y[good], rcond=None)[0]
            if np.all(np.isfinite(beta)):
                return {
                    "c0": float(beta[0]),
                    "c1": float(beta[1]),
                    "c2": float(beta[2]),
                    "c3": float(beta[3]),
                    "c4": float(beta[4]),
                    "t0": float(beta[5]),
                    "t1": float(beta[6]),
                    "t2": float(beta[7]),
                }
        except Exception:
            pass

    fallback = float(np.nanmean(y)) if np.any(np.isfinite(y)) else -5.0
    return {
        "c0": fallback,
        "c1": 0.0,
        "c2": 0.0,
        "c3": 0.0,
        "c4": 0.0,
        "t0": 0.0,
        "t1": 0.0,
        "t2": 0.0,
    }

def predict(X, c0, c1, c2, c3, c4, t0, t1, t2):
    A = _design(X)
    beta = np.array([c0, c1, c2, c3, c4, t0, t1, t2], dtype=float)
    pred = A @ beta
    return np.nan_to_num(pred, nan=-5.0, posinf=20.0, neginf=-30.0)