"""Hathaway-style asymmetric solar-cycle profile with three locally fitted parameters."""
import numpy as np
from scipy.optimize import least_squares

USED_INPUTS = ["t_year"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {
    "amplitude": {"init": [300.0]},
    "t0": {"init": [0.0]},
    "width": {"init": [5.0]},
}

def _profile(t, amplitude, t0, width):
    z = (t - t0) / np.maximum(width, 1e-6)
    return amplitude * z**3 / (np.exp(np.clip(z*z, -20.0, 50.0)) - 0.2)

def fit(X_fit, y_fit):
    t = np.asarray(X_fit[:, 0], dtype=float)
    y = np.asarray(y_fit, dtype=float)
    order = np.argsort(t)
    t = t[order]
    y = y[order]
    ymax = max(float(np.max(y)), 1.0)
    x0 = float(t[0])
    x1 = float(t[-1])
    starts = [
        [max(2.0 * ymax, 50.0), x0 - 1.0, 5.0],
        [max(1.3 * ymax, 50.0), x0 - 3.0, 4.0],
        [max(2.5 * ymax, 50.0), x0 + 1.0, 7.0],
    ]
    lo = [1e-3, x0 - 25.0, 1.5]
    hi = [5000.0, x1 + 10.0, 20.0]
    best = None
    for p0 in starts:
        try:
            r = least_squares(
                lambda p: _profile(t, p[0], p[1], p[2]) - y,
                p0, bounds=(lo, hi), max_nfev=1200
            )
            s = float(np.sum(r.fun * r.fun))
            if best is None or s < best[0]:
                best = (s, r.x)
        except Exception:
            pass
    if best is None:
        p = np.array(starts[0], dtype=float)
    else:
        p = best[1]
    return {"amplitude": float(p[0]), "t0": float(p[1]), "width": float(p[2])}

def predict(X, amplitude, t0, width):
    t = np.asarray(X[:, 0], dtype=float)
    out = _profile(t, amplitude, t0, width)
    return np.asarray(np.nan_to_num(out, nan=0.0, posinf=1e6, neginf=-1e6), dtype=float)