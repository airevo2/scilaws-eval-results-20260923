"""Cluster-calibrated hyperbolic decay of Sørensen similarity with environmental distance."""
import numpy as np
from scipy.optimize import least_squares

USED_INPUTS = ["env_dist"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {
    "amplitude": {"init": [0.5]},
    "decay": {"init": [0.2]},
}

def _form(d, amplitude, decay):
    d = np.maximum(np.asarray(d, dtype=float), 0.0)
    return amplitude / (1.0 + decay * d)

def fit(X_fit, y_fit):
    d = np.asarray(X_fit[:, 0], dtype=float)
    y = np.asarray(y_fit, dtype=float)
    good = np.isfinite(d) & np.isfinite(y)
    d = np.maximum(d[good], 0.0)
    y = np.clip(y[good], 1e-6, 1.0 - 1e-6)

    if d.size < 2:
        a0 = float(np.clip(np.nanmean(y_fit) if len(y_fit) else 0.5, 1e-4, 1.0))
        return {"amplitude": a0, "decay": 0.2}

    a0 = float(np.clip(np.max(y), 1e-3, 1.5))
    b0 = 0.2
    z0 = np.log([a0, b0])

    def residual(z):
        a = np.exp(np.clip(z[0], -20.0, 5.0))
        b = np.exp(np.clip(z[1], -20.0, 8.0))
        return _form(d, a, b) - y

    try:
        result = least_squares(
            residual, z0, loss="soft_l1", f_scale=0.04,
            max_nfev=300, bounds=([-20.0, -20.0], [5.0, 8.0])
        )
        a = float(np.exp(np.clip(result.x[0], -20.0, 5.0)))
        b = float(np.exp(np.clip(result.x[1], -20.0, 8.0)))
        if not (np.isfinite(a) and np.isfinite(b)):
            raise ValueError
        return {"amplitude": a, "decay": b}
    except Exception:
        return {"amplitude": a0, "decay": b0}

def predict(X, amplitude, decay):
    d = np.asarray(X[:, 0], dtype=float)
    a = float(np.clip(amplitude, 1e-8, 1e6))
    b = float(np.clip(decay, 1e-8, 1e6))
    return np.clip(_form(d, a, b), 0.0, 1.0)