"""Hertzian spherical-indenter force law with one cluster-specific effective modulus."""
import numpy as np

USED_INPUTS = ["indentation_m", "R_m"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {"E_eff": {"init": None}}

def fit(X_fit, y_fit):
    delta = np.maximum(np.asarray(X_fit[:, 0], dtype=float), 0.0)
    radius = np.maximum(np.asarray(X_fit[:, 1], dtype=float), 0.0)
    z = radius**0.5 * delta**1.5
    y = np.asarray(y_fit, dtype=float)
    ok = np.isfinite(z) & np.isfinite(y) & (z > 0)
    if np.count_nonzero(ok) < 3:
        return {"E_eff": 0.0}
    z = z[ok]
    y = y[ok]
    # Estimate the Hertz coefficient after removing the small force baseline
    # present near first contact, while retaining the zero-force law itself.
    zm = np.mean(z)
    ym = np.mean(y)
    den = np.sum((z - zm)**2)
    if den <= 0:
        a = np.sum(z*y) / max(np.sum(z*z), 1e-300)
    else:
        a = np.sum((z - zm)*(y - ym)) / den
    if not np.isfinite(a) or a < 0:
        a = np.sum(z*y) / max(np.sum(z*z), 1e-300)
    return {"E_eff": float(max(a, 0.0))}

def predict(X, E_eff):
    delta = np.maximum(np.asarray(X[:, 0], dtype=float), 0.0)
    radius = np.maximum(np.asarray(X[:, 1], dtype=float), 0.0)
    return np.asarray(E_eff, dtype=float) * radius**0.5 * delta**1.5