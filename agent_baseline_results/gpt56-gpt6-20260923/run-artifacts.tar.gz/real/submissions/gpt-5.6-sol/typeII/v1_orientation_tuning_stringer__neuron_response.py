"""Four-parameter von Mises orientation-tuning curve with baseline, amplitude,
preferred orientation, and concentration."""
import numpy as np
from scipy.optimize import least_squares

USED_INPUTS = ["orientation_deg"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {
    "baseline": {"init": None},
    "amplitude": {"init": None},
    "preferred_orientation": {"init": None},
    "concentration": {"init": None},
}

def _response(theta, baseline, amplitude, preferred_orientation, concentration):
    phase = np.deg2rad(2.0 * (theta - preferred_orientation))
    return baseline + amplitude * np.exp(
        concentration * (np.cos(phase) - 1.0)
    )

def fit(X_fit, y_fit):
    theta = np.asarray(X_fit[:, 0], dtype=float)
    y = np.asarray(y_fit, dtype=float)
    mask = np.isfinite(theta) & np.isfinite(y)
    theta = theta[mask]
    y = y[mask]

    if y.size == 0:
        return {
            "baseline": 0.0,
            "amplitude": 0.0,
            "preferred_orientation": 0.0,
            "concentration": 1.0,
        }

    ymin = max(0.0, float(np.min(y)))
    ymax = max(ymin + 1e-6, float(np.max(y)))
    yrange = max(ymax - ymin, 1e-6)
    imax = int(np.argmax(y))
    b0 = max(0.0, float(np.percentile(y, 20.0)))
    a0 = max(yrange, ymax - b0)
    mu0 = float(theta[imax] % 180.0)

    def residual(p):
        return _response(theta, p[0], p[1], p[2], np.exp(p[3])) - y

    p0 = np.array([b0, a0, mu0, np.log(1.0)], dtype=float)
    lower = np.array([0.0, 0.0, 0.0, np.log(1e-3)], dtype=float)
    upper = np.array([max(2.0 * ymax, 1.0), max(10.0 * yrange, 1.0),
                      180.0, np.log(100.0)], dtype=float)

    try:
        result = least_squares(
            residual, np.clip(p0, lower, upper),
            bounds=(lower, upper), max_nfev=120
        )
        p = result.x
        return {
            "baseline": float(p[0]),
            "amplitude": float(p[1]),
            "preferred_orientation": float(p[2] % 180.0),
            "concentration": float(np.exp(p[3])),
        }
    except Exception:
        return {
            "baseline": float(b0),
            "amplitude": float(a0),
            "preferred_orientation": float(mu0),
            "concentration": 1.0,
        }

def predict(X, baseline, amplitude, preferred_orientation, concentration):
    theta = np.asarray(X[:, 0], dtype=float)
    pred = _response(
        theta, float(baseline), float(amplitude),
        float(preferred_orientation), float(concentration)
    )
    return np.asarray(pred, dtype=float)