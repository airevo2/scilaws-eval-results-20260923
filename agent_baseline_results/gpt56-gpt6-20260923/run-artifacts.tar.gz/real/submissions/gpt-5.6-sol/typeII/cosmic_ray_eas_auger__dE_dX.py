"""Four-parameter Gaisser-Hillas longitudinal shower profile."""
import numpy as np
from scipy.optimize import least_squares

USED_INPUTS = ["X"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {
    "dEmax": {"init": None},
    "Xmax": {"init": None},
    "X0": {"init": None},
    "lambda_": {"init": None},
}

def _profile(X, dEmax, Xmax, X0, lambda_):
    X = np.asarray(X, dtype=float)
    den = max(Xmax - X0, 1e-6)
    lam = max(lambda_, 1e-6)
    z = np.maximum((X - X0) / den, 1e-12)
    log_y = np.log(max(dEmax, 1e-12)) + (den / lam) * np.log(z) + (Xmax - X) / lam
    return np.exp(np.clip(log_y, -700.0, 700.0))

def fit(X_fit, y_fit):
    X = np.asarray(X_fit[:, 0], dtype=float)
    y = np.maximum(np.asarray(y_fit, dtype=float), 1e-6)
    xmin = float(np.min(X))
    xmax = float(np.max(X))
    span = max(xmax - xmin, 100.0)
    imax = int(np.argmax(y))

    d0 = max(float(y[imax]), 1e-3)
    xm0 = float(X[imax])
    x00 = xmin - 0.5 * span
    l0 = max(span / 3.0, 20.0)
    p0 = np.array([d0, xm0, x00, l0], dtype=float)

    lower = np.array([
        1e-8,
        xmin - 3.0 * span,
        xmin - 20.0 * span,
        2.0,
    ])
    upper = np.array([
        max(100.0 * float(np.max(y)), 100.0),
        xmax + 3.0 * span,
        xmin - 1e-5,
        3000.0,
    ])

    def residual(p):
        return _profile(X, p[0], p[1], p[2], p[3]) - y

    try:
        result = least_squares(
            residual,
            np.clip(p0, lower, upper),
            bounds=(lower, upper),
            loss="linear",
            max_nfev=500,
        )
        p = np.asarray(result.x, dtype=float)
        if not np.all(np.isfinite(p)):
            raise ValueError("non-finite fit")
    except Exception:
        p = np.clip(p0, lower, upper)

    return {
        "dEmax": float(p[0]),
        "Xmax": float(p[1]),
        "X0": float(p[2]),
        "lambda_": float(p[3]),
    }

def predict(X, dEmax, Xmax, X0, lambda_):
    return _profile(X[:, 0], dEmax, Xmax, X0, lambda_)