"""Three-parameter Rydberg-Ritz binding-energy law.

The effective principal quantum number is
q = n - delta - alpha/q0^2, where q0 = n - delta,
and the binding energy is R/q^2.  The scale, quantum defect, and
Ritz curvature are calibrated independently for each cluster.
"""
import numpy as np
from scipy.optimize import least_squares

USED_INPUTS = ["n_qm", "l_qm"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {
    "R": {"init": None},
    "delta": {"init": None},
    "alpha": {"init": None},
}

def _predict_n(n, R, delta, alpha):
    n = np.asarray(n, dtype=float)
    q0 = np.maximum(n - delta, 1e-5)
    q = np.maximum(q0 - alpha / (q0 * q0), 1e-5)
    out = R / (q * q)
    return np.nan_to_num(out, nan=1e12, posinf=1e12, neginf=0.0)

def fit(X_fit, y_fit):
    n = np.asarray(X_fit[:, 0], dtype=float)
    y = np.maximum(np.asarray(y_fit, dtype=float), 1e-10)

    # A scale estimate based on the leading hydrogenic dependence.
    R0 = float(np.median(y * np.maximum(n - 0.5, 1.0) ** 2))
    R0 = float(np.clip(R0, 5.0e4, 2.0e5))

    def residual(p):
        return _predict_n(n, p[0], p[1], p[2]) - y

    p0 = np.array([R0, 0.5, 0.0], dtype=float)
    try:
        sol = least_squares(
            residual,
            p0,
            bounds=(
                np.array([1.0e4, -10.0, -100.0]),
                np.array([3.0e5, 10.0, 100.0]),
            ),
            x_scale=np.array([1.1e5, 1.0, 1.0]),
            max_nfev=1500,
        )
        if np.all(np.isfinite(sol.x)):
            return {
                "R": float(sol.x[0]),
                "delta": float(sol.x[1]),
                "alpha": float(sol.x[2]),
            }
    except Exception:
        pass

    return {"R": R0, "delta": 0.5, "alpha": 0.0}

def predict(X, R, delta, alpha):
    return _predict_n(X[:, 0], R, delta, alpha)