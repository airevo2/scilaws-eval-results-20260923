"""Compact red-giant large-separation scaling law with temperature and evolutionary-phase corrections."""
import numpy as np

USED_INPUTS = ["nu_max", "Teff", "phase"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    nu_max = X[:, 0]
    teff = X[:, 1]
    phase = X[:, 2]
    phase_factor = 1.0 + 0.375 * phase - 0.25 * phase * (phase - 1.0)
    scaled_frequency = nu_max * (teff / 4800.0) ** 0.75 * phase_factor
    return 0.3552 * scaled_frequency ** 0.6429