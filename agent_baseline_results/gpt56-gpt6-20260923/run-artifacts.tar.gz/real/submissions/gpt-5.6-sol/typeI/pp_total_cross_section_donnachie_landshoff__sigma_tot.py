"""Donachie–Landshoff-type two-power fit for the proton-proton total cross-section."""
import numpy as np

USED_INPUTS = ["s"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    s = X[:, 0]
    return 22.36411139 * s**0.07501361 + 38.72164517 * s**(-0.38309596)