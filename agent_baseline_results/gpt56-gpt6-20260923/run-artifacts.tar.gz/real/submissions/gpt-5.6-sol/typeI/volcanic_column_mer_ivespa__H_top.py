"""Power-law fit in log space for eruption-column height versus mass eruption rate."""
import numpy as np

USED_INPUTS = ["MER_kg_per_s"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    mer = np.maximum(X[:, 0], 1e-12)
    return 0.8950 * mer ** 0.15626