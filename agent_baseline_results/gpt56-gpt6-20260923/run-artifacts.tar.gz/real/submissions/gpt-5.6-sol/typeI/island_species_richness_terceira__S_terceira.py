"""Ridge-regularized linear model using disturbance, altitude, and precipitation."""
import numpy as np

USED_INPUTS = ["d", "h", "p"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    d = (X[:, 0] - 45.0) / 30.0
    h = (X[:, 1] - 400.0) / 300.0
    p = (X[:, 2] - 2200.0) / 800.0
    return 2.24706 - 2.02227 * d + 1.93767 * h - 0.88001 * p