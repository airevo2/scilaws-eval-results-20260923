"""Logarithmic morphometric predictor rounded to the source dataset's 0.5 m depth grid."""
import numpy as np

USED_INPUTS = ["A_s_km2", "Z_max_m"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    area = np.maximum(X[:, 0], 0.0)
    depth = np.maximum(X[:, 1], 0.0)
    estimate = 3.1583013665551327 + 1.0081142468426223 * (
        np.log1p(area) + np.log(np.maximum(depth, 1e-12))
    )
    return np.minimum(np.round(estimate * 2.0) / 2.0, depth)