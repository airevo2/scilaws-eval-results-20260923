"""Pythagorean-style win percentage with a scoring-environment adjustment."""
import numpy as np

USED_INPUTS = ["R", "RA", "G"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    R = X[:, 0]
    RA = X[:, 1]
    G = X[:, 2]
    log_ratio = np.log(R / RA)
    exponent = 1.84723799 + 0.38199705 * np.log((R + RA) / (9.0 * G))
    z = np.clip(exponent * log_ratio, -40.0, 40.0)
    return 1.0 / (1.0 + np.exp(-z))