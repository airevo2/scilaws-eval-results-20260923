"""Relative-humidity cloud fraction with condensate enhancement."""
import numpy as np

USED_INPUTS = ["q_c", "q_i", "RH", "T", "p", "q_v", "z_g", "dz_RH"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    qc = np.maximum(X[:, 0], 0.0)
    qi = np.maximum(X[:, 1], 0.0)
    rh = np.clip(X[:, 2], 0.0, 1.0)
    t = X[:, 3]
    p = np.maximum(X[:, 4], 1.0)
    qv = np.maximum(X[:, 5], 0.0)
    z = np.maximum(X[:, 6], 0.0)
    drh = X[:, 7]

    rh_term = 1.0 - np.sqrt(np.maximum(1.0 - rh, 0.0))
    condensate = 1.0 - np.exp(-4200.0 * (qc + qi))
    cold = 1.0 / (1.0 + np.exp((t - 258.0) / 7.0))
    humidity_gradient = np.clip(-180.0 * drh, 0.0, 0.35)
    pressure_factor = np.clip((p / 101325.0) ** 0.08, 0.65, 1.15)
    height_factor = 0.85 + 0.15 * np.exp(-z / 12000.0)
    vapor_factor = np.clip(1.0 + 8.0 * qv, 1.0, 1.16)

    raw = (0.78 * rh_term + 0.30 * condensate +
           0.10 * cold * condensate + humidity_gradient)
    return np.clip(raw * pressure_factor * height_factor * vapor_factor, 0.0, 1.0)