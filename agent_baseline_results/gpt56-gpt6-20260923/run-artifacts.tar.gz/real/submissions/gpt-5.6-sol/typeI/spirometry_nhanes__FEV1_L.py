"""Age-height interaction model fitted to adult-women spirometry data."""
import numpy as np

USED_INPUTS = ["age", "height_cm"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    age = X[:, 0]
    height_cm = X[:, 1]
    return (2.76796910
            - 0.0264525026 * (age - 45.0)
            + 0.0334746628 * (height_cm - 162.0)
            - 0.000282864399 * (age - 45.0) * (height_cm - 162.0))