"""Empirical flat-plate collector efficiency model using reduced-temperature loss and inlet-temperature interaction."""
import numpy as np

USED_INPUTS = ["G_W_m2", "T_in_C", "T_amb_C"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    G = X[:, 0]
    T_in = X[:, 1]
    T_amb = X[:, 2]
    reduced_temperature = (T_in - T_amb) / G
    return 0.7090648 + 0.08853641 * reduced_temperature - 0.05554554 * T_in * reduced_temperature