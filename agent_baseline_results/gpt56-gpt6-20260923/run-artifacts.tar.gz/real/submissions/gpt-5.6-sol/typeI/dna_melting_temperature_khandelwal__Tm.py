"""Physically motivated DNA melting-temperature model with strength, length, salt, and concentration effects."""
import numpy as np

USED_INPUTS = ["E", "N", "salt_M", "dna_conc_M"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    E = X[:, 0]
    N = X[:, 1]
    salt_M = X[:, 2]
    dna_conc_M = X[:, 3]
    return 16.6 * np.log10(salt_M) + 11.73 * E + 0.41 * np.log10(dna_conc_M) - 66.0 / N + 9.2