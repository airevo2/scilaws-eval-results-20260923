"""Saturating exponential density-flow law with a corridor-specific flow offset."""
import numpy as np

USED_INPUTS = ["k_veh_km_lane", "corridor"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    k = X[:, 0]
    corridor = X[:, 1]
    return 37.94229 * k * np.exp(-k / 214.15832) + 430.03719 - 560.44424 * corridor