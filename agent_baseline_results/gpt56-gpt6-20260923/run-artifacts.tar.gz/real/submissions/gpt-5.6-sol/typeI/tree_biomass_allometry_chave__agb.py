"""Robust two-constant multiplicative allometry fitted in log space with LAD loss."""
import numpy as np

USED_INPUTS = ["wood_density", "diameter_cm", "height_m"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    wood_density = X[:, 0]
    diameter_cm = X[:, 1]
    height_m = X[:, 2]
    return 0.05933036798 * (wood_density * diameter_cm**2 * height_m)**0.9836803099