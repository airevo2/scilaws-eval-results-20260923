"""Linearized genetic differentiation increases approximately linearly with log geographic distance."""
import numpy as np

USED_INPUTS = ["log_distance_km"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    x = X[:, 0]
    return np.maximum(0.0, 0.045 * x - 0.235)