"""Physically motivated bulk-modulus estimate combining inverse atomic volume and density."""
import numpy as np

USED_INPUTS = ["V_atomic_A3", "density_g_cm3"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    volume = X[:, 0]
    density = X[:, 1]
    return 1600.0 / volume + 8.0 * density