"""Positive power-law ejecta model fitted for SMAPE, using binding energy, compactness, total mass, asymmetry, and tidal deformability."""
import numpy as np

USED_INPUTS = ["M1", "M2", "Mb1", "Mb2", "C1", "C2", "q", "Lambda_tilde"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    M1 = np.maximum(X[:, 0], 1.0e-8)
    M2 = np.maximum(X[:, 1], 1.0e-8)
    Mb1 = np.maximum(X[:, 2], 1.0e-8)
    Mb2 = np.maximum(X[:, 3], 1.0e-8)
    C1 = np.maximum(X[:, 4], 1.0e-8)
    C2 = np.maximum(X[:, 5], 1.0e-8)
    q = np.clip(X[:, 6], 1.0e-6, 1.0)
    lam = np.maximum(X[:, 7], 1.0e-8)

    binding = np.maximum((Mb1 - M1) + (Mb2 - M2), 1.0e-6)
    compactness = np.maximum(C1 + C2, 1.0e-6)
    total_mass = np.maximum(M1 + M2, 1.0e-6)
    asymmetry = np.maximum(1.0 - q + 0.02, 1.0e-6)

    log_mej = (
        2.99999997
        - 0.09510199 * np.log(binding)
        + 7.99999974 * np.log(compactness)
        - 6.36025573 * np.log(total_mass)
        + 0.20042764 * np.log(asymmetry)
        + 0.94618599 * np.log(lam)
    )
    return np.exp(np.clip(log_mej, -30.0, 2.0))