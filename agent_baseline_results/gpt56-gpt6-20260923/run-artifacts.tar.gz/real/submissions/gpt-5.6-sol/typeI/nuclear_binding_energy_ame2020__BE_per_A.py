"""Extended semi-empirical binding-energy-per-nucleon law with surface, Coulomb, asymmetry, pairing, and proton-fraction corrections."""
import numpy as np

USED_INPUTS = ["Z", "N", "A", "NZ_diff", "pair"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    Z = X[:, 0]
    A = X[:, 2]
    d = X[:, 3]
    pair = X[:, 4]
    return (
        16.4281518624
        - 24.3165057299 * A ** (-1.0 / 3.0)
        + 12.9886417138 * A ** (-2.0 / 3.0)
        - 0.9030384038 * Z * (Z - 1.0) * A ** (-4.0 / 3.0)
        + 1.7202769204 * Z * (Z - 1.0) * A ** (-5.0 / 3.0)
        - 21.0596244837 * d ** 2 / A ** 2
        + 22.1066497982 * d ** 4 / A ** 4
        + 8.7029253674 * pair * A ** (-3.0 / 2.0)
        - 1.6523544552 * Z / A
    )