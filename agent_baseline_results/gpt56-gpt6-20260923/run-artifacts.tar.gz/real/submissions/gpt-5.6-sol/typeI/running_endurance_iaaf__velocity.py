"""Sex-specific power-law model for average running velocity versus race distance."""
import numpy as np

USED_INPUTS = ["distance_m", "sex_M"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    d = np.maximum(X[:, 0], 1.0)
    s = X[:, 1]
    return np.exp(2.34212656 + 0.11102973*s - 0.0643185991*np.log(d) - 0.0004310219*s*np.log(d))