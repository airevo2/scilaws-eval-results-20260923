"""Constrained log-linear gravity model fitted by least squares."""
import numpy as np

USED_INPUTS = ["log_gdp_o", "log_gdp_d", "log_dist", "contig", "comlang_off", "col_dep_ever", "fta_wto"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    return (
        -18.64760647
        + 1.02737785 * (X[:, 0] + X[:, 1])
        - 1.15272596 * X[:, 2]
        + 1.03741932 * X[:, 3]
        + 0.95689271 * X[:, 4]
        + 0.95844090 * X[:, 5]
        + 0.76160872 * X[:, 6]
    )