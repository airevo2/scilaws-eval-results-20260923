"""Compact nonlinear empirical scaling for T Tauri accretion luminosity."""
import numpy as np

USED_INPUTS = ["logL_star", "M_star_B98", "R_star"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    logL_star = X[:, 0]
    logM_star = np.log10(np.maximum(X[:, 1], 1e-12))
    logR_star = np.log10(np.maximum(X[:, 2], 1e-12))
    return (
        -4.19328
        - 4.10173 * logL_star
        + 3.28205 * logM_star
        + 6.21547 * logR_star
        + 2.85159 * np.tanh(logL_star + 0.8)
    )