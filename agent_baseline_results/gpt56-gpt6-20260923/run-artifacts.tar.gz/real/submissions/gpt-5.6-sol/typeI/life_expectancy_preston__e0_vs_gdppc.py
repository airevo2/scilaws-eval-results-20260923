"""Three-parameter saturating power-law model for life expectancy versus income."""
import numpy as np

USED_INPUTS = ["gdppc"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    gdppc = np.maximum(X[:, 0], 1e-12)
    return 75.1673010 - 749.684002 * gdppc ** (-0.738619662)