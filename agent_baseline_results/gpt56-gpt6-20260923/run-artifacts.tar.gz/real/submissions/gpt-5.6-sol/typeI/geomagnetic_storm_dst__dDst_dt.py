"""Piecewise-linear geomagnetic tendency model using Dst, electric-field driving, pressure, IMF polarity, and density."""
import numpy as np

USED_INPUTS = ["Dst", "Ey", "P_dyn", "Bz_GSM", "n_sw"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    dst = X[:, 0]
    ey = X[:, 1]
    pressure = X[:, 2]
    bz = X[:, 3]
    density = X[:, 4]
    return (
        0.424738597099004
        - 0.052840840939422 * dst
        - 0.624906877778596 * ey
        - 0.587585562349618 * pressure
        - 0.132226117685231 * np.maximum(bz, 0.0)
        + 0.718469083513385 * np.minimum(bz, 0.0)
        + 0.153457774179139 * density
    )