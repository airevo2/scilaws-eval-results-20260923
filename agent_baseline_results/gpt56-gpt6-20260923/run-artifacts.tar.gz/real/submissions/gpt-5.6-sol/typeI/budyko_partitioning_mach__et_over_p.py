"""Fu/Budyko water-energy balance curve with the standard Fu exponent."""
import numpy as np

USED_INPUTS = ["pet_over_p"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    phi = np.maximum(X[:, 0], 0.0)
    return 1.0 + phi - (1.0 + phi ** 2.6) ** (1.0 / 2.6)