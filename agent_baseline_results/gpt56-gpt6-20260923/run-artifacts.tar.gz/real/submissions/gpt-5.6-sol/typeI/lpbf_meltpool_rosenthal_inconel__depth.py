"""Physically motivated log-linear melt-pool depth model."""
import numpy as np

USED_INPUTS = ["laser_power_W", "scan_velocity_mm_per_s", "beam_diameter_um"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    P = X[:, 0]
    V = X[:, 1]
    D = X[:, 2]
    return (1316.79735299
            + 176.44711780 * np.log(P)
            - 165.53400049 * np.log(V)
            - 244.73029271 * np.log(D))