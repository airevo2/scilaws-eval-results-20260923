"""Linear black-hole mass scaling with stellar velocity dispersion, spheroid mass, and pseudobulge offset."""
import numpy as np

USED_INPUTS = ["sigma0", "log_M_sph", "Pseudobulge"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    sigma0 = X[:, 0]
    log_M_sph = X[:, 1]
    pseudobulge = X[:, 2]
    return 4.1064 + 2.6833 * np.log10(sigma0 / 200.0) + 0.4050 * log_M_sph - 0.6788 * pseudobulge