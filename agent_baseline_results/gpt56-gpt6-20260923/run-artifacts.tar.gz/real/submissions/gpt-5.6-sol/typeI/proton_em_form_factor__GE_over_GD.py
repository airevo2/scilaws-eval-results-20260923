"""Smooth positive exponential fit for the proton electric-to-dipole form-factor ratio."""
import numpy as np

USED_INPUTS = ["Q2_GeV2"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    q2 = X[:, 0]
    return 0.98336169 * np.exp(-0.02127435 * q2 - 0.03059259 * q2 * q2)