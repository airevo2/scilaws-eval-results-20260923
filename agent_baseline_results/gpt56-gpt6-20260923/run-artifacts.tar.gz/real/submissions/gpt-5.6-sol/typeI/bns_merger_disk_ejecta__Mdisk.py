"""Six-term positive disk-mass regression using tidal deformability, compactness, mass ratio, and total mass."""
import numpy as np

USED_INPUTS = ["M1", "M2", "C1", "C2", "q", "Lambda_tilde"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    m1 = X[:, 0]
    m2 = X[:, 1]
    c1 = X[:, 2]
    c2 = X[:, 3]
    q = X[:, 4]
    lam = X[:, 5]
    y = (
        0.16450340
        + 0.26910926 * (lam / 1000.0)
        - 0.01523685 / c1
        - 0.02747546 / c2
        + 0.22093456 * (1.0 - q)
        + 0.02123644 * (m1 + m2 - 2.8)
    )
    return np.maximum(1.0e-7, y)