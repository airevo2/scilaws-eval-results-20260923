"""Main-stem length as terminal segment plus a sublinear scaling of upstream drainage area excluding the outlet segment catchment."""
import numpy as np

USED_INPUTS = ["upland_area_skm", "catch_area_skm", "segment_length_km"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    A = X[:, 0]
    Ac = X[:, 1]
    Ls = X[:, 2]
    upstream_area = np.maximum(A - Ac, 1e-6)
    return Ls + 1.21263762 * upstream_area ** 0.59117317