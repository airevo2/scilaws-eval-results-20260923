"""Linear flux relation using BCAH98 stellar mass and the detection-limit flag."""
import numpy as np

USED_INPUTS = ["log10_M_star_BCAH98", "is_F_uplim"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    mass = X[:, 0]
    uplim = X[:, 1]
    return -1.6739 + 0.3 * mass - 0.5182 * uplim