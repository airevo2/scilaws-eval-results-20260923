"""Continuous broken power law for rocky planets, Neptune-like objects, and gas giants."""
import numpy as np

USED_INPUTS = ["M"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    M = np.maximum(X[:, 0], 1.0e-12)
    b1 = 2.0584
    b2 = 132.17
    return (
        1.008105
        * M**0.28167555
        * np.where(M > b1, (M / b1)**(0.58895561 - 0.28167555), 1.0)
        * np.where(M > b2, (M / b2)**(-0.04394598 - 0.58895561), 1.0)
    )