"""Power-law energy-consumption model with population, economic, demographic, urbanization, density, and climate effects."""
import numpy as np

USED_INPUTS = ["GDP", "TP", "AP", "DP", "UR", "AT"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    GDP = np.maximum(X[:, 0], 1e-12)
    TP = np.maximum(X[:, 1], 1e-12)
    AP = np.maximum(X[:, 2], 1e-12)
    DP = np.maximum(X[:, 3], 1e-12)
    UR = np.maximum(X[:, 4], 1e-12)
    AT = X[:, 5]
    log_ec = (
        -10.1
        + 0.75 * np.log(GDP)
        + 0.95 * np.log(TP)
        + 0.20 * np.log(AP)
        + 0.05 * np.log(DP)
        + 0.25 * np.log(UR)
        + 0.002 * (AT - 18.0) ** 2
    )
    return np.exp(log_ec)