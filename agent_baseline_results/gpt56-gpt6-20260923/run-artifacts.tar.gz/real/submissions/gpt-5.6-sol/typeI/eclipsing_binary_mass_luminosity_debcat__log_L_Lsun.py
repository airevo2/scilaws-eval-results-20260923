"""Mass-only cubic main-sequence luminosity relation with physically sensible low- and high-mass extrapolation."""
import numpy as np

USED_INPUTS = ["log_M_Msun"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    m = X[:, 0]
    cubic = 0.05554 + 4.46971685*m - 0.07183557*m*m - 0.42233029*m*m*m
    low = 2.05365*m - 0.97927
    high = 2.94097*m + 0.99609
    return np.where(m < -0.3, low, np.where(m > 0.9, high, cubic))