"""Kleiber allometric law for mammalian basal metabolic rate."""
import numpy as np

USED_INPUTS = ["body_mass_g"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    body_mass_g = X[:, 0]
    return 0.75 * np.log10(body_mass_g) - 1.72