"""Fu-Budyko water-balance runoff curve."""
import numpy as np

USED_INPUTS = ["p_mean", "pet_mean"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    p = X[:, 0]
    pet = X[:, 1]
    phi = pet / np.maximum(p, 1e-12)
    omega = 2.6
    q = p * (np.power(1.0 + np.power(phi, omega), 1.0 / omega) - phi)
    return np.clip(q, 0.0, p)