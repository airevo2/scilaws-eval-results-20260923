"""Z-band luminosity and broad g-i color stellar-mass relation."""
import numpy as np

USED_INPUTS = ["g", "i", "z_mag", "DM"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    g = X[:, 0]
    i = X[:, 1]
    z_mag = X[:, 2]
    DM = X[:, 3]
    return 0.4 * (DM - z_mag) + 1.18861 + 0.54863 * (g - i)