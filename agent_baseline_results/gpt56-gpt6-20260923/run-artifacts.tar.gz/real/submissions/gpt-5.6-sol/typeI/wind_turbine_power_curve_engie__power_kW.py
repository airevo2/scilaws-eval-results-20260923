"""Saturating generalized power law fitted to the turbine power curve."""
import numpy as np

USED_INPUTS = ["wind_speed_mps"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    v = np.maximum(X[:, 0], 0.0)
    u = np.maximum(v - 3.09377914, 0.0)
    return 2083.05663 * (1.0 - np.exp(-0.0154686537 * u**2.20692905))