"""Logarithmic tidal-coupling law with total-mass and secondary-mass corrections."""
import numpy as np

USED_INPUTS = ["kap2t", "mass", "m2"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    k = X[:, 0]
    M = X[:, 1]
    m2 = X[:, 2]
    z = np.log(k / 100.0)
    dm = M - 2.7
    d2 = m2 - 1.35
    return (
        3.10058
        - 0.95355 * z
        - 0.62524 * dm
        + 0.01522 * d2
        - 0.34259 * z * dm
        - 0.55615 * z * d2
        - 2.53006 * dm * d2
    )