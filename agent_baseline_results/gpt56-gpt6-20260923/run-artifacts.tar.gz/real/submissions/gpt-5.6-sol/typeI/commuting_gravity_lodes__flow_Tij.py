"""Opportunity-constrained commuting flow model with distance decay."""
import numpy as np

USED_INPUTS = ["m_i", "m_j", "d_ij_km", "s_ij"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    m_i = X[:, 0]
    m_j = X[:, 1]
    d = X[:, 2]
    s = X[:, 3]
    flow = 0.2093 * m_i * m_j / (d * (m_i + m_j + s) ** 0.69664)
    return np.log10(1.0 + flow)