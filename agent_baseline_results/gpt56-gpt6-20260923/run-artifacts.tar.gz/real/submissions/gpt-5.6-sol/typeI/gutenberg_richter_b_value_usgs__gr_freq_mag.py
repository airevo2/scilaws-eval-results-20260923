"""Gutenberg–Richter cumulative magnitude-frequency relation."""
import numpy as np

USED_INPUTS = ["M_threshold"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    magnitude = X[:, 0]
    return 8.04042105263158 - 0.998081052631579 * magnitude