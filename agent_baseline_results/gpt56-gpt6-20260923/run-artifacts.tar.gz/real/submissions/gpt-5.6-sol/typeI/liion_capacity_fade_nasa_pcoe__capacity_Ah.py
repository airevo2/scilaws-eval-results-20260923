"""Exponential capacity-fade model fitted to cycle-level capacity means."""
import numpy as np

USED_INPUTS = ["cycle_index"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    k = np.maximum(X[:, 0], 1.0)
    return 1.18650884 + 0.92684477 * np.exp(-0.01160071 * k)