"""Temperature-dependent cubic Cauchy dispersion fit for ethylene glycol."""
import numpy as np

USED_INPUTS = ["lambda_um", "temperature_C"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    lam = X[:, 0]
    temp = X[:, 1]
    u = 1.0 / (lam * lam) - 3.0
    t = (temp - 20.0) / 20.0
    return (
        1.43242745
        + 0.00379055385 * u
        - 0.000172833490 * u * u
        + 0.0000445842085 * u * u * u
        - 0.00563804763 * t
        - 0.0000849324121 * t * u
        - 0.0000381600671 * t * u * u
        + 0.0000116825704 * t * u * u * u
    )