"""Three-factor linear hardness model using lattice distortion, electronic concentration, and mixing enthalpy."""
import numpy as np

USED_INPUTS = ["delta", "VEC", "dHmix"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    delta = X[:, 0]
    vec = X[:, 1]
    dhmix = X[:, 2]
    return 50.0 * delta + 40.0 * vec - 2.0 * dhmix