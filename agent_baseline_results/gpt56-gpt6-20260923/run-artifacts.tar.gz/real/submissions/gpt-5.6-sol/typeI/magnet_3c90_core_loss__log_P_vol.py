"""Four-parameter logarithmic Steinmetz-style model with combined temperature and waveform correction."""
import numpy as np

USED_INPUTS = ["f_Hz", "B_peak_T", "T_C", "waveform_id"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    f = X[:, 0]
    B = X[:, 1]
    T = X[:, 2]
    w = X[:, 3]
    correction = (T - 25.0) + 23.19271784 * (w == 1) - 65.11273233 * (w == 2)
    return (-4.43158118
            + 1.76528910 * np.log10(f)
            + 2.47429303 * np.log10(B)
            - 0.00300062046 * correction)