"""Linear Gaia Wesenheit period-luminosity-metallicity relation."""
import numpy as np

USED_INPUTS = ["log_P", "feh"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    log_P = X[:, 0]
    feh = X[:, 1]
    return -2.82 * log_P - 1.20 + 0.20 * feh