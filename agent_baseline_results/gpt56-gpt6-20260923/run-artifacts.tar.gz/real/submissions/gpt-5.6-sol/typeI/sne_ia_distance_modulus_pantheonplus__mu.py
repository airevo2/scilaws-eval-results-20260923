"""Flat Lambda-CDM luminosity-distance relation for standardized Type Ia supernovae."""
import numpy as np

USED_INPUTS = ["z_hd"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    z = np.asarray(X[:, 0], dtype=float)
    nodes, weights = np.polynomial.legendre.leggauss(64)
    a = 0.5 * (nodes + 1.0)
    w = 0.5 * weights
    zz = z[:, None] * a[None, :]
    integrand = 1.0 / np.sqrt(0.3 * (1.0 + zz) ** 3 + 0.7)
    integral = z * np.sum(integrand * w[None, :], axis=1)
    d_l_mpc = (299792.458 / 70.0) * (1.0 + z) * integral
    return 5.0 * np.log10(d_l_mpc) + 25.0