"""Power-law cumulative near-Earth-object size-frequency distribution in absolute magnitude."""
import numpy as np

USED_INPUTS = ["H_upper"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    H = X[:, 0]
    return np.power(10.0, 0.35 * H - 3.43)