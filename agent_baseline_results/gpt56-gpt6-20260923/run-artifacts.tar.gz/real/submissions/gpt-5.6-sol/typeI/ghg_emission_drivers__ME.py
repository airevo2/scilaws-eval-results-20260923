"""Direct-SMAPE log-linear methane emissions model."""
import numpy as np

USED_INPUTS = ["GDP", "TP", "AP", "DP", "UR", "AT"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    gdp = np.maximum(X[:, 0], 1e-12)
    population = np.maximum(X[:, 1], 1e-12)
    active_population = np.maximum(X[:, 2], 1e-12)
    density = np.maximum(X[:, 3], 1e-12)
    urbanization = np.maximum(X[:, 4], 1e-12)
    temperature = X[:, 5]
    return np.exp(
        3.166400
        + 0.153692 * np.log(gdp)
        + 1.032675 * np.log(population)
        + 0.000348 * active_population
        - 0.333471 * np.log(density)
        + 0.002310 * urbanization
        - 0.001066 * temperature
    )