"""WGS84 Somigliana normal-gravity formula."""
import numpy as np

USED_INPUTS = ["latitude"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    latitude = X[:, 0]
    s = np.sin(np.deg2rad(latitude))
    s2 = s * s
    return 9.7803253359 * (1.0 + 0.00193185265241 * s2) / np.sqrt(1.0 - 0.00669437999013 * s2)