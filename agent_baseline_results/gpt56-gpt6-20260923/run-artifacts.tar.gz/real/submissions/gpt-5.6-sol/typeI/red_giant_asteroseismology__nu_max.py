"""Empirical power-law relation between nu_max and the independently measured large frequency separation."""
import numpy as np

USED_INPUTS = ["delta_nu"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    delta_nu = X[:, 0]
    return np.exp(1.645545 + 1.359233 * np.log(delta_nu))