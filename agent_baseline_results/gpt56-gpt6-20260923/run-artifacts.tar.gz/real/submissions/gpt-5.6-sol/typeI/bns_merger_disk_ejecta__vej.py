"""Published Dietrich–Ujevic dynamical-ejecta velocity law, expressed in units of c."""
import numpy as np

USED_INPUTS = ["q", "C1", "C2"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    q = X[:, 0]
    c1 = X[:, 1]
    c2 = X[:, 2]
    return -0.309 * (q * (1.0 - 1.879 * c1) + (1.0 / q) * (1.0 - 1.879 * c2)) + 0.657