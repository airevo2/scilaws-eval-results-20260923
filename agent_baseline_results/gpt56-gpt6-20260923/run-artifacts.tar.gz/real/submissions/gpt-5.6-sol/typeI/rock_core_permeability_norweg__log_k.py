"""Monotonic saturating permeability-porosity relationship."""
import numpy as np

USED_INPUTS = ["phi"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    phi = X[:, 0]
    return -2.21782555 + 20.95647773 * phi / (1.0 + phi)