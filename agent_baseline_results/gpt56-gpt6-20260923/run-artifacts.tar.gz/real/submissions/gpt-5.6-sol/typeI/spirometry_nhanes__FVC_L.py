"""Quadratic adolescent male FVC model using height and age."""
import numpy as np

USED_INPUTS = ["age", "height_cm"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    age = X[:, 0]
    height_cm = X[:, 1]
    return (-0.408116481
            - 0.163969180 * age
            + 0.00929235945 * age * age
            + 0.000181969911 * height_cm * height_cm)