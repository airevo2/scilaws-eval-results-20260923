"""Allometric cruising-speed model using mass and wing loading."""
import numpy as np

USED_INPUTS = ["mass_kg", "wing_area_m2"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    mass_kg = X[:, 0]
    wing_area_m2 = X[:, 1]
    return 12.5 * (mass_kg / np.sqrt(wing_area_m2)) ** 0.17