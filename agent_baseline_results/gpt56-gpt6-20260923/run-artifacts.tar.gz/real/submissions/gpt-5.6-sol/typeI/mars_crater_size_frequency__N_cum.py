"""Cubic log-log fit for cumulative Martian crater density."""
import numpy as np

USED_INPUTS = ["D_lower_km"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    x = np.log10(np.maximum(X[:, 0], 1e-12))
    log_n = (-2.56908592
             - 1.90854969 * x
             + 1.23369969 * x**2
             - 0.52843732 * x**3)
    return 10.0**log_n