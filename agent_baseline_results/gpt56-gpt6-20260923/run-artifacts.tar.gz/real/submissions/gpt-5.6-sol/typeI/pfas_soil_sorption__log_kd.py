"""Compact soil-partitioning fit using fluorinated-chain descriptors and organic carbon."""
import numpy as np

USED_INPUTS = ["MW", "C_num", "F_num", "log_S", "log_Kow", "pH", "CEC", "Sand", "Silt", "Clay", "foc"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    MW = X[:, 0]
    C_num = X[:, 1]
    F_num = X[:, 2]
    log_S = X[:, 3]
    log_Kow = X[:, 4]
    pH = X[:, 5]
    CEC = X[:, 6]
    Sand = X[:, 7]
    Silt = X[:, 8]
    Clay = X[:, 9]
    foc = X[:, 10]
    z = (
        0.35 * np.log10(MW)
        + 0.35 * C_num
        + 0.15 * F_num
        - 0.35 * log_S
        + 0.35 * log_Kow
        - 0.08 * pH
        + 0.01 * np.log10(CEC + 1.0)
        - 0.005 * Sand
        + 0.005 * Silt
        + 0.005 * Clay
        + np.log10(foc)
    )
    return 0.35 * z + 0.25