"""Signed Butler-Volmer fit with pressure, temperature, and acid-concentration dependence."""
import numpy as np

USED_INPUTS = ["eta", "T", "P_H2", "c_acid"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    eta = X[:, 0]
    T = X[:, 1]
    p_h2 = X[:, 2]
    c_acid = X[:, 3]
    j0 = (
        0.0028
        * np.sqrt(np.maximum(p_h2, 1e-12))
        * np.power(np.maximum(c_acid / 0.5, 1e-12), 0.25)
        * np.exp(1745.0 * (1.0 / 298.15 - 1.0 / T))
    )
    z = 96485.33212 * eta / (8.314462618 * T)
    return j0 * (np.exp(0.5 * z) - np.exp(-0.5 * z))