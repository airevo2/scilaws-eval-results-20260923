"""Quadratic mass--SFR surface fit for gas-phase oxygen abundance."""
import numpy as np

USED_INPUTS = ["log_Mstar", "log_SFR"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    m = X[:, 0] - 10.0
    s = X[:, 1]
    return (
        8.91519973
        + 0.21790252 * m
        + 0.04856537 * s
        - 0.15605279 * m * m
        + 0.11972777 * m * s
        - 0.04388599 * s * s
    )