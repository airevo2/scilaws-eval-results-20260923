"""Parker-spiral fit for the daily mean azimuthal IMF component."""
import numpy as np

USED_INPUTS = ["B_r_nT", "v_sw_km_s", "r_AU"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    return -400.0 * X[:, 2] * X[:, 0] / X[:, 1]