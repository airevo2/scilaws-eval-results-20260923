"""Three-term gradient closure for zonal subgrid-scale eddy momentum forcing."""
import numpy as np

USED_INPUTS = ["d_zeta2_dx", "d_zetaD_dx", "d_zetaDtilde_dy"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    d_zeta2_dx = X[:, 0]
    d_zetaD_dx = X[:, 1]
    d_zetaDtilde_dy = X[:, 2]
    return (-6.77444283e8 * d_zeta2_dx
            + 1.06409009e9 * d_zetaD_dx
            - 1.12014764e9 * d_zetaDtilde_dy)