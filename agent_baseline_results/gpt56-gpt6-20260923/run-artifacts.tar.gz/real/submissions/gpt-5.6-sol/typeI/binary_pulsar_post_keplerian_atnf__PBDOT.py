"""Peters–Mathews quadrupole prediction for gravitational-wave orbital-period decay."""
import numpy as np

USED_INPUTS = ["Pb", "e"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    Pb = X[:, 0]
    e = X[:, 1]
    eccentricity_factor = (
        1.0 + (73.0 / 24.0) * e**2 + (37.0 / 96.0) * e**4
    ) / np.maximum(1.0 - e**2, 1e-15)**3.5
    return -3.030706704616816e-14 * Pb**(-5.0 / 3.0) * eccentricity_factor