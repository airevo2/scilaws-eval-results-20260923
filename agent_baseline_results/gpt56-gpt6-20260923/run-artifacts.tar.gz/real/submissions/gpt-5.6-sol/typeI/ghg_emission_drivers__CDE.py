"""SMAPE-optimized log-linear power-law model for national CO2 emissions."""
import numpy as np

USED_INPUTS = ["GDP", "TP", "AP", "DP", "UR", "AT"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    gdp = np.maximum(X[:, 0], 1e-12)
    population = np.maximum(X[:, 1], 1e-12)
    active_share = np.maximum(X[:, 2], 1e-12)
    density = np.maximum(X[:, 3], 1e-12)
    urban_share = np.maximum(X[:, 4], 1e-12)
    temperature = X[:, 5]
    log_prediction = (
        -11.19563265
        + 0.80148729 * np.log(gdp)
        + 1.03457160 * np.log(population)
        + 2.59527651 * np.log(active_share)
        - 0.07334486 * np.log(density)
        + 0.46145975 * np.log(urban_share)
        - 0.03250131 * temperature
    )
    return np.exp(log_prediction)