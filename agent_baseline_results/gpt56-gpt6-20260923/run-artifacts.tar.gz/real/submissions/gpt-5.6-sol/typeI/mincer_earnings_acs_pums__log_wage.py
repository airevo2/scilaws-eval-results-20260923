"""Mincer earnings equation with linear schooling and concave potential experience."""
import numpy as np

USED_INPUTS = ["SCHL_years", "exp"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    s = X[:, 0]
    x = X[:, 1]
    return 8.9 + 0.105 * s + 0.043 * x - 0.00075 * x * x