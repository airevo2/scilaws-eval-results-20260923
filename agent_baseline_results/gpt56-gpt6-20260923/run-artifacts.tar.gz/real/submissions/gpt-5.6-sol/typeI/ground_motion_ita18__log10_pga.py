"""GMPE-style log10 PGA using hypocentral distance attenuation, magnitude-distance coupling, EC8 site terms, and faulting terms."""
import numpy as np

USED_INPUTS = ["Mw", "R_km", "depth_km", "ec8_A", "ec8_B", "ec8_C", "ec8_D", "ec8_E", "sof_NF", "sof_TF", "sof_SS"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    mw = X[:, 0]
    r = X[:, 1]
    depth = X[:, 2]
    log_distance = np.log10(np.sqrt(r * r + depth * depth))
    return (
        0.0143
        + 0.9475 * mw
        - 1.0254 * log_distance
        + 0.0423 * mw * log_distance
        - 0.4274 * X[:, 3]
        - 0.2516 * X[:, 4]
        - 0.1256 * X[:, 5]
        - 0.2332 * X[:, 6]
        - 0.0596 * X[:, 7]
        - 0.0338 * X[:, 8]
        - 0.0442 * X[:, 9]
        - 0.0096 * X[:, 10]
    )