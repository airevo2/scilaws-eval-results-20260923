"""Subexponential growth: tumor volume to the two-thirds power increases linearly with time."""
import numpy as np
from scipy.optimize import least_squares

USED_INPUTS = ["time_day"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {
    "a": {"init": None},
    "b": {"init": None},
}

def fit(X_fit, y_fit):
    t = np.asarray(X_fit[:, 0], dtype=float)
    y = np.asarray(y_fit, dtype=float)
    valid = np.isfinite(t) & np.isfinite(y)
    t, y = t[valid], np.maximum(y[valid], 0.0)

    if len(t) == 0:
        return {"a": 0.0, "b": 0.0}
    if len(t) < 2 or np.ptp(t) == 0:
        return {"a": float(np.mean(y) ** (2.0 / 3.0)), "b": 0.0}

    origin = float(np.min(t))
    time_scale = float(np.ptp(t))
    volume_scale = max(float(np.max(y)), np.finfo(float).tiny)
    u = (t - origin) / time_scale
    v = y / volume_scale

    design = np.column_stack((np.ones(len(u)), u))
    initial = np.linalg.lstsq(design, v ** (2.0 / 3.0), rcond=None)[0]
    initial[1] = max(float(initial[1]), 0.0)
    if initial[1] == 0:
        initial[0] = float(np.mean(v) ** (2.0 / 3.0))

    def residual(p):
        return np.maximum(p[0] + p[1] * u, 0.0) ** (3.0 / 2.0) - v

    def jacobian(p):
        q = (3.0 / 2.0) * np.sqrt(np.maximum(p[0] + p[1] * u, 0.0))
        return np.column_stack((q, q * u))

    p = initial
    try:
        result = least_squares(
            residual,
            initial,
            jac=jacobian,
            bounds=([-np.inf, 0.0], [np.inf, np.inf]),
            max_nfev=300,
        )
        if np.all(np.isfinite(result.x)):
            p = result.x
    except Exception:
        pass

    root_scale = volume_scale ** (2.0 / 3.0)
    b = root_scale * p[1] / time_scale
    a = root_scale * p[0] - b * origin
    return {"a": float(a), "b": float(b)}

def predict(X, a, b):
    t = np.asarray(X[:, 0], dtype=float)
    return np.maximum(a + b * t, 0.0) ** (3.0 / 2.0)