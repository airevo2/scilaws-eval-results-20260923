"""Weir discharge scales as crest width times head to the 3/2 power, with a saturating head-to-height correction."""
import numpy as np
from scipy.optimize import nnls

USED_INPUTS = ["h_m", "p_m", "b_m"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {
    "a": {"init": None},
    "c": {"init": None},
}

def _design(X):
    X = np.asarray(X, dtype=float)
    h = np.maximum(X[:, 0], 0.0)
    p = np.maximum(X[:, 1], np.finfo(float).tiny)
    b = np.maximum(X[:, 2], 0.0)
    scale = b * h**1.5
    return np.column_stack((scale, scale * h / (h + p)))

def fit(X_fit, y_fit):
    A = _design(X_fit)
    y = np.asarray(y_fit, dtype=float).reshape(-1)
    valid = np.isfinite(y) & np.all(np.isfinite(A), axis=1)
    A, y = A[valid], y[valid]
    if len(y) == 0 or not np.any(A[:, 0] > 0):
        return {"a": 0.0, "c": 0.0}

    norm = np.linalg.norm(A, axis=0)
    norm = np.where(norm > 0, norm, 1.0)
    try:
        coefficients, _ = nnls(A / norm, y)
        coefficients = coefficients / norm
        return {"a": float(coefficients[0]), "c": float(coefficients[1])}
    except Exception:
        s = A[:, 0]
        a = max(float(np.dot(s, y) / np.dot(s, s)), 0.0)
        return {"a": a, "c": 0.0}

def predict(X, a, c):
    return _design(X) @ np.array([a, c], dtype=float)