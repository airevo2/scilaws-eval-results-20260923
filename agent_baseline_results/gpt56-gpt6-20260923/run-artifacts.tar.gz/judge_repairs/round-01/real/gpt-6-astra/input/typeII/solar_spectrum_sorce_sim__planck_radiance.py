"""Planck spectral radiance with one effective temperature fitted per cluster."""
import numpy as np
from scipy.optimize import minimize_scalar

USED_INPUTS = ["wavelength_nm"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {"temperature_K": {"init": None}}

def predict(X, temperature_K):
    wavelength_m = np.maximum(np.asarray(X, dtype=float)[:, 0], 1e-12) * 1e-9
    # Exact SI physical constants: Planck constant, light speed, Boltzmann constant.
    h = 6.62607015e-34
    c = 299792458.0
    k_B = 1.380649e-23
    exponent = h * c / (wavelength_m * k_B * temperature_K)
    return (
        2.0 * h * c**2
        / wavelength_m**5
        / np.expm1(np.minimum(exponent, 700.0))
        * 1e-9
    )

def fit(X_fit, y_fit):
    X = np.asarray(X_fit, dtype=float)
    y = np.asarray(y_fit, dtype=float).reshape(-1)
    valid = np.isfinite(X[:, 0]) & (X[:, 0] > 0) & np.isfinite(y)
    X, y = X[valid], y[valid]
    if len(y) == 0:
        return {"temperature_K": 5772.0}

    result = minimize_scalar(
        lambda temperature: float(np.mean((predict(X, temperature) - y)**2)),
        bounds=(1000.0, 20000.0),
        method="bounded",
        options={"xatol": 1e-5, "maxiter": 200},
    )
    temperature = float(result.x) if np.isfinite(result.fun) else 5772.0
    return {"temperature_K": temperature}