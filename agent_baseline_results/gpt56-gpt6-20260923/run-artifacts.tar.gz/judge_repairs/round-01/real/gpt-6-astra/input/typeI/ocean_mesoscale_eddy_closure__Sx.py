"""Quadratic stress-gradient closure with linear backscatter and velocity–shear coupling."""
import numpy as np

USED_INPUTS = ["u", "v", "zeta", "D", "d_zeta2_dx", "d_zetaD_dx", "d_zetaDtilde_dy"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    u = X[:, 0]
    v = X[:, 1]
    zeta = X[:, 2]
    D = X[:, 3]
    stress_gradient = -X[:, 4] + 2 * (X[:, 5] - X[:, 6])
    return (
        6.15282423e8 * stress_gradient
        + 1.68318936e-7 * u
        + 0.178896540 * v * (D + zeta)
    )