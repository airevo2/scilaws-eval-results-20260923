"""Saturating Weibull allometry with a single locally fitted height scale."""
import numpy as np

USED_INPUTS = ["DBH_cm"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {"height_scale": {"init": None}}

def _shape(X):
    diameter = np.maximum(np.asarray(X, dtype=float)[:, 0], 0.0)
    return -np.expm1(-(diameter / 64.0) ** 0.72)

def fit(X_fit, y_fit):
    shape = _shape(X_fit)
    height = np.asarray(y_fit, dtype=float).reshape(-1)
    valid = np.isfinite(shape) & np.isfinite(height)
    shape, height = shape[valid], height[valid]
    denominator = float(np.dot(shape, shape))
    if denominator > 0.0:
        scale = max(0.0, float(np.dot(shape, height) / denominator))
    else:
        scale = 0.0
    return {"height_scale": scale}

def predict(X, height_scale):
    return height_scale * _shape(X)