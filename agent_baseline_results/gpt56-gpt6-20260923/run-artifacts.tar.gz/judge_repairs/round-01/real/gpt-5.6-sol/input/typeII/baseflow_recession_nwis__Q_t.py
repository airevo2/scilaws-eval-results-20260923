"""Two-parameter nonlinear reservoir recession: dQ/dt = -a Q^c."""
import numpy as np
from scipy.optimize import least_squares

USED_INPUTS = ["t", "Q_0"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {"a": {"init": None}, "c": {"init": None}}

def _predict_form(t, q0, a, c):
    t = np.maximum(np.asarray(t, dtype=float), 0.0)
    q0 = np.maximum(np.asarray(q0, dtype=float), 1e-30)
    if abs(c - 1.0) < 1e-5:
        out = q0 * np.exp(-a * t)
    else:
        inside = q0 ** (1.0 - c) - (1.0 - c) * a * t
        out = np.maximum(inside, 1e-30) ** (1.0 / (1.0 - c))
    return np.maximum(out, 1e-30)

def fit(X_fit, y_fit):
    t = np.maximum(np.asarray(X_fit[:, 0], dtype=float), 0.0)
    q0 = np.maximum(np.asarray(X_fit[:, 1], dtype=float), 1e-30)
    y = np.maximum(np.asarray(y_fit, dtype=float), 1e-30)

    scale = max(float(np.median(y)), 1.0)
    a0 = 0.1 / max(float(np.median(t[t > 0])) if np.any(t > 0) else 1.0, 1.0)
    c0 = 1.3

    def residual(z):
        a = np.exp(z[0]) / scale ** (np.exp(z[1]) - 1.0)
        c = np.exp(z[1])
        yp = _predict_form(t, q0, a, c)
        return np.log(yp) - np.log(y)

    try:
        result = least_squares(
            residual,
            [np.log(a0), np.log(c0)],
            bounds=([-20.0, np.log(0.2)], [10.0, np.log(5.0)]),
            max_nfev=300,
        )
        c_hat = float(np.exp(result.x[1]))
        a_hat = float(np.exp(result.x[0]) / scale ** (c_hat - 1.0))
        if not np.isfinite(a_hat) or not np.isfinite(c_hat) or a_hat <= 0:
            raise ValueError
        return {"a": a_hat, "c": c_hat}
    except Exception:
        return {"a": float(a0), "c": float(c0)}

def predict(X, a, c):
    return _predict_form(X[:, 0], X[:, 1], float(a), float(c))