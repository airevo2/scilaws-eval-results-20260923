"""Physical 1/v background plus the dominant Au-197 resonance."""
import numpy as np

USED_INPUTS = ["E_eV"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    E = np.maximum(X[:, 0], 1e-30)
    background = 10.0 ** (1.197 - 0.5 * np.log10(E))
    resonance = 10.0 ** 4.48 / (1.0 + ((E - 4.906) / 0.106) ** 2)
    return np.log10(background + resonance)